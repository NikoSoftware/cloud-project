package com.smzc.taxi.centorcontrol.web.interceptor;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.centorcontrol.web.annotation.Anonymous;
import com.smzc.taxi.centorcontrol.web.annotation.OpenAPI;
import com.smzc.taxi.centorcontrol.web.context.ActionContext;
import com.smzc.taxi.centorcontrol.web.enums.ErrCodes;
import com.smzc.taxi.common.consts.RedisConst;
import com.smzc.taxi.common.utils.AesUtil;
import com.smzc.taxi.common.utils.MD5Utils;
import com.smzc.taxi.service.centorcontrol.enums.CentorControlProducer;
import com.smzc.taxi.service.centorcontrol.exception.SignException;
import com.smzc.taxi.service.portal.bean.SystemConfigurationVo;
import com.smzc.taxi.service.portal.enums.SystemConfigurationEnum;
import com.smzc.taxi.service.portal.service.ISystemConfigurationFacade;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.util.Asserts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.HandlerMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 鉴权拦截器
 *
 * @author : lufy
 * @version v1.0
 * @date : 2019/5/29
 */
@Slf4j
@Component
public class AuthHandlerInterceptor implements HandlerInterceptor {

    @Autowired
    private RedisTemplate redisTemplate;

    @Reference
    private ISystemConfigurationFacade systemConfigurationFacade;

    private static final String TIMESTAMP = "timestamp";
    private static final String SIGN = "sign";
    private static final String CHANNEL = "channel";
    // 开放接口超时时间，毫秒
    private static final Integer OPEN_API_TIMESTAMP_EXPIRE = 1000*60*3;

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        try {
            if (!(handler instanceof HandlerMethod)) {
                throw new Exception("错误的鉴权请求");
            }

            HandlerMethod handlerMethod = (HandlerMethod) handler;
            Method method = handlerMethod.getMethod();
            Asserts.notNull(method, request.getMethod() + " [handler method is null");

            if (null != method.getAnnotation(OpenAPI.class)) {
                checkOpenApi(request);
                return true;
            }

            if (null != method.getAnnotation(Anonymous.class)) {
                return true;
            }
            String token = request.getHeader("token");
            String tokenAsed = decryptToken(token);
            String[] data = tokenAsed.split(":");
            if (data.length < 3) {
                throw new SignException("鉴权失败!");
            }
            Long diverId = Long.valueOf(data[0]);
            check(RedisConst.CENTORCONTROL_DRIVER_TOKEN + diverId, token);
            Long vehicleId = Long.valueOf(data[1]);
            check(RedisConst.CENTORCONTROL_VEHICLE_TOKEN + vehicleId, token);
            ActionContext context = ActionContext.getContext();
            context.setDriverId(diverId);
            context.setVehicle(vehicleId);
            return true;
        } catch (Exception ex) {
            log.error("验签失败",ex);
            throw new SignException(ex.getMessage());
        }

    }

    private String decryptToken(String token) throws Exception {
        String tokenAesd = AesUtil.aesDecrypt(token);
        Assert.isTrue(!StringUtils.isEmpty(tokenAesd), "鉴权信息缺失!");
        return tokenAesd;
    }

    private void check(String redisKey, String token) {
        String cacheToken = (String)redisTemplate.opsForValue().get(redisKey);

        Assert.hasLength(cacheToken, "token失效");
        Assert.isTrue(token.equals(cacheToken), "token失效");
        redisTemplate.opsForValue().set(redisKey, token, 3, TimeUnit.MINUTES);
    }

    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable Exception ex) throws Exception {
        ActionContext.setContext(null);
    }

    private void checkOpenApi(HttpServletRequest request) throws SignException {
        Map pathVariables = (Map) request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        String channel = (String) pathVariables.get(CHANNEL);
        String timestamp = request.getHeader(TIMESTAMP);
        String sign = request.getHeader(SIGN);

        CentorControlProducer p = CentorControlProducer.indexOf(channel);
        if (p == CentorControlProducer.NULL) {
            throw new SignException("还没有实现平台接口:"+channel);
        }

        if (StringUtils.isEmpty(timestamp)) {
            throw new SignException("鉴权失败，没有找到header[timestamp]");
        }

        // 时间戳
        if (System.currentTimeMillis() - Long.valueOf(timestamp) >= OPEN_API_TIMESTAMP_EXPIRE) {
            throw new SignException("鉴权失败，时间戳超时");
        }

        if (StringUtils.isEmpty(sign)) {
            throw new SignException("鉴权失败，没有找到header[sign]");
        }

        List<SystemConfigurationVo> systemConfigurationVos = systemConfigurationFacade.getCentorCopntrolConfigsByKeyAndGroup(SystemConfigurationEnum.TAXI_CENTOL_CONTROL_THIRD_PARTY_TOEKN, channel);
        if (null == systemConfigurationVos || systemConfigurationVos.isEmpty()) {
            throw new SignException("token 未找到，请联系管理员");
        }
        String smSign = MD5Utils.getMD5(new String(timestamp + channel + systemConfigurationVos.get(0).getConfigValue()).getBytes());
        log.debug("recv timestamp:{},channel:{},sign:{}; sm sign:{}", timestamp, channel, sign, smSign);
        if (smSign.equals(sign)) {
            return;
        }
        throw new SignException("鉴权失败");
    }
}
