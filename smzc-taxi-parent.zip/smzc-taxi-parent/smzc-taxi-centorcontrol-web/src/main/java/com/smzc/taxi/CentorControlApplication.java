package com.smzc.taxi;

import com.alibaba.dubbo.spring.boot.annotation.EnableDubboConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;

@EnableDubboConfiguration
@SpringBootApplication(exclude= {DataSourceAutoConfiguration.class,MongoAutoConfiguration.class})
//@ImportResource(value={"classpath*:dubbo-*.xml"})
public class CentorControlApplication {

	public static void main(String[] args) {
		SpringApplication.run(CentorControlApplication.class, args);
	}

}
