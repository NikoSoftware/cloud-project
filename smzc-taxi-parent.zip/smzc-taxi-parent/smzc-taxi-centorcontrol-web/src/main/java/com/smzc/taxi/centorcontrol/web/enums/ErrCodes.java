package com.smzc.taxi.centorcontrol.web.enums;

/**
 * Created by smzcck on 2019/6/5.
 */
public enum ErrCodes {

    NO_CHANNEL(2001,"没有找到相应的平台"),
    SIGN_ERROR(2002,"验签失败"),
    LOGIN_ERROR(2003,"打卡失败");

    private Integer code;
    private String message;

    ErrCodes(int code, String msg) {
        this.code = code;
        this.message = msg;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getMessage() {
        return this.message;
    }
}
