package com.smzc.taxi.centorcontrol.web.configuration;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.ValueFilter;
import com.alibaba.fastjson.support.config.FastJsonConfig;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;

@Configuration
public class FastJsonConvertersConfiguration {

	@Bean
	public HttpMessageConverters fastJsonHttpMessageConverters() {

		FastJsonHttpMessageConverter fastConverter = new FastJsonHttpMessageConverter();
		FastJsonConfig config = new FastJsonConfig();
		/*config.setSerializeFilters(new ValueFilter() {

			@Override
			public Object process(Object object, String name, Object value) {
				return Optional.ofNullable(value).orElse("");
			}
		});*/
		config.setSerializerFeatures(SerializerFeature.WriteBigDecimalAsPlain, SerializerFeature.WriteDateUseDateFormat,
				SerializerFeature.WriteNullListAsEmpty,
				SerializerFeature.WriteNullNumberAsZero, SerializerFeature.WriteNullBooleanAsFalse);
		fastConverter.setFastJsonConfig(config);
		fastConverter.setSupportedMediaTypes(
				Stream.of(MediaType.APPLICATION_JSON_UTF8, MediaType.TEXT_HTML).collect(Collectors.toList()));
		HttpMessageConverter<?> converter = fastConverter;
		return new HttpMessageConverters(converter);
	}

}
