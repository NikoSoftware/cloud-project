package com.smzc.taxi.centorcontrol.web.interceptor;

import com.smzc.taxi.boot.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 统一处理异常
 *
 * @author : lufy
 * @version v1.0
 * @date : 2019/5/30
 */
@Slf4j
@ControllerAdvice
public class ErrorResponseAdvice {

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseBody
    public Response handleEx(IllegalArgumentException ex){
        return Response.instance().message(ex.getMessage()).code(-1).build();
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public Response handleEx(MethodArgumentNotValidException ex){
        BindingResult bindingResult = ex.getBindingResult();
        StringBuilder stringBuilder = new StringBuilder();
        for (int i =0;i<bindingResult.getFieldErrorCount();i++){
            if(i>0){
                stringBuilder.append(";");
            }
            FieldError fieldError = bindingResult.getFieldErrors().get(i);
            stringBuilder.append(fieldError.getField());
            stringBuilder.append(":");
            stringBuilder.append(fieldError.getDefaultMessage());
        }
        return Response.instance().message(stringBuilder.toString()).code(-1).build();
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public Response handleEx(Exception ex){
        return Response.instance().message(ex.getMessage()).code(-1).build();
    }
}
