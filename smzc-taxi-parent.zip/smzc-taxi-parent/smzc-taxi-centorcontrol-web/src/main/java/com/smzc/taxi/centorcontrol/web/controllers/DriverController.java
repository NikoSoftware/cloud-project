package com.smzc.taxi.centorcontrol.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.HttpResponseEnum;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.centorcontrol.web.annotation.Anonymous;
import com.smzc.taxi.centorcontrol.web.configuration.NormalConfig;
import com.smzc.taxi.centorcontrol.web.context.ActionContext;
import com.smzc.taxi.service.centorcontrol.bean.CentorControlDeviceVo;
import com.smzc.taxi.service.centorcontrol.bean.DriverSignInResultVo;
import com.smzc.taxi.service.centorcontrol.service.CentorcontrolDriverFacade;
import com.smzc.taxi.service.centorcontrol.service.ICenterControlDeviceFacade;
import com.smzc.taxi.service.driver.bean.DriverTakenRecordResultVo;
import com.smzc.taxi.service.driver.bean.DriverTakenReqVo;
import com.smzc.taxi.service.driver.service.IDriverFacade;
import com.smzc.taxi.service.driver.service.IDriverTakenRecordFacade;
import com.smzc.taxi.service.order.emun.PlatformType;
import io.swagger.annotations.*;
import org.apache.http.util.Asserts;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;

/**
 * @Desc : .....
 * @Author : lufy
 * @Date : 2019/5/13 15:53
 */
@Api(tags="中控司机Controller" )
@RestController
@RequestMapping(NormalConfig.apiPrefix + "/driver")
public class DriverController {

    @Reference
    private IDriverFacade driverFacade;

    @Reference
    private CentorcontrolDriverFacade centorcontrolDriverFacade;

    @Reference
    private IDriverTakenRecordFacade driverTakenRecordFacade;

    @Reference
    private ICenterControlDeviceFacade centerControlDeviceFacade;

    /**
     * @Description: 根据司机Id获取司机状态
     * @Param: []
     * @Author: Yb.Z
     * @create: 2019/05/30 11:35
     * @return: com.smzc.taxi.boot.response.Response<com.smzc.taxi.service.driver.bean.DriverVehicleInfoProvideVo>
     */
    @ApiOperation(value = "获取司机状态", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @PostMapping("/workState")
    public Response<DriverSignInResultVo> getDriverWorkState() {
        Long driverId = ActionContext.getContext().getDriverId();
        Asserts.notNull(driverId, "获取司机ID信息错误");
        return Response.instance().data(centorcontrolDriverFacade.getDriverVehicleInfoByDriverId(driverId));
    }

    /**
     * @Description: 开始听单/停止听单
     * @Param: [driverTakenReqVo]
     * @Author: Yb.Z
     * @create: 2019/05/30 16:43
     * @return: com.smzc.taxi.boot.response.Response<com.smzc.taxi.service.driver.bean.DriverTakenRecordResultVo>
     */
    @ApiOperation(value = "开始/停止听单", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @PostMapping(value = "/takenOrder")
    public Response<DriverTakenRecordResultVo> addTakeOrderRecode(@RequestBody @Validated DriverTakenReqVo driverTakenReqVo) throws Exception {
        // 司机参数获取
        Long driverId = ActionContext.getContext().getDriverId();
        Asserts.notNull(driverId, "获取司机ID信息错误");
        driverTakenReqVo.setSource(PlatformType.ANDROID_PAD.getIndex());
        driverTakenReqVo.setDriverId(driverId);
        return Response.instance().data(driverTakenRecordFacade.addDriverTakenRecord(driverTakenReqVo));
    }

    @ApiOperation(value = "中控打卡登录", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @Anonymous
    @GetMapping("/signIn")
    public Response<DriverSignInResultVo> login(@ApiParam("加密格式 ServiceSuperviseCardNo:VehicleNo") String content) {
        DriverSignInResultVo result = centorcontrolDriverFacade.login(content);
        return  Response.instance().data(result);
    }

    /**
    * @Description: 更新中控设备pushId
    * @Param: [centorControlDeviceVo]
    * @Author: Yb.Z
    * @create: 2019/06/03 10:32
    * @return: com.smzc.taxi.boot.response.Response*/
    @Deprecated
    @PostMapping("/updateDriverDeviceInfo")
    @ApiOperation(value = "更新中控设备pushId", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "更新成功"))
    public Response updateDriverDeviceInfo(@RequestBody @NotNull CentorControlDeviceVo centorControlDeviceVo) {
        Integer result = centerControlDeviceFacade.updateCenterControlDeviceInfo(centorControlDeviceVo);
        if (result == null || result < 1) {
            return Response.instance().code(HttpResponseEnum.DRIVER_UPDATE_DEVICE_INFO_FAIL.code).message("更新中控设备信息失败").build();
        } else {
            return Response.instance().build();
        }
    }
}
