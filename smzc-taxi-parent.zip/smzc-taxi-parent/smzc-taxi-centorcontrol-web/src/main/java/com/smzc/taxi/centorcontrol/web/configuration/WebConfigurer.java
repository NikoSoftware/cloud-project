package com.smzc.taxi.centorcontrol.web.configuration;

import com.smzc.taxi.centorcontrol.web.interceptor.AuthHandlerInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.servlet.MultipartConfigElement;

/**
 * .....
 *
 * @author : lufy
 * @version v1.0
 * @date : 2019/5/29
 */
@Configuration
public class WebConfigurer implements WebMvcConfigurer {
    @Autowired
    private AuthHandlerInterceptor authHandlerInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authHandlerInterceptor).addPathPatterns("/**")
                .excludePathPatterns("/swagger-ui.html/**",
                        "/swagger-resources/**",
                        "/webjars/**",
                        "/error",
                        "/",
                        "/csrf");
    }
}
