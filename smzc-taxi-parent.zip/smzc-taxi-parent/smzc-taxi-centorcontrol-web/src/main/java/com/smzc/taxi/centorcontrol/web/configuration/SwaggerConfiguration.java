package com.smzc.taxi.centorcontrol.web.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import io.swagger.annotations.ApiOperation;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@Profile({"devel","test"})
@ComponentScan(basePackages = {"com.smzc.taxi.centorcontrol.web.controllers"})
public class SwaggerConfiguration {

	
	@Bean
	public Docket orderExtendApi() {

		return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).groupName("中控端").select()
				.apis(RequestHandlerSelectors.basePackage("com.smzc.taxi.centorcontrol.web.controllers"))
				.paths(PathSelectors.any()).build().pathMapping("/");
	
	}

	private ApiInfo apiInfo() {
		springfox.documentation.service.Contact contact = new Contact("caik", null, "caikun@sm.vvip-u.com");
		ApiInfoBuilder apiInfoBuilder = new ApiInfoBuilder();
		apiInfoBuilder.title("神马专车出租车");
		apiInfoBuilder.description("神马专车出租车-中控相关接口");
		apiInfoBuilder.version("1.0.0");
		apiInfoBuilder.contact(contact);
		return apiInfoBuilder.build();

	}
}
