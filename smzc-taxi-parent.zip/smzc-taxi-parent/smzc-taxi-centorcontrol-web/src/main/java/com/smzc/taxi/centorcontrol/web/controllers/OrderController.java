package com.smzc.taxi.centorcontrol.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.centorcontrol.web.annotation.Anonymous;
import com.smzc.taxi.centorcontrol.web.configuration.NormalConfig;
import com.smzc.taxi.centorcontrol.web.context.ActionContext;
import com.smzc.taxi.service.centorcontrol.bean.RealOrderRequestVo;
import com.smzc.taxi.service.centorcontrol.bean.RequstWaitReceiveVo;
import com.smzc.taxi.service.centorcontrol.bean.VirtualOrderRequestVo;
import com.smzc.taxi.service.centorcontrol.service.CentorControlOrderFacade;
import com.smzc.taxi.service.driver.bean.basic.BaseRespVo;
import com.smzc.taxi.service.driver.bean.order.*;
import com.smzc.taxi.service.order.bean.vo.OrderVirtualVo;
import com.smzc.taxi.service.order.emun.PlatformType;
import com.smzc.taxi.service.order.facade.IDriverOrderFacade;
import com.smzc.taxi.service.portal.bean.SystemConfigurationVo;
import com.smzc.taxi.service.portal.enums.SystemConfigurationEnum;
import com.smzc.taxi.service.portal.service.ISystemConfigurationFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 *  订单控制相关Controller
 * Created by smzcck on 2019/5/28.
 */
@Api(tags="中控订单Controller" )
@RestController
@RequestMapping(NormalConfig.apiPrefix+"/order")
@Slf4j
public class OrderController {

    @Reference
    CentorControlOrderFacade centorControlOrderFacade;

    @Reference
    private ISystemConfigurationFacade systemConfigurationFacade;

    // add by zyb 2019-06-24
    @Reference
    private IDriverOrderFacade driverOrderFacade;

    @PostMapping("/queryDrivingOrderId")
    @ApiOperation(value = "获取司机服务中订单", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<String> queryDrivingOrderId()throws Exception{
        String result = centorControlOrderFacade.queryDrivingOrderId(ActionContext.getContext().getDriverId());
        return Response.instance().data(result);
    }

    @PostMapping("/queryDriverReceivedOrderList")
    @ApiOperation(value = "司机已确认订单列表", notes = "toke参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<List<OrderDetailVo>> queryDriverReceivedOrderList() throws Exception{
        List<OrderDetailVo> result = centorControlOrderFacade.queryDriverReceivedOrderList(ActionContext.getContext().getDriverId());
        return Response.instance().data(result);
    }

    @PostMapping("/queryDriverReceivedOrderDetail")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "司机订单详情", notes = "json格式输入参数，有返回数据")
    public Response<OrderDetailRespVo> queryDriverReceivedOrderDetail(@RequestBody @Validated OrderIdReqVo vo) throws Exception{
        OrderDetailRespVo result = centorControlOrderFacade.queryDriverReceivedOrderDetail(vo.getOrderId(), ActionContext.getContext().getDriverId());
        // 把订单金额赋值给支付金额，主要是用于前端展示。前端目前修改比较麻烦，后期还是希望前端能直接使用订单金额。
        result.setPayAmount(result.getOrderAmount());
        return Response.instance().code(result.getRespCode().getCode()).message(result.getRespCode().getMessage()).data(result);
    }

    @PostMapping("/driverArriveStartPoint")
    @ApiOperation(value = "司机订单到达上车点", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<OrderDetailRespVo> driverArriveStartPoint(@RequestBody @Validated RealOrderRequestVo vo)throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PAD);
        vo.setDriverId(ActionContext.getContext().getDriverId());
        vo.setVehicleId(ActionContext.getContext().getVehicle());
        OrderDetailRespVo result = centorControlOrderFacade.driverArriveStartPoint(vo);
        return Response.instance().code(result.getRespCode().getCode()).message(result.getRespCode().getMessage()).data(result);
    }

    @Deprecated
    @PostMapping("/driverReceivePassenger")
    @ApiOperation(value = "司机订单乘客已上车", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<OrderDetailRespVo> driverReceivePassenger(@RequestBody @Validated RealOrderRequestVo vo)throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PAD);
        vo.setDriverId(ActionContext.getContext().getDriverId());
        vo.setVehicleId(ActionContext.getContext().getVehicle());
        OrderDetailRespVo result = centorControlOrderFacade.driverReceivePassenger(vo);
        return Response.instance().code(result.getRespCode().getCode()).message(result.getRespCode().getMessage()).data(result);
    }

    @PostMapping("/driverArriveEndPoint")
    @ApiOperation(value = "司机订单乘客已下车", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<OrderDetailRespVo> driverArriveEndPoint(@RequestBody @Validated RealOrderRequestVo vo)throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PAD);
        vo.setDriverId(ActionContext.getContext().getDriverId());
        vo.setVehicleId(ActionContext.getContext().getVehicle());
        OrderDetailRespVo result = centorControlOrderFacade.driverArriveEndPoint(vo);
        return Response.instance().code(result.getRespCode().getCode()).message(result.getRespCode().getMessage()).data(result);
    }

    @PostMapping("/addPayOffDetails")
    @ApiOperation(value = "司机订单发起收款", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<BaseRespVo> addPayOffDetails(@RequestBody @Validated OrderPayOffDetailsVo vo)throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PAD);
        BaseRespVo result = centorControlOrderFacade.addPayOffDetails(vo, ActionContext.getContext().getDriverId());
        return Response.instance().code(result.getCode()).message(result.getMessage()).build();
    }

    @PostMapping("/addPayoff")
    @ApiOperation(value = "司机订单收取车费", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<BaseRespVo> addPayoff(@RequestBody @Validated OrderIdReqVo vo)throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PAD);
        BaseRespVo result = centorControlOrderFacade.addPayoff(vo, ActionContext.getContext().getDriverId());
        return Response.instance().code(result.getCode()).message(result.getMessage()).build();
    }

    @PostMapping("/getWaitReceive")
    @ApiOperation(value = "司机待接订单列表", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<List<OrderListRespVo>> getWaitReceive(@RequestBody @Validated RequstWaitReceiveVo vo)throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PAD);
        vo.setDriverId(ActionContext.getContext().getDriverId());
        vo.setVehicleId(ActionContext.getContext().getVehicle());
        List<OrderListRespVo> result = centorControlOrderFacade.getWaitReceive(vo);
        return Response.instance().data(result);
    }

    @PostMapping("/robOrder")
    @ApiOperation(value = "司机抢单", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<BaseRespVo> robOrder(@RequestBody @Validated RealOrderRequestVo vo) throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PAD);
        vo.setDriverId(ActionContext.getContext().getDriverId());
        vo.setVehicleId(ActionContext.getContext().getVehicle());
        BaseRespVo result = centorControlOrderFacade.robOrder(vo);
        return Response.instance().code(result.getCode()).message(result.getMessage()).build();
    }

    @PostMapping("/chargeMeter")
    @ApiOperation(value = "开始打表-埋表", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<OrderDetailRespVo> chargeMeter(@RequestBody @Validated RealOrderRequestVo vo) {
        vo.setPlatformType(PlatformType.ANDROID_PAD);
        vo.setDriverId(ActionContext.getContext().getDriverId());
        vo.setVehicleId(ActionContext.getContext().getVehicle());
        OrderDetailRespVo result = centorControlOrderFacade.chargeMeter(vo);
        return Response.instance().code(result.getRespCode().getCode()).message(result.getRespCode().getMessage()).data(result);
    }

    @Deprecated
    @PostMapping("/shutMeter")
    @ApiOperation(value = "结束打表-抬表", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<OrderDetailRespVo> shutMeter(@RequestBody @Validated RealOrderRequestVo vo) {
        vo.setPlatformType(PlatformType.ANDROID_PAD);
        vo.setDriverId(ActionContext.getContext().getDriverId());
        vo.setVehicleId(ActionContext.getContext().getVehicle());
        OrderDetailRespVo result = centorControlOrderFacade.shutMeter(vo);
        return Response.instance().code(result.getRespCode().getCode()).message(result.getRespCode().getMessage()).data(result);
    }

    /**
     * @Description: 前端拉取虚拟订单
     * @param vo
     * @Author: Yb.Z
     * @create: 2019/06/21 15:52
     * @return: com.smzc.taxi.boot.response.Response<java.util.List<com.smzc.taxi.service.driver.bean.order.OrderListRespVo>>
     */
    @PostMapping("/getVirtualOrders")
    @ApiOperation(value = "虚拟订单列表", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @Anonymous
    public Response<List<OrderListRespVo>> getVirtualOrders(@RequestBody @Validated VirtualOrderRequestVo vo){
        if (log.isDebugEnabled()) {
            log.debug("拉取虚拟订单，参数VirtualOrderRequestVo ： {}",vo);
        }

        // 虚拟订单开关
        boolean virtualOpen = false;
        try {
            List<SystemConfigurationVo> scVoList = systemConfigurationFacade.getValueByKey(SystemConfigurationEnum.ORDER_VIRTUAL_OPEN, vo.getAreaCode());
            if (!CollectionUtils.isEmpty(scVoList)) {
                virtualOpen = Boolean.parseBoolean(scVoList.get(0).getConfigValue());
            }
        } catch (Exception e) {
            log.error("查询是否开启虚拟订单失败：", e);
        }
        if (!virtualOpen) {
            return Response.instance().data(Collections.EMPTY_LIST);
        }

        List<OrderVirtualVo> orderVirtual = driverOrderFacade.getOrderVirtual(vo.getVehicleId(), vo.getAreaCode());
        List<OrderListRespVo> virtualOrder = orderVirtual.parallelStream().map(orderVirtualVo -> {
            OrderListRespVo orderListRespVo = new OrderListRespVo();
            orderListRespVo.setFromAddress(orderVirtualVo.getPlanFromAddress());
            orderListRespVo.setToAddress(orderVirtualVo.getPlanToAddress());
            orderListRespVo.setTotalDistance(orderVirtualVo.getPredictMileage());
            return orderListRespVo;
        }).collect(Collectors.toList());
        if (log.isDebugEnabled()) {
            log.debug("调用司机端接口得到的返回值是:{}",orderVirtual);
            log.debug("转换后的list是:{}",virtualOrder);
        }
        return Response.instance().data(virtualOrder);
    }

    /* 中控端 暂时不需要这些接口
    @PostMapping("/queryNotes")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "查询司机某个订单的留言", notes = "json格式输入参数，查询全部，有返回数据")
    public Response<List<DriverOrderNoteRespVo>> queryNotes(@RequestBody @Validated OrderIdReqVo query){
        List<DriverOrderNoteRespVo> result = driverOrdersFacade.queryNotes(query);
        return Response.instance().data(result);
    }

    @PostMapping("/readNote")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "司机读取留言", notes = "json格式输入参数，无返回数据")
    public Response readNote(@RequestBody @Validated DriverOrderNoteReadReqVo req){
        driverOrdersFacade.readNote(req);
        return Response.instance().build();
    }

    @PostMapping("/addCallingRecord")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "添加拨打电话记录", notes = "json格式输入参数，无返回数据")
    public Response addCallingRecord(@RequestBody @Validated OrderIdReqVo req){
        driverOrdersFacade.addCallingRecord(req);
        return Response.instance().build();
    }

    @PostMapping("/smsNotifyPassenger")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "司机到达上车地点短信通知司机", notes = "json格式输入参数，无返回数据")
    public Response smsNotifyPassenger(@RequestBody @Validated OrderIdReqVo req){
        driverOrdersFacade.smsNotifyPassenger(req);
        return Response.instance().build();
    }

    @PostMapping("/queryPassengerLastPosition")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "乘客最新位置获取", notes = "json格式输入参数，有返回数据")
    public Response<DriverOrderPassengerPositionRespVo> queryPassengerLastPosition(@RequestBody @Validated OrderIdReqVo query){
        DriverOrderPassengerPositionRespVo result = driverOrdersFacade.queryPassengerLastPosition(query);
        return Response.instance().data(result);
    }

    @PostMapping("/queryPageHistoryOrders")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "司机历史订单查询", notes = "json格式输入参数，分页查询，有返回数据")
    public Response<PageInfo<DriverOrderHistoryRespVo>> queryPageHistoryOrders(@RequestBody @Validated DriverOrderHistoryQryVo query)throws Exception{
        query.setDriverId(ActionContext.getContext().getDriverId());
        PageInfo<DriverOrderHistoryRespVo> result = driverOrdersFacade.queryPageHistoryOrders(query);
        return Response.instance().data(result);
    }
    */

}
