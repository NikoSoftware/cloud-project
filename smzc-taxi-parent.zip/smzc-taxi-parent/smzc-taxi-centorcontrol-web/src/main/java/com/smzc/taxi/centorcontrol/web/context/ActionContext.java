package com.smzc.taxi.centorcontrol.web.context;

import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

/**
 * 线程局部存储信息
 */

public class ActionContext implements Serializable {

	private static final long serialVersionUID = 1L;

	private static ThreadLocal<WeakReference<ActionContext>> actionContext = ThreadLocal
			.withInitial(() -> new WeakReference<>(new ActionContext(new HashMap<>())));

	private final static String DRIVER = "DRIVER";
	private final static String VEHICLE = "VEHICLEID";

	private Map<String, Object> context;

	private ActionContext(Map<String, Object> context) {
		this.context = context;
	}

	public static void setContext(WeakReference<ActionContext> context) {
		actionContext.set(context);
	}

	public static ActionContext getContext() {
		if (actionContext.get() == null) {
			ActionContext context = new ActionContext(new HashMap<>());
			WeakReference<ActionContext> weakReference = new WeakReference<ActionContext>(context);
			actionContext.set(weakReference);
			return weakReference.get();
		} else
			return actionContext.get().get();
	}

	public Object get(String key) {
		return context.get(key);
	}

	public void put(String key, Object value) {
		context.put(key, value);
	}

	public void setDriverId(Long driverId){
		context.put(DRIVER, driverId);
	}
	public Long getDriverId(){
		return (Long)context.get(DRIVER);
	}
	public void setVehicle(Long vehicleId){
		context.put(VEHICLE, vehicleId);
	}
	public Long getVehicle(){
		return (Long)context.get(VEHICLE);
	}
}
