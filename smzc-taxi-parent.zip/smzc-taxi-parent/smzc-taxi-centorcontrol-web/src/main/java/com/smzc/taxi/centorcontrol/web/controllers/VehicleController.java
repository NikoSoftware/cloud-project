package com.smzc.taxi.centorcontrol.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSONObject;
import com.smzc.taxi.boot.mq.SmRocketMqTemplate;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.centorcontrol.web.annotation.Anonymous;
import com.smzc.taxi.centorcontrol.web.annotation.OpenAPI;
import com.smzc.taxi.centorcontrol.web.configuration.NormalConfig;
import com.smzc.taxi.centorcontrol.web.context.ActionContext;
import com.smzc.taxi.centorcontrol.web.enums.ErrCodes;
import com.smzc.taxi.common.utils.AesUtil;
import com.smzc.taxi.common.utils.MD5Utils;
import com.smzc.taxi.service.centorcontrol.bean.RequestSyncLocationVo;
import com.smzc.taxi.service.centorcontrol.bean.VehicleStartVo;
import com.smzc.taxi.service.centorcontrol.bean.VehicleStatusVo;
import com.smzc.taxi.service.centorcontrol.enums.CentorControlProducer;
import com.smzc.taxi.service.centorcontrol.exception.SignException;
import com.smzc.taxi.service.centorcontrol.service.ICenterControlDeviceMessagePushFacade;
import com.smzc.taxi.service.centorcontrol.service.CentorControlVehicleFacade;
import com.smzc.taxi.service.driver.bean.push.DriverMessageDualChannelVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.Random;

/**
 * Created by smzcck on 2019/5/25.
 */
@Slf4j
@Api(tags="中控车辆相关Controller" )
@RestController
@RequestMapping(NormalConfig.apiPrefix+"/vehicle")
public class VehicleController {

    @Reference
    CentorControlVehicleFacade vehicleFacade;

    @Reference
    private ICenterControlDeviceMessagePushFacade centerControlDeviceMessagePushFacade;

    @Resource
    SmRocketMqTemplate smRocketMqTemplate;

    private Random random = new Random();

    @Deprecated
    @ApiOperation(value = "启动时上传车辆信息", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @PostMapping("/{channel}/vehicleStart" )
    public Response vehicleStart(@PathVariable("channel")String channel, @RequestBody @Validated VehicleStartVo vehicleStartVo){
        CentorControlProducer p = CentorControlProducer.indexOf(channel);
        if (p == CentorControlProducer.NULL) {
            log.warn("还没有实现对应的平台接口:{}", channel);
            return Response.instance().code(ErrCodes.NO_CHANNEL.getCode()).message(ErrCodes.NO_CHANNEL.getMessage()).build();
        }
        vehicleStartVo.setProducer(p.getName());
        vehicleFacade.vehicleStart(vehicleStartVo);
        return Response.instance().build();
    }

    @OpenAPI
    @ApiOperation(value = "同步车辆位置", notes = "公共平台接口")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @PostMapping(value = "/{channel}/syncLocation")
    @ResponseBody
    public Response syncLocation(@PathVariable("channel")String channel, @RequestBody @Validated RequestSyncLocationVo location) throws Exception{
        CentorControlProducer p = CentorControlProducer.indexOf(channel);
        location.setChannel(p.getName());

        try {
            smRocketMqTemplate.asyncSend("sync_location", "sync_location_tag", location, new SendCallback() {
                @Override
                public void onSuccess(SendResult sendResult) {
                    log.debug("send mq Success channel:{}" ,channel);
                }

                @Override
                public void onException(Throwable throwable) {
                    log.error("发送GPS同步数据到MQ失败", throwable);
                }
            });
        }catch (Exception e) {
            log.error("发送GPS同步数据到MQ失败",e);
        }
        if (log.isDebugEnabled()){
            log.debug("recv channel:{} location:{}", p.getName(), JSONObject.toJSONString(location));
        }
        return Response.instance().build();
    }

    /**
     * @Description: 中控端拉取redis双通道消息
     * @Author: Yb.Z
     * @create: 2019/06/19 9:33
     * @return: com.smzc.taxi.boot.response.Response<java.util.List<com.smzc.taxi.service.driver.bean.push.DriverMessageDualChannelVo>>
     */
    @GetMapping("/getDualChannelMessage")
    @ApiOperation(value = "拉取redis双通道消息", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "拉取成功"))
    public Response<DriverMessageDualChannelVo> getDualChannelMessageByVehicleId(){
        Long vehicleId = ActionContext.getContext().getVehicle();
        DriverMessageDualChannelVo dualChannelVo = centerControlDeviceMessagePushFacade.getDualChannelVoByVehicleId(vehicleId);
        return Response.instance().data(dualChannelVo);
    }

    public static void main(String[] args) throws Exception{
        String str = "1562642251330"+"changyun"+"25e01a8cfa05e3164daff1d97c741608";
        System.out.println(MD5Utils.getMD5(str.getBytes()));
    }
}
