package com.smzc.taxi.centorcontrol.web.configuration;

/**
 * 基本全局配置参数信息
 *
 * @author : lufy
 * @version v1.0
 * @date : 2019/6/19
 */
public class NormalConfig {
    public final static String apiPrefix="/centorcontrol";
}
