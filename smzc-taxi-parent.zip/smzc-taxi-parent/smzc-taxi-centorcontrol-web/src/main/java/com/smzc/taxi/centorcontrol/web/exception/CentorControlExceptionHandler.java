package com.smzc.taxi.centorcontrol.web.exception;

import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.centorcontrol.web.enums.ErrCodes;
import com.smzc.taxi.service.centorcontrol.exception.LoginException;
import com.smzc.taxi.service.centorcontrol.exception.SignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by smzcck on 2019/6/6.
 */
@RestController
@ControllerAdvice
@Slf4j
public class CentorControlExceptionHandler {
    @ExceptionHandler(value = SignException.class)
    public Response<Object> httpMessageNotReadableException(HttpServletRequest req, SignException e)
            throws Exception {
        log.error(req.getRequestURI(), e);
        String msg = e.getMessage();
        return Response.instance().message(msg).code(ErrCodes.SIGN_ERROR.getCode()).data(e.getData());
    }

    @ExceptionHandler(value = LoginException.class)
    public Response<Object> httpMessageNotReadableException(HttpServletRequest req, LoginException e)
            throws Exception {
        log.error(req.getRequestURI(), e);
        //log.error("requestURL:{},response:{}",req.getRequestURI(),JSON.parseString(e.getData()));
        return Response.instance().message(e.getMessage()).code(e.getCode()).data(e.getData());
    }
}
