package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;

/**
 * @author: zhaohui
 * @date: 2019-05-22 17:44
 * @description:
 */

import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.service.driver.bean.DriverSuggestionVo;
import com.smzc.taxi.service.driver.bean.basic.BaseRespVo;
import com.smzc.taxi.service.driver.service.ISuggestionFeedbackFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.http.util.Asserts;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@Api(tags="意见反馈Controller" )
@RequestMapping(value = "/suggestionFeedback")
public class DriverSuggestionFeedbackController {

    @Reference
    private ISuggestionFeedbackFacade suggestionFeedbackFacade;

    @ApiOperation(value = "意见反馈", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @PostMapping(value = "/submit")
    public Response<BaseRespVo> driverScanUseVehicle(@RequestBody @Validated DriverSuggestionVo driverSuggestionVo ) throws Exception{
        driverSuggestionVo.setDriverId(DriverUtils.getCurrentDriverId());
        driverSuggestionVo.setMobile(DriverUtils.getCurrentDriverMobilePhone());
        BaseRespVo respVo = suggestionFeedbackFacade.sumit(driverSuggestionVo);
        return  Response.instance().code(respVo.getCode()).message(respVo.getMessage()).data(null);

    }
}
