package com.smzc.taxi.driver.web.controllers.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

/**
 * @author xiaohb
 * @description: 跨域响应处理
 * @date 2019/7/18 21:47
 */
@Slf4j
public class CrossDomainRespHandler {

    public static void handleCrossdomainRequest(HttpServletRequest request, HttpServletResponse response, Object result){
        PrintWriter out = null;
        try{
            response.setCharacterEncoding("UTF-8");
            response.setContentType("text/javascript;charset=UTF-8");
            out = response.getWriter();
            String callback = request.getParameter("callback");//客户端请求参数

            String data = new ObjectMapper().writeValueAsString(result);
            out.write(callback+"("+data+")");//返回jsonp格式数据
            out.flush();
        } catch (Exception e){
            log.error("jsonp数据响应失败"+e.getMessage(),e);
        } finally {
            if(out != null){
                out.close();
            }
        }
    }

}
