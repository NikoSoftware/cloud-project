package com.smzc.taxi.driver.web.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @Description 正则工具类
 * @Date 2019/5/24 16:45
 * @Created by  zhanglian
 */
public class RegexUtils {

    /**
     * 手机号格式
     * @param mobilePhone
     * @return
     */
    public static boolean isMobilePhone(String mobilePhone){
        String mobilePhoneRegex = "^[0-9]{11}$";
        Pattern pattern = Pattern.compile(mobilePhoneRegex);
        Matcher matcher = pattern.matcher(mobilePhone);
        return matcher.matches();
    }

    /**
     * 身份证号格式
     * @param cardNo
     * @return
     */
    public static boolean isIdNo(String cardNo){
        String cardNoRegex = "^[a-zA-Z0-9]{1,18}$";
        Pattern pattern = Pattern.compile(cardNoRegex);
        Matcher matcher = pattern.matcher(cardNo);
        return matcher.matches();
    }

    /**
     * 车牌号格式
     * @param vehicleNo
     * @return
     */
    public static boolean isVehicleNo(String vehicleNo){
        String vehicleNoRegex = "^[\u4e00-\u9fa5][A-Z][A-Z0-9]{5,6}$";
        Pattern pattern = Pattern.compile(vehicleNoRegex);
        Matcher matcher = pattern.matcher(vehicleNo);
        return matcher.matches();
    }

    public static void main(String[] args) throws Exception {
        boolean mobilePhone = isMobilePhone("13566668888");
        boolean cardNo = isIdNo("asdfg123456789A");
        boolean vehicleNo = isVehicleNo("川a123456");
        System.out.println("isMobilePhone"+mobilePhone);
    }



}
