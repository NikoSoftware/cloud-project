package com.smzc.taxi.driver.web.configuration;

import com.alibaba.fastjson.JSON;
import com.smzc.taxi.common.utils.DateUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class DateConverterConfiguration implements Converter<String, Date> {

    private static final List<String> formart = new ArrayList<>(7);
    static{
        formart.add("yyyy");
        formart.add("yyyy-MM");
        formart.add("yyyy-MM-dd");
        formart.add("yyyy-MM-dd hh:mm");
        formart.add("yyyy-MM-dd hh:mm:ss");
        formart.add("hh:mm:ss");
        formart.add("hh:mm");
    }

    @Override
    public Date convert(String source) {
        String value = source.trim();
        if ("".equals(value)) {
            return null;
        }
        if (source.matches("^\\d{4}"))
            return DateUtils.getDate(source, formart.get(0));
        if(source.matches("^\\d{4}-\\d{1,2}$")){
            return DateUtils.getDate(source, formart.get(1));
        }else if(source.matches("^\\d{4}-\\d{1,2}-\\d{1,2}$")){
            return DateUtils.getDate(source, formart.get(2));
        }else if(source.matches("^\\d{4}-\\d{1,2}-\\d{1,2} {1}\\d{1,2}:\\d{1,2}$")){
            return DateUtils.getDate(source, formart.get(3));
        }else if(source.matches("^\\d{4}-\\d{1,2}-\\d{1,2} {1}\\d{1,2}:\\d{1,2}:\\d{1,2}$")){
            return DateUtils.getDate(source, formart.get(4));
        }else  if(source.matches("^\\d{1,2}:\\d{1,2}:\\d{1,2}$")){
            return DateUtils.getDate(source, formart.get(5));
        }else if(source.matches("^\\d{1,2}:\\d{1,2}$")){
            return DateUtils.getDate(source, formart.get(6));
        }else {
            throw new IllegalArgumentException("Invalid boolean value '" + source + "'");
        }
    }

}
