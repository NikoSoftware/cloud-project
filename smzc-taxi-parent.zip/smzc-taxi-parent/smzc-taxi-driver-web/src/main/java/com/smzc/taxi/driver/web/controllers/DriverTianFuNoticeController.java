package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSONObject;
import com.smzc.taxi.service.finance.bean.CustApplyAndUpdateNotifyVo;
import com.smzc.taxi.service.finance.enums.HandleType;
import com.smzc.taxi.service.finance.exception.FinanceException;
import com.smzc.taxi.service.finance.facade.IDriverAccountManageFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;


/**
 * @Author denglin
 * @Description
 * @Date 2019/5/17 16:49
 * @Version 1.0
 */
@RestController
@RequestMapping("/tianfuPay")
@Api(tags = "天府银行回调地址")
@Slf4j
public class DriverTianFuNoticeController {
    @Reference
    private IDriverAccountManageFacade driverAccountManageFacade;

    /**
     * 天府银行后台审核相关回调地址
     *
     * @param httpServletRequest
     */
    @ApiOperation(value = "天府银行后台审核相关回调地址", notes = "multipart/form-data文件格式输入参数")
    @PostMapping("/applyCust/noticeUrl")
    public String applyCustNotice(HttpServletRequest httpServletRequest) {
        Map<String, String[]> parameterMap = httpServletRequest.getParameterMap();
        log.info("天府银行回调通知司机入驻审核情况："+ JSONObject.toJSONString(parameterMap));
        if(parameterMap==null||parameterMap.size()==0){
            log.info("天府银行回调通知司机入驻审核未获取到任何参数，不做处理");
            throw new FinanceException("未收到任何回调参数！");
        }
        CustApplyAndUpdateNotifyVo request = getCustApplyAndUpdateNotifyVo(httpServletRequest);
        driverAccountManageFacade.custApplyAndUpdateNotify(request, HandleType.APPLY_CUST.getCode());
        return "success";
    }

    /**
     * 天府银行改卡相关回调地址
     *
     * @param httpServletRequest
     */
    @ApiOperation(value = "天府银行改卡相关回调地址", notes = "multipart/form-data文件格式输入参数")
    @PostMapping("/changeBankCard/noticeUrl")
    public String changeBankCardNotice(HttpServletRequest httpServletRequest) {
        Map<String, String[]> parameterMap = httpServletRequest.getParameterMap();
        log.info("天府银行回调通知司机银行改卡审核情况："+ JSONObject.toJSONString(parameterMap));
        if(parameterMap==null||parameterMap.size()==0){
            log.info("天府银行回调通知司机银行改卡审核情况未获取到任何参数，不做处理");
            throw new FinanceException("未收到任何回调参数！");
        }
        CustApplyAndUpdateNotifyVo request = getCustApplyAndUpdateNotifyVo(httpServletRequest);
        driverAccountManageFacade.custApplyAndUpdateNotify(request, HandleType.CHANGE_BANK_CARD.getCode());
        return "success";
    }

    /**
     * 组装参数
     *
     * @param httpServletRequest
     * @return
     */
    private CustApplyAndUpdateNotifyVo getCustApplyAndUpdateNotifyVo(HttpServletRequest httpServletRequest) {
        CustApplyAndUpdateNotifyVo request = new CustApplyAndUpdateNotifyVo();
        request.setPartner(httpServletRequest.getParameter("partner"));
        request.setRemark(httpServletRequest.getParameter("remark"));
        request.setStatus(httpServletRequest.getParameter("status"));
        request.setSubpartner(httpServletRequest.getParameter("subpartner"));
        request.setType(httpServletRequest.getParameter("type"));
        request.setSign_type(httpServletRequest.getParameter("sign_type"));
        request.setSign(httpServletRequest.getParameter("sign"));
        return request;
    }
}
