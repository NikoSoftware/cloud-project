package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.HttpResponseEnum;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.service.driver.bean.BankCardReqVo;
import com.smzc.taxi.service.driver.bean.BankCardRespVo;
import com.smzc.taxi.service.driver.bean.DriverAuthenticationVo;
import com.smzc.taxi.service.driver.bean.DriverWalletDetailVo;
import com.smzc.taxi.service.driver.bean.DriverWithdrawApplyVo;
import com.smzc.taxi.service.driver.bean.DriverWithdrawDetailVo;
import com.smzc.taxi.service.driver.bean.PayPasswordReqVo;
import com.smzc.taxi.service.driver.bean.TradeInfoDetailRespVo;
import com.smzc.taxi.service.driver.bean.TradeInfoVo;
import com.smzc.taxi.service.driver.bean.WithdrawRespVo;
import com.smzc.taxi.service.driver.service.IMyWalletFacade;
import io.netty.handler.codec.http.HttpResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;

@Api(tags = "钱包controller")
@RestController
@RequestMapping("/myWallet")
public class MyWalletController {

    @Reference
    private IMyWalletFacade myWalletFacade;

    @ApiOperation(value = "检查是否设置了支付秘密", notes = "json格式输入参数")
    @PostMapping("/checkHavePayPassword")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<Boolean> checkHavePayPassword() throws Exception {
        Long currentDriverId = DriverUtils.getCurrentDriverId();
        Boolean result = myWalletFacade.checkHavePayPassword(currentDriverId);
        return Response.instance().data(result);
    }

    @ApiOperation(value = "检查支付秘密是否正确", notes = "")
    @PostMapping("/checkPayPassword")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<Boolean> checkPayPassword(@RequestBody PayPasswordReqVo payPassword) throws Exception {
        final Long currentDriverId = DriverUtils.getCurrentDriverId();
        final Boolean result = myWalletFacade.checkPayPassword(currentDriverId, payPassword.getPayPassword());
        if (result) {
            return Response.instance().data(result);
        } else {
            return Response.instance().result(HttpResponseEnum.ACCOUNT_PASSWORD_ERROR).data(false);
        }
    }

    @ApiOperation(value = "设置支付密码", notes = "json格式输入参数")
    @PostMapping("/setPayPassword")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<Boolean> setPayPassword(@RequestBody PayPasswordReqVo payPassword) throws Exception {
        final Long currentDriverId = DriverUtils.getCurrentDriverId();
        final Boolean result = myWalletFacade.setPayPassword(currentDriverId, payPassword);
        if (result) {
            return Response.instance().result(HttpResponseEnum.SUCCESS).data(result);
        } else {
            return Response.instance().result(HttpResponseEnum.PARAMETERS_ERROR).data(false);
        }
    }


    /**
     * 修改银行卡
     *
     * @param bankCardReqVo
     */
    @ApiOperation(value = "修改银行卡", notes = "json格式输入参数")
    @PostMapping("/modifyBankCard")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<Boolean> modifyBankCard(@RequestBody BankCardReqVo bankCardReqVo) throws Exception {
        final Long currentDriverId = DriverUtils.getCurrentDriverId();
        final Boolean result = myWalletFacade.modifyBankCard(currentDriverId, bankCardReqVo);
        if (result) {
            return Response.instance().result(HttpResponseEnum.SUCCESS).data(result);
        } else {
            return Response.instance().result(HttpResponseEnum.PARAMETERS_ERROR).data(false);
        }
    }

    /**
     * 获取银行卡信息
     */
    @ApiOperation(value = "获取银行卡信息", notes = "json格式输入参数")
    @PostMapping("/getBankCardInfo")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<BankCardRespVo> getBankCardInfo() throws Exception {
        final Long currentDriverId = DriverUtils.getCurrentDriverId();
        final BankCardRespVo bankCardInfo = myWalletFacade.getBankCardInfo(currentDriverId);
        return Response.instance().data(bankCardInfo);
    }

    /**
     * 获取交易明细
     *
     * @param searchMonth
     * @return
     */
    @ApiOperation(value = "获取交易明细", notes = "json格式输入参数")
    @GetMapping("/getTradeInfoDetail")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
//    @ApiImplicitParams({
//            @ApiImplicitParam(name = "searchMonth", value = "查询日期 如(2019-05) 时间格式为yyyy-mm", dataType = "String", required = true)
//    })
    public Response<TradeInfoDetailRespVo> getTradeInfoDetail(@RequestParam("searchMonth") String searchMonth) throws Exception {
        Assert.notNull(searchMonth,"传入时间为空");
        final Long currentDriverId = DriverUtils.getCurrentDriverId();
        final TradeInfoDetailRespVo tradeInfoDetail = myWalletFacade.getTradeInfoDetail(currentDriverId, searchMonth);
        return Response.instance().data(tradeInfoDetail);
    }

    /**
     * 获取钱包明细
     *
     * @return
     */
    @ApiOperation(value = "获取钱包明细", notes = "json格式输入参数")
    @PostMapping("/getWalletDetail")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<DriverWalletDetailVo> getWalletDetail() throws Exception {
        final Long currentDriverId = DriverUtils.getCurrentDriverId();
        final DriverWalletDetailVo walletDetail = myWalletFacade.getWalletDetail(currentDriverId);
        return Response.instance().data(walletDetail);
    }

    /**
     * 提现
     *
     * @return
     */
    @ApiOperation(value = "提现", notes = "json格式输入参数")
    @PostMapping("/withdraw")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<WithdrawRespVo> withdraw(@RequestBody DriverWithdrawApplyVo driverWithdrawApplyVo) throws Exception {
        final Long currentDriverId = DriverUtils.getCurrentDriverId();
        final WithdrawRespVo result = myWalletFacade.withdraw(currentDriverId, driverWithdrawApplyVo);
        if (result.getSuccess()){
            return Response.instance().data(result);
        }else {
            return Response.instance().message("提现失败").data(result);
        }
    }

    /**
     * 提现详情
     *
     * @return
     */
    @ApiOperation(value = "提现详情")
    @GetMapping("/getWithdrawDetail")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
//    @ApiImplicitParams({
//            @ApiImplicitParam(name = "tradeId", value = "提现id号", dataType = "Long", required = true)
//    })
    public Response<DriverWithdrawDetailVo> getWithdrawDetail(@RequestParam("tradeId") String tradeId) throws Exception {
        final Long currentDriverId = DriverUtils.getCurrentDriverId();
        DriverWithdrawDetailVo withdrawDetail = myWalletFacade.getWithdrawDetail(tradeId);
        return Response.instance().data(withdrawDetail);
    }

    /**
     * 身份验证
     *
     * @return
     */
    @ApiOperation(value = "身份验证")
    @PostMapping("/authentication")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<Boolean> authentication(@RequestBody DriverAuthenticationVo authenticationVo) throws Exception {
        final Long currentDriverId = DriverUtils.getCurrentDriverId();
        Integer result = myWalletFacade.authentication(currentDriverId, authenticationVo);
        if (result == HttpResponseEnum.OPERATION_SUCCESS.getCode()){
            return Response.instance().data(true);
        }else {
            return Response.instance().result(HttpResponseEnum.getCode(result)).data(false);
        }
    }
    /**
     * 司机已知自己银行卡修改结果
     *
     * @return
     */
    @ApiOperation(value = "司机已知自己银行卡修改结果")
    @PostMapping("/knowBankcardModifyResult")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<Boolean> knowBankcardModifyResult() throws Exception {
        final Long currentDriverId = DriverUtils.getCurrentDriverId();
        Boolean result = myWalletFacade.knowBankcardModifyResult(currentDriverId);
        if (result){
            return Response.instance().data(result);
        }else {
            return Response.instance().message("数据操作失败").data(result);
        }
    }
}
