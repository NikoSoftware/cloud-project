package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.service.driver.bean.ServiceScoreVo;
import com.smzc.taxi.service.driver.service.IDriverGradeDaysFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author: zhaohui
 * @date: 2019-05-26 22:51
 * @description: 服务评分
 *
 */
@RestController
@Api(tags = "服务评分")
@RequestMapping(value = "/serviceScore")
@Slf4j
public class ServiceScoreController {

    @Reference
    IDriverGradeDaysFacade serviceScoreFacade;

    @PostMapping("/selectServiceScore")
    @ApiOperation(value = "获取本月，本季度，半年，全年，累计的评分", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<ServiceScoreVo> selectServiceScore() throws Exception{
        Long currentDriverId = DriverUtils.getCurrentDriverId();
        ServiceScoreVo serviceScoreVo =  serviceScoreFacade.selectServiceScore(currentDriverId);
        return Response.instance().data(serviceScoreVo);
    }


}
