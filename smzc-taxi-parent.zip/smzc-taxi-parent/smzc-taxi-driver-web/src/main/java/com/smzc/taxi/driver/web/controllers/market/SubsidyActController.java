package com.smzc.taxi.driver.web.controllers.market;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.market.service.driver.bean.subsidy.DriverSubsidyParticipationDetailVo;
import com.smzc.market.service.driver.bean.subsidy.DriverSubsidyRewardCountInfoReqVo;
import com.smzc.market.service.driver.service.IDriverSubsidyFacade;
import com.smzc.taxi.boot.response.HttpResponseEnum;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.service.driver.bean.DriverInformationVo;
import com.smzc.taxi.service.driver.bean.DriverWorkStateRedisVo;
import com.smzc.taxi.service.driver.bean.market.SubsidyDriverInfoVo;
import com.smzc.taxi.service.driver.bean.market.SubsidyRewardDetailReqVo;
import com.smzc.taxi.service.driver.service.IDriverFacade;
import com.smzc.taxi.service.driver.service.IDriverInformationFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


/**
 * @Description 司机补贴活动
 * @Date 2019/7/15 16:28
 * @Created by  zhanglian
 */
@RestController
@Api(tags = "营销活动")
@RequestMapping(value = "/subsidy")
@Slf4j
public class SubsidyActController {

    @Reference(group="smzc-market")
    private IDriverSubsidyFacade driverSubsidyFacade;

    @Reference
    private IDriverInformationFacade driverInformationFacade;

    @Reference
    private IDriverFacade driverFacade;

    /**
     * 司机补贴邀新活动剩余次数
     * @return
     */
    @PostMapping("/subsidyLeftRewardCount")
    @ApiOperation(value = "获取司机补贴奖励剩余次数", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "发送成功"))
    public Response<DriverSubsidyParticipationDetailVo> getDriverLeftSubsidyRewardCount(@RequestBody @Validated SubsidyRewardDetailReqVo subsidyRewardDetailReqVo) throws Exception {

        DriverSubsidyRewardCountInfoReqVo rewardCountReqVo = new DriverSubsidyRewardCountInfoReqVo();
        rewardCountReqVo.setActivityNo(subsidyRewardDetailReqVo.getActivityNo());
        rewardCountReqVo.setDriverId(DriverUtils.getCurrentDriverId());

        DriverSubsidyParticipationDetailVo driverSubsidyParticipationDetail = driverSubsidyFacade.getDriverSubsidyParticipationDetail(rewardCountReqVo);
        if (null == driverSubsidyParticipationDetail){
            return Response.instance().code(HttpResponseEnum.DATA_NOT_FOUND.code).message("未找到司机补贴奖励信息").data(null);
        } else {
            return Response.instance().data(driverSubsidyParticipationDetail);
        }
    }

    /**
     * 获取司机补贴活动司机信息
     * @return
     */
    @PostMapping("/subsidyDriverInfo")
    @ApiOperation(value = "获取司机补贴活动司机信息", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "发送成功"))
    public Response<SubsidyDriverInfoVo> getSubsidyDriverInfo() throws Exception {
        Long driverId = DriverUtils.getCurrentDriverId();
        DriverInformationVo driverInfo = driverInformationFacade.findDriverInformationByDriverId(driverId);
        DriverWorkStateRedisVo driverCurrentWorkState = driverFacade.getDriverCurrentWorkState(DriverUtils.getCurrentDriverId());

        if (null == driverInfo || null == driverCurrentWorkState) {
            return Response.instance().code(HttpResponseEnum.DATA_NOT_FOUND.code).message("未找到司机补贴奖励剩余次数信息").data(null);
        } else {
            SubsidyDriverInfoVo subsidyDriverInfo = new SubsidyDriverInfoVo();
            subsidyDriverInfo.setDriverName(driverInfo.getName());
            subsidyDriverInfo.setDriverMobilePhone(driverInfo.getMobilePhone());
            subsidyDriverInfo.setVehicleId(driverInfo.getVehicleId());
            subsidyDriverInfo.setDriverStatus(driverCurrentWorkState.getWorkState());
            return Response.instance().data(subsidyDriverInfo);
        }

    }




}
