package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.HttpResponseEnum;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.service.driver.bean.DriverAppCheckUpdateReqVo;
import com.smzc.taxi.service.driver.bean.DriverAppVersionRespVo;
import com.smzc.taxi.service.driver.enums.DriverAppOsTypeEnum;
import com.smzc.taxi.service.driver.service.IDriverAppVersionFacade;
import io.swagger.annotations.*;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author pengpengcheng
 * @description
 * @date 2019/5/27
 */
@Api(tags = "司机端App版本信息")
@RestController
@RequestMapping("/driverAppVersion")
public class DriverAppVersionController {
    @Reference
    private IDriverAppVersionFacade driverAppVersionFacade;

    @ApiOperation(value = "司机客户端检查更新", notes = "json格式输入参数, 基于versionName比较版本")
    @ApiResponses({
            @ApiResponse(code = 200, message = "获取成功, 返回更新信息"),
            @ApiResponse(code = -1, message = "数据没找到")
    })
    @PostMapping("/checkUpdate")
    public Response<DriverAppVersionRespVo> checkUpdate(@RequestBody @Validated DriverAppCheckUpdateReqVo checkUpdateReqVo) {
        DriverAppVersionRespVo appVersion = driverAppVersionFacade.checkUpdate(checkUpdateReqVo);
        if (null == appVersion) {
            return Response.instance().result(HttpResponseEnum.DATA_NOT_FOUND).build();
        }
        return Response.instance().data(appVersion);
    }

    @ApiOperation(value = "安卓司机客户端检查更新", notes = "返回最新版本信息")
    @ApiResponses({
            @ApiResponse(code = 200, message = "获取成功, 返回最新版本信息"),
            @ApiResponse(code = -1, message = "数据没找到")
    })
    @GetMapping("/androidCheckUpdate")
    public Response<DriverAppVersionRespVo> AndroidCheckUpdate() {
        DriverAppVersionRespVo appVersion = driverAppVersionFacade.getLatestAppVersionByOsType(DriverAppOsTypeEnum.ANDROID.getType());
        if (null == appVersion) {
            return Response.instance().result(HttpResponseEnum.DATA_NOT_FOUND).build();
        }
        return Response.instance().data(appVersion);
    }
}
