package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.service.driver.bean.CustomerServicePhoneVo;
import com.smzc.taxi.service.driver.service.ICustomerServicePhoneFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author: zhaohui
 * @date: 2019-05-22 17:44
 * @description:
 */


@RestController
@Api(tags="客服电话相关的Controller" )
@RequestMapping(value = "/customerServicePhone")
public class CustomerServicePhoneController {

    @Reference
    private ICustomerServicePhoneFacade customerServicePhoneFacade;

    @ApiOperation(value = "查看所有的客服电话电话", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @PostMapping(value = "/all")
    public Response selectAll(){
        List<CustomerServicePhoneVo> customerServicePhoneVoList = customerServicePhoneFacade.selectAll();
        return  Response.instance().data(customerServicePhoneVoList);
    }

}
