//package com.smzc.taxi.driver.web.controllers;
//
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.alibaba.dubbo.config.annotation.Reference;
//import com.github.pagehelper.PageInfo;
//import com.smzc.taxi.boot.response.Response;
//import com.smzc.taxi.service.portal.bean.AnnouncementQryVo;
//import com.smzc.taxi.service.portal.bean.AnnouncementRespVo;
//import com.smzc.taxi.service.portal.service.IAnnouncementFacade;
//
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;
//import io.swagger.annotations.ApiResponse;
//import io.swagger.annotations.ApiResponses;
//
//@RestController
//@Api(tags="司机公告" )
//@RequestMapping(value = "/announce")
//public class DriverAnnounceController {
//    @Reference
//    private IAnnouncementFacade announceFacade;
//
//    @ApiOperation(value = "分页查询司机公告", notes = "json格式输入参数")
//    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
//    @PostMapping(value = "/page")
//    public Response<PageInfo<AnnouncementRespVo>> getDriverAnnouncementPage(@RequestBody @Validated AnnouncementQryVo query) {
//    	PageInfo<AnnouncementRespVo> page = announceFacade.getDriverAnnouncementPage(query);
//        return  Response.instance().data(page);
//    }
//    
//    @ApiOperation(value = "司机读取公告", notes = "只有未读状态的才执行此请求，已读公告再次读取时不用执行此请求，避免系统资源浪费")
//    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
//    @GetMapping(value = "/read")
//    public Response<Integer> readAnnouncement(Long announcId, Long driverId) {
//    	announceFacade.readAnnouncement(announcId, driverId);
//        return  Response.instance().data(1);
//    }
//}
