package com.smzc.taxi.driver.web.exception;

/**
 * @Description token异常类
 * @Date 2019/5/23 17:18
 * @Created by  zhanglian
 */
public class TokenException extends Exception {

    public TokenException(String message) {
        super(message);
    }
}
