package com.smzc.taxi.driver.web.exception;

import com.smzc.taxi.boot.response.HttpResponseEnum;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.interceptor.DriverMobileInterceptor;
import com.smzc.taxi.service.finance.exception.FinanceException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @Description 司机端异常处理器
 * @Date 2019/5/23 17:16
 * @Created by  zhanglian
 */
@RestController
@ControllerAdvice
@Slf4j
public class DriverExceptionHandler {

    @ExceptionHandler(value = Exception.class)
    public Response<Void> driverHttpException(HttpServletRequest req, Exception e) throws Exception {
        log.error("司机端端异常拦截uri-->" + req.getRequestURI() + ",deviceOsType(1-ios,0-android)-->" + req.getHeader(DriverMobileInterceptor.DEVICEOSTYPE), e);

        Response<Void> response = Response.instance().build();
        String exceptionStr = e.toString();
        if (exceptionStr.contains(TokenException.class.getName())) {
            response.setCode(HttpResponseEnum.DRIVER_MOBILE_LOGIN_101.code);
            response.setMessage(e.getMessage());
            return response;
        }else if(exceptionStr.contains(IllegalArgumentException.class.getName()) ||
                exceptionStr.contains(IllegalStateException.class.getName())){
            response.setCode(HttpResponseEnum.NETWORK_ERROR.code);
            response.setMessage(e.getMessage());
            return response;
        }else if (exceptionStr.contains(MethodArgumentNotValidException.class.getName())){
            MethodArgumentNotValidException exception = (MethodArgumentNotValidException) e;
            response.setCode(HttpResponseEnum.NETWORK_ERROR.code);
            response.setMessage(exception.getBindingResult().getAllErrors().get(0).getDefaultMessage());
            return response;
        } else if (exceptionStr.contains(FinanceException.class.getName())){
            FinanceException exception = (FinanceException) e;
            response.setCode(HttpResponseEnum.NETWORK_ERROR.code);
            response.setMessage(exception.getMessage());
            return response;
        }
        response.setCode(HttpResponseEnum.SYSTEM_ERROR.code);
        response.setMessage(HttpResponseEnum.SYSTEM_ERROR.message);

        return response;
    }

}
