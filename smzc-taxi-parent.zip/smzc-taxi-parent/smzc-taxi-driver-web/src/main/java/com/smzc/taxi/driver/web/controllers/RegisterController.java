package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.HttpResponseEnum;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.RegexUtils;
import com.smzc.taxi.service.driver.bean.*;
import com.smzc.taxi.service.driver.bean.basic.BaseRespVo;
import com.smzc.taxi.service.driver.bean.basic.QiNiuTokenVo;
import com.smzc.taxi.service.driver.service.IDriverLoginFacade;
import com.smzc.taxi.service.driver.service.IDriverRegisterFacade;
import com.smzc.taxi.service.driver.service.IQiNiuFacade;
import com.smzc.taxi.service.portal.service.IOpenCityFacade;
import com.smzc.taxi.service.portal.service.ITaxiCompanyConfigFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Description
 * @Date 2019/5/16 16:14
 * @Created by  zhanglian
 */
@RestController
@Api(tags = "登录注册")
@RequestMapping(value = "/driverReg")
@Slf4j
public class RegisterController {

    @Reference
    IDriverRegisterFacade driverRegisterFacade;

    @Reference
    private IQiNiuFacade qiNiuFacade;

    @Reference
    private IOpenCityFacade openCityFacade;

    @Reference
    private ITaxiCompanyConfigFacade taxiCompanyConfigFacade;


    @PostMapping("/getOpenCityList")
    @ApiOperation(value = "获取开通城市", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<List<OpenCityVo>> getOpenCityList(){
        List<OpenCityVo> openCityVos = openCityFacade.selectOpenCityList();
        return Response.instance().data(openCityVos);
    }


    @PostMapping("/getTaxiCompanyList")
    @ApiOperation(value = "获取出租车公司", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<List<TaxiCompanyVo>> getTaxiCompanyList(@RequestBody TaxiCompanyPageQryVo taxiCompanyPageQryVo){
        List<TaxiCompanyVo> taxiCompanyVos = taxiCompanyConfigFacade.pageQueryTaxiCompanyByCompanyKey(taxiCompanyPageQryVo);
        return Response.instance().data(taxiCompanyVos);
    }


   /* //取消获取开户行列表功能
    @PostMapping("/getBankList")
    @ApiOperation(value = "获取开户行", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<List<BankVo>> getBankList(){
        List<BankVo> bankVos = driverRegisterFacade.selectBankList();
        return Response.instance().data(bankVos);
    }*/

    @PostMapping("/getQiNiuToken")
    @ApiOperation(value = "七牛云上传token", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<QiNiuTokenVo> getQiNiuToken() {
        return Response.instance().data(qiNiuFacade.getUploadToken());
    }

    @PostMapping("/submitPersonalInfo")
    @ApiOperation(value = "提交个人信息", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response submitPersonalInfo(@RequestBody @Validated DriverRegPersonalInfoReqVo personalInfoReqVo){
        boolean isMobilePhone = RegexUtils.isMobilePhone(personalInfoReqVo.getMobilePhone());
        if (!isMobilePhone) {
            return Response.instance().code(HttpResponseEnum.DRIVER_DATA_FORMAT_ERROR.code).message("手机格式不对!").build();
        }
        if (!RegexUtils.isIdNo(personalInfoReqVo.getIdNo())) {
            return Response.instance().code(HttpResponseEnum.DRIVER_DATA_FORMAT_ERROR.code).message("身份证号格式不对!").build();
        }
        Integer count = driverRegisterFacade.savePersonalInfo(personalInfoReqVo);
        if (count == null || count.intValue() < 1) {
            return Response.instance().code(HttpResponseEnum.DRIVER_SAVE_PERSONAL_INFO_FAIL.code).message("个人信息上传失败!").build();
        } else {
            return Response.instance().build();
        }
    }


    @PostMapping("/submitVehicleInfo")
    @ApiOperation(value = "提交车辆信息", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response submitVehicleInfo(@RequestBody @Validated DriverRegVehicleInfoReqVo vehicleInfoReqVo){
        boolean isMobilePhone = RegexUtils.isMobilePhone(vehicleInfoReqVo.getMobilePhone());
        if (!isMobilePhone) {
            return Response.instance().code(HttpResponseEnum.DRIVER_DATA_FORMAT_ERROR.code).message("手机格式不对!").build();
        }
        if (!RegexUtils.isVehicleNo(vehicleInfoReqVo.getVehicleNo())) {
            return Response.instance().code(HttpResponseEnum.DRIVER_DATA_FORMAT_ERROR.code).message("车牌号格式不对!").build();
        }
        BaseRespVo respVo = driverRegisterFacade.saveVehicleInfo(vehicleInfoReqVo);
        return Response.instance().code(respVo.getCode()).message(respVo.getMessage()).build();
    }

    @PostMapping("/submitBankCardInfo")
    @ApiOperation(value = "提交结算账号信息", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response submitBankCardInfo(@RequestBody @Validated DriverRegBankCardInfoReqVo bankCardInfoReqVo){
        boolean isMobilePhone = RegexUtils.isMobilePhone(bankCardInfoReqVo.getMobilePhone());
        if (!isMobilePhone) {
            return Response.instance().code(HttpResponseEnum.DRIVER_DATA_FORMAT_ERROR.code).message("手机格式不对!").build();
        }
        DriverRegisterVo registerVo = driverRegisterFacade.saveBankCardInfo(bankCardInfoReqVo);
        return Response.instance().code(registerVo.getCode()).message(registerVo.getMessage()).build();
    }

}
