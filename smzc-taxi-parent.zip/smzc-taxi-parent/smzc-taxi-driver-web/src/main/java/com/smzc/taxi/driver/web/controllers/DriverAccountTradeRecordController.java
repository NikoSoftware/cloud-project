package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.service.driver.bean.DriverAccountTradeRecordVo;
import com.smzc.taxi.service.driver.bean.DriverAppHomeDataVo;
import com.smzc.taxi.service.driver.bean.DriverIncomeByDayVo;
import com.smzc.taxi.service.driver.bean.DriverIncomeByMonthVo;
import com.smzc.taxi.service.driver.service.IDriverAccountTradeRecordFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.util.Asserts;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


/**
 * @Author ranhk
 * @Description
 * @Date 2019/5/17 16:49
 * @Version 1.0
 */
@RestController
@RequestMapping("/driverAccountTrade")
@Api(tags = "日/月收入明细")
@Slf4j
public class DriverAccountTradeRecordController {
    @Reference
    private IDriverAccountTradeRecordFacade driverAccountTradeRecordFacade;

    @PostMapping("/getIncomeByMonth")
    @ApiOperation(value = "月收入详情", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "查询"))
    public Response<DriverIncomeByMonthVo> getIncomeByMonth(@RequestBody @Validated DriverAccountTradeRecordVo request) throws Exception{
        Long driverId = DriverUtils.getCurrentDriverId();
        request.setDriverId(driverId);
        return Response.instance().data(driverAccountTradeRecordFacade.getIncomeByMonth(request));
    }

    @PostMapping("/getIncomeByDay")
    @ApiOperation(value = "日收入详情", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "查询"))
    public Response<DriverIncomeByDayVo> getIncomeByDay(@RequestBody @Validated DriverAccountTradeRecordVo  request) throws Exception{
        Long driverId = DriverUtils.getCurrentDriverId();
        request.setDriverId(driverId);
        return Response.instance().data(driverAccountTradeRecordFacade.getIncomeByDay(request));
    }

    /**
     * 获取今日收入/今日单量/本月收入/司机当前位置
     * @date: 2019/5/16 18:20
     * @param: [driverScanVehicleVo]
     * @return: com.smzc.taxi.boot.response.Response<org.apache.poi.ss.formula.functions.T>
     */
    @ApiOperation(value = "App首页数据接口", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @PostMapping(value = "/homeData")
    public Response<DriverAppHomeDataVo> driverAppHomeData()throws Exception{
        // 获取今日收入/今日单量/本月收入
        // 获取在线听单时长 秒
        Long driverId = DriverUtils.getCurrentDriverId();
        return Response.instance().data( driverAccountTradeRecordFacade.driverHomeIncomeDetail( driverId ) );
    }
}
