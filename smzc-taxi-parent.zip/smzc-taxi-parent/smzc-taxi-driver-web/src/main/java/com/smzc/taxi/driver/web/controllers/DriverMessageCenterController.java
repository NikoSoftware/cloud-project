package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.github.pagehelper.PageInfo;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.service.driver.bean.push.DriverMessageCenterListRespVo;
import com.smzc.taxi.service.driver.bean.push.DriverMessageCenterQryVo;
import com.smzc.taxi.service.driver.bean.push.DriverMessageCenterReadVo;
import com.smzc.taxi.service.driver.service.IDriverMessagePushFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author by wanglin
 * @date 2019/5/16 15:59
 * @description 司机消息中心
 */
@RestController
@RequestMapping(value = "/driver/messageCenter")
@Slf4j
@Api(tags = "消息中心")
public class DriverMessageCenterController {

    @Reference
    private IDriverMessagePushFacade driverMessagePushFacade;

    /**
     * 消息中心列表
     */
    @PostMapping("/list")
    @ApiOperation(value = "消息中心列表", notes = "json格式输入参数，无返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<PageInfo<DriverMessageCenterListRespVo>> list(@RequestBody @Validated DriverMessageCenterQryVo query) throws Exception {
        query.setDriverId(DriverUtils.getCurrentDriverId());
        PageInfo<DriverMessageCenterListRespVo> pageInfo = driverMessagePushFacade.centerQueryPage(query);
        return Response.instance().data(pageInfo);
    }

    /**
     * 司机阅读消息，添加阅读记录
     */
    @PostMapping("/read")
    @ApiOperation(value = "消息中心阅读消息", notes = "json格式输入参数，无返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response read(@RequestBody @Validated DriverMessageCenterReadVo vo) throws Exception {
        vo.setDriverId(DriverUtils.getCurrentDriverId());
        driverMessagePushFacade.centerRead(vo);
        return Response.instance().build();
    }
}
