package com.smzc.taxi.driver.web.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * 描述：司机环境配置
 *
 * @author sy.z
 * @date 2019/6/11 17:50
 */
@Configuration
public class ThreadPoolTaskExecutorConfiguration {

    /**
     *  仅用于GPS位置上报线程池配置
     * @date: 2019/6/12 15:15
     */
    @Bean("positionRefreshThreadPoolTaskExecutor")
    public ThreadPoolTaskExecutor positionRefreshThreadPoolTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(30);
        executor.setQueueCapacity(1000);
        executor.setKeepAliveSeconds(60);
        executor.setThreadNamePrefix("PositionThreadPoolTaskExecutor-");
        executor.initialize();
        return executor;
    }
}
