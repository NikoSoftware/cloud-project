package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.HttpResponseEnum;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.driver.web.common.RegexUtils;
import com.smzc.taxi.driver.web.interceptor.DriverMobileInterceptor;
import com.smzc.taxi.service.driver.bean.*;
import com.smzc.taxi.service.driver.bean.basic.BaseRespVo;
import com.smzc.taxi.service.driver.service.IDriverLoginFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * @Description
 * @Date 2019/5/16 10:52
 * @Created by zhangxiao
 */

@RestController
@Api(tags = "登录注册")
@RequestMapping(value = "/driverLogin")
@Slf4j
public class LoginController {

    @Reference
    IDriverLoginFacade driverLoginFacade;

    @PostMapping("/loginValidateCode")
    @ApiOperation(value = "获取登录验证码", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "发送成功"))
    public Response loginValidateCode(@RequestBody @Validated LoginValidateCodeReqVo validateCodeReqVo){
        boolean isMobilePhone = RegexUtils.isMobilePhone(validateCodeReqVo.getMobilePhone());
        if (!isMobilePhone) {
            return Response.instance().code(HttpResponseEnum.DRIVER_DATA_FORMAT_ERROR.code).message("手机格式不对!").build();
        }
        BaseRespVo baseRespVo = driverLoginFacade.sendValidateCode(validateCodeReqVo);
        return Response.instance().code(baseRespVo.getCode()).message(baseRespVo.getMessage()).build();
    }


    @PostMapping("/login")
    @ApiOperation(value = "登录", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<LoginRespVo> login(@RequestBody @Validated LoginReqVo loginReqVo,HttpServletRequest request){
        boolean isMobilePhone = RegexUtils.isMobilePhone(loginReqVo.getMobilePhone());
        if (!isMobilePhone) {
            return Response.instance().code(HttpResponseEnum.DRIVER_DATA_FORMAT_ERROR.code).message("手机格式不对!").build();
        }
        LoginVo loginVo = new LoginVo();
        loginVo.setMobilePhone(loginReqVo.getMobilePhone());
        loginVo.setValidateCode(loginReqVo.getValidateCode());
        loginVo.setDeviceOsType(request.getHeader("deviceOsType")==null ? null:Integer.valueOf(request.getHeader("deviceOsType")));
        loginVo.setAppVersion(request.getHeader("appVersion"));

        DriverLoginVo driverLoginVo = driverLoginFacade.login(loginVo);
        if (driverLoginVo.getCode().intValue() == HttpResponseEnum.SUCCESS.code) {
            return Response.instance().data(driverLoginVo.getLoginRespVo());
        } else {
            return Response.instance().code(driverLoginVo.getCode()).message(driverLoginVo.getMessage()).data(null);
        }
    }


    @PostMapping("/autoLogin")
    @ApiOperation(value = "自动登录", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<LoginRespVo> autoLogin(HttpServletRequest request)throws Exception{
        LoginVo loginVo = new LoginVo();
        loginVo.setDriverId(DriverUtils.getCurrentDriverId());
        loginVo.setToken(request.getHeader(DriverMobileInterceptor.MOBILEAUTHORIZATION));
        loginVo.setDeviceOsType(request.getHeader("deviceOsType")==null?null:Integer.valueOf(request.getHeader("deviceOsType")));
        loginVo.setAppVersion(request.getHeader("appVersion"));

        DriverLoginVo driverLoginVo = driverLoginFacade.autoLogin(loginVo);
        if (driverLoginVo.getCode().intValue() == HttpResponseEnum.SUCCESS.code) {
            return Response.instance().data(driverLoginVo.getLoginRespVo());
        } else {
            return Response.instance().code(driverLoginVo.getCode()).message(driverLoginVo.getMessage()).data(null);
        }
    }

    @PostMapping("/refreshLogin")
    @ApiOperation(value = "刷新登录", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response<LoginRespVo> refreshLogin(@RequestBody @Validated LoginValidateCodeReqVo reqVo,HttpServletRequest request){
        boolean isMobilePhone = RegexUtils.isMobilePhone(reqVo.getMobilePhone());
        if (!isMobilePhone) {
            return Response.instance().code(HttpResponseEnum.DRIVER_DATA_FORMAT_ERROR.code).message("手机格式不对!").build();
        }
        LoginVo loginVo = new LoginVo();
        loginVo.setMobilePhone(reqVo.getMobilePhone());
        loginVo.setDeviceOsType(request.getHeader("deviceOsType")==null ? null:Integer.valueOf(request.getHeader("deviceOsType")));
        loginVo.setAppVersion(request.getHeader("appVersion"));

        DriverLoginVo driverLoginVo = driverLoginFacade.refreshLogin(loginVo);
        if (driverLoginVo.getCode().intValue() == HttpResponseEnum.SUCCESS.code) {
            return Response.instance().data(driverLoginVo.getLoginRespVo());
        } else {
            return Response.instance().code(driverLoginVo.getCode()).message(driverLoginVo.getMessage()).data(null);
        }
    }



    @PostMapping("/logout")
    @ApiOperation(value = "注销", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response logout() throws Exception{
        BaseRespVo baseRespVo = driverLoginFacade.logout(DriverUtils.getCurrentDriverId());
        return Response.instance().code(baseRespVo.getCode()).message(baseRespVo.getMessage()).build();
    }


    @PostMapping("/saveLoginOrLogoutLog")
    @ApiOperation(value = "保存登录/退出日志", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response saveLoginOrLogoutLog(@RequestBody @Validated DriverLoginLogVo logVo) throws Exception{
        BaseRespVo respVo = driverLoginFacade.saveLoginOrLogoutLog(logVo);
        return Response.instance().code(respVo.getCode()).message(respVo.getMessage()).build();
    }


    @PostMapping("/updateDriverDeviceInfo")
    @ApiOperation(value = "更新司机设备信息", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public Response updateDriverDeviceInfo(@RequestBody @Validated DriverDeviceVo driverDeviceVo) throws Exception{
        driverDeviceVo.setId(DriverUtils.getCurrentDriverId());
        Integer result = driverLoginFacade.updateDriverDeviceInfo(driverDeviceVo);
        if (result == null || result.intValue()<1) {
            return Response.instance().code(HttpResponseEnum.DRIVER_UPDATE_DEVICE_INFO_FAIL.code).message("更新司机设备信息失败").build();
        } else {
            return Response.instance().build();
        }
    }

    /**
     * token校验 - token与driverId是否对应有效
     * @return
     */
    public Response checkToken(DriverTokenCheckVo tokenCheckVo){
        Response<Object> response = Response.instance().build();
        DriverTokenCheckRespVo respVo = driverLoginFacade.checkToken(tokenCheckVo);
        response.setCode(respVo.getCode());
        response.setMessage(respVo.getMsg());
        return response;
    }


}
