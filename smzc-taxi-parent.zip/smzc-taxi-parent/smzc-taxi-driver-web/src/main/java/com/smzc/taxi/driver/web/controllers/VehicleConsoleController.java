package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.service.driver.bean.VehicleDriverRedisVo;
import com.smzc.taxi.service.driver.bean.centercontrol.DriverSignInReqVo;
import com.smzc.taxi.service.driver.bean.centercontrol.DriverSignRespVo;
import com.smzc.taxi.service.driver.bean.centercontrol.DriverStatusInfoVo;
import com.smzc.taxi.service.driver.service.IVehicleCenterControlFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 描述：车辆控制台Controller 测试
 *
 * @author sy.z
 * @date 2019/6/4 14:47
 */
@RestController
@Api( value = "司机端-扫码用车",tags="司机扫码用车Controller 测试" )
@RequestMapping(value = "/vehicle/console")
@Slf4j
public class VehicleConsoleController {

    @Reference
    IVehicleCenterControlFacade vehicleCenterControlFacade;

    @ApiOperation(value = "打卡测试", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @PostMapping(value = "/signInTest")
    public Response test(@RequestBody DriverSignInReqVo reqVo){
        DriverSignRespVo<DriverStatusInfoVo> respVo = vehicleCenterControlFacade.driverSignIn(reqVo);
        log.info("返回参数：{}",respVo);
        return Response.instance().data(respVo);
    }


    @ApiOperation(value = "获取车辆绑定信息（条件：车牌号）", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @PostMapping(value = "/vehicleNoMappingTest")
    public Response test2(@RequestBody List<String> reqVo){
        List<VehicleDriverRedisVo> respVo = vehicleCenterControlFacade.getDriverVehicleMapping(reqVo);
        log.info("返回参数：{}",respVo);
        return Response.instance().data(respVo);
    }

}
