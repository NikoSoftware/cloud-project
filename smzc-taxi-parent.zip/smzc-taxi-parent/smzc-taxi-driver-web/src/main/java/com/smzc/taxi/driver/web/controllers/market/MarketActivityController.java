package com.smzc.taxi.driver.web.controllers.market;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.market.service.driver.bean.MarketActivityReqVo;
import com.smzc.market.service.driver.bean.MarketActivityRespVo;
import com.smzc.market.service.driver.enums.BusinessTypeEnum;
import com.smzc.market.service.driver.enums.DriverTypeEnum;
import com.smzc.market.service.driver.service.IDriverMarketActivityFacade;
import com.smzc.market.service.system.bean.SystemConfigurationVo;
import com.smzc.market.service.system.enums.SystemConfigurationEnum;
import com.smzc.market.service.system.service.IMarketSystemConfigurationFacade;
import com.smzc.taxi.boot.response.HttpResponseEnum;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.service.driver.bean.DriverInformationVo;
import com.smzc.taxi.service.driver.bean.market.SubsidyInviteScanConfigVo;
import com.smzc.taxi.service.driver.service.IDriverInformationFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * @Description 营销活动
 * @Date 2019/7/15 16:06
 * @Created by  zhanglian
 */
@RestController
@Api(tags = "营销活动")
@RequestMapping(value = "/market")
@Slf4j
public class MarketActivityController {

    @Reference(group="smzc-market")
    private IDriverMarketActivityFacade marketActivityFacade;

    @Reference(group="smzc-market")
    private IMarketSystemConfigurationFacade marketSystemConfigurationFacade;

    @Reference
    private IDriverInformationFacade driverInformationFacade;

    /**
     * 司机参与营销活动列表
     * @return
     */
    @PostMapping("/participationMarketActList")
    @ApiOperation(value = "司机参与营销活动列表", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "发送成功"))
    public Response<List<MarketActivityRespVo>> getParticipationMarketActivityList() throws Exception {
        Long currentDriverId = DriverUtils.getCurrentDriverId();
        DriverInformationVo driverInfo = driverInformationFacade.findDriverInformationByDriverId(currentDriverId);
        MarketActivityReqVo marketActivityReqVo = new MarketActivityReqVo();
        marketActivityReqVo.setBusinessType(BusinessTypeEnum.SM_TAXI.type);
        marketActivityReqVo.setDriverType(DriverTypeEnum.TAXI_DRIVER.type);
        marketActivityReqVo.setCityCode(driverInfo.getAreaCode());
        List<MarketActivityRespVo> respVoList = marketActivityFacade.selectAllOpeningMarketActivities(marketActivityReqVo);
        return Response.instance().data(respVoList);
    }
    /**
     * 司机邀新二维码扫描配置
     * @return
     */
    @PostMapping("/subsidyInviteScanConfig")
    @ApiOperation(value = "司机邀新二维码扫描配置", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "发送成功"))
    public Response<SubsidyInviteScanConfigVo> getSubsidyInviteScanConfig(){
        SubsidyInviteScanConfigVo subsidyInviteScanConfigVo = new SubsidyInviteScanConfigVo();
        SystemConfigurationVo systemConfiguration = marketSystemConfigurationFacade.getSystemConfiguration(SystemConfigurationEnum.MARKET_SUBSIDY_TREE_PLATFORM_SCAN_CONFIG, null);
        if (null != systemConfiguration && null != systemConfiguration.getConfigValue() && !"".equals(systemConfiguration.getConfigValue())){
            String config = systemConfiguration.getConfigValue();
            subsidyInviteScanConfigVo.setTreePlatformAllowScan(Boolean.valueOf(config));
            return Response.instance().data(subsidyInviteScanConfigVo);
        } else {
            return Response.instance().code(HttpResponseEnum.DATA_NOT_FOUND.code).message("未查询司机邀新二维码扫描配置").data(null);
        }

    }

    /**
     * 获取系统当前时间戳
     * @return
     */
    @PostMapping("/currentSystemTime")
    @ApiOperation(value = "系统当前时间戳", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "发送成功"))
    public Response<Integer> getCurrentSystemTime(){
        String timestamp = String.valueOf(new Date().getTime() / 1000);
        return Response.instance().data(Integer.valueOf(timestamp));
    }


}
