package com.smzc.taxi.driver.web.common;

import com.smzc.taxi.driver.web.exception.TokenException;
import com.smzc.taxi.driver.web.interceptor.DriverMobileInterceptor;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import javax.servlet.http.HttpServletRequest;

/**
 * @Description 司机工具类
 * @Date 2019/5/21 10:50
 * @Created by  zhanglian
 */
public class DriverUtils {

    /**
     * 获取当前请求HttpServletRequest实例
     * @return
     */
    public static HttpServletRequest getCurrentRequest(){
        return ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
    }

    /**
     * 获取当前登录司机id
     * @return
     */
    public static Long getCurrentDriverId() throws Exception {
        String driverIdStr = String.valueOf(getCurrentRequest().getAttribute(DriverMobileInterceptor.DRIVERID));
        if (driverIdStr == null || "".equals(driverIdStr)) {
            throw new TokenException("当前登录异常,请重新登录！");
        }
        return Long.valueOf(driverIdStr);
    }

    /**
     * 获取当前登录司机手机号
     * @return
     */
    public static String getCurrentDriverMobilePhone() throws Exception{
        String driverPhoneStr = String.valueOf(getCurrentRequest().getAttribute(DriverMobileInterceptor.DRIVERID_PHONE));
        if (driverPhoneStr == null || "".equals(driverPhoneStr)) {
            throw new TokenException("当前登录异常,请重新登录！");
        }
        return driverPhoneStr;
    }
}
