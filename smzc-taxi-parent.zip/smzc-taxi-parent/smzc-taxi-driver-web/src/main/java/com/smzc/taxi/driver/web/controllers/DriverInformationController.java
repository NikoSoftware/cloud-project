package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.service.driver.bean.DriverPersonalVo;
import com.smzc.taxi.service.driver.bean.DriverVehicleVo;
import com.smzc.taxi.service.driver.service.IDriverInformationFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author: zhaohui
 * @date: 2019-05-22 17:44
 * @description: 司机相关资料接口
 */
@RestController
@RequestMapping(value = "/driver")
@Slf4j
@Api(tags = "司机相关资料接口")
public class DriverInformationController {

	@Reference
    private IDriverInformationFacade driverInformationFacade;

    /**
     * 司机信息(司机信息+车辆信息)
     */
    @PostMapping("/getDriverInformation")
    @ApiOperation(value = "司机相关信息", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<DriverPersonalVo> getDriverInformation() throws Exception{
        Long driverId = DriverUtils.getCurrentDriverId();
        DriverPersonalVo driverPersonalVo = driverInformationFacade.getDriverInformation(driverId);
        return Response.instance().data(driverPersonalVo);
    }

}
