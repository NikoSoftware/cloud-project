package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSONObject;
import com.smzc.lbs.service.bean.LBSRequest;
import com.smzc.lbs.service.bean.LBSResponse;
import com.smzc.lbs.service.bean.taxi.TaxiVehicleLocationBean;
import com.smzc.lbs.service.facade.ILBS4TaxiFacade;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.common.consts.DriverConst;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.service.driver.bean.DriverPositionRefreshVo;
import com.smzc.taxi.service.driver.bean.PositionTrackAddVo;
import com.smzc.taxi.service.driver.bean.push.DriverMessageDualChannelVo;
import com.smzc.taxi.service.driver.service.IDriverMessagePushFacade;
import com.smzc.taxi.service.driver.service.IPositionFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.BeanUtils;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;


/**
 * 描述：司机位置信息
 *
 * @author sy.z
 * @date 2019/5/15 11:11
 */
@RestController
@Api( value = "司机端-位置信息管理",tags="位置信息管理Controller" )
@RequestMapping(value = "/driver/position")
@Slf4j
public class DriverPositionController {


    @Reference
    private IPositionFacade positionFacade;

    @Reference
    private IDriverMessagePushFacade driverMessagePushFacade;

    @Reference(group = "lbs")
    private ILBS4TaxiFacade lbs4TaxiFacade;

    @Resource(name = "positionRefreshThreadPoolTaskExecutor")
    private ThreadPoolTaskExecutor threadPoolExecutor;



    /**
     * 获取司机历史轨迹（司机端5分钟上报一次接口）调用lbs
     * @date: 2019/5/16 15:11
     * @param: [positionTrackAddVo]
     * @return: com.smzc.taxi.boot.response.Response
     */
    @PostMapping("/vehicleTrack")
    @ApiOperation(value = "获取上传司机历史轨迹（司机端5分钟上报一次接口）", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response getVehicleLocationTrack(@RequestBody @Validated PositionTrackAddVo positionTrackAddVo)throws Exception{
        // 司机参数获取
        Long driverId = DriverUtils.getCurrentDriverId();
        positionTrackAddVo.setDriverId( driverId );
        positionFacade.vehiclePositionTrack( positionTrackAddVo );
        return  Response.instance().build();
    }

    /**
     * 保存司机位置（司机端10s上报一次接口）调用lbs
     * @date: 2019/5/16 15:11
     * @param: [driverPositionRefreshVo]
     * @return: com.smzc.lbs.service.bean.taxi.TaxiNearbyVehicle
     */
    @ApiOperation(value = "保存司机位置", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @PostMapping(value = "/savePosition")
    public Response<DriverMessageDualChannelVo> saveDriverPosition(@RequestBody @Validated DriverPositionRefreshVo driverPositionRefreshVo)throws Exception{
        log.debug("上报位置入参：{}",driverPositionRefreshVo);
        // 司机参数获取
        Long driverId = DriverUtils.getCurrentDriverId();
        driverPositionRefreshVo.setDriverId( driverId );
        // 拉取消息内容
        DriverMessageDualChannelVo dualChannelVo = driverMessagePushFacade.getDualChannelVoByDriverId(driverId);
        // 验证数据规则
        threadPoolExecutor.execute(()->{
            log.debug("上报位置入参-2：{}",driverPositionRefreshVo);
            if(null == Strings.trimToNull(driverPositionRefreshVo.getAreaCode()) || DriverConst.NULL_STR.equals(driverPositionRefreshVo.getAreaCode().trim().toLowerCase())){
                log.error("司机注册绑定城市AreaCode为空/null:{}",driverPositionRefreshVo);
                return;
            }
            TaxiVehicleLocationBean vehiclePosition = new TaxiVehicleLocationBean();
            BeanUtils.copyProperties(driverPositionRefreshVo, vehiclePosition);
            vehiclePosition.setLat(driverPositionRefreshVo.getLatitude().doubleValue());
            vehiclePosition.setLng(driverPositionRefreshVo.getLongitude().doubleValue());
            vehiclePosition.setCurrentTime(System.currentTimeMillis());
            LBSResponse response = lbs4TaxiFacade.refreshTaxiVehicleLocation( LBSRequest.instance().data(vehiclePosition));
            log.debug("上报位置返回：{}",JSONObject.toJSONString(response));
            if(null == response || !response.isSuccess()){
                log.error("调用LBS服务保存/更新司机位置信息失败,{}",vehiclePosition);
            }
        });
        return  Response.instance().data(dualChannelVo);
    }


}
