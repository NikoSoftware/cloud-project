package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.github.pagehelper.PageInfo;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.service.driver.bean.basic.BaseRespVo;
import com.smzc.taxi.service.driver.bean.order.*;
import com.smzc.taxi.service.driver.service.IDriverOrdersFacade;
import com.smzc.taxi.service.order.bean.vo.OrderPlanGPSVo;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.smzc.taxi.service.order.emun.PlatformType;
import com.smzc.taxi.service.order.facade.IDriverOrderFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.Assert;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author xiaohb
 * @description: 出租车司机订单
 * @date 2019/5/20 11:32
 */
@RestController
@RequestMapping(value="/driverOrders")
@Slf4j
@Api(tags = "出租车司机订单")
public class DriverOrdersController {

	@Reference
    private IDriverOrdersFacade driverOrdersFacade;// 司机
	@Reference
    private IDriverOrderFacade driverOrderFacade;// 订单

    @PostMapping("/saveOrderPlanGPS")
    @ApiOperation(value = "订单GPS规划路径", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<String> saveOrderPlanGPS(@RequestBody OrderPlanGPSVo reqVo)throws Exception{
        Assert.notNull(reqVo, "对象不能为空");
        Assert.notNull(reqVo.getOrderId(), "订单id不能为空");
        Assert.notEmpty(reqVo.getGpsList(), "规划路径GPS集合不能为空");

        driverOrderFacade.saveOrderPlanGPS(reqVo);
        return  Response.instance().code(CommonCode.SUCCESS.getCode()).message(CommonCode.SUCCESS.getMessage()).data(null);
    }

    @PostMapping("/queryDrivingOrderId")
    @ApiOperation(value = "获取司机服务中订单", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<String> queryDrivingOrderId()throws Exception{
        return  Response.instance().code(CommonCode.SUCCESS.getCode()).message(CommonCode.SUCCESS.getMessage()).data(driverOrdersFacade.queryDrivingOrderId(DriverUtils.getCurrentDriverId()));
    }

    @PostMapping("/getWaitReceive")
    @ApiOperation(value = "司机待接订单列表", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<List<OrderListRespVo>> getWaitReceive(@RequestBody @Validated OrderWaitReceiveVo vo)throws Exception{
        return  Response.instance().code(CommonCode.SUCCESS.getCode()).message(CommonCode.SUCCESS.getMessage()).data(driverOrdersFacade.getWaitReceive(vo, DriverUtils.getCurrentDriverId()));
    }

    @PostMapping("/queryDriverReceivedOrderList")
    @ApiOperation(value = "司机已确认订单列表", notes = "toke参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<List<OrderDetailVo>> queryDriverReceivedOrderList() throws Exception{
        return  Response.instance().code(CommonCode.SUCCESS.getCode()).message(CommonCode.SUCCESS.getMessage()).data(driverOrdersFacade.queryDriverReceivedOrderList(DriverUtils.getCurrentDriverId()));
    }

    @PostMapping("/robOrder")
    @ApiOperation(value = "司机抢单", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<BaseRespVo> robOrder(@RequestBody @Validated robOrderVo vo) throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PHONE);
        BaseRespVo respVo = driverOrdersFacade.robOrder(vo, DriverUtils.getCurrentDriverId());
        return  Response.instance().code(respVo.getCode()).message(respVo.getMessage()).data(null);
    }

    @PostMapping("/queryDriverReceivedOrderDetail")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "司机订单详情", notes = "json格式输入参数，有返回数据")
    public Response<OrderDetailRespVo> queryDriverReceivedOrderDetail(@RequestBody @Validated OrderIdReqVo vo)throws Exception{
        OrderDetailRespVo respVo = driverOrdersFacade.queryDriverReceivedOrderDetail(vo.getOrderId(), DriverUtils.getCurrentDriverId());
        return  Response.instance().code(respVo.getRespCode().getCode()).message(respVo.getRespCode().getMessage()).data(respVo);
    }

    @PostMapping("/driverArriveStartPoint")
    @ApiOperation(value = "司机订单到达上车点", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<OrderDetailRespVo> driverArriveStartPoint(@RequestBody @Validated OrderReqVo vo)throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PHONE);
        OrderDetailRespVo respVo = driverOrdersFacade.driverArriveStartPoint(vo, DriverUtils.getCurrentDriverId());
        return  Response.instance().code(respVo.getRespCode().getCode()).message(respVo.getRespCode().getMessage()).data(respVo);
    }

    @PostMapping("/driverReceivePassenger")
    @ApiOperation(value = "司机订单乘客已上车", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<OrderDetailRespVo> driverReceivePassenger(@RequestBody @Validated OrderReqVo vo)throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PHONE);
        OrderDetailRespVo respVo = driverOrdersFacade.driverReceivePassenger(vo, DriverUtils.getCurrentDriverId());
        return  Response.instance().code(respVo.getRespCode().getCode()).message(respVo.getRespCode().getMessage()).data(respVo);
    }

    @PostMapping("/driverArriveEndPoint")
    @ApiOperation(value = "司机订单乘客已下车", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<OrderDetailRespVo> driverArriveEndPoint(@RequestBody @Validated OrderReqVo vo)throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PHONE);
        OrderDetailRespVo respVo =  driverOrdersFacade.driverArriveEndPoint(vo, DriverUtils.getCurrentDriverId());
        return  Response.instance().code(respVo.getRespCode().getCode()).message(respVo.getRespCode().getMessage()).data(respVo);
    }

    @PostMapping("/addPayOffDetails")
    @ApiOperation(value = "司机订单发起收款", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<BaseRespVo> addPayOffDetails(@RequestBody @Validated OrderPayOffDetailsVo vo)throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PHONE);
        BaseRespVo respVo = driverOrdersFacade.addPayOffDetails(vo, DriverUtils.getCurrentDriverId());
        return  Response.instance().code(respVo.getCode()).message(respVo.getMessage()).data(null);
    }

    @PostMapping("/addPayoff")
    @ApiOperation(value = "司机订单线下收取车费", notes = "json格式输入参数，有返回数据")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    public Response<BaseRespVo> addPayoff(@RequestBody @Validated OrderIdReqVo vo)throws Exception{
        vo.setPlatformType(PlatformType.ANDROID_PHONE);
        vo.setDriverId(DriverUtils.getCurrentDriverId());
        BaseRespVo respVo = driverOrdersFacade.addPayoff(vo, DriverUtils.getCurrentDriverId());
        return  Response.instance().code(respVo.getCode()).message(respVo.getMessage()).data(null);
    }

    @PostMapping("/queryNotes")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "查询司机某个订单的留言", notes = "json格式输入参数，查询全部，有返回数据")
    public Response<List<DriverOrderNoteRespVo>> queryNotes(@RequestBody @Validated OrderIdReqVo query){
        List<DriverOrderNoteRespVo> respVos = driverOrdersFacade.queryNotes(query);
        return Response.instance().data(respVos);
    }

    @PostMapping("/readNote")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "司机读取留言", notes = "json格式输入参数，无返回数据")
    public Response readNote(@RequestBody @Validated DriverOrderNoteReadReqVo req){
        driverOrdersFacade.readNote(req);
        return Response.instance().build();
    }

    @PostMapping("/addCallingRecord")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "添加拨打电话记录", notes = "json格式输入参数，无返回数据")
    public Response addCallingRecord(@RequestBody @Validated OrderIdReqVo req){
        driverOrdersFacade.addCallingRecord(req);
        return Response.instance().build();
    }

    @PostMapping("/smsNotifyPassenger")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "司机到达上车地点短信通知乘客", notes = "json格式输入参数，无返回数据")
    public Response smsNotifyPassenger(@RequestBody @Validated OrderIdReqVo req){
        driverOrdersFacade.smsNotifyPassenger(req);
        return Response.instance().build();
    }

    @PostMapping("/queryPassengerLastPosition")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "乘客最新位置获取", notes = "json格式输入参数，有返回数据")
    public Response<DriverOrderPassengerPositionRespVo> queryPassengerLastPosition(@RequestBody @Validated OrderIdReqVo query){
        DriverOrderPassengerPositionRespVo respVo = driverOrdersFacade.queryPassengerLastPosition(query);
        return Response.instance().data(respVo);
    }

    @PostMapping("/queryPageHistoryOrders")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @ApiOperation(value = "司机历史订单查询", notes = "json格式输入参数，分页查询，有返回数据")
    public Response<PageInfo<DriverOrderHistoryRespVo>> queryPageHistoryOrders(@RequestBody @Validated DriverOrderHistoryQryVo query)throws Exception{
        Long driverId = DriverUtils.getCurrentDriverId();
        query.setDriverId(driverId);
        PageInfo<DriverOrderHistoryRespVo> pageInfo = driverOrdersFacade.queryPageHistoryOrders(query);
        return Response.instance().data(pageInfo);
    }

}
