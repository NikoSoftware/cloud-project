package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.service.driver.bean.DriverTakenRecordResultVo;
import com.smzc.taxi.service.driver.bean.DriverTakenReqVo;
import com.smzc.taxi.service.driver.service.IDriverTakenRecordFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 描述：司机听单记录信息
 *
 * @author sy.z
 * @date 2019/5/15 11:13
 */
@RestController
@Api( value = "司机端-司机听单/收入信息",tags="司机听单记录信息Controller" )
@RequestMapping(value = "/driver/taken")
public class DriverTakenRecordController {

    @Reference
    IDriverTakenRecordFacade driverTakenRecordFacade;

    @ApiOperation(value = "开始/停止听单", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "操作成功"))
    @PostMapping(value = "/takenOrder")
    public Response<DriverTakenRecordResultVo> addTakeOrderRecode(@RequestBody @Validated DriverTakenReqVo driverTakenReqVo) throws Exception{
        // 司机参数获取
        Long driverId = DriverUtils.getCurrentDriverId();
        driverTakenReqVo.setDriverId( driverId );
        return Response.instance().data(driverTakenRecordFacade.addDriverTakenRecord( driverTakenReqVo ));
    }
}
