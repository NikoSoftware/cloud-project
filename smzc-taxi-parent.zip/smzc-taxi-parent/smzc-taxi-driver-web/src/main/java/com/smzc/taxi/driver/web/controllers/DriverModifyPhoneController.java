package com.smzc.taxi.driver.web.controllers;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.HttpResponseEnum;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.driver.web.common.DriverUtils;
import com.smzc.taxi.driver.web.common.RegexUtils;
import com.smzc.taxi.service.driver.bean.DriverModifyPhoneCodeReqVo;
import com.smzc.taxi.service.driver.bean.DriverModifyPhoneReqVo;
import com.smzc.taxi.service.driver.bean.basic.BaseRespVo;
import com.smzc.taxi.service.driver.service.IDriverModifyPhoneFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author xiaohb
 * @description: 司机修改手机号码
 * @date 2019/7/8 15:35
 */
@RestController
@RequestMapping(value="/driverModifyPhone")
@Slf4j
@Api(tags = "司机修改手机号码")
public class DriverModifyPhoneController {

    @Reference
    private IDriverModifyPhoneFacade driverModifyPhoneFacade;

    @PostMapping("/modifyPhoneValidateCode")
    @ApiOperation(value = "获取修改手机号码验证码", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "发送成功"))
    public Response modifyPhoneValidateCode(@RequestBody @Validated DriverModifyPhoneCodeReqVo reqVo) throws Exception{
        boolean isMobilePhone = RegexUtils.isMobilePhone(reqVo.getNewMobileNo());
        if (!isMobilePhone) {
            return Response.instance().code(HttpResponseEnum.DRIVER_DATA_FORMAT_ERROR.code).message("手机格式匹配!").build();
        }
        if (reqVo.getNewMobileNo().equals(DriverUtils.getCurrentDriverMobilePhone())){
            return Response.instance().code(HttpResponseEnum.DATA_EXISTING.code).message("该手机号与当前绑定的手机号相同").build();
        }
        reqVo.setDriverId(DriverUtils.getCurrentDriverId());
        BaseRespVo baseRespVo = driverModifyPhoneFacade.modifyPhoneValidateCode(reqVo);
        return Response.instance().code(baseRespVo.getCode()).message(baseRespVo.getMessage()).build();
    }

    @PostMapping("/modifyPhone")
    @ApiOperation(value = "修改司机手机号码", notes = "json格式输入参数")
    @ApiResponses(@ApiResponse(code = 200, message = "发送成功"))
    public Response modifyPhone(@RequestBody @Validated DriverModifyPhoneReqVo reqVo) throws Exception{
        boolean isMobilePhone = RegexUtils.isMobilePhone(reqVo.getNewMobileNo());
        if (!isMobilePhone) {
            return Response.instance().code(HttpResponseEnum.DRIVER_DATA_FORMAT_ERROR.code).message("手机格式不匹配!").build();
        }
        String mobilePhone = DriverUtils.getCurrentDriverMobilePhone();
        if (reqVo.getNewMobileNo().equals(mobilePhone)){
            return Response.instance().code(HttpResponseEnum.DATA_EXISTING.code).message("该手机号与当前绑定的手机号相同").build();
        }
        reqVo.setDriverId(DriverUtils.getCurrentDriverId());
        reqVo.setOldMobileNo(mobilePhone);
        BaseRespVo baseRespVo = driverModifyPhoneFacade.modifyPhone(reqVo);
        return Response.instance().code(baseRespVo.getCode()).message(baseRespVo.getMessage()).build();
    }

}
