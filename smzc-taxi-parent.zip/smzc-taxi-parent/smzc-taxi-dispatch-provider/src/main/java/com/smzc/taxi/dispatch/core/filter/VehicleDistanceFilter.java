package com.smzc.taxi.dispatch.core.filter;


import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.lbs.service.bean.CircleAreaArgs;
import com.smzc.lbs.service.bean.LBSRequest;
import com.smzc.lbs.service.bean.LBSResponse;
import com.smzc.lbs.service.bean.taxi.TaxiNearbyVehicle;
import com.smzc.lbs.service.facade.ILBS4TaxiFacade;
import com.smzc.taxi.dispatch.core.annotation.DispatchFilter;
import com.smzc.taxi.service.dispatch.bean.DispatchTaxiVehicleBean;
import com.smzc.taxi.service.dispatch.bean.RecommendedVehicle;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collection;

/**
 * Created by duankun on 2019/5/13.
 */
@Component
@DispatchFilter(chain = DispatchFilterChain.VEHICLE, name = "vehicleDistanceFilter", order = 1)
public class VehicleDistanceFilter implements SimpleDispatchFilter<DispatchTaxiVehicleBean, RecommendedVehicle> {
    @Reference(group = "lbs")
    ILBS4TaxiFacade lbs4TaxiFacade;

    @Override
    public Object doFilter(DispatchTaxiVehicleBean request, Collection<RecommendedVehicle> data) {
        LBSResponse<Collection<TaxiNearbyVehicle>> lbsResponse = lbs4TaxiFacade.nearbyVehicle(LBSRequest.instance().data(CircleAreaArgs.instance().areaCode(request.getAreaCode()).lng(request.getStartLng()).lat(request.getStartLat()).radius(request.getRadius())));
        if(!CollectionUtils.isEmpty(lbsResponse.getData())) {
            lbsResponse.getData().stream().forEach(taxiNearbyVehicle -> data.add(RecommendedVehicle.instance().vehicleId(taxiNearbyVehicle.getVehicleId())));
        }
        return null;
    }

}
