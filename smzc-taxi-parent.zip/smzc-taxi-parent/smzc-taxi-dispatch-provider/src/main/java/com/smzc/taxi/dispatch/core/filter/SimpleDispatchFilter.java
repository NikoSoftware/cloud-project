package com.smzc.taxi.dispatch.core.filter;

import java.util.Collection;

/**
 * Created by duankun on 2019/5/13.
 */
public interface SimpleDispatchFilter<R, D> {
    Object doFilter(R request, Collection<D> data);
}
