package com.smzc.taxi;


import com.alibaba.druid.spring.boot.autoconfigure.DruidDataSourceAutoConfigure;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(exclude = {MongoAutoConfiguration.class, DruidDataSourceAutoConfigure.class})
@EnableScheduling
@ImportResource(value = {"classpath*:dubbo-*.xml"})
@ComponentScan(basePackages = {"com.smzc.taxi.dispatch", "com.smzc.taxi.boot.datasource"})
public class DispatchProviderApplication {
    public static void main(String[] args) {
        SpringApplication.run(DispatchProviderApplication.class, args);
    }
}
