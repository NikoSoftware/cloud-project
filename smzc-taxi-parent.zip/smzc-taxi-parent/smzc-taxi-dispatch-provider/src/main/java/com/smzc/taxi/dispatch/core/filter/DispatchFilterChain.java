package com.smzc.taxi.dispatch.core.filter;

import com.alibaba.fastjson.JSON;
import com.smzc.taxi.dispatch.core.annotation.DispatchFilter;
import com.smzc.taxi.service.dispatch.bean.DispatchTaxiOrderBean;
import com.smzc.taxi.service.dispatch.bean.DispatchTaxiVehicleBean;
import com.smzc.taxi.service.dispatch.bean.RecommendedOrder;
import com.smzc.taxi.service.dispatch.bean.RecommendedVehicle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * Created by duankun on 2019/5/13.
 */
@Component
public class DispatchFilterChain implements ApplicationContextAware {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    public static final String VEHICLE = "vehicle";
    public static final String ORDER = "order";
    private ApplicationContext applicationContext;
    private Collection<SimpleDispatchFilter> vehicleFilterChain;
    private Collection<SimpleDispatchFilter> orderFilterChain;

    public synchronized void initFilterChain() {
        logger.info("filterChains initialize start");
        Map<String, Object> filterMap = applicationContext.getBeansWithAnnotation(DispatchFilter.class);
        if (CollectionUtils.isEmpty(filterMap)) {
            return;
        }
        Map<String, Map<Integer, SimpleDispatchFilter>> orderedFilterMap = new HashMap<>();
        for (Object obj : filterMap.values()) {
            if (!(obj instanceof SimpleDispatchFilter)) {
                continue;
            }
            DispatchFilter dispatchFilter = AopUtils.getTargetClass(obj).getAnnotation(DispatchFilter.class);
            int order = dispatchFilter.order();
            String chain = dispatchFilter.chain();
            String name = dispatchFilter.name();
            logger.info("add filter:{} order:{} to chain:{}", name, order, chain);
            if (orderedFilterMap.get(chain) == null) {
                orderedFilterMap.put(chain, new TreeMap<>());
            }
            orderedFilterMap.get(chain).put(order, (SimpleDispatchFilter) obj);
        }
        vehicleFilterChain = orderedFilterMap.get(VEHICLE).values();
        orderFilterChain = orderedFilterMap.get(ORDER).values();
        logger.info("filterChains initialize completed");
    }

    public Collection<RecommendedVehicle> doFilterVehicle(DispatchTaxiVehicleBean dispatchTaxiVehicleBean) {
        Collection<RecommendedVehicle> recommendedVehicles = new ArrayList<>();
        for (SimpleDispatchFilter filter : vehicleFilterChain) {
            Object filterResult = filter.doFilter(dispatchTaxiVehicleBean, recommendedVehicles);
            if (CollectionUtils.isEmpty(recommendedVehicles) || (filterResult != null && filterResult instanceof Boolean && !((Boolean) filterResult))) {
                logger.warn("orderNo:{} vehicle filter:{} break filterResult:{} results:{}", dispatchTaxiVehicleBean.getOrderNo(), filter.getClass().getSimpleName(), filterResult, JSON.toJSONString(recommendedVehicles));
                break;
            }
            logger.info("orderNo:{} filter:{} doFilter results:{}", dispatchTaxiVehicleBean.getOrderNo(), filter.getClass().getSimpleName(), JSON.toJSONString(recommendedVehicles));
        }
        return recommendedVehicles;
    }

    public Collection<RecommendedOrder> doFilterOrder(DispatchTaxiOrderBean dispatchTaxiOrderBean) {
        Collection<RecommendedOrder> recommendedOrders = new ArrayList<>();
        for (SimpleDispatchFilter filter : orderFilterChain) {
            filter.doFilter(dispatchTaxiOrderBean, recommendedOrders);
            if (CollectionUtils.isEmpty(recommendedOrders)) {
                logger.warn("driverId:{} order filter:{} break because result empty", dispatchTaxiOrderBean.getDriverId(), filter.getClass().getSimpleName());
                break;
            }
            logger.info("driverId:{} filter:{} doFilter results:{}", dispatchTaxiOrderBean.getDriverId(), filter.getClass().getSimpleName(), JSON.toJSONString(recommendedOrders));
        }
        return recommendedOrders;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
        this.initFilterChain();
    }

}
