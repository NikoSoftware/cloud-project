package com.smzc.taxi.dispatch.core.filter;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.smzc.taxi.dispatch.core.annotation.DispatchFilter;
import com.smzc.taxi.service.dispatch.bean.DispatchTaxiVehicleBean;
import com.smzc.taxi.service.dispatch.bean.RecommendedVehicle;
import com.smzc.taxi.service.driver.bean.DriverWorkStateVo;
import com.smzc.taxi.service.driver.enums.DriverWorkStateEnum;
import com.smzc.taxi.service.driver.service.IDriverFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by duankun on 2019/5/21.
 */
@Component
@DispatchFilter(chain = DispatchFilterChain.VEHICLE, name = "driverStatusFilter", order = 2)
public class DriverStatusFilter implements SimpleDispatchFilter<DispatchTaxiVehicleBean, RecommendedVehicle> {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    @Reference(version = "1.0.0")
    IDriverFacade driverFacade;

    @Override
    public Object doFilter(DispatchTaxiVehicleBean request, Collection<RecommendedVehicle> data) {
        List<DriverWorkStateVo> driverWorkStates = driverFacade.driverWorkState(data.stream().map(RecommendedVehicle::getVehicleId).collect(Collectors.toList()));
        logger.info("find driver work state parameters:{} results:{}", JSON.toJSONString(data), JSON.toJSONString(driverWorkStates));
        Iterator<RecommendedVehicle> it = data.iterator();
        List<RecommendedVehicle> removedVehicles = new ArrayList<>();
        if (request.getFictitiousOrder()) {
            while (it.hasNext()) {
                RecommendedVehicle recommendedVehicle = it.next();
                DriverWorkStateVo driverWorkState = this.findDriverWorkState(driverWorkStates, recommendedVehicle.getVehicleId());
                if (driverWorkState == null || driverWorkState.getDriverId() != null) {
                    removedVehicles.add(recommendedVehicle);
                    it.remove();
                }
            }
            logger.info("current order:{} is fictitious order,remove vehicles:{} whose driver is online", request.getOrderNo(), JSON.toJSONString(removedVehicles));
        } else {
            while (it.hasNext()) {
                RecommendedVehicle recommendedVehicle = it.next();
                DriverWorkStateVo driverWorkState = this.findDriverWorkState(driverWorkStates, recommendedVehicle.getVehicleId());
                if (driverWorkState == null || driverWorkState.getDriverId() == null || driverWorkState.getWorkStatus() != DriverWorkStateEnum.DRIVER_WAITING) {
                    removedVehicles.add(recommendedVehicle);
                    it.remove();
                    continue;
                }
                recommendedVehicle.setDriverId(driverWorkState.getDriverId());
            }
            logger.info("current order:{} is real order,remove vehicles:{} whose driver is not standby", request.getOrderNo(), JSON.toJSONString(removedVehicles));
        }
        return !request.getFictitiousOrder();
    }

    private DriverWorkStateVo findDriverWorkState(List<DriverWorkStateVo> driverWorkStates, Long vehicleId) {
        Optional<DriverWorkStateVo> optional = driverWorkStates.stream().filter(driverWorkState -> driverWorkState.getVehicleId().longValue() == vehicleId.longValue()).findFirst();
        return optional.isPresent() ? optional.get() : null;
    }
}
