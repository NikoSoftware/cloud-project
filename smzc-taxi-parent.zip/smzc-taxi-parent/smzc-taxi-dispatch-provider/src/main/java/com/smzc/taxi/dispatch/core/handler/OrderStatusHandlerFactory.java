package com.smzc.taxi.dispatch.core.handler;

import com.smzc.taxi.dispatch.core.annotation.OrderStatusHandler;
import com.smzc.taxi.dispatch.util.Assert;
import com.smzc.taxi.service.dispatch.bean.OrderInfoBean;
import com.smzc.taxi.service.order.emun.OrderStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by duankun on 2019/5/14.
 */
@Component
public class OrderStatusHandlerFactory implements ApplicationContextAware {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private ApplicationContext applicationContext;
    private Map<OrderStatus, SimpleOrderStatusHandler> orderStatusHandlers;
    private final DefaultOrderStatusHandler defaultOrderStatusHandler = new DefaultOrderStatusHandler();

    private synchronized void initOrderStatusHandlerFactory() {
        logger.info("OrderStatusHandlerFactory initialize start");
        Map<String, Object> handlerMap = applicationContext.getBeansWithAnnotation(OrderStatusHandler.class);
        if (CollectionUtils.isEmpty(handlerMap)) {
            return;
        }
        orderStatusHandlers = new HashMap<>();
        for (Object obj : handlerMap.values()) {
            if (!(obj instanceof SimpleOrderStatusHandler)) {
                continue;
            }
            OrderStatusHandler orderStatusHandler = AopUtils.getTargetClass(obj).getAnnotation(OrderStatusHandler.class);
            OrderStatus[] orderStatuses = orderStatusHandler.orderStatus();
            for (OrderStatus os : orderStatuses) {
                Assert.isNull(orderStatusHandlers.get(os),"multi orderStatusHandler found for orderStatus:" + os);
                orderStatusHandlers.put(os, (SimpleOrderStatusHandler) obj);
            }
        }
        this.applicationContext.getAutowireCapableBeanFactory().autowireBean(defaultOrderStatusHandler);
        logger.info("OrderStatusHandlerFactory initialize completed");
    }

    public SimpleOrderStatusHandler getOrderStatusHandler(OrderStatus orderStatus) {
        SimpleOrderStatusHandler handler = orderStatusHandlers.get(orderStatus);
        return handler == null ? defaultOrderStatusHandler : handler;
    }


    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
        this.initOrderStatusHandlerFactory();
        OrderInfoBean orderInfoBean = new OrderInfoBean();
        orderInfoBean.setAreaCode("028");
        orderInfoBean.setOrderNo("123012fas");
        orderInfoBean.setStartLat(31.12341);
        orderInfoBean.setStartLng(104.12312);
        orderInfoBean.setOrderStatus(OrderStatus.CANCEL);
        this.getOrderStatusHandler(orderInfoBean.getOrderStatus()).doHandle(orderInfoBean);
    }
}