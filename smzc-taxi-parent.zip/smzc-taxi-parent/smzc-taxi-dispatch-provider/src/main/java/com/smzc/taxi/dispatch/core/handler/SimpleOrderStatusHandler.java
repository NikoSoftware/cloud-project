package com.smzc.taxi.dispatch.core.handler;

import com.smzc.taxi.service.dispatch.bean.OrderInfoBean;

/**
 * Created by duankun on 2019/5/14.
 */
public interface SimpleOrderStatusHandler {
    void doHandle(OrderInfoBean orderInfoBean);
}
