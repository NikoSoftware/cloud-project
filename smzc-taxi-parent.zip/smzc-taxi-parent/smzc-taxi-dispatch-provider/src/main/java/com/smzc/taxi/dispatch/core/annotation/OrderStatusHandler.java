package com.smzc.taxi.dispatch.core.annotation;

import com.smzc.taxi.service.order.emun.OrderStatus;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by duankun on 2019/5/20.
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface OrderStatusHandler {
    OrderStatus[] orderStatus();
}
