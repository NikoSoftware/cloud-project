package com.smzc.taxi.dispatch.core.filter;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.lbs.service.bean.CircleAreaArgs;
import com.smzc.lbs.service.bean.LBSRequest;
import com.smzc.lbs.service.bean.LBSResponse;
import com.smzc.lbs.service.bean.taxi.TaxiNearbyOrder;
import com.smzc.lbs.service.facade.ILBS4TaxiFacade;
import com.smzc.taxi.dispatch.core.annotation.DispatchFilter;
import com.smzc.taxi.service.dispatch.bean.DispatchTaxiOrderBean;
import com.smzc.taxi.service.dispatch.bean.RecommendedOrder;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collection;

/**
 * Created by duankun on 2019/5/21.
 */
@Component
@DispatchFilter(chain = DispatchFilterChain.ORDER, name = "orderDistanceFilter", order = 1)
public class OrderDistanceFilter implements SimpleDispatchFilter<DispatchTaxiOrderBean, RecommendedOrder> {
    @Reference(group = "lbs")
    ILBS4TaxiFacade lbs4TaxiFacade;

    @Override
    public Object doFilter(DispatchTaxiOrderBean request, Collection<RecommendedOrder> data) {
        LBSResponse<Collection<TaxiNearbyOrder>> lbsResponse = lbs4TaxiFacade.nearbyOrder(LBSRequest.instance().data(CircleAreaArgs.instance().areaCode(request.getAreaCode()).lng(request.getLng()).lat(request.getLat()).radius(request.getRadius())));
        if(!CollectionUtils.isEmpty(lbsResponse.getData())) {
            lbsResponse.getData().stream().forEach(taxiNearbyOrder -> data.add(RecommendedOrder.instance().orderNo(taxiNearbyOrder.getOrderNo())));
        }
        return null;
    }

}
