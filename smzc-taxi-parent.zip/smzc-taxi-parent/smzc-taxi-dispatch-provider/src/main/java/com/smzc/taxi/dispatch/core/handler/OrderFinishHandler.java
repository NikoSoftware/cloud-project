package com.smzc.taxi.dispatch.core.handler;

import com.smzc.taxi.dispatch.core.annotation.OrderStatusHandler;
import com.smzc.taxi.service.dispatch.bean.OrderInfoBean;
import com.smzc.taxi.service.order.emun.OrderStatus;
import org.springframework.stereotype.Component;

/**
 * Created by duankun on 2019/5/14.
 */
@Component
@OrderStatusHandler(orderStatus = {OrderStatus.WAIT_PAY})
public class OrderFinishHandler implements SimpleOrderStatusHandler {
    @Override
    public void doHandle(OrderInfoBean orderInfoBean) {

    }
}
