package com.smzc.taxi.dispatch.core.handler;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.lbs.service.bean.LBSRequest;
import com.smzc.lbs.service.bean.taxi.TaxiOrderBean;
import com.smzc.lbs.service.facade.ILBS4TaxiFacade;
import com.smzc.taxi.dispatch.core.annotation.OrderStatusHandler;
import com.smzc.taxi.service.dispatch.bean.OrderInfoBean;
import com.smzc.taxi.service.order.emun.OrderStatus;
import org.springframework.stereotype.Component;

/**
 * Created by duankun on 2019/5/14.
 */
@Component
@OrderStatusHandler(orderStatus = {OrderStatus.CANCEL, OrderStatus.REJECTED, OrderStatus.SYS_CANCEL})
public class OrderCancelHandler implements SimpleOrderStatusHandler {
    @Reference(group = "lbs")
    ILBS4TaxiFacade lbs4TaxiFacade;

    @Override
    public void doHandle(OrderInfoBean orderInfoBean) {
        TaxiOrderBean taxiOrderBean = new TaxiOrderBean();
        taxiOrderBean.setOrderNo(orderInfoBean.getOrderNo());
        taxiOrderBean.setAreaCode(orderInfoBean.getAreaCode());
        taxiOrderBean.setCommand(TaxiOrderBean.Command.REMOVE);
        lbs4TaxiFacade.syncTaxiOrder(LBSRequest.instance().data(taxiOrderBean));
    }
}
