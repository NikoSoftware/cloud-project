package com.smzc.taxi.common.third.safetycall.util.encoder;

import java.io.IOException;

public class CEStreamExhausted extends IOException
{

}
