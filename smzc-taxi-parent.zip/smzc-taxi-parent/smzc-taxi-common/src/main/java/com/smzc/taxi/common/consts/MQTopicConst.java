package com.smzc.taxi.common.consts;

public final class MQTopicConst {
    public static final String SMS = "taxi_sms";
    public static final String DING_DING_MSG = "taxi_ding_ding_msg";

    /**
     * 出租车订单消息
     */
    public static final String TAXI_ORDER = "taxi_order";

    /**
     * 司机工作状态TOPIC
     */
    public static final String TAXI_DRIVER_WORK_STATUS = "taxi_driver_work_status";



    /**
     * 出租车中控消息
     */
    public static final String TAXI_CENTER_CONTROLLER = "taxi_center_controller";
    public static final String TAXI_OPEN_ORDER_INFO = "taxi_open_order_info";


    /**
     * 司机审核topic
     */
    public static final String TAXI_DRIVER_AUDIT = "taxi_driver_audit";

    /**
     * @Description: 司机听单状态扭转topic(同步中控平台和手机端状态)
     * @Author: Yb.Z
     * @create: 2019/06/10 16:58
     */
    // update by zyb 2019-06-18 统一使用TAXI_DRIVER_WORK_STATUS作为topic，用tag来区分
    // public static final String TAXI_DRIVER_STATUS = "taxi_driver_status";

    /**
     * 订单线下收款分布式事务
     */
    public static final String TAXI_DRIVER_CASH_RECEIVABLE = "taxi_driver_cash_receivable";
    /**
     * 支付完成订单处理失败topic
     */
    public static final String TAXI_ORDER_PAYOFF_FAIL = "taxi_order_payoff_fail";
}
