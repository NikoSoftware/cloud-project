package com.smzc.taxi.common.enums;

/**
 * @Description
 * @Date 2019/7/1 10:17
 * @Created by  zhaohui
 */
public enum DateTypeEnum {
    BEGIN(1, "一天中的开始时间"),
    END(2, "一天中的结束时间");

    public Integer value;

    public String message;

    DateTypeEnum(Integer status, String message) {
        this.value = status;
        this.message = message;
    }



    public Integer getStatus() {
        return value;
    }

    public void setStatus(Integer status) {
        this.value = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
