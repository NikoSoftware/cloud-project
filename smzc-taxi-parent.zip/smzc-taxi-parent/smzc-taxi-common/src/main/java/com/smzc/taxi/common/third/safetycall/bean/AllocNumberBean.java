package com.smzc.taxi.common.third.safetycall.bean;

import java.io.Serializable;

/**
 * @Description: 号码申请绑定Bean
 * @author zhukai
 * @date 2019年5月15日 下午2:47:44
 */
public class AllocNumberBean implements Serializable {

    private static final long serialVersionUID = 4107468957623512739L;

    /**
     * 主叫号码
     */
    private String caller;

    /**
     * 被叫号码
     */
    private String callee;

    /*
     * 城市
     */
    private String city;

    /**
     * 订单id
     */
    private String orderId;

    public String getCaller() {

        return caller;
    }

    public void setCaller(String caller) {

        this.caller = caller;
    }

    public String getCallee() {

        return callee;
    }

    public void setCallee(String callee) {

        this.callee = callee;
    }

    public String getCity() {

        return city;
    }

    public void setCity(String city) {

        this.city = city;
    }

    public String getOrderId() {

        return orderId;
    }

    public void setOrderId(String orderId) {

        this.orderId = orderId;
    }

}
