package com.smzc.taxi.common.third.safetycall.constant;


public class YtxConstant {
    /**
     * 租用时间(4小时)
     */
    public static Integer LEASE_TIME = 4 * 60 * 60;

    /**
     * 编码类型
     */
    public static String CHARSET = "utf-8";

    /**
     * 签名类型
     */
    public static String SIGN_TYPE = "MD5";
    /**
     * 成功状态
     */
    public static String SUCESS="000000";

}
