
package com.smzc.taxi.common.consts;

/**
 * @author zhukai
 * @Description:redis常量key放置
 * @date 2019年5月17日 下午4:03:19
 */
public class RedisConst {

    // 出租车价格缓存
    public static final String TAXI_PRICE_AREACODE = "taxi:price:areacode:";
    // 客服电话缓存
    public static final String TAXI_PASSENGER_CONSUMER_SERVICE= "taxi:passenger:consumer:service";

    // SystemConfiguration配置缓存
    public static final String TAXI_SYSTEM_CONFIGURATION = "taxi:system:configuration";

    // 待处理的订单缓存列表
    public static final String TAXI_WAIT_RECEIVE_ORDER = "taxi:wait:receive:order:";
    // redis 锁前缀
    public static final String TAXI_WAIT_LOCK_ORDER = "taxi:wait:lock:order:";

    // 待取消的订单-未抢的
    public static final String WAIT_CANCEL_ORDER = "taxi:wait:cancel:order:";

    // 最大时间缓存
    public static final String TAXIT_WAIT_MAXTIME = "taxi:wait:max:time:";

    /**
     * 乘客未完成的订单记录
     */
    public static final String TAXI_SUB_ORDER_INTRIP = "taxi:order:sub:intrip:";

    /**
     * 订单临时缓存，订单入库后就会删除
     */
    public static final String TAXI_ORDER_TEMP_INFO = "taxi:order:temp:info:";

    public static final String TAXI_ORDER_MQ_UNIQUENESS = "taxi:order:mq:uniqueness:";

    /**
     * 订单状态缓存，生命周期，自动调度到订单结束
     */
    public static final String TAXI_ORDER_STATUS = "taxi:order:status:";

    /**
     * 订单状态缓存，生命周期，自动调度到订单结束
     */
    public static final String TAXI_ORDER_CACHE = "taxi:order:cache:";

    /**
     * 更新车辆位置信息时间信息
     */
    public static final String VEHICLE_POSITION_LAST_TIME = "taxi:vehicle:position:updatedTime:";
    public static final String FAST_ALARM_SMS = "taxi:fast_alarm:sms_msg:";
    public static final String FAST_ALARM_DING_DING_MSG = "taxi:fast_alarm:ding_ding_msg";
    public static final String JOURNEY_SHARE_ORDER_ID = "taxi:journey:share:orderId";//行程分享订单

    /**
     * 司机端相关
     */
    //司机首页收入统计
    public static final String DRIVER_HOME_DATA_BUCKET = "taxi:driver:homeData:";
    //司机token
    public static final String LOGIN_SESSION_TOKEN_BUCKET = "taxi:driver:login:token:";
    //验证码
    public static final String DRIVER_VALIDATE_CODE_BUCKET = "taxi:driver:login:validateCode:";
    //司机修改手机号码的验证码
    public static final String DRIVER_MODIFY_PHONE_VALIDATE_CODE = "taxi:driver:modifyPhone:validateCode:";
    // 车辆绑的司机和司机状态信息 key:{taxi:vehicle:driver:work:车辆ID} val {VehicleDriverRedisVo}
    public static final String VEHICLE_DRIVER_WORK_STATE="taxi:vehicle:driver:work:state:";
    //中控通过车牌号获取车辆ID,司机ID绑定关系
    public static final String VEHICLENO_DRIVER_WORK_STATE = "taxi:vehicleno:driver:work:state:";
    //车辆绑的司机和司机状态信息 key:{taxi:driver:work:state:司机ID} val:{DriverWorkStateRedisVo}
    public static final String DRIVER_WORK_STATE ="taxi:driver:work:state:";
    //听单/ 停止听单操作频率 key:{taxi:driver:taken:time:interval:司机ID} val: 时间戳
    public static final String DRIVER_TAKEN_TIME_INTERVAL = "taxi:driver:taken:time:interval:";
    // 司机抢单过程中时间间隔 key:{taxi:driver:rob:order:time:interval:司机ID} val: 无
    public static final String DRIVER_ROB_ORDER_TIME_INTERVAL = "taxi:driver:rob:order:time:interval:";
    //向出租车司机极光推送消息双通道
    public static final String TAXI_DRIVER_MESSAGE_PUSH = "taxi:driver:message:push:";
    //向出租车司机定时预约推送消息
    public static final String TAXI_DRIVER_MESSAGE_APPOINTMENT = "taxi:driver:message:appointment:";
    //司机订单线下支付生成司机交易记录mq幂等
    public static final String TAXI_DRIVER_MQ_CASH_RECEIVABLE= "taxi:driver:mq:cash:receivable:";
    //司机端TransferOrderStatusConsumer mq幂等
    public static final String TAXI_DRIVER_MQ_TRANSFER_ORDER_STATUS = "taxi:driver:mq:transfer:order:status:";
    //司机端TransferOrderStatusConsumer mq幂等
    public static final String TAXI_DRIVER_MQ_TURN_WORK_STATE = "taxi:driver:mq:turn:woke:state:";
    //司机端DriverAuditConsumer mq幂等
    public static final String TAXI_DRIVER_MQ_DRIVER_AUDIT_RESULT = "taxi:driver:mq:driverAudit:result:";
    //司机端 正在修改的银行卡id
    public static final String TAXI_DRIVER_CHANGING_BANKCARD = "taxi:driver:changing:bankcard:";
    //所有开通城市
    public static final String ALL_OPEN_CITY_LIST = "taxi:driver:allOpenCityList";
    //司机到达上车位置向乘客发送短信次数key
    public static final String TAXI_DRIVER_ARRIVE_SMS_NOTIFY_PASSENGER_COUNT = "taxi:driver:arrive:sms:notify:passenger:count:";
    //司机到达上车位置向乘客发送短信时间频率key
    public static final String TAXI_DRIVER_ARRIVE_SMS_NOTIFY_PASSENGER_FREQUENCY = "taxi:driver:arrive:sms:notify:passenger:frequency:";
    /**
     * 钱包相关
     */
    //司机提现支付密码错误次数
    public static final String DRIVER_WALLET_WITHDRAW_PASSWORD_ERROR_NUMBER = "taxi:driver:withdraw:errorPassword:";
    //提现锁住时间，单位秒
    public static final Integer WITHDRAW_LOCK_TIME = 30 * 60;
    //幂等key失效时间1小时，单位秒
    public static final Long IDEMPOTENT_INVALID_TIME = 60 * 60L;
    // mq发送重试次数
    public static final int RETRY_TIMES = 3;
    //签名预下单
    public static final String  SIGN_PREORDE ="taxi:wallet:preorde:";

    /**
     * 中控相关
     */
    //司机唯一有效token前缀
    public static final String CENTORCONTROL_DRIVER_TOKEN = "taxi:centorcontrol:driver:";
    //车辆唯一有效token前缀
    public static final String CENTORCONTROL_VEHICLE_TOKEN = "taxi:centorcontrol:vehicle:";
    // add by zyb 2019-06-03 向中控设备极光推送消息双通道
    public static final String CENTORCONTROL_PUSH_MESSAGE = "taxi:centorcontrol:push:message:";
    // add end
    // add by zyb 2019-06-04 车牌号对应车辆信息
    public static final String CENTORCONTROL_VEHICLE_NO_TO_VEHICLE_INFO = "taxi:centorcontrol:vehicle:no:info";
    // SyncLocationConsumer 同步gps mq 幂等
    public static final String TAXI_CENTORCONTROL_SYNC_GPS = "taxi:centorcontrol:sync:gps:";
    // add by zyb 2019-06-12 中控端TransferOrderStatusConsumer mq幂等
    public static final String TAXI_CENTORCONTROL_MQ_TRANSFER_ORDER_STATUS = "taxi:centorcontrol:mq:transfer:order:status:";
    // add by luofei  中控端对应服务商接口地址缓存
    public static final String CENTORCONTROL_SERVICEAPI_CONFIG = "taxi:centorcontrol:apiservicekey:";
    /**
     * 车辆相关
     */
    public static final String TAXI_VEHICLE_DETAIL = "taxi:vehicle:detail:";

    /**
     * 乘客端相关
     */
    //乘客端创建订单 Redis Lock 前缀
    public static final String TAXI_CREATE_ORDER = "taxi:passenger:create:order:";
    public static final String TAXI_PASSENGER_OPEN_CITYS = "taxi:passenger:open:citys";
    public static final String TAXI_PASSENGER_BUSINESS_TYPE = "taxi:passenger:business:type";
    public static final String PASSENGER_VALIDATE_CODE_BUCKET = "customer:login:";
    public static final String LOGIN_SESSION_TOKEN_BUCKET_PASSENGER = "customer:login:token:";

    /**
     * 司机自动审核偏移量
     */
    public static final String TAXI_DRIVER_AUTO_AUDIT_OFFSET = "taxi:driver:auto:audit:offset";
    /**
     * 定时到天府银行查询司机审核状态（包括司机入驻审核，银行卡修改）偏移量
     */
    public static final String TAXI_DRIVER_AUDIT_QUERY_OFFSET = "taxi:driver:audit:query:offset";
}

