package com.smzc.taxi.common.third.safetycall.client;

import java.util.Date;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.params.CoreConnectionPNames;

import com.smzc.taxi.common.third.safetycall.bean.AllocNumberBean;
import com.smzc.taxi.common.third.safetycall.bean.FreeNumberBean;
import com.smzc.taxi.common.third.safetycall.conf.SysConfig;
import com.smzc.taxi.common.third.safetycall.util.CcopHttpClient;
import com.smzc.taxi.common.third.safetycall.util.DateUtil;
import com.smzc.taxi.common.third.safetycall.util.EncryptUtil;

/**
 * @Description: 隐号抽象类
 * @author zhukai
 * @date 2019年5月15日 下午2:37:10
 */
public abstract class AbstractSafetyCall {

    public static final String NEW_SETNUMBER = "provide";

    public static final String NEW_RELEASENUMBER = "releaseaxb";

    /**
     * 号码申请绑定
     * 
     * @author zhukai
     * @date 2019年5月15日 下午2:51:28
     * @param allocNumberBean
     * @return
     */
    public abstract String axbSetNumber(AllocNumberBean allocNumberBean);

    /**
     * @author zhukai
     * @date 2019年5月15日 下午2:57:00号码申请解绑
     * @param freeNumberBean
     * @return
     */
    public abstract String axbReleaseNumber(FreeNumberBean freeNumberBean);

    protected HttpClient getCloseableHttpClient() {

        CcopHttpClient chc = new CcopHttpClient();
        HttpClient httpclient = null;
        try {
            httpclient = chc.registerSSL(SysConfig.SERVER_IP, "TLS", SysConfig.SERVER_PORT, "https");
            httpclient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 1000);
            httpclient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 2000);
        } catch(Exception e) {
            e.printStackTrace();
            throw new RuntimeException("初始化httpclient异常" + e.getMessage());
        }
        return httpclient;
    }

    protected HttpPost getHttpPost(String action) throws Exception {

        String timestamp = DateUtil.dateToStr(new Date(), DateUtil.DATE_TIME_NO_SLASH);
        EncryptUtil eu = new EncryptUtil();
        String sig = SysConfig.ACCOUNT_SID + SysConfig.ACCOUNT_TOKEN + timestamp;
        String acountName = SysConfig.ACCOUNT_SID;
        String signature = eu.md5Digest(sig);
        String url = "";
        if(NEW_RELEASENUMBER.equals(action)) {
            url = getBaseUrl().append("/Accounts/").append(acountName).append("/nme/").append("xb").append("/cu12").append("/" + action + "?sig=").append(signature).toString();
        } else {
            url = getBaseUrl().append("/Accounts/").append(acountName).append("/nme/").append("axb").append("/cu12").append("/" + action + "?sig=").append(signature).toString();
        }
        HttpPost httpPost = new HttpPost(url);
        setHttpHeader(httpPost);
        String src = acountName + ":" + timestamp;
        String auth = eu.base64Encoder(src);
        httpPost.setHeader("Authorization", auth);
        return httpPost;
    }

    protected StringBuffer getBaseUrl() {

        StringBuffer sb = new StringBuffer("https://");
        sb.append(SysConfig.SERVER_IP).append(":").append(SysConfig.SERVER_PORT);
        sb.append("/2013-12-26");
        return sb;
    }

    protected void setHttpHeader(HttpPost httpPost) {

        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-Type", "application/json;charset=utf-8");
    }
}
