package com.smzc.taxi.common.third.safetycall.enums;


/**
 * @Description: 隐号通话详细结果说明
 * @author zhukai
 * @date 2019年5月20日 下午4:40:08
 */
public enum PhoneCallResultEnum {
    ERROR_CODE_1(1, "未分配的号码"),ERROR_CODE_2(2, "无路由到指定的转接网"),
    ERROR_CODE_3(3, "无路由到目的地"),ERROR_CODE_4(4, "发送专用信息音"),
    ERROR_CODE_16(16, "正常的呼叫拆线"),ERROR_CODE_17(17, "用户忙"),
    ERROR_CODE_18(18, "用户未响应"),ERROR_CODE_19(19, "用户未应答"),
    ERROR_CODE_20(20, "用户缺席"),ERROR_CODE_21(21, "呼叫拒收"),
    ERROR_CODE_22(22, "号码改变"),ERROR_CODE_27(27, "目的地不可达"),
    ERROR_CODE_28(28, "无效的号码格式（地址不全）"),ERROR_CODE_29(29, "性能拒绝"),
    ERROR_CODE_31(31, "正常—未指定"),ERROR_CODE_34(34, "无电路/通路可用"),
    ERROR_CODE_42(42, "交换设备拥塞"),ERROR_CODE_50(50, "所请求的性能未预定"),
    ERROR_CODE_53(53, "CUG中限制去呼叫"),ERROR_CODE_55(55, "CUG中限制来呼叫"),
    ERROR_CODE_57(57, "承载能力无权"),ERROR_CODE_58(58, "承载能力目前不可用"),
    ERROR_CODE_65(65, "承载能力未实现"),ERROR_CODE_69(69, "所请求的性能未实现"),
    ERROR_CODE_87(87, "被叫用户不是CUG的成员"),ERROR_CODE_88(88, "不兼容的目的地"),
    ERROR_CODE_90(90, "不存在的CUG"),ERROR_CODE_91(91, "无效的转接网选择"),
    ERROR_CODE_95(95, "无效的消息，未指定"),ERROR_CODE_97(97, "消息类型不存在或未实现"),
    ERROR_CODE_99(99, "参数不存在或未实现"),ERROR_CODE_102(102, "定时器终了时恢复"),
    ERROR_CODE_103(103, "参数不存在或未实现—传递"),ERROR_CODE_110(110, "消息带有未被识别的参数—舍弃"),
    ERROR_CODE_111(111, "协议错误，未指定"),ERROR_CODE_127(127, "互通，未指定"),
    ERROR_CODE_202(202, "用户忙，MSRN获取失败，平台挂机"),ERROR_CODE_203(203, "用户去活，平台挂机"),
    ERROR_CODE_204(204, "用户在平台侧关机，平台挂机"),ERROR_CODE_205(205, "用户未开户，平台挂机"),
    ERROR_CODE_206(206, "中间号不允许呼叫，平台挂机"),ERROR_CODE_207(207, "主号拨打中间号，平台挂机"),
    ERROR_CODE_209(209, "主叫打中间号带原始被叫，平台挂机");

    private int code;

    private String name;

    PhoneCallResultEnum(int code, String name) {

        this.code = code;
        this.name = name;
    }

    public static PhoneCallResultEnum fromCode(int code) {

        for(PhoneCallResultEnum item:values()) {
            if(item.code == code) {
                return item;
            }
        }
        return ERROR_CODE_1;
    }

    public int getCode() {

        return code;
    }

    public void setCode(int code) {

        this.code = code;
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {

        this.name = name;
    }
}
