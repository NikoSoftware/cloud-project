package com.smzc.taxi.common.utils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializeFilter;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.github.pagehelper.PageInfo;

import static com.alibaba.fastjson.JSON.parse;

public class JsonUtils {

    private static final SerializerFeature[] features = {

        SerializerFeature.WriteMapNullValue, // 输出空置字段

        SerializerFeature.WriteNullListAsEmpty, // list字段如果为null，输出为[]，而不是null

        SerializerFeature.WriteNullNumberAsZero, // 数值字段如果为null，输出为0，而不是null

        SerializerFeature.WriteNullBooleanAsFalse, // Boolean字段如果为null，输出为false，而不是null

        SerializerFeature.WriteNullStringAsEmpty // 字符类型字段如果为null，输出为""，而不是null

    };

    public static <T> T toObject(String content, Class<T> clazz) {
        T object = (T)JSON.parseObject(content, clazz);
        return object;
    }
    
    /**
     * 数组对象深度copy目标对象
     * @param clazz 目标类型
     * @param source 数组对象
     * **/
    public static <E, T> List<T> copyList(Class<T> clazz, List<E> source) {
		return JSON.parseArray(JSON.toJSONString(source), clazz);
	}

    /**
     * @description 复制分页列表
     * @param clazz
     * @param source
     * @return com.github.pagehelper.PageInfo<T>
     * @date 2019/5/9 14:18
     * @author qiukaihong
     */
    public static <E, T> PageInfo<T> copyPageList(Class<T> clazz, PageInfo<E> source) {
        PageInfo<T> pageInfo = JSON.parseObject(JSON.toJSONString(source), PageInfo.class);
        pageInfo.setList(JSON.parseArray(JSON.toJSONString(source.getList()), clazz));
        return pageInfo;
    }
    
    /**
     * copy对象属性到目标对象
     * @param clazz 目标类型
     * @param source 数组对象
     * **/
    public static <E, T> T copyProperites(Class<T> clazz, Object source) {
		return JSON.parseObject(JSON.toJSONString(source), clazz);
	}
    
    
    public static String toJson(Object response) {
        String outJson = JSON.toJSONString(response, features);
        return outJson;
    }

    public static String toJsonByFilter(Object response, SerializeFilter filter) {
        String outJson = JSON.toJSONString(response, filter, features);
        return outJson;
    }

    /**
     * 把含有uncode特殊json字符串中的转为中文字json字符串
     **/
    public static String uncodeToJson(String uncodeJson) {
        JSONObject jsonObject = JSONObject.parseObject(uncodeJson);
        String json = jsonObject.toJSONString();
        return json;
    }

    /**
     * bean对象转map
     * 注意: bean的value必须为String类型
     * @param o
     * @return
     */
    public static Map<String,String> beanToMapString(Object o){
        if (o == null){
            return new HashMap<>();
        }
        return (Map<String,String>) parse(JSON.toJSONString(o));
    }

}
