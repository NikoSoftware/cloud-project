package com.smzc.taxi.common.third.safetycall.conf;
/**
 * @Description: 云通讯相关配置
 * @author zhukai
 * @date 2019年5月15日 下午3:01:27
 */
public class SysConfig {

    public static String SERVER_IP = "apppro.cloopen.com";

    public static int SERVER_PORT = 8883;

    public static String ACCOUNT_SID = "8aaf070858297ab601582dbe6fa906f5";

    public static String ACCOUNT_TOKEN = "a55b2efed7884b66a9078cdb7868dd40";

    public static String APP_ID = "8aaf0708624670f201626a78d0990dcf";
    /**
     * 定于域名地址
     */
//    public static String DOMAIN="http://222.209.83.122:19865";//开发
//    public static String DOMAIN="http://222.209.83.122:20087"; //测试
    public static String DOMAIN="https://passenger-taxi.vvip-u.com"; //生产
    /**
     * 定义回调接口
     */
    public static String CDR_NOTIFY_URL=DOMAIN+"/taxi/restful/api/1.0/safecall/saveCallDetail";

}
