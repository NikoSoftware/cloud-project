package com.smzc.taxi.common.utils;

import org.apache.http.util.Asserts;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @Description  短信验证码util
 * @Date 2019/5/21 19:16
 * @Created by  zhanglian
 */
public class SmsValidateCodeUtil {
    public static String genValidateCode() {
        return ((int) ((Math.random() * 9 + 1) * 100000)) + "";
    }

    /**
     * 获取当前小时内 司机万能验证码
     * @param mobilePhone
     * @return
     */
    public static String getDriverSuperValidateCode(String mobilePhone) {
        Asserts.check(isMobilePhone(mobilePhone),"电话号码错误！");
        String subMobilePhone = mobilePhone.substring(0,3)+mobilePhone.substring(mobilePhone.length()-4, mobilePhone.length());
        String date = new SimpleDateFormat("yyyyMMddHH").format(new Date());
        String temp = String.valueOf((Long.valueOf(date) * Long.valueOf(subMobilePhone) * 81) << 5);
        String superValidateCode = temp.substring(temp.length() - 6, temp.length());
        return superValidateCode;
    }

    /**
     * 获取当前小时内万能验证码
     * @return
     */
    public static String getCurrentTimeSuperValidateCode() {
        String date = new SimpleDateFormat("yyyyMMddHH").format(new Date());
        String temp = String.valueOf((Long.valueOf(date) * 8090) << 5);
        String superValidateCode = temp.substring(temp.length() - 6, temp.length());
        return superValidateCode;
    }

    /**
     * 手机号格式
     * @param mobilePhone
     * @return
     */
    public static boolean isMobilePhone(String mobilePhone){
        String mobilePhoneRegex = "^[0-9]{11}$";
        Pattern pattern = Pattern.compile(mobilePhoneRegex);
        Matcher matcher = pattern.matcher(mobilePhone);
        return matcher.matches();
    }

    public static void main(String[] args) throws Exception {
        System.out.println("司机 13566667777 万能验证码"+getDriverSuperValidateCode("13566667777"));
        System.out.println("所有人万能验证码："+getCurrentTimeSuperValidateCode());
    }
}
