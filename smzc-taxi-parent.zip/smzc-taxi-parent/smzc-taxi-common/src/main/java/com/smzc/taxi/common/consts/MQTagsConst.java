package com.smzc.taxi.common.consts;

public final class MQTagsConst {

    public final static String TAG_SPLIT = "||";

    public final static String FAST_ALARM = "fast_alarm";

    /**
     * 银行审核司机信息完成通知
     */
    public static final String DRIVER_AUDIT_RESULT_NOTIFY = "DRIVER_AUDIT_RESULT_NOTIFY";

    /**
     * 银行审核司机银行卡信息完成通知
     */
    public static final String DRIVER_AUDIT_BANKCARD_RESULT_NOTIFY = "DRIVER_AUDIT_BANKCARD_RESULT_NOTIFY";

    // ===================================订单 tag  start new -==============================================

    /**
     * 新增订单
     */
    public final static String INIT="INIT";

    /**
     * 等待司机抢单
     */
    public final static String WAIT_DRIVER_CONFIRM="WAIT_DRIVER_CONFIRM";
    /**
     * 司机已出发
     */
    public final static String DRIVER_STARTING ="DRIVER_STARTING";
    /**
     * 司机已到达
     */
    public final static String DRIVER_ARRIVE ="DRIVER_ARRIVE";
    /**
     * 行程中
     */
    public final static String IN_TRIP ="IN_TRIP";
    /**
     * 行程结束-待收款
     */
    public final static String WAIT_COLLECT_MONEY ="WAIT_COLLECT_MONEY";
    /**
     * 待支付
     */
    public final static String WAIT_PAY = "WAIT_PAY";
    /**
     * 取消待支付
     */
    public final static String WAIT_PAY_CANCEL ="WAIT_PAY_CANCEL";
    /**
     * 驳回待支付
     */
    public final static String WAIT_PAY_REJECT ="WAIT_PAY_REJECT";
    /**
     * 待评价
     */
    public final static String WAIT_EVALUATE ="WAIT_EVALUATE";
    /**
     * 已驳回
     */
    public final static String REJECTED ="REJECTED";
    /**
     * 已完成
     */
    public final static String FINISH ="FINISH";
    /**
     * 5分钟自动取消
     */
    public final static String SYS_CANCEL ="SYS_CANCEL";
    /**
     * 乘客取消
     */
    public final static String CANCEL = "CANCEL";



    // ===================================订单 tag   end -================================================



    /**
     * 司机状态变更
     */
    public final static String TRANSFER_DIRVER_STATUS ="TRANSFER_DIRVER_STATUS";

    // add by zyb 2019-06-10 司机听单状态扭转时中控平台和手机端同步消息tag
    /**
     * 司机听单扭转时中控端通知司机端
     */
    public final static String TRANSFER_DRIVER_STATUS_CENTOR_CONTROL_TO_DRIVER = "TRANSFER_DRIVER_STATUS_CENTOR_CONTROL_TO_DRIVER";

    /**
     * 司机听单状态扭转时司机端通知中控端
     */
    public final static String TRANSFER_DRIVER_STATUS_DRIVER_TO_CENTOR_CONTROL = "TRANSFER_DRIVER_STATUS_DRIVER_TO_CENTOR_CONTROL";
    // add ended

    /**
     * 订单线下收款，生成司机线下收款交易记录
     */
    public final static String TAXI_DRIVER_CASH_RECEIVABLE_TAG = "TAXI_DRIVER_CASH_RECEIVABLE_TAG";

    /**
     * 支付完成订单处理失败tags
     */
    public static final String TAXI_ORDER_PAYOFF_FAIL_TAGS = "taxi_order_payoff_fail_tags";

    /**
     * 互娱屏专用,行程开始
     */
    public static final String TAXI_ORDER_IN_TRIP = "taxi_open_order_in_trip";

    /**
     * 互娱屏专用,行程结束
     */
    public static final String TAXI_ORDER_FINISH_TRIP = "taxi_open_order_finish_trip";


    /**
     * 司机补贴
     */
    public final static String TAXI_ORDER_DRIVER_SUBSIDY = "taxi_order_driver_subsidy";


}
