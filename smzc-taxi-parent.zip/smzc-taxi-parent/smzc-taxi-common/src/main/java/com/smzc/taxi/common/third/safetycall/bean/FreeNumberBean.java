package com.smzc.taxi.common.third.safetycall.bean;

import java.io.Serializable;

/**
 * @Description: 号码解绑请求Bean
 * @author zhukai
 * @date 2019年5月15日 下午2:52:54
 */
public class FreeNumberBean implements Serializable {

    private static final long serialVersionUID = -5373362412815114036L;

    /**
     * 绑定Id,唯一
     */
    private String bindId;

    /**
     * 城市
     */
    private String city;

    public String getBindId() {

        return bindId;
    }

    public void setBindId(String bindId) {

        this.bindId = bindId;
    }

    public String getCity() {

        return city;
    }

    public void setCity(String city) {

        this.city = city;
    }

}
