package com.smzc.taxi.common.consts;

public class SmsTemplateConst {
    /**
     * 一键报警
     * 您的朋友${TXT_12}可能遇到危险，您为TA的紧急联系人，TA的行程信息：https://t1.vvip-u.com/${TXT_15}，
     * 神马专车提醒您，请理智处理，必要时及时联系警方获取帮助。
     */
//    public static final String FAST_ALARM = "93c2dee206ce4680979c655b3daa8493";
    public static final String FAST_ALARM = "5d382f1003814a8eab153344e6fb5223";

    /**
     * 出租车司机到达乘客上车位置，向乘客发送短信 - 由司机端出发
     * template:【神马出行】您预订的出租车（车牌号：${车牌号}）已抵达您的上车位置，电话 ${司机电话}
     */
    public static final String DRIVER_ARRIVE_PASSENGER_BOARDING_POSITION = "SMS_165676111";

    /**
     * 出租车司机审核通过
     * template:【神马专车】司机您好。你的出租车账号申请已通过，请登录APP查看
     */
    public static final String DRIVER_AUDIT_SUCCESS = "SMS_167525003";

    /**
     * 出租车司机审核失败
     * template:【神马专车】司机您好。你的出租车账号申请已被驳回，请登录APP查看具体原因
     */
    public static final String DRIVER_AUDIT_FAILED = "SMS_167525001";
    /**
     * 用户登录发送验证码
     */
    public static final String LOGIN_REGIST = "SMS_147971394";//用户登陆
}
