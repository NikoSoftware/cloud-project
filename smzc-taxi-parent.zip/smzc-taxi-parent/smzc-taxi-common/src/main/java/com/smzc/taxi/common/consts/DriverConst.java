package com.smzc.taxi.common.consts;

public class DriverConst {

    /**
     * 司机提现密码错误次数
     */
    public static final int DRiVER_WITHDRAW_ERROR_NUM = 4;

    /** 空字符串 验证 */
    public static final String NULL_STR = "null";


    /**
     * 万能验证码配置
     * 0：关闭
     * 1：开启个人万能验证码
     * 2.开启所有人万能验证码
     */
    public static final String SUPER_VALIDATE_CODE_CONFIG_CLOSE = "0";
    public static final String SUPER_VALIDATE_CODE_CONFIG_OPEN_SINGLE = "1";
    public static final String SUPER_VALIDATE_CODE_CONFIG_OPEN_ALL = "2";

}
