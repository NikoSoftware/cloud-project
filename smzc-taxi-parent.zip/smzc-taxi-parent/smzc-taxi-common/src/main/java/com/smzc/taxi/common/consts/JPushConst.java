package com.smzc.taxi.common.consts;

/**
 * @author by wanglin
 * @date 2019/5/25 16:11
 * @description
 */
public class JPushConst {

    /**
     * 消息推送的默认title
     */
    public static final String DEFAULT_TITLE = "神马专车";

    /**
     *  车牌被其他司机使用（其他司机使用该车辆上线听单），强制“停止听单”-停止听单提醒”
     */
    public static final String DRIVER_TAKEN_OFFLINE = "抱歉，您当前无法继续听单！该车辆已被${driverName}使用。如有疑问请联系客服！";

    /**
     * 乘客和业务后台驳回取消订单时司机端的提示内容
     */
    public static final String DRIVER_ORDER_CANCEL_PUSH_CONTENT = "您有一笔订单已撤销，请知晓！";

    /**
     * 乘客新增订单时司机端的提示内容
     */
    public static final String DRIVER_ORDER_ADD_PUSH_CONTENT = "您有一笔新订单！";

    /**
     *  司机在待命中，如果后台禁用该司机，立即提示消息给司机端
     */
    public static final String DRIVER_ACCOUNT_FORBIDDENT = "您的账号已被禁用。如有疑问请联系客服！";

    /**
     * 司机奖励标题
     */
    public static String DRIVER_REWARD_TITLE = "奖励通知";

    /**
     * 司机邀新奖励内容
     */
    public static String DRIVER_NEW_REWARD_CONTENT = "您的订单乘客已线上付款，你已获得邀新奖励%s元。";

    /**
     * 司机完单奖励内容
     */
    public static String DRIVER_COMPLETE_REWARD_CONTENT_ = "您的订单乘客已线上付款，你已获得完单奖励%s元。";

}
