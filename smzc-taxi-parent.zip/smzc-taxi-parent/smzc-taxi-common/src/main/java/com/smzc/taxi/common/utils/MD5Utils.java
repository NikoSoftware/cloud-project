package com.smzc.taxi.common.utils;

import java.security.MessageDigest;
import java.util.Random;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Hex;

/**
 * MD5加密解密工具类
 *
 */
@Slf4j
public class MD5Utils {

    /**
     * 使用Apache的Hex类实现Hex(16进制字符串和)和字节数组的互转
     *
     */
    private static String md5Hex(String str) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(str.getBytes());
            return new String(new Hex().encode(digest));
        } catch (Exception e) {
            log.error(e.toString());
            return "";
        }
    }

    /**
     * 加盐MD5加密
     *
     */
    public static String getSaltMD5(String password, String salt) {
        password = md5Hex(salt + password);
        char[] cs = new char[48];
        for (int i = 0; i < 48; i += 3) {
            cs[i] = password.charAt(i / 3 * 2 + 1);
            cs[i + 1] = salt.charAt(i / 3);
            cs[i + 2] = password.charAt(i / 3 * 2);
        }
        return String.valueOf(cs);
    }

    public static String getMD5(byte[] value) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(value);
            return new String(new Hex().encode(digest));
        } catch (Exception e) {
            log.error(e.toString());
            return "";
        }
    }

    /**
     * 生成盐值
     */
    public static String generateSalt(){
        // 生成一个16位的随机数
        Random random = new Random();
        StringBuilder sBuilder = new StringBuilder(16);
        sBuilder.append(random.nextInt(888888888)).append(random.nextInt(9999999));
        int len = sBuilder.length();
        if (len < 16) {
            for (int i = 0; i < 16 - len; i++) {
                sBuilder.append("9");
            }
        }
        // 生成最终的加密盐
        return  sBuilder.toString();
    }

    public static void main(String[] args) {
        String password = "kjlasf14";
        String salt = "3860062345622957";
//        String salt = generateSalt();
//        "b3608eb6e503c0bb6a623a3994765f969d24e24e94e52074"
        System.out.println(salt);
        final String saltMD5 = getSaltMD5(password, salt);
        System.out.println(saltMD5);

    }

}