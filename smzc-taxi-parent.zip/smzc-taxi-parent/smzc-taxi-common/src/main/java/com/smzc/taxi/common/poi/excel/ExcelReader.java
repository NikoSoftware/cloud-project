package com.smzc.taxi.common.poi.excel;

import com.smzc.taxi.common.poi.excel.cell.CellEditor;
import com.smzc.taxi.common.poi.util.IterUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Excel读取器<br>
 * 读取Excel工作簿
 *
 * @author Looly
 * @since 3.1.0
 */
public class ExcelReader extends ExcelBase<ExcelReader> {


    /**
     * 是否忽略空行
     */
    private boolean ignoreEmptyRow = true;

    /**
     * 单元格值处理接口
     */
    private CellEditor cellEditor;

    /**
     * 标题别名
     */
    private Map<String, String> headerAlias = new HashMap<>();


    /**
     * 设置是否忽略空行
     *
     * @param ignoreEmptyRow 是否忽略空行
     * @return this
     */
    public ExcelReader setIgnoreEmptyRow(boolean ignoreEmptyRow) {
        this.ignoreEmptyRow = ignoreEmptyRow;
        return this;
    }

    /**
     * 设置单元格值处理逻辑<br>
     * 当Excel中的值并不能满足我们的读取要求时，通过传入一个编辑接口，可以对单元格值自定义，例如对数字和日期类型值转换为字符串等
     *
     * @param cellEditor 单元格值处理接口
     * @return this
     */
    public ExcelReader setCellEditor(CellEditor cellEditor) {
        this.cellEditor = cellEditor;
        return this;
    }


    /**
     * 获得标题行的别名Map
     *
     * @return 别名Map
     */
    public Map<String, String> getHeaderAlias() {
        return headerAlias;
    }

    /**
     * 设置标题行的别名Map
     *
     * @param headerAlias 别名Map
     * @return this
     */
    public ExcelReader setHeaderAlias(Map<String, String> headerAlias) {
        this.headerAlias = headerAlias;
        return this;
    }


    /**
     * 构造
     *
     * @param sheet Excel中的sheet
     */
    public ExcelReader(Sheet sheet) {
        super(sheet);
    }

    /**
     * 构造
     *
     * @param book       {@link Workbook} 表示一个Excel文件
     * @param sheetIndex sheet序号，0表示第一个sheet
     */
    public ExcelReader(Workbook book, int sheetIndex) {
        this(book.getSheetAt(sheetIndex));
    }

    /**
     * 构造
     *
     * @param bookStream     Excel文件的流
     * @param sheetIndex     sheet序号，0表示第一个sheet
     * @param closeAfterRead 读取结束是否关闭流
     */
    public ExcelReader(InputStream bookStream, int sheetIndex, boolean closeAfterRead) {
        this(WorkbookUtil.createBook(bookStream, closeAfterRead), sheetIndex);
    }


    /**
     * 增加标题别名
     *
     * @param header 标题
     * @param alias  别名
     * @return this
     */
    public ExcelReader addHeaderAlias(String header, String alias) {
        this.headerAlias.put(header, alias);
        return this;
    }


    /**
     * 读取Excel为Map的列表，读取所有行，默认第一行做为标题，数据从第二行开始<br>
     * Map表示一行，标题为key，单元格内容为value
     *
     * @return Map的列表
     */
    public List<Map<String, Object>> readAll() {
        return read(0, 1, Integer.MAX_VALUE);
    }

    /**
     * 读取Excel为Map的列表<br>
     * Map表示一行，标题为key，单元格内容为value
     *
     * @param headerRowIndex 标题所在行，如果标题行在读取的内容行中间，这行做为数据将忽略
     * @param startRowIndex  起始行（包含，从0开始计数）
     * @param endRowIndex    读取结束行（包含，从0开始计数）
     * @return Map的列表
     */
    public List<Map<String, Object>> read(int headerRowIndex, int startRowIndex, int endRowIndex) {
        checkNotClosed();
        // 边界判断
        final int firstRowNum = sheet.getFirstRowNum();
        final int lastRowNum = sheet.getLastRowNum();
        if (headerRowIndex < firstRowNum) {
            throw new IndexOutOfBoundsException("Header row index " + headerRowIndex + " is lower than first row index " + firstRowNum);
        } else if (headerRowIndex > lastRowNum) {
            throw new IndexOutOfBoundsException("Header row index " + headerRowIndex + " is greater than last row index " + firstRowNum);
        }
        // 读取起始行（包含）
        startRowIndex = Math.max(startRowIndex, firstRowNum);
        // 读取结束行（包含）
        endRowIndex = Math.min(endRowIndex, lastRowNum);

        // 读取header
        List<Object> headerList = readRow(sheet.getRow(headerRowIndex));

        final List<Map<String, Object>> result = new ArrayList<>(endRowIndex - startRowIndex + 1);
        List<Object> rowList;
        for (int i = startRowIndex; i <= endRowIndex; i++) {
            if (i != headerRowIndex) {
                // 跳过标题行
                rowList = readRow(sheet.getRow(i));
                if (CollectionUtils.isNotEmpty(rowList) || false == ignoreEmptyRow) {
                    if (null == rowList) {
                        rowList = new ArrayList<>(0);
                    }
                    result.add(IterUtil.toMap(aliasHeader(headerList), rowList, true));
                }
            }
        }
        return result;
    }


    /**
     * 读取一行
     *
     * @param row 行
     * @return 单元格值列表
     */
    private List<Object> readRow(Row row) {
        return RowUtil.readRow(row, this.cellEditor);
    }


    /**
     * 转换标题别名，如果没有别名则使用原标题，当标题为空时，列号对应的字母便是header
     *
     * @param headerList 原标题列表
     * @return 转换别名列表
     */
    private List<String> aliasHeader(List<Object> headerList) {
        final int size = headerList.size();
        final ArrayList<String> result = new ArrayList<>(size);
        if (CollectionUtils.isEmpty(headerList)) {
            return result;
        }

        for (int i = 0; i < size; i++) {
            result.add(aliasHeader(headerList.get(i), i));
        }
        return result;
    }

    /**
     * 转换标题别名，如果没有别名则使用原标题，当标题为空时，列号对应的字母便是header
     *
     * @param headerObj 原标题
     * @param index     标题所在列号，当标题为空时，列号对应的字母便是header
     * @return 转换别名列表
     * @since 4.3.2
     */
    private String aliasHeader(Object headerObj, int index) {
        if (null == headerObj) {
            return ExcelUtil.indexToColName(index);
        }
        final String header = headerObj.toString();
        String s = this.headerAlias.get(header);
        return (null == s) ? header : s;
    }


    /**
     * 检查是否未关闭状态
     */
    private void checkNotClosed() {
        if (this.isClosed) {
            throw new IllegalArgumentException("ExcelReader has been closed!");
        }
    }

}
