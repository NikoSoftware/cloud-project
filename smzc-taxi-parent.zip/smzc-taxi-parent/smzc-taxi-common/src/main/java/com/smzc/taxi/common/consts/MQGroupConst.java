package com.smzc.taxi.common.consts;

/**
 * @author pengpengcheng
 * @description mq分组常量
 * @date 2019/6/11
 */
public class MQGroupConst {
    /**
     * 司机端分组前缀, 需自己加后缀以区分不同的消费分组
     */
    public final static String TAXI_DRIVER_CONSUMER_GROUP_PREFIX = "taxi-driver-consumer-group-";

    /**
     * @Description: 中控端分组前缀, 需自己加后缀以区分不同的消费分组
     * @Author: Yb.Z
     * @create: 2019/06/18 15:20
     */
    public final static String TAXI_CENTORCONTROL_CONSUMER_GROUP_PREFIX = "taxi-centorcontrol-consumer-group-";

    /**
     * 订单模块消费订单新增的MQ
     */
    public final static String TAXI_ORDER_GROUP_PREFIX = "taxi-order-group";
}
