package com.smzc.taxi.common.third.safetycall.util;

import java.util.Properties;

public class PropertiesUtil {

    public static Properties getPropertie() {

        Properties props = new Properties();
        props.setProperty("log4j.rootLogger", "info,A,R");
        props.setProperty("log4j.appender.A", "org.apache.log4j.ConsoleAppender");
        props.setProperty("log4j.appender.Out.Target", "System.out");
        props.setProperty("log4j.appender.A.layout", "org.apache.log4j.PatternLayout");
        props.setProperty("log4j.appender.A.layout.ConversionPattern", "smzc-taxi-common --->|SysOut -->%d{yyyy-MM-dd HH:mm:ss:SSS} [%t]%5p{%F:%L}-%m%n");
        props.setProperty("log4j.appender.R", "org.apache.log4j.RollingFileAppender");
        props.setProperty("log4j.appender.R.File", "/smapp/logs_put/app_logs/smzc-taxi-common.log");
        props.setProperty("log4j.appender.R.MaxFileSize", "10MB");
        props.setProperty("log4j.appender.R.DatePattern", ".yyyy-MM-dd");
        props.setProperty("log4j.appender.R.layout", "org.apache.log4j.PatternLayout");
        props.setProperty("log4j.appender.R.layout.ConversionPattern", "smzc-taxi-common --->%d{yyyy-MM-dd HH:mm:ss:SSS} [%t]%5p{%F:%L}-%m%n");
        return props;
    }

}
