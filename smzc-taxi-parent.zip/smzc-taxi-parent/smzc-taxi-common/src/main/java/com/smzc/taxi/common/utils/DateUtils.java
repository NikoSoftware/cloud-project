package com.smzc.taxi.common.utils;

import com.smzc.taxi.common.enums.DateTypeEnum;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;

import static com.smzc.taxi.common.enums.DateTypeEnum.BEGIN;
import static com.smzc.taxi.common.enums.DateTypeEnum.END;

public class DateUtils {

	/**
	 * Date format pattern used to parse date to china date
	 * eg. 2017年01月01日
	 */
	public static final String PATTERN_CHINESE_DATE = "yyyy年MM月dd日";

	/**
	 * Date format pattern used to parse time to china time without second
	 * eg. 2017年01月01日 00:00
	 */
	public static final String PATTERN_CHINESE_TIME = "yyyy年MM月dd日 HH:mm";

	/**
	 * Date format pattern used to parse time to china time
	 * eg. 2017年01月01日 00:00:00
	 */
	public static final String PATTERN_CHINESE_TIME_FULL = "yyyy年MM月dd日 HH:mm:ss";

	/**
	 * Date format pattern used to parse time to china time without second
	 * eg. 01月01日 00:00
	 */
	public static final String PATTERN_CHINESE_MONTH_TIME = "MM月dd日 HH:mm";

	/**
	 * Date format pattern used to parse time to general date
	 * eg. 2017-01-01
	 */
	public static final String PATTERN_GENERAL_DATE = "yyyy-MM-dd";

	/**
	 * Date format pattern used to parse time to general time without second
	 * eg. 2017-01-01 00:00
	 */
	public static final String PATTERN_GENERAL_TIME = "yyyy-MM-dd HH:mm";

	/**
	 * Date format pattern used to parse time to general time
	 * eg. 2017-01-01 00:00:00
	 */
	public static final String PATTERN_GENERAL_TIME_FULL = "yyyy-MM-dd HH:mm:ss";

	/**
	 * Date format pattern used to parse time to general date split with slash
	 * eg. 2017-01-01
	 */
	public static final String PATTERN_GENERAL_SLASH_DATE = "yyyy/MM/dd";

	/**
	 * Date format pattern used to parse time to general time without second split with slash
	 * eg. 2017-01-01 00:00
	 */
	public static final String PATTERN_GENERAL_SLASH_TIME = "yyyy/MM/dd HH:mm";

	/**
	 * Date format pattern used to parse time to general time split with slash
	 * eg. 2017-01-01 00:00:00
	 */
	public static final String PATTERN_GENERAL_SLASH_TIME_FULL = "yyyy/MM/dd HH:mm:ss";

	/**
	 * Date format pattern used to parse time to general date split with point
	 * eg. 2017-01-01
	 */
	public static final String PATTERN_GENERAL_POINT_DATE = "yyyy.MM.dd";

	/**
	 * Date format pattern used to parse time to general time without second split with point
	 * eg. 2017-01-01 00:00
	 */
	public static final String PATTERN_GENERAL_POINT_TIME = "yyyy.MM.dd HH:mm";

	/**
	 * Date format pattern used to parse time to general time split with point
	 * eg. 2017-01-01 00:00:00
	 */
	public static final String PATTERN_GENERAL_POINT_TIME_FULL = "yyyy.MM.dd HH:mm:ss";

	/**
	 * eg. 20:12:59
	 */
	public static final String PATTERN_HH_MM_SS = "HH:mm:ss";

	/**
	 * eg. 20:12
	 */
	public static final String PATTERN_HH_MM = "HH:mm";

	/**
	 * Date format pattern used to parse time to general date without separator
	 * eg. 20170101
	 */
	public static final String PATTERN_DATE_WITHOUT_SEPARATOR = "yyyyMMdd";

	/**
	 * Date format pattern used to parse time to general date without separator
	 * eg. 20170101120000
	 */
	public static final String PATTERN_DATE_TIME_WITHOUT_SEPARATOR = "yyyyMMddHHmmss";

	public static final Integer BEGIN_OF_DAY = 1;
    public static final Integer END_OF_DAY = 2;


    public static final Integer SECONDS_ONE_DAY = 86400; //一天的秒数
	public static final Integer SECONDS_ONE_HOUR = 3600; //一小时的秒数
	public static final Integer SECONDS_ONE_MINUTE = 60; //一分钟的秒数
	public static final Integer SECONDS_ONE_MILLISECOND = 60000; //一分钟的毫秒秒数


	/**
	 * 返回指定日期指定格式的日期字符串
	 * @param date 日期
	 * @param pattern 指定格式
	 * @return
	 */
	 public static String getDateString(Date date, String pattern){
	      if(date == null){
	            return "";
	      } else{
	    	  SimpleDateFormat formatter = new SimpleDateFormat(pattern);
	          return formatter.format(date);
	      }
	  }

	/**
	 * 返回当前日期指定格式的日期字符串
	 * @param pattern 指定格式
	 * @return
	 */
	public static String getDateString(String pattern){
	        return getDateString(new Date(), pattern);
	}

	/**
	 * 返回格式为 yyyy-MM-dd HH:mm:ss的日期字符串
	 * @param  date 为Date对象
	 *
	 */
	public static String getDateString(Date date){
		return getDateString(date,PATTERN_GENERAL_TIME_FULL);
	}

	/**
	 * 解析自定字符串的日期
	 * @param strDate 日期字符串
	 * @param pattern 解析格式
	 * @return
	 */
	public static Date getDate(String strDate, String pattern){
		if(strDate==null)
			return null;
		SimpleDateFormat b = new SimpleDateFormat(pattern);
		try{
			return b.parse(strDate.trim());
		}catch(ParseException ex){
			return null;
		}
	}

	/**
	 * 返回指定格式的Timestamp
	 * @param  strDate 为字符串
	 * @param  pattern 为Timestamp输出格式
	 */
	public static Timestamp getTimestamp(String strDate,String pattern){
		if(strDate == null){
			return null;
		} else{
			SimpleDateFormat formatter = new SimpleDateFormat(pattern);
			return Timestamp.valueOf(formatter.format(strDate));
		}
	}

	/**
	 * 将Date转换为Timestamp
	 * @param  date 为字符串
	 * @param  pattern Timestamp输出格式
	 * */
	public static Timestamp getTimestamp(Date date,String pattern){
		if(date == null){
			return null;
		} else{
			SimpleDateFormat format = new SimpleDateFormat(pattern);
			return Timestamp.valueOf(format.format(date));
		}
	}

	/**
	 * 日期相加
	 * @param  date 日期
	 * @interval  设置间隔天数
	 * @type      year(1) or MONTH(2) or day(5)or minute(12)
	 * */
	public static Date addDay(Date date, int interval, int type){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(type,interval);
		return calendar.getTime();
	}

	/**
	 * 比较两个日期字符串的间隔天数据
	 * @param startDateString  开始日期 (yyyy-MM-dd)
	 * @param endDateString 结束日期 (yyyy-MM-dd)
	 * @return int
	 * */
	public static int getIntervalDays(String startDateString,String endDateString){
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			return new Long((format.parse(startDateString).getTime()-format.parse(endDateString).getTime())/(1000 * 60 * 60 * 24)).intValue();
		} catch (ParseException e) {
			e.printStackTrace();
			return -1;
		}
	}

	/**
	 * 比较时间，开始时间等于结束时间返回true，否则返回false
	 * @param startDateString
	 * @param endDateString
	 * @param pattern 日期格式
	 * @return
	 */
	public static boolean compareDate(String startDateString, String endDateString,String pattern) throws ParseException {
		try {
			SimpleDateFormat format= new  SimpleDateFormat(pattern);
			Date startDate =  format.parse(startDateString);
			Date endDate = format.parse(endDateString);
			if(startDate.equals(endDate))
				return true;
		} catch (ParseException e) {
			throw e;
		}
		return false;
	}

	/**
	 * 获取某个月第一天日期
	 * @param reduceMonth 相差月份
	 * @return
	 */
	public static Date getLastFirstDay(int reduceMonth) {
		Calendar nowTime = Calendar.getInstance();
		nowTime.add(Calendar.MONTH, reduceMonth);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM");
		nowTime.getTime();
		String date = format.format(nowTime.getTime());
		try {
			return format.parse(date);
		} catch (ParseException e) {
			return null;
		}
	}

	/**
	 * 获取当天的开始时间
	 * @return
	 */
	public static Date getCurrentStartDay(){
		return ofPassBeginOrEndTime(0,new Date(),BEGIN);
	}

	/**
	 * 获取某天的开始时间
	 * @param date 某天的日期
	 * @return
	 */
	public static Date getCurrentStartDay(Date date){
		return ofPassBeginOrEndTime(0,date,BEGIN);
	}

	/**
	 * 获取当天的结束时间
	 * @return
	 */
	public static Date getCurrentEndDay(){
		return ofPassBeginOrEndTime(0,new Date(),END);
	}

	/**
	 * 获取某天的结束时间
	 * @param date 某天的日期
	 * @return
	 */
	public static Date getCurrentEndDay(Date date){
		return ofPassBeginOrEndTime(0,date,END);
	}

	/**
	 * 获取当天月第一天
	 * @return
	 */
	public static Date getCurrentStartMonth(){
		return getCurrentStartMonthByTime(new Date());
	}

	/**
	 * 获取指定时间月第一天
	 * @param date
	 * @return
	 */
	public static Date getCurrentStartMonthByTime(Date date){
		GregorianCalendar gcLast=(GregorianCalendar)Calendar.getInstance();
		gcLast.setTime(date);
		//设置为第一天
		gcLast.set(Calendar.DAY_OF_MONTH, 1);
		gcLast.set(Calendar.HOUR_OF_DAY, 0);
		gcLast.set(Calendar.MINUTE,0);
		gcLast.set(Calendar.SECOND,0);
		gcLast.set(Calendar.MILLISECOND,0);
		return gcLast.getTime();
	}

	/**
	 * 获取当前月最后一天
	 * @return
	 */
	public static Date getCurrentEndMonth(){
		return getCurrentEndMonthByTime(new Date());
	}

	/**
	 * 获取指定日期最后一天
	 * @param date
	 * @return
	 */
	public static Date getCurrentEndMonthByTime(Date date){
		Calendar calendar=Calendar.getInstance();
		calendar.setTime(date);
		//设置日期为本月最大日期
		calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	/**
	 * 拆分范围内日期到天(包括开始日期，不包括结束日期)
	 * @param startDate 开始日期
	 * @param endDate 结束日期
	 * @return
	 */
	public static List<Date> splitDateToDay(Date startDate, Date endDate){
		List<Date> list = new ArrayList<Date>();
		Calendar calendar = Calendar.getInstance();
		list.add(startDate);
		while(endDate.getTime() > startDate.getTime()){
			calendar.setTime(startDate);
			calendar.add(Calendar.DATE,1);
			startDate = calendar.getTime();
			list.add(startDate);
		}
		return list;
	}

	/**
	 *
	 * @param day  负数代表过去几天，零是当天，正数是未来几天
	 * @param date 基准时间，在这个时间的基础上面，通过{@param day}增加和减少时间
	 *
	 * @example:  ofPassBeginOrEndTime(-1, new Date(), BEGIN_OF_DAY) 返回当前时间前一天的开始时间，比如现在是 2019-06-09 12:45:45 返回的数据为 2019-06-08 00:00:00
	 */
	public static Date ofPassBeginOrEndTime(int day, Date date, DateTypeEnum dateTypeEnum){
		LocalDateTime localDateTime = null;

		if (BEGIN_OF_DAY.intValue() == dateTypeEnum.getStatus()) {
			localDateTime =  dateToLocalDateTime(date).plusDays(day).withHour(0).withMinute(0).withSecond(0).withNano(0);
		} else if (END_OF_DAY.intValue() == dateTypeEnum.getStatus()) {
			localDateTime =  dateToLocalDateTime(date).plusDays(day).withHour(23).withMinute(59).withSecond(59).withNano(999999999);
		}
		return localDateTimeToDate(localDateTime);
	}




	/**
	 * string转Date
	 * @param time
	 * @param pattern
	 * @return
	 */
	public static Date stringToDate(String time, String pattern){
		try {
			DateFormat format = new SimpleDateFormat(pattern);
			return format.parse(time);
		} catch (Exception e) {
			return null;
		}
	}


	/**
	 * Date转LocalDateTime
	 * @param date
	 * @return
	 */
	public static LocalDateTime dateToLocalDateTime(Date date) {
		Instant instant = date.toInstant();
		ZoneId zone = ZoneId.systemDefault();
		return LocalDateTime.ofInstant(instant, zone);
	}

	/**
	 * LocalDateTime转Date
	 */

	public static Date localDateTimeToDate(LocalDateTime localDateTime) {
		ZoneId zoneId = ZoneId.systemDefault();
		ZonedDateTime zdt = localDateTime.atZone(zoneId);
		return Date.from(zdt.toInstant());
	}


	/**
	 *
	 * 指定的 {@param Date} 是否在 指定的 {@param beginHour}和 {@param endHour} 之间
	 * 比如：{@param Date}  2019-06-22 12:24:00 在 {@param beginHour}=12 和 {@param endHour}=13 之间，返回true
	 * @param date  指定时间
	 * @param beginHour  开始的整点
	 * @param endHour    结束的整点
	 * @return
	 */
	public static boolean belongPeriodTime(Date date, int beginHour, int beginMin, int endHour, int endMin){
		LocalDateTime now =  dateToLocalDateTime(date);
		LocalDateTime beginLocalDateTime = LocalDateTime.of(now.getYear(),now.getMonthValue(),now.getDayOfMonth(),beginHour,beginMin,0,0);
		LocalDateTime endLocalDateTime = LocalDateTime.of(now.getYear(),now.getMonthValue(),now.getDayOfMonth(),endHour,endMin,0,0);

		if(now.isAfter(beginLocalDateTime) && now.isBefore(endLocalDateTime)){
			return true;
		}
		return false;
	}





}
