package com.smzc.taxi.common.utils;

import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.metadata.*;
import com.alibaba.excel.support.ExcelTypeEnum;
import org.apache.poi.ss.usermodel.IndexedColors;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

public class EasyExcelUtil {
    /**
     * 将数据以excel文件的形式写入指定路径下（路径不存在会自动创建）
     * 表格样式为null，会设置默认表格样式
     */
    public static void writeExcelFile(List<? extends BaseRowModel> reportList, String filePath, String fileName,TableStyle tableStyle) throws IOException {
        File file = new File(filePath+fileName+".xlsx");
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
            file.createNewFile();
        }
        OutputStream out = new FileOutputStream(file);
        ExcelWriter writer = new ExcelWriter(out, ExcelTypeEnum.XLSX);
        Sheet sheet = new Sheet(1, 0);
        sheet.setSheetName(fileName);
        sheet.setAutoWidth(Boolean.TRUE);
        Table table = new Table(1);
        TableStyle style = tableStyle == null ? commonTableStyle() : tableStyle;
        table.setTableStyle(style);
        table.setClazz(reportList.get(0).getClass());
        writer.write(reportList, sheet, table);
        writer.finish();
        out.close();
    }

    private static TableStyle commonTableStyle() {
        TableStyle tableStyle = new TableStyle();
        Font headFont = new Font();
        headFont.setBold(true);
        headFont.setFontHeightInPoints((short) 14);
        headFont.setFontName("楷体");
        tableStyle.setTableHeadFont(headFont);
        Font contentFont = new Font();
        contentFont.setFontHeightInPoints((short) 12);
        contentFont.setFontName("黑体");
        tableStyle.setTableContentFont(contentFont);
        tableStyle.setTableContentBackGroundColor(IndexedColors.WHITE);
        return tableStyle;
    }
}
