package com.smzc.taxi.common.third.safetycall.client;

import java.io.ByteArrayInputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.BasicHttpEntity;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSONObject;
import com.smzc.taxi.common.third.safetycall.bean.AllocNumberBean;
import com.smzc.taxi.common.third.safetycall.bean.FreeNumberBean;
import com.smzc.taxi.common.third.safetycall.conf.SysConfig;
import com.smzc.taxi.common.third.safetycall.constant.YtxConstant;

import lombok.extern.slf4j.Slf4j;

/**
 * @Description: 云通讯隐号请求实现
 * @author zhukai
 * @date 2019年5月15日 下午2:59:14
 */
@Slf4j
public class YuntxSafetyCall extends AbstractSafetyCall {

    @Override
    public String axbSetNumber(AllocNumberBean allocNumberBean) {

        HttpClient httpclient = getCloseableHttpClient();
        HttpPost httppost = null;
        String result = "";
        try {
            httppost = getHttpPost(NEW_SETNUMBER);
            JSONObject json = new JSONObject();
            json.put("appId", SysConfig.APP_ID);
            json.put("expirationSetting", "3");
            json.put("aNumber", allocNumberBean.getCallee());
            json.put("bNumber", allocNumberBean.getCaller());
            json.put("xNumberRestrict", "1");
            json.put("areaCode", allocNumberBean.getCity());
            json.put("mappingDuration", YtxConstant.LEASE_TIME);
            json.put("cdrNotifyUrl", SysConfig.CDR_NOTIFY_URL);
            json.put("userData", allocNumberBean.getOrderId());
            log.debug("获取隐号传入参数:{}", json.toString());
            httppost.setEntity(getRequestBody(json.toString()));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            if(entity != null)
                result = EntityUtils.toString(entity, YtxConstant.CHARSET);
            EntityUtils.consume(entity);
            log.info("获取隐号出参:{}", result);
        } catch(Exception e) {
        	log.error("获取隐号出错:", e);
            throw new RuntimeException("获取隐号出错!");
        } finally {
            if(null != httppost) {
                httppost.releaseConnection();
            }
            if(null != httpclient) {
                httpclient.getConnectionManager().shutdown();
            }
        }

        return result;
    }

    private HttpEntity getRequestBody(String param) {

        BasicHttpEntity requestBody = new BasicHttpEntity();
        try {
            requestBody.setContent(new ByteArrayInputStream(param.getBytes(YtxConstant.CHARSET)));
            requestBody.setContentLength(param.getBytes(YtxConstant.CHARSET).length);
        } catch(Exception e) {
            log.error("解析参数失败!",e);
            throw new RuntimeException("解析参数失败!");
        }
        return requestBody;
    }

    @Override
    public String axbReleaseNumber(FreeNumberBean freeNumberBean) {

        HttpClient httpclient = getCloseableHttpClient();
        HttpPost httppost = null;
        String result = "";
        try {
            httppost = getHttpPost(NEW_RELEASENUMBER);
            JSONObject json = new JSONObject();
            json.put("appId", SysConfig.APP_ID);
            json.put("mappingId", freeNumberBean.getBindId());
            log.debug("解绑隐号传入参数:{}", json.toString());
            httppost.setEntity(getRequestBody(json.toString()));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            if(entity != null)
                result = EntityUtils.toString(entity, YtxConstant.CHARSET);
            EntityUtils.consume(entity);
            log.debug("解绑隐号出参:", result);
        } catch(Exception e) {
            log.error("解绑隐号出错!", e);
            throw new RuntimeException("解绑隐号出错!");
        } finally {
            if(null != httppost) {
                httppost.releaseConnection();
            }
            if(null != httpclient) {
                httpclient.getConnectionManager().shutdown();
            }
        }
        return result;
    }
}
