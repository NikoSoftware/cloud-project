package com.smzc.taxi.common.utils;

import org.apache.commons.io.FileUtils;

import java.io.*;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
public class ZipUtil {

    /**
     * 将指定文件夹下的所有文件打成zip，
     * 删除源文件后，并返回byte数组
     * @param filePath 源文件夹路径
     */
    public static byte[] packZip(String filePath) throws IOException {
        File tempFile = new File(filePath);
        //在当前文件父路径下创建一个临时zip文件
        String zipFileName = DateUtils.getDateString(new Date(),DateUtils.PATTERN_DATE_TIME_WITHOUT_SEPARATOR) + ".zip";
        String zipFilePath = tempFile.getParent()+File.separator+zipFileName;
        File zipFile=new File(zipFilePath);
        if (!zipFile.getParentFile().exists()) {
            zipFile.getParentFile().mkdirs();
            zipFile.createNewFile();
        }
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile));
        try{
            File[] files = new File(filePath).listFiles();
            byte[] buffer = new byte[1024];
            for (File file2 : files) {
                FileInputStream fis = new FileInputStream(file2);
                try{
                    zos.putNextEntry(new ZipEntry(file2.getName()));
                    int len;
                    while ((len = fis.read(buffer)) != -1) {
                        zos.write(buffer, 0, len);
                    }
                    zos.flush();
                    zos.closeEntry();
                } finally {
                    fis.close();
                }
            }
        } finally {
            zos.close();
        }

        byte[] byteResult = FileUtils.readFileToByteArray(zipFile);
        if(tempFile.isDirectory()){
            FileUtils.deleteDirectory(tempFile);
        } else {
            FileUtils.forceDelete(tempFile);
        }
        FileUtils.forceDelete(zipFile);
        return byteResult;
    }
}
