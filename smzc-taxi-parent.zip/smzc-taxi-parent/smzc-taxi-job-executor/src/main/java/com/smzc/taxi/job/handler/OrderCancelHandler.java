package com.smzc.taxi.job.handler;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.service.order.facade.IOrderFacade;
import com.smzc.taxi.service.vehicle.bean.VehicleColorVo;
import com.smzc.taxi.service.vehicle.facade.IVehicleManageFacade;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 *
 * 订单5分钟自动取消
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/5/29 14:30
 */
@JobHandler(value = "orderCancelHandler")
@Component
public class OrderCancelHandler extends IJobHandler {

    @Reference
    private IOrderFacade orderFacade;

    @Override
    public ReturnT<String> execute(String param) throws Exception {
        try {
            orderFacade.autoCancelOrder(param);
            return SUCCESS;
        } catch (Exception e) {
            XxlJobLogger.log("订单5分钟自动取消异常：" + e.getMessage());
            return FAIL;
        }
    }
}