package com.smzc.taxi.job.handler.market;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.market.service.driver.service.IDriverMarketActivityDataCacheFacade;
import com.smzc.taxi.common.utils.DateUtils;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author by wanglin
 * @date 2019/8/5 19:59
 * @description 加载司机营销活动数据到缓存 (每隔10分钟加载一次)
 */
@JobHandler(value = "driverMarketActivityDataCacheHandler")
@Component
@Slf4j
public class DriverMarketActivityDataCacheHandler extends IJobHandler {

    @Reference(group="smzc-market")
    private IDriverMarketActivityDataCacheFacade driverMarketActivityDataCacheFacade;

    private static final String paramSplit = ";";

    @Override
    public ReturnT<String> execute(String param) throws Exception {
        try {
            Date startDate = new Date();
            log.info("driverMarketActivityDataCacheHandler开始执行时间:[{}],接受到的信息param信息:[{}]", DateUtils.getDateString(startDate), param);
            driverMarketActivityDataCacheFacade.addDataCache(getActivityIds(param));
            Date endDate = new Date();
            log.info("driverMarketActivityDataCacheHandler结束执行时间:[{}],消耗时间[{}]ms", DateUtils.getDateString(endDate),endDate.getTime() - startDate.getTime());
            return SUCCESS;
        } catch (Exception e){
            log.warn("driverMarketActivityDataCacheHandler执行异常",e);
            XxlJobLogger.log("driverMarketActivityDataCacheHandler执行失败，失败信息: " +  e );
            return FAIL;
        }
    }

    private List<Long> getActivityIds(String param){
        List<Long> list = new ArrayList<>();
        if (StringUtils.isNotBlank(param)){
            list = Stream.of(param.split(paramSplit)).map(Long::valueOf).collect(Collectors.toList());
        }
        return list;
    }
}
