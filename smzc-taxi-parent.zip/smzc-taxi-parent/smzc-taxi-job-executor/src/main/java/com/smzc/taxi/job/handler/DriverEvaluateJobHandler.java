package com.smzc.taxi.job.handler;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.common.enums.DateTypeEnum;
import com.smzc.taxi.common.utils.DateUtils;
import com.smzc.taxi.service.driver.bean.DriverGradeDaysVo;
import com.smzc.taxi.service.driver.bean.MobilesAndTimeVo;
import com.smzc.taxi.service.driver.service.IDriverGradeDaysFacade;
import com.smzc.taxi.service.order.bean.vo.OrderEvaluateDriverDayVo;
import com.smzc.taxi.service.order.facade.IOrderEvaluateFacade;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.smzc.taxi.common.utils.DateUtils.PATTERN_GENERAL_DATE;
import static com.smzc.taxi.common.utils.DateUtils.PATTERN_GENERAL_TIME_FULL;

/**
 * @author: zhaohui
 * @date: 2019-05-22 17:44
 * @description: 统计司机每天的评分
 */

@JobHandler(value = "driverEvaluateJobHandler")
@Component
@Slf4j
public class DriverEvaluateJobHandler extends IJobHandler {

    @Reference
    private IDriverGradeDaysFacade driverGradeDaysFacade;

    @Reference
    private IOrderEvaluateFacade orderEvaluateFacade;

    /**
     * param: 时间;手机号码;手机号码;
     * eg:    2019-06-12;1862450222;13676377376;
     */
    @Override
    public ReturnT<String> execute(String param) throws Exception {
        Long startTime = System.currentTimeMillis();
        Date beginDate = null;//开始日期
        Date endDate = null;//结束日期
        final String regexWitMobile = "^(\\d{4}-\\d{2}-\\d{2});(\\d{10,12};)+$";
        final String regexWithDate = "^(\\d{4}-\\d{2}-\\d{2});$";

        try {
            log.info("driverEvaluateJobHandler接受到的信息param信息{}", param);
            //如果参数符合 2009-08-07;18624501413;1472345321;
            if(regexMatch(param,regexWitMobile)){
                MobilesAndTimeVo mobileListAndBeginEndDate = findMobileListAndBeginEndDate(param);
                Date[] beginAndEndDate  = mobileListAndBeginEndDate.getBeginAndEndDate();
                beginDate = beginAndEndDate[0];
                endDate = beginAndEndDate[1];
                List<String> mobileList = mobileListAndBeginEndDate.getMobileList();
                List<OrderEvaluateDriverDayVo> orderEvaluateDriverDayVoList = orderEvaluateFacade.selectDriverEvaluateDayByMobileList(beginDate, endDate, mobileList);
                if(orderEvaluateDriverDayVoList != null && orderEvaluateDriverDayVoList.size() > 0) {
                    List<DriverGradeDaysVo> driverGradeDaysVoList = evaluateDriverToGradeDays(orderEvaluateDriverDayVoList,beginDate);
                    driverGradeDaysFacade.batchUpdate(driverGradeDaysVoList);
                    log.info("driverEvaluateJobHandler执行完成，批量更新 {} 个司机信息", orderEvaluateDriverDayVoList.size() );
                }
                Long endTime = System.currentTimeMillis();
                log.info("driverEvaluateJobHandler执行完成，使用时间: {} ms ", endTime - startTime);
                return SUCCESS;
            }else{
                Date date;
                if (regexMatch(param,regexWithDate)){
                    //手动执行，计算当天的。
                    param = param.substring(0, param.length() - 1);
                    date = DateUtils.getDate(param,PATTERN_GENERAL_DATE);
                    beginDate = DateUtils.ofPassBeginOrEndTime(0, date, DateTypeEnum.BEGIN);
                    endDate = DateUtils.ofPassBeginOrEndTime(0, date, DateTypeEnum.END);
                }else if(DateUtils.belongPeriodTime(new Date(),0,55,2,0)){
                    //corn执行，计算前一天的。
                    date = new Date();
                    beginDate = DateUtils.ofPassBeginOrEndTime(-1, date, DateTypeEnum.BEGIN);
                    endDate = DateUtils.ofPassBeginOrEndTime(-1, date, DateTypeEnum.END);
                }else{
                    log.info("driverEvaluateJobHandler执行失败。当前时间{}",DateUtils.getDateString(PATTERN_GENERAL_TIME_FULL));
                    return FAIL;
                }

                beginDate = DateUtils.ofPassBeginOrEndTime(0, date, DateTypeEnum.BEGIN);
                endDate = DateUtils.ofPassBeginOrEndTime(0, date, DateTypeEnum.END);
                List<OrderEvaluateDriverDayVo> orderEvaluateDriverDayVoList = orderEvaluateFacade.selectDriverEvaluateDay(beginDate, endDate);
                if(CollectionUtils.isNotEmpty(orderEvaluateDriverDayVoList)) {
                    List<DriverGradeDaysVo> driverGradeDaysVoList = evaluateDriverToGradeDays(orderEvaluateDriverDayVoList,beginDate);
                    driverGradeDaysFacade.batchInsert(driverGradeDaysVoList);
                    log.info("driverEvaluateJobHandler执行完成，批量插入:  {} 个司机信息",orderEvaluateDriverDayVoList.size());
                }
                Long endTime = System.currentTimeMillis();
                log.info("driverEvaluateJobHandler执行完成，使用时间: {} ms ", endTime - startTime);
                return SUCCESS;
            }

        } catch (Exception e) {
            log.warn("driverEvaluateJobHandler执行异常",e);
            XxlJobLogger.log("driverEvaluateJobHandler执行失败，失败信息: " +  e );
            return FAIL;
        }
    }

    private  MobilesAndTimeVo findMobileListAndBeginEndDate(String param){
        MobilesAndTimeVo mobilesAndTimeVo = new MobilesAndTimeVo();
        Date[] beginAndEndDate = new Date[2];

        String[] driverTimeAndMobileSplit = param.split(";");
        String dateStr = driverTimeAndMobileSplit[0];
        Date date =  DateUtils.stringToDate(dateStr, PATTERN_GENERAL_DATE);
        Date beginDate = DateUtils.getCurrentStartDay(date);
        Date endDate = DateUtils.getCurrentEndDay(date);

        beginAndEndDate[0] = beginDate;
        beginAndEndDate[1] = endDate;

        ArrayList<String> mobileList = new ArrayList<>(Arrays.asList(driverTimeAndMobileSplit));
        mobileList.remove(0);

        mobilesAndTimeVo.setBeginAndEndDate(beginAndEndDate);
        mobilesAndTimeVo.setMobileList(mobileList);
        return mobilesAndTimeVo;
    }



    private static boolean regexMatch(String param, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(param);
        return matcher.matches();
    }





    private  List<DriverGradeDaysVo> evaluateDriverToGradeDays(List<OrderEvaluateDriverDayVo> orderEvaluateDriverDayVoList,Date date){
        List<DriverGradeDaysVo> driverGradeDaysVoList = new ArrayList<>();
        for (OrderEvaluateDriverDayVo bean: orderEvaluateDriverDayVoList) {
            DriverGradeDaysVo vo = new DriverGradeDaysVo();
            vo.setDays(date);
            vo.setDriverId(bean.getDriverId());
            vo.setOrderNum(bean.getTotalNum());
            vo.setTotalScore(bean.getTotalScore());
            driverGradeDaysVoList.add(vo);
        }
        return driverGradeDaysVoList;
    }






}
