package com.smzc.taxi.job.handler;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.common.utils.DateUtils;
import com.smzc.taxi.service.driver.bean.TransferAccountDeliveryReq;
import com.smzc.taxi.service.driver.bean.TransferAccountRecordVo;
import com.smzc.taxi.service.driver.service.ITransferAccoutRecordFacade;
import com.smzc.taxi.service.finance.enums.TransferStateEnum;
import com.smzc.taxi.service.finance.facade.IDriverWalletFacade;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * @author: zhangzb
 * @date: 2019-7-10 18:05:55
 * @description:
 */
@Slf4j
@Component
@JobHandler(value = "transferAccountHandler")
public class TransferAccountHandler extends IJobHandler {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 一次性批量查询的数目
     */
    private static final int QUERY_PAGE_NUM = 20;

    private static final int QUERY_FAIL_PRE_DAYS = -10;
    private static final int QUERY_PROCESS_PRE_DAYS = -5;
    /**
     * 删除前xx天成功的记录
     */
    private static final int DELETE_SUCCESS_PRE_DAYS = -30;

    @Reference
    private ITransferAccoutRecordFacade transferAccoutRecordFacade;

    @Reference
    private IDriverWalletFacade driverWalletFacade;

    public TransferAccountHandler() {
    }

    @Override
    public ReturnT<String> execute(String s) throws Exception {
        Date now = new Date();
        Date queryFailureDateTime = org.apache.commons.lang3.time.DateUtils.addDays(now, QUERY_FAIL_PRE_DAYS);
        log.info("{}: 定时器{}开始执行.....", DateUtils.getDateString(now), "transferAccountHandler");
        // 待重试的记录
        List<TransferAccountRecordVo> retryList = transferAccoutRecordFacade.getTranAcountRecordList(queryFailureDateTime, TransferStateEnum.FAILURE.getCode(), QUERY_PAGE_NUM);
        if (CollectionUtils.isNotEmpty(retryList)) {
            log.info("已查询到待重试的数量：" + retryList.size());
            for (TransferAccountRecordVo record : retryList) {
                TransferAccountDeliveryReq retryReq = new TransferAccountDeliveryReq();
                retryReq.setOutTransferNo(record.getOutTransferNo());
                retryReq.setSubpartner(record.getSubpartner());
                retryReq.setTransferAmount(record.getTransferAmount());

                try {
                    if (StringUtils.isBlank(record.getFailCode())) {
                        // 重试查询
                        TransferAccountRecordVo resultRecord = driverWalletFacade.retryTransferAccount(retryReq);
                        // “3001”重复转账批次号
                        if ("3001".equals(resultRecord.getFailCode())) {
                            queryTransferAccountInfo(record);
                        } else {
                            record.setRetryTimes((byte) (record.getRetryTimes() + 1));
                            record.setTfTransferNo(resultRecord.getTfTransferNo());
                            record.setTransferState(resultRecord.getTransferState());
                            record.setFailCode(resultRecord.getFailCode());
                            record.setFailReason(resultRecord.getFailReason());
                            record.setTransferBatchNo(resultRecord.getTransferBatchNo());

                            // 更新转账记录和奖励流水
                            transferAccoutRecordFacade.updateRecordById(record);
                        }
                    } else {
                        // 换新批次号重试
                        String newOutTransferNo = increateStringNum(retryReq.getOutTransferNo());
                        retryReq.setOutTransferNo(newOutTransferNo);
                        TransferAccountRecordVo resultRecord = driverWalletFacade.retryTransferAccount(retryReq);
                        record.setRetryTimes((byte) (record.getRetryTimes() + 1));
                        record.setOutTransferNo(newOutTransferNo);
                        record.setTfTransferNo(resultRecord.getTfTransferNo());
                        record.setTransferState(resultRecord.getTransferState());
                        record.setFailCode(resultRecord.getFailCode());
                        record.setFailReason(resultRecord.getFailReason());
                        record.setTransferBatchNo(resultRecord.getTransferBatchNo());

                        // 更新转账记录和奖励流水
                        transferAccoutRecordFacade.updateRecordById(record);
                    }
                } catch (Exception e) {
                    logger.error(String.format("transferAccountHandler outTransferNo=s%", record.getOutTransferNo()), e.getMessage());
                }
            }
        }

        Date queryProcessDateTime = org.apache.commons.lang3.time.DateUtils.addHours(now, QUERY_PROCESS_PRE_DAYS);
        List<TransferAccountRecordVo> processList = transferAccoutRecordFacade.getTranAcountRecordList(queryProcessDateTime, TransferStateEnum.PROCESS.getCode(), QUERY_PAGE_NUM);
        if (CollectionUtils.isNotEmpty(processList)) {
            for (TransferAccountRecordVo recordVo : processList) {
                queryTransferAccountInfo(recordVo);
            }
        }

        return SUCCESS;
    }

    private void queryTransferAccountInfo(TransferAccountRecordVo record) {
        TransferAccountDeliveryReq queryReq = new TransferAccountDeliveryReq();
        queryReq.setPartner(record.getPartner());
        queryReq.setTransferBatchNo(record.getTransferBatchNo());
        queryReq.setOutTransferNo(record.getOutTransferNo());

        try {
            TransferAccountRecordVo recordVo = driverWalletFacade.queryTransferAccount(queryReq);
            record.setTfTransferNo(recordVo.getTfTransferNo());
            record.setTransferState(recordVo.getTransferState());
            record.setFailCode(recordVo.getFailCode());
            record.setFailReason(recordVo.getFailReason());
            record.setTransferBatchNo(recordVo.getTransferBatchNo());

            transferAccoutRecordFacade.updateRecordById(record);
        } catch (Exception e) {
            logger.error(String.format("transferAccountHandler outTransferNo=s%", queryReq.getOutTransferNo()), e.getMessage());
        }
    }

    private String increateStringNum(String outTransferNo) {
        if (StringUtils.isBlank(outTransferNo) && outTransferNo.length() < 4) {
            return outTransferNo;
        }
        String preStr = outTransferNo.substring(0, outTransferNo.length() - 4);
        String endStr = outTransferNo.substring(outTransferNo.length() - 4, outTransferNo.length());

        int count = Integer.parseInt(endStr) + 1;
        String result = "";
        for (int i = 1000; i > 0; ) {
            if (count / i > 0) {
                result = result + count;
                break;
            } else {
                result = result + "0";
            }
            i = i/10;
        }
        return preStr.concat(result);
    }
}
