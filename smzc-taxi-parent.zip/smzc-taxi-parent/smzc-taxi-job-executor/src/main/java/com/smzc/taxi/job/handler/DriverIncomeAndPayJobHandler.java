package com.smzc.taxi.job.handler;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.common.utils.DateUtils;
import com.smzc.taxi.service.driver.service.IDriverAccountTradeRecordFacade;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * @Description 定时将司机财务收支信息存入到mongo中
 * 每天晚上1点执行
 * 可以手动通过输入时间，确定执行哪一天(该时间不能是大于或等于今天的时间)，
 * 如果不传参数则，默认同步前一天的数据
 * @Author denglin
 * @Date 2019/5/29 20:22
 **/
@JobHandler(value = "driverIncomeAndPayJobHandler")
@Component
@Slf4j
public class DriverIncomeAndPayJobHandler extends IJobHandler {
    @Reference
    private IDriverAccountTradeRecordFacade driverAccountTradeRecordFacade;

    @Override
    public ReturnT<String> execute(String s) {
        long start = 0;
        long end = 0;
        try {
            if (StringUtils.isNotBlank(s)) {
                start =  DateUtils.getCurrentStartDay(new SimpleDateFormat("yyyy-MM-dd").parse(s)).getTime();
                end = start + 3600 * 24 * 1000 - 1;
            }
        } catch (ParseException e) {
            XxlJobLogger.log("如果要家参数，那参数只能为时间:yyyy-MM-dd 样式：" + e.getMessage());
            return FAIL;
        }
        driverAccountTradeRecordFacade.syncDriverIncomeAndPayToMongodbByDay(start, end);
        return SUCCESS;
    }

}
