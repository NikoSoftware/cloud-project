package com.smzc.taxi.job.handler.market;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.market.service.driver.service.IDriverMarketActivityFacade;
import com.smzc.taxi.common.utils.DateUtils;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author by wanglin
 * @date 2019/8/5 19:59
 * @description 检查司机营销活动状态(每隔30秒加载一次)
 * 如果当前时间到达开始时间，活动状态需要由 "未开启" 变成 "进行中"
 * 如果当前时间超过结束时间，活动状态需要由 "进行中" 变成 "已过期"
 */
@JobHandler(value = "driverMarketActivityCheckStatusHandler")
@Component
@Slf4j
public class DriverMarketActivityCheckStatusHandler extends IJobHandler {

    @Reference(group="smzc-market")
    private IDriverMarketActivityFacade driverMarketActivityFacade;

    @Override
    public ReturnT<String> execute(String param) throws Exception {
        try {
            Date startDate = new Date();
            log.info("driverMarketActivityCheckStatusHandler开始执行时间:[{}],接受到的信息param信息:[{}]", DateUtils.getDateString(startDate), param);
            driverMarketActivityFacade.checkMarketActivityStatus();
            Date endDate = new Date();
            log.info("driverMarketActivityCheckStatusHandler结束执行时间:[{}],消耗时间[{}]ms", DateUtils.getDateString(endDate),endDate.getTime() - startDate.getTime());
            return SUCCESS;
        } catch (Exception e){
            log.warn("driverMarketActivityCheckStatusHandler执行异常",e);
            XxlJobLogger.log("driverMarketActivityCheckStatusHandler执行失败，失败信息: " +  e );
            return FAIL;
        }
    }
}
