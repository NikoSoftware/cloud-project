package com.smzc.taxi.job.handler;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.service.order.facade.IOrderFacade;
import com.smzc.taxi.service.order.facade.IOrderPayoffFacade;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;
import org.springframework.stereotype.Component;

/**
 *
 * 这里是你的描述信息
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/6/20 9:30
 */
@JobHandler(value = "orderPaySattusHandler")
@Component
public class OrderPaySattusHandler extends IJobHandler {

    @Reference
    private IOrderPayoffFacade orderPayoffFacade;

    @Override
    public ReturnT<String> execute(String param) throws Exception {
        try {
            orderPayoffFacade.syncOrderPayStatus(param);
            return SUCCESS;
        } catch (Exception e) {
            XxlJobLogger.log("定时同步订单支付状态：" + e.getMessage());
            return FAIL;
        }
    }
}