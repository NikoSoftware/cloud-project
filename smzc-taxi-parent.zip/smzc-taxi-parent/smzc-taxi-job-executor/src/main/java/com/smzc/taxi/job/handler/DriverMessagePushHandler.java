package com.smzc.taxi.job.handler;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.common.utils.DateUtils;
import com.smzc.taxi.service.driver.service.IDriverMessagePushFacade;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author by wanglin
 * @date 2019/7/15 10:45
 * @description 定时处理向司机预约push推送的消息(每个一分钟调用一次)
 */
@JobHandler(value = "driverMessagePushHandler")
@Component
@Slf4j
public class DriverMessagePushHandler extends IJobHandler {

    @Reference
    private IDriverMessagePushFacade driverMessagePushFacade;

    @Override
    public ReturnT<String> execute(String param) throws Exception {
        try {
            Date startDate = new Date();
            log.info("driverMessagePushHandler开始执行时间:[{}],接受到的信息param信息:[{}]", DateUtils.getDateString(startDate), param);
            Boolean pushResult = driverMessagePushFacade.handleAppointmentPush(param);
            Date endDate = new Date();
            log.info("driverMessagePushHandler结束执行时间:[{}],是否处理并且成功push推送:[{}],消耗时间[{}]ms", DateUtils.getDateString(endDate), pushResult,endDate.getTime() - startDate.getTime());
            return SUCCESS;
        } catch (Exception e){
            log.warn("driverMessagePushHandler执行异常",e);
            XxlJobLogger.log("driverMessagePushHandler执行失败，失败信息: " +  e );
            return FAIL;
        }
    }
}
