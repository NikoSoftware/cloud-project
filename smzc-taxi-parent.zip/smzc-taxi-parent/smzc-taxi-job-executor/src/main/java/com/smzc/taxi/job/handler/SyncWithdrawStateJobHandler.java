package com.smzc.taxi.job.handler;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSONObject;
import com.smzc.taxi.common.utils.DateUtils;
import com.smzc.taxi.service.driver.bean.DriverAccountTradeRecordUpdateVo;
import com.smzc.taxi.service.driver.bean.WithdrawQueryReqVo;
import com.smzc.taxi.service.driver.service.IDriverAccountTradeRecordFacade;
import com.smzc.taxi.service.finance.facade.IDriverWalletFacade;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * @author: zhangzb
 * @date: 2019/5/28 11:25
 * @description: 同步司机提现结果
 */
@JobHandler(value = "syncWithdrawStateJobHandler")
@Component
@Slf4j
public class SyncWithdrawStateJobHandler extends IJobHandler {

    /**
     * 一次性批量查询提现状态的数目
     */
    private static final int QUERY_WITHDRAW_STATE_NUM = 20;

    @Reference
    private IDriverAccountTradeRecordFacade tradeRecordFacade;

    @Reference
    private IDriverWalletFacade driverWalletFacade;

    @Override
    public ReturnT<String> execute(String s) throws Exception {
        Date now = new Date();
        log.info("{}: 定时器{}开始执行.....", DateUtils.getDateString(now), "syncWithdrawStateJobHandler");
        // 查询待同步的提现申请记录
        List<WithdrawQueryReqVo> queryReqList = tradeRecordFacade.getNeedQueryWithdrawRecord(QUERY_WITHDRAW_STATE_NUM);

        List<DriverAccountTradeRecordUpdateVo> recordUpdateVos = null;
        if (CollectionUtils.isNotEmpty(queryReqList)) {
            recordUpdateVos = driverWalletFacade.withdrawBatchQuery(queryReqList);
            log.info(DateUtils.getDateString(new java.util.Date()) + ", 待同步：" + JSONObject.toJSONString(queryReqList));
        }
        // 回调司机更新提现记录
        if (CollectionUtils.isNotEmpty(recordUpdateVos)) {
            tradeRecordFacade.withdrawUpdateDriverTradeRecordCallBack(recordUpdateVos);
            log.info(DateUtils.getDateString(new java.util.Date()) + ", 已同步：" + JSONObject.toJSONString(recordUpdateVos));
        }

        return SUCCESS;
    }
}
