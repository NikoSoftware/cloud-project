package com.smzc.taxi.job.handler;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSONObject;
import com.smzc.taxi.service.driver.bean.audit.AuditUnNoticeParams;
import com.smzc.taxi.service.driver.service.IDriverAuditFacade;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author denglin
 * @description 定时到天府银行查询司机审核状态（包括司机入驻审核，银行卡修改）
 * @date 2019/6/15
 */
@Slf4j
@Component
@JobHandler(value = "driverAuditQueryJobHandler")
public class DriverAuditQueryJobHandler extends IJobHandler {

    /**
     * 默认一次自动审核数量, 可通过参数覆盖
     */
    private static final Integer DEFAULT_AUTO_AUDIT_LIMIT = 10;

    @Reference(async = true)
    private IDriverAuditFacade driverAuditFacade;

    @Override
    public ReturnT<String> execute(String param) {
        log.info("执行定时到天府银行查询司机审核状态任务, param: {}", param);
        Integer limit = DEFAULT_AUTO_AUDIT_LIMIT;
        AuditUnNoticeParams auditUnNoticeParams=null;
        if(StringUtils.isNotBlank(param)){
            try {
                auditUnNoticeParams = JSONObject.parseObject(param, AuditUnNoticeParams.class);
            } catch (Exception e) {
                log.error("执行定时到天府银行查询司机审核状态任务参数解析错误: {}", param);
                throw new RuntimeException("执行定时到天府银行查询司机审核状态任务参数解析错误"+param);
            }
        }

        try {
            if(auditUnNoticeParams!=null){
                limit = Integer.valueOf(auditUnNoticeParams.getLimit());
            }
        } catch (NumberFormatException e) {
            log.error("执行定时到天府银行查询司机审核状态任务错误: {}, 将使用默认值: {}", param, DEFAULT_AUTO_AUDIT_LIMIT);
        }

        List<String> emails=null;
        if(auditUnNoticeParams!=null&&auditUnNoticeParams.getEmails()!=null){
            emails = auditUnNoticeParams.getEmails().size()==0?null: auditUnNoticeParams.getEmails();
        }

        driverAuditFacade.handleAuditQueryJob(limit,emails);
        return SUCCESS;
    }
}
