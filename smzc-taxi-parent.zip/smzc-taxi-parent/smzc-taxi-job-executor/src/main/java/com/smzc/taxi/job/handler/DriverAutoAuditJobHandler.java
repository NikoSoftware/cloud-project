package com.smzc.taxi.job.handler;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.service.driver.service.IDriverAuditFacade;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author pengpengcheng
 * @description 司机自动审核任务
 * @date 2019/6/15
 */
@Slf4j
@Component
@JobHandler(value = "driverAutoAuditJobHandler")
public class DriverAutoAuditJobHandler extends IJobHandler {

    /**
     * 默认一次自动审核数量, 可通过参数覆盖
     */
    private static final Integer DEFAULT_AUTO_AUDIT_LIMIT = 10;

    /**
     * 最大超时时间三分钟, 避免因任务未及时提交到线程池导致定时任务错误
     */
    @Reference(timeout = 18000)
    private IDriverAuditFacade driverAuditFacade;

    @Override
    public ReturnT<String> execute(String param) {
        log.info("执行定时自动审核司机任务, param: {}", param);
        Integer limit = DEFAULT_AUTO_AUDIT_LIMIT;
        try {
            limit = Integer.valueOf(param);
        } catch (NumberFormatException e) {
            log.error("司机自动审核任务参数错误: {}, 将使用默认值: {}", param, DEFAULT_AUTO_AUDIT_LIMIT);
        }

        driverAuditFacade.handleAutoAuditJob(limit);
        return SUCCESS;
    }
}
