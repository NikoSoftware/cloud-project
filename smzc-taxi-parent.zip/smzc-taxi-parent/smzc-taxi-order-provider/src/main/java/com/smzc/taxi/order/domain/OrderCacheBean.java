package com.smzc.taxi.order.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 缓存流程中必须用的订单相关的数据
 *
 * @author liuinjie
 * @date 2019/05/16
 */
@Data
public class OrderCacheBean implements Serializable {

    /**
     * id
     */
    private Long id;

    /**
     * 终点纬度
     */
    private Double planToLatitude;

    /**
     * 终点经度
     */
    private Double planToLongitude;

    /**
     * 终点地址
     */
    private String planToAddress;

    /**
     * 终点街道
     */
    private String planToStreet;

    /**
     * 起点经度纬度
     */
    private Double planFromLatitude;

    /**
     * 起点经度
     */
    private Double planFromLongitude;

    /**
     * 起点地址
     */
    private String planFromAddress;

    /**
     * 起点街道
     */
    private String planFromStreet;

    /**
     * 司机ID
     */
    private Long driverId;

    /**
     * 司机名称
     */
    private String driverName;

    /**
     * 城市编码
     */
    private String cityCode;

    /**
     * 车辆ID
     */
    private Long vehicleId;

    /**
     * 车辆编号
     */
    private String vehicleNo;

    /**
     * 乘客ID
     */
    private Long subscriberId;

    /**
     * 乘客姓名
     */
    private String subscriberName;

    /**
     * 预估时间
     */
    private Integer predictTime;

    /**
     * 添加类型
     */
    private Byte addType;

    /**
     * 乘车时间
     */
    private Date scheduleTime;

    /**
     * 司机手机号
     */
    private String driverPhone;

    /**
     * 乘客手机号
     */
    private String passengerPhone;

    /**
     * 起点城市编码
     */
    private String planFromCityCode;
}