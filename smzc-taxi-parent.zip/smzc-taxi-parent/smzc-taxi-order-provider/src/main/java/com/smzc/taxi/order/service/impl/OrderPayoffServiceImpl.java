package com.smzc.taxi.order.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.common.utils.Arith;
import com.smzc.taxi.common.utils.DateUtils;
import com.smzc.taxi.common.utils.JsonUtils;
import com.smzc.taxi.order.dao.mapper.*;
import com.smzc.taxi.order.domain.*;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.OrderActivityService;
import com.smzc.taxi.order.service.OrderPayoffService;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.service.context.ProxyStatusTransferControl;
import com.smzc.taxi.service.driver.bean.DriverAccountTradeRecordFinanceVo;
import com.smzc.taxi.service.driver.enums.TradeEventTypeEnum;
import com.smzc.taxi.service.driver.enums.TradeStatusEnum;
import com.smzc.taxi.service.driver.service.IDriverAccountTradeRecordFacade;
import com.smzc.taxi.service.finance.enums.TfbPayChannel;
import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.emun.PayType;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.order.exception.OrderException;
import com.smzc.taxi.service.passenger.bean.price.*;
import com.smzc.taxi.service.passenger.enums.CountPricelType;
import com.smzc.taxi.service.passenger.enums.OrderPriceDetailType;
import com.smzc.taxi.service.passenger.service.IPriceConfigureFacade;
import com.smzc.taxi.service.portal.bean.PriceModifyInnerVo;
import com.smzc.taxi.service.portal.bean.PriceModifyLogVo;
import com.smzc.taxi.service.portal.bean.PriceModifyUpdVo;
import com.smzc.taxi.service.portal.enums.SmPayChannel;
import com.smzc.taxi.service.portal.service.IPriceModifyLogFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 订单结算服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/25
 */
@Slf4j
@Service
public class OrderPayoffServiceImpl implements OrderPayoffService {

    @Resource
    private OrderPayoffMapper orderPayoffMapper;

    @Resource
    private OrderPayoffDetailMapper orderPayoffDetailMapper;

    @Resource
    OrderInfoMapper orderInfoMapper;

    @Reference(version = "1.0.0")
    private IPriceModifyLogFacade orderPriceModifyLogFacade;

    // 计价接口
    @Reference(version = "1.0.0")
    private IPriceConfigureFacade priceConfigureFacade;

    @Resource
    OrderService orderService;

    @Reference(version = "1.0.0")
    private IDriverAccountTradeRecordFacade accountTradeRecordFacade;
    @Resource
    OrderActivityService orderActivityService;
    @Resource
    OrderActivityMapper orderActivityMapper;
    @Resource
    ProxyStatusTransferControl proxyStatusTransferControl;

    @Resource
    OrderInfoExtMapper orderInfoExtMapper;

    @Override
    public CommonCode addPayoff(OrderPayoffVo orderPayoffVo) {
        final Long orderId = orderPayoffVo.getOrderId();
        OrderCacheBean orderCache = orderService.getOrderCache(orderId);
        AssertUtil.notNull(orderCache, "OrderId:[" + orderId + "],订单不存在");
        OrderInfoContext orderInfo = JsonUtils.copyProperites(OrderInfoContext.class, orderCache);
        orderInfo.setStatus(orderService.getOrderStatusById(orderId));
        boolean contains = Arrays.asList(
                OrderStatus.WAIT_PAY,
                OrderStatus.WAIT_PAY_CANCEL,
                OrderStatus.WAIT_PAY_REJECT)
                .contains(orderInfo.getStatus());

        AssertUtil.isTrue(contains, "OrderId:[" + orderId + "],待支付的订单才能进入最后结算");

        // 查询乘客应该支付的金额
        OrderPayoff orderPayoff = orderPayoffMapper.selectPayoffByOrderId(orderPayoffVo.getOrderId());

        AssertUtil.notNull(orderPayoff, "OrderId:[" + orderId + "],此订单无结算信息，不能结算");

        // 订单支付金额
        int payAmount = orderPayoff.getPayAmount();

        // 只有线上支付才需要验证支付金额
        if (PayType.ON_LINE == orderPayoffVo.getPayType()) {
            if (orderPayoffVo.getPayAmount() != payAmount) {
                throw new OrderException("OrderId:[" + orderId + "],传入的总价与明细计算出的总价不一致，结算失败,传入金额:[" + orderPayoffVo.getPayAmount() + "]");
            }
        } else {
            // 线下支付
            // 删除写入的优惠金额,支付金额=订单金额
            orderPayoff.setDiscountAmount(0);
            orderPayoff.setPayAmount(orderPayoff.getOrderAmount());
        }


        // 准备修改订单结算数据
        orderPayoff.setPayChannel(orderPayoffVo.getPayChannel().getCode());
        orderPayoff.setPayType(orderPayoffVo.getPayType().getIndex());
        orderPayoff.setPayTime(orderPayoffVo.getPayTime());

        // 判定是走取消?驳回还是待评价
        final List<OrderPayoffDetail> payoffDetailList = orderPayoffDetailMapper.selectListByOrderId(orderPayoffVo.getOrderId());
        List<String> filterList = payoffDetailList.stream()
                .map(OrderPayoffDetail::getCostKey)
                .collect(Collectors.toList());

        OrderStatus toStatus;
        OrderStatus fromStatus;

        if (filterList.contains(OrderPriceDetailType.CANCELAMOUNT.getFieldName())) {
            fromStatus = OrderStatus.WAIT_PAY_CANCEL;
            toStatus = OrderStatus.CANCEL;
        } else if (filterList.contains(OrderPriceDetailType.REJECTAMOUNT.getFieldName())) {
            fromStatus = OrderStatus.WAIT_PAY_REJECT;
            toStatus = OrderStatus.REJECTED;
        } else {
            fromStatus = OrderStatus.WAIT_PAY;
            toStatus = OrderStatus.WAIT_EVALUATE;
        }

        orderInfo.setPlatformType(orderPayoffVo.getPlatformType());
        orderInfo.setDiscountAmount(orderPayoff.getDiscountAmount());
        orderInfo.setOrderAmount(orderPayoff.getOrderAmount());
        final ControlContext context =
                new ControlContext(fromStatus, toStatus, orderInfo);
        context.put("payType", orderPayoffVo.getPayType());
        context.put("orderPayoff", orderPayoff);
        proxyStatusTransferControl.transfer(context);
        return CommonCode.SUCCESS;
    }

    @Override
    public CommonCode addPayOffDetails(OrderPayoffDetailContextVo contextVo) {
        List<OrderPayoffDetailVo> list = contextVo.getList();
        final Long orderId = list.get(0).getOrderId();
        final OrderCacheBean orderCache = orderService.getOrderCache(orderId);
        AssertUtil.notNull(orderCache, "OrderId:{" + orderId + "},不存在此订单");
        OrderInfoContext orderInfo = JsonUtils.copyProperites(OrderInfoContext.class, orderCache);
        orderInfo.setStatus(orderService.getOrderStatusById(orderId));

        if (OrderStatus.WAIT_COLLECT_MONEY != orderInfo.getStatus()) {
            throw new OrderException("OrderId:{" + orderId + "},待收款才能发起收款");
        }
        orderInfo.setPlatformType(contextVo.getPlatformType());
        final ControlContext context =
                new ControlContext(OrderStatus.WAIT_COLLECT_MONEY, OrderStatus.WAIT_PAY, orderInfo);
        context.put("payoffDetailList", list);
        proxyStatusTransferControl.transfer(context);
        return CommonCode.SUCCESS;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updPayoffEdtails(List<OrderPayoffDetailVo> list) {
        for (OrderPayoffDetailVo vo : list) {
            if (vo != null) {
                OrderPayoffDetail detail = new OrderPayoffDetail(vo.getOrderId(), vo.getCostKey(), vo.getCostAmount());
                orderPayoffDetailMapper.updateByOrderId(detail);
            }
        }
    }


    @Override
    @RouterDataSource(DataSourceAddr.SLAVE)
    public List<OrderPayoffDetailVo> queryPayoffDetailListByOrderId(Long orderId) {
        List<OrderPayoffDetail> list = orderPayoffDetailMapper.selectListByOrderId(orderId);
        List<OrderPayoffDetailVo> orderPayoffDetailVoList = list.stream()
                .filter(data -> {
                    return OrderPriceDetailType.OTHERAMOUNT != OrderPriceDetailType.fromFieldName(data.getCostKey()); //筛选出 其他订单
                })
                .map(data -> {
                    OrderPriceDetailType orderFeeEnum = OrderPriceDetailType.fromFieldName(data.getCostKey());
                    return new OrderPayoffDetailVo(data.getOrderId(), data.getCostKey()
                            , data.getCostAmount(), orderFeeEnum == null ? null : orderFeeEnum.getName());
                }).collect(Collectors.toList());

        return orderPayoffDetailVoList;
    }

    @Override
    @RouterDataSource(DataSourceAddr.SLAVE)
    public List<OrderPayoffDetailDiffVo> queryPayoffDetailListByOrderId_v2(Long orderId) {
        List<OrderPayoffDetail> list = orderPayoffDetailMapper.selectListByOrderId(orderId);
        List<OrderPayoffDetailDiffVo> orderPayoffDetailVoList = list.stream()
                .filter(data -> {
                    return OrderPriceDetailType.OTHERAMOUNT != OrderPriceDetailType.fromFieldName(data.getCostKey())
                            && data.getCostAmount() != 0;
                })
                .map(data -> {
                    OrderPriceDetailType orderFeeEnum = OrderPriceDetailType.fromFieldName(data.getCostKey());
                    String amount = "￥" + Arith.div(data.getCostAmount(), 100, 2);
                    if (data.getCostAmount() < 0) {
                        amount = "-" + amount.replace("-", "");
                    }
                    return new OrderPayoffDetailDiffVo(data.getOrderId(), data.getCostKey()
                            , amount, orderFeeEnum == null ? null : orderFeeEnum.getName());
                }).collect(Collectors.toList());
        return orderPayoffDetailVoList;
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public PageInfo<IncomeVo> queryIncomeList(IncomeQryVo qryVo) {
        //神马内部定义支付渠道 转化为 天府银行定义支付渠道
        SmPayChannel smPayChannel = qryVo.getSmPayChannel();
        if (smPayChannel != null) {
            List<TfbPayChannel> tfbPayChannelList = new ArrayList<>();
            tfbPayChannelList.addAll(TfbPayChannel.buildTfChannelsBySmChannel(smPayChannel));
            qryVo.setTfbPayChannelList(tfbPayChannelList);
        }
        //查询
        PageHelper.startPage(qryVo.getPageNum(), qryVo.getPageSize());
        List<IncomeVo> incomeVoList = orderPayoffMapper.queryIncomeList(qryVo);
        if (incomeVoList != null) {
            for (IncomeVo vo : incomeVoList) {
                vo.setSmPayChannel(TfbPayChannel.getSmChannelByTfChannel(vo.getPayChannel()));
            }
        }
        return new PageInfo<>(incomeVoList);
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public IncomeVo queryIncomeByOrderId(Long orderId) {
        IncomeQryVo qryVo = new IncomeQryVo();
        qryVo.setOrderId(orderId);
        List<IncomeVo> incomeVoList = orderPayoffMapper.queryIncomeList(qryVo);
        if (CollectionUtils.isEmpty(incomeVoList)) {
            return null;
        }
        IncomeVo vo = incomeVoList.get(0);
        vo.setSmPayChannel(TfbPayChannel.getSmChannelByTfChannel(vo.getPayChannel()));
        return vo;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommonCode updPayoffDetail(PriceModifyUpdVo updVo, PriceModifyInnerVo innerVo) {

        Long orderId = Long.valueOf(updVo.getOrderId());
        // 改价前各项费用金额
        Map<String, Integer> map = getPayoffMap(innerVo.getPayOffDetailList());
        Integer basicAmount = map.get(OrderPriceDetailType.BASICAMOUNT.getFieldName());
        Integer bridgeAmount = map.get(OrderPriceDetailType.BRIDGEAMOUNT.getFieldName());
        Integer parkAmount = map.get(OrderPriceDetailType.PARKAMOUNT.getFieldName());
        Integer cleanAmount = map.get(OrderPriceDetailType.CLEANINGAMOUNT.getFieldName());

        // 各项费用的调整金额
        Integer adjustBasicAmount = transformInteger(updVo.getAdjustBasicAmount());
        Integer adjustBridgeAmount = transformInteger(updVo.getAdjustBridgeAmount());
        Integer adjustParkAmount = transformInteger(updVo.getAdjustParkAmount());
        Integer adjustCleanAmount = transformInteger(updVo.getAdjustCleanAmount());
        // 调整后各项费用的金额
        Long finalBasicAmount = (long) basicAmount + (long) adjustBasicAmount;
        Long finalBridgeAmount = (long) bridgeAmount + (long) adjustBridgeAmount;
        Long finalparkAmount = (long) parkAmount + (long) adjustParkAmount;
        Long finalCleanAmount = (long) cleanAmount + (long) adjustCleanAmount;
        checkAmount(finalBasicAmount, finalBridgeAmount, finalparkAmount, finalCleanAmount);

        OrderInfo orderInfo = orderInfoMapper.selectByPrimaryKey(orderId);

        OrderPriceCalculateVo orderPriceCalculateVo = new OrderPriceCalculateVo();
        orderPriceCalculateVo.setSubscriberId(orderInfo.getSubscriberId());
        orderPriceCalculateVo.setAreaCode(orderInfo.getCityCode());

        orderPriceCalculateVo.setBasicAmount(finalBasicAmount.intValue());
        orderPriceCalculateVo.setBridgeAmount(finalBridgeAmount.intValue());
        orderPriceCalculateVo.setCleaningAmount(finalCleanAmount.intValue());
        orderPriceCalculateVo.setParkAmount(finalparkAmount.intValue());
        //
        orderPriceCalculateVo.setCountPricelType(CountPricelType.PASSENGER);
        OrderCacheBean orderCache = orderService.getOrderCache(orderInfo.getId());
        orderPriceCalculateVo.setFrom(new UserPosition(orderCache.getPlanFromLongitude(), orderCache.getPlanFromLatitude()));
        orderPriceCalculateVo.setTo(new UserPosition(orderCache.getPlanToLongitude(), orderCache.getPlanToLatitude()));
        orderPriceCalculateVo.setOrderId(orderInfo.getId());
        List<OrderActivity> list = orderActivityMapper.selectByOrderId(orderId);
        DiscountVoucherVo discountVoucherVo = new DiscountVoucherVo();
        discountVoucherVo.setActivityList(JsonUtils.copyList(ActivityResultVo.class, list));
        orderPriceCalculateVo.setDiscountVoucherVo(discountVoucherVo);

        // 新加需求 写入手机编号
        OrderInfoExt orderInfoExt = orderInfoExtMapper.selectByOrderId(orderId);
        orderPriceCalculateVo.setDeviceType(orderInfoExt.getDeviceFrom());
        orderPriceCalculateVo.setDeviceNumber(orderInfoExt.getDeviceNumber());


        final OrderPriceCalculateResultVo orderPriceCalculate = priceConfigureFacade.getOrderPriceCalculate(orderPriceCalculateVo);
        List<CalculateResultItem> priceDetailList = orderPriceCalculate.getPriceDetailList();
        List<OrderPayoffDetailVo> paoffDetailList = priceDetailList.parallelStream().map(m -> {

            final Integer code = m.getCode();
            if (OrderPriceDetailType.BASICAMOUNT.getCode() == code.intValue()) {
                return new OrderPayoffDetailVo(orderInfo.getId(), OrderPriceDetailType.BASICAMOUNT.getFieldName(), m.getAmount());
            } else if (OrderPriceDetailType.BRIDGEAMOUNT.getCode() == code.intValue()) {
                return new OrderPayoffDetailVo(orderInfo.getId(), OrderPriceDetailType.BRIDGEAMOUNT.getFieldName(), m.getAmount());
            } else if (OrderPriceDetailType.CLEANINGAMOUNT.getCode() == code.intValue()) {
                return new OrderPayoffDetailVo(orderInfo.getId(), OrderPriceDetailType.CLEANINGAMOUNT.getFieldName(), m.getAmount());
            } else if (OrderPriceDetailType.PARKAMOUNT.getCode() == code.intValue()) {
                return new OrderPayoffDetailVo(orderInfo.getId(), OrderPriceDetailType.PARKAMOUNT.getFieldName(), m.getAmount());
            } else if (OrderPriceDetailType.VOUCHERAMOUNT.getCode() == code.intValue()) {
                return new OrderPayoffDetailVo(orderInfo.getId(), OrderPriceDetailType.VOUCHERAMOUNT.getFieldName(), -m.getAmount());
            } else if (OrderPriceDetailType.DIRECTIONAMOUNT.getCode() == code.intValue()) {
                return new OrderPayoffDetailVo(orderInfo.getId(), OrderPriceDetailType.DIRECTIONAMOUNT.getFieldName(), -m.getAmount());
            } else {
                return null;
            }
        }).filter(Objects::nonNull).collect(Collectors.toList());

        // 改价
        this.updPayoffEdtails(paoffDetailList);

        // 修改结算表
        this.updateByOrderId(orderInfo.getId(), orderPriceCalculate);

        // 修改订单活动
        DiscountVoucherResultVo resultVo = orderPriceCalculate.getDiscountVoucherResultVo();
        if (resultVo != null) {
            final List<ActivityResultVo> activityList = resultVo.getActivityList();
            // 批量添加订单活动
            orderActivityMapper.delOrderActivity(orderInfo.getId());
            orderActivityService.batchAddOrderActivity(activityList, orderInfo.getId(), orderPriceCalculateVo.getCountPricelType());
        }


        log.debug("订单id={}，由操作员{}改价成功，改价前:{}，调差明细[基本费用:{}，路桥费:{}，停车费:{}，清洁费:{}]，改价后:{}",
                orderId, updVo.getCreatedBy(), innerVo.getPayAmount(), adjustBasicAmount, adjustBridgeAmount, adjustParkAmount, adjustCleanAmount, orderPriceCalculate.getPayAmount());
        // 保存改价记录
        PriceModifyLogVo logVo = new PriceModifyLogVo();
        BeanUtils.copyProperties(updVo, logVo);
        logVo.setOrderId(orderId);
        logVo.setSourcePayAmount(innerVo.getPayAmount());
        logVo.setDstPayAmount(orderPriceCalculate.getPayAmount());
        logVo.setAdjustBasicAmount(adjustBasicAmount);
        logVo.setAdjustBridgeAmount(adjustBridgeAmount);
        logVo.setAdjustParkAmount(adjustParkAmount);
        logVo.setAdjustCleanAmount(adjustCleanAmount);
        orderPriceModifyLogFacade.saveLog(logVo);
        return CommonCode.SUCCESS;
    }


    @Override
    public void syncOrderPayStatus(String params) {
        Integer time = Integer.valueOf(params);
        AssertUtil.notNull(time, "时间参数不能为空");
        AssertUtil.isTrue(time > 0, "时间参数必须大于0");
        Date date = DateUtils.addDay(new Date(), -time, 12);
        List<Byte> statusList = Arrays.asList(
                OrderStatus.WAIT_PAY.getIndex(),
                OrderStatus.WAIT_PAY_CANCEL.getIndex(),
                OrderStatus.WAIT_PAY_REJECT.getIndex()
        );

        // 查询指定时间之内没有付款的订单
        List<Long> list = orderInfoMapper.selectByWaitPayAndUpdTime(date, statusList);
        if (CollectionUtils.isEmpty(list)) {
            return;
        }

        list.stream().forEach(orderId -> {
            try {
                DriverAccountTradeRecordFinanceVo financeVo = accountTradeRecordFacade.getBySourceIdAndeventType(orderId.toString(), TradeEventTypeEnum.ORDER);
                if (financeVo != null && financeVo.getConfirmState().equals(TradeStatusEnum.SUCCESS.getCode())) {
                    log.info("OrderId:{},获取支付状态：{}", orderId, financeVo.getConfirmState());
                    // 已支付
                    addPayoff(orderId, financeVo);
                    log.info("OrderId:{},支付状态同步成功", orderId);
                }
            } catch (Exception e) {
                log.error("OrderId:{},订单支付状态同步异常", orderId, e);
            }
        });
    }

    private void addPayoff(Long id, DriverAccountTradeRecordFinanceVo financeVo) {
        OrderPayoffVo orderPayoffVo = new OrderPayoffVo();
        orderPayoffVo.setOrderId(id);
        orderPayoffVo.setPayChannel(TfbPayChannel.getByCode(financeVo.getTransChannel()));
        orderPayoffVo.setPayTime(financeVo.getFinishTime());
        orderPayoffVo.setPayType(financeVo.getTradeChannel() == 0 ? PayType.ON_LINE : PayType.OFF_LINE);
        orderPayoffVo.setOrderAmount(null);
        orderPayoffVo.setPayAmount(financeVo.getTotalAmount());
        addPayoff(orderPayoffVo);

    }

    /**
     * 改价
     *
     * @param id
     * @param orderPriceCalculate
     */
    private void updateByOrderId(Long id, OrderPriceCalculateResultVo orderPriceCalculate) {
        OrderPayoff orderPayoff = new OrderPayoff();
        orderPayoff.setOrderId(id);
        orderPayoff.setOrderAmount(orderPriceCalculate.getTotalAmount());
        orderPayoff.setDiscountAmount(orderPriceCalculate.getDiscountAllAmount());
        orderPayoff.setPayAmount(orderPriceCalculate.getPayAmount());
        orderPayoffMapper.updateByOrderId(orderPayoff);
    }

    /**
     * 神马内部定义支付渠道 转化为 天府银行定义支付渠道
     */
    private void convertPayChannel(SmPayChannel smPayChannel, List<TfbPayChannel> tfbPayChannelList) {
        if (SmPayChannel.ALIPAY == smPayChannel) {
            tfbPayChannelList.add(TfbPayChannel.ALIPAY);
            tfbPayChannelList.add(TfbPayChannel.ALIPAY_WAP);
        } else if (SmPayChannel.WX == smPayChannel) {
            tfbPayChannelList.add(TfbPayChannel.WX);
            tfbPayChannelList.add(TfbPayChannel.WX_LITE);
            tfbPayChannelList.add(TfbPayChannel.WX_WEB_H5);
        } else {
            tfbPayChannelList.add(TfbPayChannel.B2B);
            tfbPayChannelList.add(TfbPayChannel.B2C_CREDIT);
            tfbPayChannelList.add(TfbPayChannel.B2C);
            tfbPayChannelList.add(TfbPayChannel.BALANCE);
            tfbPayChannelList.add(TfbPayChannel.WALLET);
            tfbPayChannelList.add(TfbPayChannel.COIN_PURSE);
            tfbPayChannelList.add(TfbPayChannel.OFFLINE_PAY);
            tfbPayChannelList.add(TfbPayChannel.QUICKPAY_CGNB);
            tfbPayChannelList.add(TfbPayChannel.CREDITCARD_CGNB);
            tfbPayChannelList.add(TfbPayChannel.QUICK_DEBIT_PAY);
            tfbPayChannelList.add(TfbPayChannel.QUICK_CREDIT_PAY);
        }
    }

    /**
     * 天府银行定义支付渠道 转化为 神马内部定义支付渠道
     */
    private void convertPayChannel(IncomeVo vo) {
        TfbPayChannel payChannel = vo.getPayChannel();
        if (TfbPayChannel.ALIPAY == payChannel || TfbPayChannel.ALIPAY_WAP == payChannel) {
            vo.setSmPayChannel(SmPayChannel.ALIPAY);
        } else if (TfbPayChannel.WX == payChannel || TfbPayChannel.WX_LITE == payChannel || TfbPayChannel.WX_WEB_H5 == payChannel) {
            vo.setSmPayChannel(SmPayChannel.WX);
        } else {
            vo.setSmPayChannel(SmPayChannel.OTHERS);
        }
    }

    /**
     * <p> 转为分为单位的金额 </p>
     *
     * @param value 金额（元）
     * @return
     */
    private Integer transformInteger(String value) {
        if (value == null) {
            return 0;
        }
        BigDecimal result = new BigDecimal(value);
        result = result.multiply(new BigDecimal(100));
        AssertUtil.isTrue(result.longValue() <= Integer.MAX_VALUE && result.longValue() >= Integer.MIN_VALUE, "金额超限");
        return result.intValue();
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public OrderAmountVo selectOrderAmountByOrderId(Long orderId) {
        Long subscriberId = orderInfoMapper.getSubscriberIdById(orderId);
        if (subscriberId == null) {
            return null;
        }
        OrderPayoff orderPayoff = orderPayoffMapper.selectPayoffByOrderId(orderId);
        OrderAmountVo vo = new OrderAmountVo();
        vo.setOrderAmount(orderPayoff.getOrderAmount());
        vo.setPayAmount(orderPayoff.getPayAmount());
        vo.setDiscountAmount(orderPayoff.getDiscountAmount());
        vo.setSubscriberId(subscriberId);
        return vo;
    }

    /**
     * 校验改价后金额
     *
     * @param finalBasicAmount
     * @param finalBridgeAmount
     * @param finalparkAmount
     * @param finalCleanAmount
     */
    private void checkAmount(Long finalBasicAmount, Long finalBridgeAmount, Long finalparkAmount, Long finalCleanAmount) {
        // 校验改价后各项费用是否为负
        AssertUtil.isTrue(finalBasicAmount > -1, OrderPriceDetailType.BASICAMOUNT.getName() + "费用扣减不允许为负");
        AssertUtil.isTrue(finalBridgeAmount > -1, OrderPriceDetailType.BRIDGEAMOUNT.getName() + "费用扣减不允许为负");
        AssertUtil.isTrue(finalparkAmount > -1, OrderPriceDetailType.PARKAMOUNT.getName() + "费用扣减不允许为负");
        AssertUtil.isTrue(finalCleanAmount > -1, OrderPriceDetailType.CLEANINGAMOUNT.getName() + "费用扣减不允许为负");
        // 校验改价后金额是否超限
        AssertUtil.isTrue(finalBasicAmount <= Integer.MAX_VALUE, OrderPriceDetailType.BASICAMOUNT.getName() + "金额超限");
        AssertUtil.isTrue(finalBridgeAmount <= Integer.MAX_VALUE, OrderPriceDetailType.BRIDGEAMOUNT.getName() + "金额超限");
        AssertUtil.isTrue(finalparkAmount <= Integer.MAX_VALUE, OrderPriceDetailType.PARKAMOUNT.getName() + "金额超限");
        AssertUtil.isTrue(finalCleanAmount <= Integer.MAX_VALUE, OrderPriceDetailType.CLEANINGAMOUNT.getName() + "金额超限");
    }

    private Map<String, Integer> getPayoffMap(List<OrderPayoffDetailVo> details) {
        if (CollectionUtils.isEmpty(details)) {
            throw new OrderException("订单明细不存在");
        }
        Map<String, Integer> map = new HashMap<>();
        for (OrderPayoffDetailVo vo : details) {
            OrderPriceDetailType type = OrderPriceDetailType.fromFieldName(vo.getCostKey());
            AssertUtil.notNull(type, "订单费用明细key数据错误");
            AssertUtil.notNull(vo.getCostAmount(), type.getName() + " 费用明细不存在");
            map.put(vo.getCostKey(), vo.getCostAmount());
        }
        return map;
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public OrderPayoffAmoutVo selectOrderPayoffAmountByOrderId(Long orderId) {
        AssertUtil.notNull(orderId, "订单id不能为空");
        OrderStatus orderStatus = orderService.getOrderStatusById(orderId);
        AssertUtil.isTrue(orderStatus == OrderStatus.WAIT_PAY
                        || orderStatus == OrderStatus.WAIT_EVALUATE
                        || orderStatus == OrderStatus.FINISH,
                "订单状态不为待支付或已评价或已完成");
        return orderPayoffMapper.selectOrderPayoffAmountByOrderId(orderId);
    }
}
