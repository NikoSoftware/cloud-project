package com.smzc.taxi.order.service;

import com.github.pagehelper.PageInfo;
import com.smzc.taxi.order.domain.OrderCacheBean;
import com.smzc.taxi.order.domain.OrderInfo;
import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.portal.bean.DriverOrderReqVo;
import com.smzc.taxi.service.portal.bean.PriceModifyInnerVo;
import com.smzc.taxi.service.portal.bean.PriceModifyQryVo;
import com.smzc.taxi.service.portal.bean.PriceModifyRespVo;

import java.util.List;

/**
 *
 * 中控服务
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/6/18 16:10
 */
public interface CenterControllerOrderService {

    /**
     * buriedClock
     * @param driverOrderReqVo
     * @return
     */
    CommonCode buriedClock(DriverOrderReqVo driverOrderReqVo);

    /**
     * riseClock
     * @param driverOrderReqVo
     * @return
     */
    CommonCode riseClock(DriverOrderReqVo driverOrderReqVo);
}
