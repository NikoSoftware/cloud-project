package com.smzc.taxi;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 七牛云配置
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/6/12
 */
@Component
@ConfigurationProperties(prefix = "qiniu.upload")
@Data
public class QiNiuConfig {

    private String accessKey;
    private String secretKey;
    private String bucket;
    private String baseUri;

}
