package com.smzc.taxi.order.service.validator;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.service.driver.bean.OpenCityVo;
import com.smzc.taxi.service.order.bean.vo.OrderInfoVo;
import com.smzc.taxi.service.portal.service.IOpenCityFacade;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * 城市开放规则等校验
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/7/29
 */
@Component
public class RuleValidator implements OrderValidator {

    @Reference(version = "1.0.0")
    private IOpenCityFacade openCityFacade;

    @Override
    public ValidResult valid(OrderInfoVo orderInfoVo, ValidResult r) {
        //        校验城市是否开放
        final String planFromCityCode = orderInfoVo.getPlanFromCityCode();
        final List<OpenCityVo> openCityVos = openCityFacade.selectOpenCityList();

        if (CollectionUtils.isEmpty(openCityVos)) {
            return r.error("未配置开放城市");
        }

        boolean b = openCityVos.stream().anyMatch(item -> item.getAreaCode().equals(planFromCityCode));
        if (!b) {
            return r.error("订单起点所在城市[" + orderInfoVo.getPlanFromCityName() + "]未开放！");
        }

        return r;
    }
}
