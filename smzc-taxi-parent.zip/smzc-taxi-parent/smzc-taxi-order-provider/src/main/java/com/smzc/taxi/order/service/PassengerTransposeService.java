package com.smzc.taxi.order.service;

public interface PassengerTransposeService {

    /**
     * 解绑隐号
     *
     * @param orderId
     */
    void releaseSafeCallPhone(Long orderId);
}
