package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.smzc.taxi.order.service.OrderNoteService;
import com.smzc.taxi.service.order.bean.vo.OrderNoteVo;
import com.smzc.taxi.service.order.facade.IOrderNoteFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 订单留言
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/20
 */
@Component
@Service
@Slf4j
public class OrderNoteFacade implements IOrderNoteFacade {
    @Resource
    private OrderNoteService orderNoteService;

    @Override
    public void addNote(OrderNoteVo vo) {
        try {
            orderNoteService.addOrderNote(vo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public List<OrderNoteVo> getPageList(Long orderId) {
        try {
            return orderNoteService.getPageList(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public void batchUpdateReadStatus(List<Long> idList) {
        try {
            orderNoteService.batchUpdateReadStatus(idList);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }
}
