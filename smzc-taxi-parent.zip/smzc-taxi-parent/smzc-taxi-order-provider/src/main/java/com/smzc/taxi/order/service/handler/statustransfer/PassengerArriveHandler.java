package com.smzc.taxi.order.service.handler.statustransfer;

import com.smzc.taxi.boot.mq.SmRocketMqTemplate;
import com.smzc.taxi.common.consts.MQTopicConst;
import com.smzc.taxi.order.dao.mapper.OrderAddressMapper;
import com.smzc.taxi.order.domain.OrderAddress;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.order.bean.mq.MqMessageBody;
import com.smzc.taxi.service.order.emun.OrderAddType;
import com.smzc.taxi.service.order.emun.OrderStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.util.Collections;


/**
 * 乘客到达指定地点开始行程
 * 已到达流转到行程中
 *
 * @author chenzhongqin
 * @version 1.0
 * @date 2019/5/23
 */
@Slf4j
@OrderServiceHandler(fromStatus = OrderStatus.DRIVER_ARRIVE, toStatus = OrderStatus.IN_TRIP)
public class PassengerArriveHandler extends OrderHandler {

    @Resource
    private OrderAddressMapper orderAddressMapper;

    @Autowired
    private SmRocketMqTemplate rocketMqTemplate;

    @Override
    public void process(ControlContext context) {
        // 存实际的上车点
        OrderInfoContext orderInfo = context.getEntity();
        OrderAddress orderAddress = orderAddressMapper.selectByOrderId(orderInfo.getId());
        OrderAddress param = new OrderAddress();
        param.setId(orderAddress.getId());
        param.setPracticalFromAddress(orderInfo.getPracticalAddress());
        param.setPracticalFromStreet(orderInfo.getPracticalStreet());
        param.setPracticalFromLongitude(orderInfo.getLongitude());
        param.setPracticalFromLatitude(orderInfo.getLatitude());
        int updEffect = orderAddressMapper.updateByPrimaryKeySelective(param);
        if (updEffect > 0) {
            log.debug("OrderId:{},修改实际上车点 成功", context.getOrderId());
        } else {
            log.error("OrderId:{},修改实际上车点 失败,参数{}", context.getOrderId(), param.toString());
        }

    }

    @Override
    public void asyncMethod(final ControlContext context) {
        super.asyncMethod(context);
//        邀新订单mq消息tag映射
        if (context.getEntity().getAddType() == OrderAddType.NEW_ADD.getIndex()) {
            MqMessageBody msg = super.getPublicMqMsgBody(context);
            msg.setDriverIdList(Collections.singletonList(context.getEntity().getDriverId()));
            try {
                rocketMqTemplate.syncSendOrderly(MQTopicConst.TAXI_ORDER, OrderStatus.WAIT_DRIVER_CONFIRM.toString(), msg, msg.getOrderId().toString());
                rocketMqTemplate.syncSendOrderly(MQTopicConst.TAXI_CENTER_CONTROLLER, OrderStatus.WAIT_DRIVER_CONFIRM.toString(), msg, msg.getOrderId().toString());
                log.debug("消息发送成功。订单{}，topic:{},tags:{}", msg.getOrderId(), MQTopicConst.TAXI_CENTER_CONTROLLER, OrderStatus.WAIT_DRIVER_CONFIRM.toString());
            } catch (Exception e) {
                log.error("订单{}，mq消息推送异常,TOPIC:{},TAGS：{},消息内容：{}", msg.getOrderId(), MQTopicConst.TAXI_ORDER + "&" + MQTopicConst.TAXI_CENTER_CONTROLLER,
                        MQTopicConst.TAXI_CENTER_CONTROLLER, msg.toString(), e);
            }
        }

        //        先不上线，上线的时候放开
        //log.info("司机已到达发消息给互相娱乐屏幕,id:{}",context.getOrderId());
        //rocketMqTemplate.syncSend(MQTopicConst.TAXI_OPEN_ORDER_INFO, MQTagsConst.TAXI_ORDER_IN_TRIP,new MQHYPBody(context.getOrderId()));
    }

    @Override
    public boolean isPushMessage(ControlContext context) {
        return context.getEntity().getAddType() != OrderAddType.NEW_ADD.getIndex();
    }

}
