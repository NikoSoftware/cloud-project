package com.smzc.taxi.order.service.handler.statustransfer;

import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.dispatch.bean.RecommendedVehicle;
import com.smzc.taxi.service.order.bean.mq.MqMessageBody;
import com.smzc.taxi.service.order.emun.OrderAddType;
import com.smzc.taxi.service.order.emun.OrderStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 等待司机抢单
 * 此handler 不处理任何逻辑，只是一个过度状态
 * 会调用父类中的finish接口方法，处理公共逻辑
 *
 * @author liuinjie
 * @version 1.0
 * @Date 2019-5-21
 */
@Slf4j
@OrderServiceHandler(fromStatus = OrderStatus.AUTO_DISPATCHING, toStatus = OrderStatus.WAIT_DRIVER_CONFIRM)
public class WaitDriverRobHandler extends OrderHandler {

    @Override
    public void process(ControlContext context) {
        // 不需要处理，直接结束

    }

    @Override
    public MqMessageBody initMessage(ControlContext context) {
        List<RecommendedVehicle> list = (List<RecommendedVehicle>) context.get("vehicleList");
        if (!CollectionUtils.isEmpty(list)) {
            // 将待抢订单推送给司机端和中控
            MqMessageBody mqMessageBody = super.getPublicMqMsgBody(context);
            mqMessageBody.setDriverIdList(list.stream().map(RecommendedVehicle::getDriverId).collect(Collectors.toList()));
            mqMessageBody.setVehicleIdList(list.stream().map(RecommendedVehicle::getVehicleId).collect(Collectors.toList()));
            return mqMessageBody;
        }
        return null;
    }

    @Override
    public boolean isPushMessage(ControlContext context) {
        return context.getEntity().getAddType() != OrderAddType.NEW_ADD.getIndex();
    }

}
