package com.smzc.taxi.order.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 订单地址信息 order_address
 *
 * @author :liuxinjie
 * @date :2019/5/22
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OrderAddress extends BaseBean {

    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 订单城市编码
     */
    private String cityCode;

    /**
     * 起点城市编码
     */
    private String planFromCityCode;

    /**
     * 终点城市编码
     */
    private String planToCityCode;

    /**
     * 终点地址
     */
    private String planToAddress;

    /**
     * 终点街道
     */
    private String planToStreet;

    /**
     * 终点纬度
     */
    private Double planToLatitude;

    /**
     * 终点经度
     */
    private Double planToLongitude;

    /**
     * 起点地址
     */
    private String planFromAddress;

    /**
     * 起点街道
     */
    private String planFromStreet;

    /**
     * 起点经度纬度
     */
    private Double planFromLatitude;

    /**
     * 起点经度
     */
    private Double planFromLongitude;

    /**
     * 实际到达地址
     */
    private String practicalToAddress;

    /**
     * 实际到达街道
     */
    private String practicalToStreet;

    /**
     * 实际到达纬度
     */
    private Double practicalToLatitude;

    /**
     * 实际到达经度
     */
    private Double practicalToLongitude;

    /**
     * 实际出发地址
     */
    private String practicalFromAddress;

    /**
     * 实际出发街道
     */
    private String practicalFromStreet;

    /**
     * 实际出发纬度
     */
    private Double practicalFromLatitude;

    /**
     * 实际出发经度
     */
    private Double practicalFromLongitude;

    /**
     * 起点城市名称
     */
    private String planFromCityName;

    /**
     * 终点城市名称
     */
    private String planToCityName;

    /**
     * 起点百度uid
     */
    private String planFromUid;

    /**
     * 终点百度uid
     */
    private String planToUid;

    /**
     * 百度起点code
     */
    private String baiduFromCode;

    /**
     * 百度终点code
     */
    private String baiduToCode;

}