package com.smzc.taxi.order.service.handler.statustransfer;

import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.order.emun.OrderAddType;
import com.smzc.taxi.service.order.emun.OrderStatus;
import lombok.extern.slf4j.Slf4j;


/**
 * 司机到达指定地点实现类
 * 已出发流转到已到达
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/6/13 16:03
 */
@Slf4j
@OrderServiceHandler(fromStatus = OrderStatus.DRIVER_STARTING, toStatus = OrderStatus.DRIVER_ARRIVE)
public class DriverArriveHandler extends OrderHandler {


    @Override
    public void process(ControlContext context) {
        // 司机已到达发消息给互相娱乐屏幕，不能使用公共的消息方法，得单独写
    }

    @Override
    public boolean isPushMessage(ControlContext context) {
        return context.getEntity().getAddType() != OrderAddType.NEW_ADD.getIndex();
    }
}
