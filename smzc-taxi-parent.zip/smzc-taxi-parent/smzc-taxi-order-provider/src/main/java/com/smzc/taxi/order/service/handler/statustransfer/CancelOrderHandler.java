package com.smzc.taxi.order.service.handler.statustransfer;

import com.smzc.taxi.common.utils.JsonUtils;
import com.smzc.taxi.order.dao.mapper.OrderCancelMapper;
import com.smzc.taxi.order.dao.mapper.OrderPayoffDetailMapper;
import com.smzc.taxi.order.dao.mapper.OrderPayoffMapper;
import com.smzc.taxi.order.domain.OrderCancel;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.domain.OrderPayoff;
import com.smzc.taxi.order.domain.OrderPayoffDetail;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.PassengerTransposeService;
import com.smzc.taxi.order.util.OrderRedis;
import com.smzc.taxi.service.order.bean.mq.MqMessageBody;
import com.smzc.taxi.service.order.bean.vo.OrderCancelVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.passenger.enums.OrderPriceDetailType;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;

/**
 * 取消订单基础处理器
 *
 * @author luofei
 * @version V1.0
 * @date 2019/5/21
 */
@Slf4j
public abstract class CancelOrderHandler extends OrderHandler {

    @Resource
    private OrderCancelMapper orderCancelMapper;

    @Resource
    private OrderPayoffDetailMapper orderPayoffDetailMapper;

    @Resource
    private OrderPayoffMapper orderPayoffMapper;

    @Resource
    OrderRedis orderRedis;

    @Resource
    PassengerTransposeService passengerTransposeService;

    private final String FEE_KEY = "amount";

    @Override
    public void process(ControlContext context) {
        OrderCancelVo orderCancelVo = (OrderCancelVo) context.get("orderCancelInfo");
        OrderInfoContext orderInfo = context.getEntity();
        if (orderInfo.getStatus() == OrderStatus.CANCEL) {
            return;
        }

        OrderCancel orderCancel = toOrderCancel(orderCancelVo);
        orderCancelMapper.insert(orderCancel);

        log.info("取消订单，订单id={}：当前状态{}", orderCancelVo.getOrderId(), orderInfo.getStatus().getName());

        subProcess(context);

        afterProcess(context);

        // 取消时，清缓存
        orderRedis.removeAll(orderInfo.getId());

        OrderStatus toStatus = context.getToStatus();

        if (toStatus.equals(OrderStatus.CANCEL) || toStatus.equals(OrderStatus.SYS_CANCEL)) {
            Long subscriberId = context.getEntity().getSubscriberId();
            log.info("取消订单时，清空乘客行程中的订单缓存，乘客id={}", subscriberId);
            orderRedis.delSubIntripOrder(subscriberId);
        }
    }

    public abstract void subProcess(ControlContext context);

    public void setCancelPrice(ControlContext context, Integer price) {
        if (price != null && price > 0) {
            context.setToStatus(OrderStatus.WAIT_PAY_CANCEL);
            context.put(FEE_KEY, price);
        }
    }

    private Integer getCancelPrice(ControlContext context) {
        return (Integer) context.get(FEE_KEY);
    }

    protected void afterProcess(ControlContext context) {
        if (context.getFromStatus() == OrderStatus.DRIVER_STARTING || context.getFromStatus() == OrderStatus.DRIVER_ARRIVE) {
            transferDriverWorkStatus(context);
        }
        // 如果不存在取消费 就不需要保存支付以及明细
        Integer price = getCancelPrice(context);
        if (null == price || price == 0) {
            return;
        }

        OrderInfoContext orderInfo = context.getEntity();
        OrderPayoff orderPayoff = new OrderPayoff();
        orderPayoff.setOrderId(orderInfo.getId());
        orderPayoff.setOrderAmount(price);
        orderPayoff.setPayAmount(price);
        orderPayoff.setPayChannel(null);
        orderPayoff.setPayType(null);
        orderPayoff.setPayTime(null);
        orderPayoff.setVersion(0);
        orderPayoffMapper.insert(orderPayoff);

        OrderPayoffDetail orderPayoffDetail = new OrderPayoffDetail();
        orderPayoffDetail.setCostAmount(price);
        orderPayoffDetail.setCostKey(OrderPriceDetailType.CANCELAMOUNT.getFieldName());
        orderPayoffDetail.setOrderId(orderInfo.getId());
        orderPayoffDetailMapper.insert(orderPayoffDetail);

    }

    private OrderCancel toOrderCancel(OrderCancelVo orderCancelVo) {
        return JsonUtils.copyProperites(OrderCancel.class, orderCancelVo);
    }

    @Override
    public MqMessageBody initMessage(ControlContext context) {
        OrderCancelVo orderCancelVo = (OrderCancelVo) context.get("orderCancelInfo");
        MqMessageBody orderCancelMq = super.getPublicMqMsgBody(context);
        orderCancelMq.setReason(orderCancelVo.getCancelReason());
        return orderCancelMq;
    }

    @Override
    public void finish(final ControlContext context) {
        super.finish(context);
        Integer price = getCancelPrice(context);
        if (price == null || price == 0) {
            passengerTransposeService.releaseSafeCallPhone(context.getEntity().getId());
        }
    }
}
