package com.smzc.taxi.order.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单状态坐标记录
 * 对应表 :order_status_position
 *
 * @author :james
 * @date :2019-05-16
 */
public class OrderStatusPosition extends BaseBean {

    /**
     * 订单id
     */
    private Long orderId;

    /**
     * 订单状态 枚举类型
     */
    private Byte orderStatus;

    /**
     * 司机id
     */
    private Long driverId;

    /**
     * 经度
     */
    private Double longitude;

    /**
     * 纬度
     */
    private Double latitude;

    /**
     * 城市地址
     */
    private String address;

    /**
     * 街道
     */
    private String street;

    /**
     * 行政区划代码
     */
    private String divisionCode;


    private static final long serialVersionUID = 1L;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Byte getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Byte orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Long getDriverId() {
        return driverId;
    }

    public void setDriverId(Long driverId) {
        this.driverId = driverId;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street == null ? null : street.trim();
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode == null ? null : divisionCode.trim();
    }

}