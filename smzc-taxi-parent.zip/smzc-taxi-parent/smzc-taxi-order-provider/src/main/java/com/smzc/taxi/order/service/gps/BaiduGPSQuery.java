package com.smzc.taxi.order.service.gps;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.order.domain.QueryGPSBean;
import com.smzc.taxi.order.util.JSONUtils;
import com.smzc.taxi.service.driver.bean.DriverCurrentTrajectoryVo;
import com.smzc.taxi.service.driver.bean.DriverPointVo;
import com.smzc.taxi.service.driver.service.IPositionFacade;
import com.smzc.taxi.service.order.bean.vo.GPSVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 百度鹰眼
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/6/24
 */
@Component
@Slf4j
public class BaiduGPSQuery implements GPSQuery {

    @Reference(version = "1.0.0")
    private IPositionFacade positionFacade;

    @Override
    public List<GPSVo> execute(QueryGPSBean queryGPSBean) {
        DriverCurrentTrajectoryVo driverCurrentTrajectoryVo = new DriverCurrentTrajectoryVo();
        driverCurrentTrajectoryVo.setDriverName(queryGPSBean.getDriverName());
        driverCurrentTrajectoryVo.setVehicleNo(queryGPSBean.getVehicleNo());
        driverCurrentTrajectoryVo.setStartTime(queryGPSBean.getStartTime() / 1000);
        driverCurrentTrajectoryVo.setEndTime(queryGPSBean.getEndTime() / 1000);
        try {
            // log.info("轨迹查询。请求参数：{}", JSONUtils.toJSONString(driverCurrentTrajectoryVo));
            final List<DriverPointVo> driverPointVos = positionFacade.driverCurrentTrajectory(driverCurrentTrajectoryVo);
            if (!driverPointVos.isEmpty()) {
                return driverPointVos.parallelStream().map(item -> {
                    GPSVo gps = new GPSVo();
                    gps.setLatitude(item.getLatitude());
                    gps.setLongitude(item.getLongitude());
                    return gps;
                }).collect(Collectors.toList());
            }
        } catch (Exception e) {
            log.error("轨迹查询！请求参数：{}", JSONUtils.toJSONString(driverCurrentTrajectoryVo), e);
        }

        return Lists.newArrayList();
    }

}
