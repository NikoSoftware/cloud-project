package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderStatusHistory;
import com.smzc.taxi.service.order.emun.OrderStatus;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface OrderStatusHistoryMapper {

    int insert(OrderStatusHistory record);

    OrderStatusHistory selectByOrderIdAndToStatus(@Param("orderId") Long orderId, @Param("orderStatus") OrderStatus orderStatus);

    /**
     * 查询订单状态记录
     *
     * @param orderId 订单id
     * @return 状态列表
     */
    List<OrderStatusHistory> selectStatusHistoryListByOrderId(Long orderId);

    Date selectCreateTimeByOrderIdAndToStatus(@Param("orderId") Long orderId, @Param("orderStatus") OrderStatus orderStatus);
}