package com.smzc.taxi.order.util;

import com.smzc.taxi.common.utils.DateUtils;
import com.smzc.taxi.order.domain.OrderCacheBean;
import com.smzc.taxi.order.domain.OrderCancelBean;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.service.order.emun.OrderStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.smzc.taxi.common.consts.RedisConst.*;

/**
 * 订单缓存封装
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/5/29 14:03
 */
@Slf4j
@Component
public class OrderRedis {


    @Resource
    RedisTemplate redisTemplate;


    /**
     * 缓存的基础时间 1个小时的秒数
     */
    final static Integer baseTime = DateUtils.SECONDS_ONE_HOUR;


    /**
     * 下单时写入待抢订单缓存
     * 抢单成功、系统取消、驳回、取消，待抢缓存会被删除
     * 以上规则失效后，1H 自动删除此数据
     *
     * @param orderInfoContext
     */
    public void setWaitRobOrder(OrderInfoContext orderInfoContext) {
        redisTemplate.opsForValue().set(TAXI_WAIT_RECEIVE_ORDER + orderInfoContext.getId(), orderInfoContext, baseTime, TimeUnit.SECONDS);
    }

    /**
     * 获取待抢订单缓存
     * 抢单成功、系统取消、驳回、取消，待抢缓存会被删除
     *
     * @param orderId
     * @return
     */
    public OrderInfoContext getWaitRobOrder(Long orderId) {
        return (OrderInfoContext) redisTemplate.opsForValue().get(TAXI_WAIT_RECEIVE_ORDER + orderId);
    }

    /**
     * 获取待抢订单缓存
     * 抢单成功、系统取消、驳回、取消，待抢缓存会被删除
     *
     * @param orderId
     * @return
     */
    public OrderInfoContext getWaitRobOrder(String orderId) {
        return getWaitRobOrder(Long.valueOf(orderId));
    }

    /**
     * 批量获取待抢缓存数据
     * @param idList
     * @return
     */
    public List<OrderInfoContext> getWaitRobOrderList(List<String> idList) {
        List<String> keys = idList.stream().map(p -> TAXI_WAIT_RECEIVE_ORDER + p).collect(Collectors.toList());
        return redisTemplate.opsForValue().multiGet(keys);
    }

    /**
     * 从待抢订单缓存中移除
     *
     * @param orderId
     */
    public void removeWaitRob(Long orderId) {
        redisTemplate.delete(TAXI_WAIT_RECEIVE_ORDER + orderId);
    }

    /**
     * 移除此订单的所有缓存
     *
     * @param orderId
     */
    public void removeAll(Long orderId) {
        try {
            removeWaitRob(orderId);
            delTempOrderInfo(orderId);
            // log.info("redis删除成功，订单号：{}", orderId);
        } catch (Exception e) {
            log.error("redis删除失败:", e);
        }
    }



    // ======================== 以上是待抢缓存处理方法 ==================================
    // ======================== 以下是待取消缓存队列，专用于定时任务检查订单是否过期 ============================


    /**
     * 获取待取消缓存列表
     *
     * @return
     */
    public OrderCancelBean getWaitCancelOrderRightPop() {
        return (OrderCancelBean) redisTemplate.opsForList().rightPop(WAIT_CANCEL_ORDER);
    }


    /**
     * 将所有新添加的订单写入redis list
     * 用于定时任务取消 5分钟之内未被接单的订单
     *
     * @param orderInfo
     */
    public void setWaitCancelOrderLeftPush(OrderInfoContext orderInfo) {
        OrderCancelBean orderCancelBean = new OrderCancelBean(orderInfo.getId(), orderInfo.getCreatedTime().getTime(), orderInfo.getCityCode());
        redisTemplate.opsForList().leftPush(WAIT_CANCEL_ORDER, orderCancelBean);
    }

    /**
     * 将取出的对象还回redis缓存
     */
    public void setWaitCancelOrderRightPush(OrderCancelBean orderCancelBean) {
        redisTemplate.opsForList().rightPush(WAIT_CANCEL_ORDER, orderCancelBean);
    }

    // ========================= 以上是待取消缓存队列，专用于定时任务检查订单是否过期 ============================
    // ========================= 以下只缓存订单状态，1H~2H 自动删除 ===========================================

    /**
     * 缓存订单状态
     * 缓存随机时间1H~2H
     *
     * @param id
     * @param status
     */
    public void setOrderStatus(Long id, OrderStatus status) {
        String key = TAXI_ORDER_STATUS + id;

        // 取1个小时内的随机时间
        int randTime = new Random().nextInt(baseTime);
        if(status == null){
            redisTemplate.opsForValue().set(key, null, (baseTime+randTime), TimeUnit.SECONDS);
        } else{
            redisTemplate.opsForValue().set(key, status.getIndex(), (baseTime+randTime), TimeUnit.SECONDS);
        }

    }

    /**
     * 获取订单状态
     * @param id
     * @return
     */
    public OrderStatus getOrderStatus(Long id){
        Byte status = (Byte)redisTemplate.opsForValue().get(TAXI_ORDER_STATUS + id);

        return status == null ? null : OrderStatus.fromIndex(status);
    }

    public void delOrderStatus(Long id){
        redisTemplate.delete(TAXI_ORDER_STATUS + id);
    }

    // ========================= 以上只缓存订单状态，1H~2H 自动删除 ===========================================
    // ========================= 以下缓存订单关键不会变化的数据，24小时自动删除 =================================

    /**
     * 缓存订单关键数据
     * 缓存随机时间12小时
     * @param orderCache
     *
     */
    public void setOrderCache(OrderCacheBean orderCache) {
        String key = TAXI_ORDER_CACHE + orderCache.getId();

        // 订单数据统计在12个小时后过期
        redisTemplate.opsForValue().set(key, orderCache, (baseTime * 12), TimeUnit.SECONDS);
    }

    /**
     * 获取订单关键数据
     * @param id
     * @return
     */
    public OrderCacheBean getOrderCache(Long id){
        return (OrderCacheBean)redisTemplate.opsForValue().get(TAXI_ORDER_CACHE + id);
    }

    // ========================= 以上缓存订单关键不会变化的数据，12小时自动删除 =================================



    // ========================= 移除订单相关的所有缓存
    public void clearAll() {
        redisTemplate.delete(WAIT_CANCEL_ORDER);
        log.info("{}, redis被清空", "待取消缓存");
        Set<String> keys = redisTemplate.keys(TAXI_WAIT_RECEIVE_ORDER + "*");
        redisTemplate.delete(keys);
        log.info("{}, redis被清空", "待抢订单缓存");
        Set<String> keys2 = redisTemplate.keys(DRIVER_WORK_STATE + "*");
        redisTemplate.delete(keys2);
        log.info("{}, redis被清空", "司机工作状态缓存");
        Set<String> keys3 = redisTemplate.keys(VEHICLE_DRIVER_WORK_STATE + "*");
        redisTemplate.delete(keys3);
        log.info("{}, redis被清空", "司机车辆状态缓存");
        Set<String> keys4 = redisTemplate.keys(TAXI_ORDER_CACHE + "*");
        redisTemplate.delete(keys4);
        log.info("{}, redis被清空", "订单关键数据缓存");


    }


    /**
     * 缓存最大呼叫时长，只保存3分钟
     *
     * @param cityCode
     * @param maxNum
     */
    public void setTaxiMaxCallTimeOut(String cityCode, Integer maxNum) {
        redisTemplate.opsForValue().set(TAXIT_WAIT_MAXTIME + cityCode, maxNum, 3, TimeUnit.MINUTES);
    }

    /**
     * 获取最大呼叫时长
     *
     * @param cityCode
     * @return
     */
    public Integer getTaxiMaxCallTimeOut(String cityCode) {
        return (Integer) redisTemplate.opsForValue().get(TAXIT_WAIT_MAXTIME + cityCode);
    }

    /**
     * 设置订单临时数据
     * @param orderInfoContext
     */
    public void setTempOrderInfo(OrderInfoContext orderInfoContext) {
        Long id = orderInfoContext.getId();
        redisTemplate.opsForValue().set(TAXI_ORDER_TEMP_INFO + id, orderInfoContext, baseTime, TimeUnit.SECONDS);
    }

    /**
     * 获取订单临时数据
     * @param id
     * @return
     */
    public OrderInfoContext getTempOrderInfo(Long id){
        return (OrderInfoContext) redisTemplate.opsForValue().get(TAXI_ORDER_TEMP_INFO + id);
    }


    /**
     * 删除订单临时数据
     * @param id
     */
    public void delTempOrderInfo(Long id){
        redisTemplate.delete(TAXI_ORDER_TEMP_INFO + id);
    }


    /**
     * 记录乘客未完成的订单
     *
     * @param subId
     * @param orderId
     */
    public void setSubIntripOrder(Long subId, Long orderId) {
        redisTemplate.opsForValue().set(TAXI_SUB_ORDER_INTRIP + subId, orderId, (baseTime * 12), TimeUnit.SECONDS);
    }

    /**
     * 获取乘客未完成的订单，
     * 存在则返回true
     *
     * @param subId
     * @return
     */
    public Long getSubIntripOrder(Long subId) {
        return (Long) redisTemplate.opsForValue().get(TAXI_SUB_ORDER_INTRIP + subId);
    }

    /**
     * 删除乘客未完成的订单
     *
     * @param subId
     */
    public void delSubIntripOrder(Long subId) {
        redisTemplate.delete(TAXI_SUB_ORDER_INTRIP + subId);
    }

}
