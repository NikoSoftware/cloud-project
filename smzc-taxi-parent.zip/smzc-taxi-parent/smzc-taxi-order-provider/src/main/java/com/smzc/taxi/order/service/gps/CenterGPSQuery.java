package com.smzc.taxi.order.service.gps;

import com.alibaba.dubbo.config.annotation.Reference;
import com.google.common.collect.Lists;
import com.smzc.taxi.order.domain.QueryGPSBean;
import com.smzc.taxi.order.util.JSONUtils;
import com.smzc.taxi.service.centorcontrol.bean.ThirdPartyAPITracksRequestParamVo;
import com.smzc.taxi.service.centorcontrol.bean.ThirdPartyAPITracksResponseVo;
import com.smzc.taxi.service.centorcontrol.bean.VehicleTrackPointVo;
import com.smzc.taxi.service.centorcontrol.service.CentorControlVehicleFacade;
import com.smzc.taxi.service.order.bean.vo.GPSVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 中控第三方
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/6/24
 */
@Component
@Slf4j
public class CenterGPSQuery implements GPSQuery {

    @Reference(version = "1.0.0")
    private CentorControlVehicleFacade centorControlVehicleFacade;

    @Override
    public List<GPSVo> execute(QueryGPSBean queryGPSBean) {
        ThirdPartyAPITracksRequestParamVo partyAPITracksRequestParamVo = new ThirdPartyAPITracksRequestParamVo();
        partyAPITracksRequestParamVo.setVehicleNo(queryGPSBean.getVehicleNo());
        partyAPITracksRequestParamVo.setStartTime(queryGPSBean.getStartTime());
        partyAPITracksRequestParamVo.setEndTime(queryGPSBean.getEndTime());
        partyAPITracksRequestParamVo.setMaxSize(queryGPSBean.getMaxSize());
        try {
            log.info("轨迹查询，获取第三方中控平台数据。请求参数：{}", JSONUtils.toJSONString(partyAPITracksRequestParamVo));
            final ThirdPartyAPITracksResponseVo thirdPartyAPITracksResponseVo = centorControlVehicleFacade.syncVehiclePosition(partyAPITracksRequestParamVo);
            List<VehicleTrackPointVo> trackPoints = thirdPartyAPITracksResponseVo.getPoints();
            if (trackPoints.isEmpty()) {
                log.warn("轨迹查询，获取第三方中控平台数据为空。请求参数：{}", JSONUtils.toJSONString(partyAPITracksRequestParamVo));
            } else {
                return trackPoints.parallelStream().map(item -> {
                    GPSVo gps = new GPSVo();
                    gps.setLatitude(item.getLatitude());
                    gps.setLongitude(item.getLongitude());
                    return gps;
                }).collect(Collectors.toList());
            }
        } catch (Exception e) {
            log.error("轨迹查询，获取第三方中控平台数据异常！请求参数：{}", JSONUtils.toJSONString(partyAPITracksRequestParamVo), e);
        }
        return Lists.newArrayList();
    }
}
