package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderCallHistory;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderCallHistoryMapper {

    int insert(OrderCallHistory record);

    List<OrderCallHistory> queryPagedList(@Param("orderId") Long orderId, @Param("startNo") int startNo, @Param("pageSize") int pageSize);
}