package com.smzc.taxi.order.domain;

import com.smzc.taxi.service.order.emun.OrderStatus;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.core.annotation.Order;

/**
 * 订单信息order_info
 *
 * @author tangqiandong
 * @date 2019/05/16
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OrderInfo extends BaseBean {

    /**
     * 乘客手机号
     */
    private String passengerPhone;

    /**
     * 乘客名称
     */
    private String passengerName;

    /**
     * 用户ID
     */
    private Long subscriberId;

    /**
     * 用户手机号
     */
    private String subscriberPhone;

    /**
     * 用户姓名
     */
    private String subscriberName;

    /**
     * 司机ID
     */
    private Long driverId;

    /**
     * 司机名称
     */
    private String driverName;

    /**
     * 司机手机号
     */
    private String driverPhone;

    /**
     * 调度类型  1.自动   2.人工
     *
     * @see com.smzc.taxi.service.order.emun.DispatchType
     */
    private Byte dispatchType;

    /**
     * 订单状态
     * 待处理、自动调度中、等待司机接单、司机已出发、司机已到达、行程中、待支付、待评价、已完成、已取消
     *
     * @see com.smzc.taxi.service.order.emun.OrderStatus
     */
    private OrderStatus status;

    /**
     * 订单来源  1.出租车
     */
    private Byte sourceType;

    /**
     * 订单类型  3.出租车
     */
    private Byte type;

    /**
     * 出租车ID
     */
    private Long vehicleId;

    /**
     * 车牌号
     */
    private String vehicleNo;

    /**
     * 公司ID
     */
    private Long driverCompanyId;

    /**
     * 所属出租车公司
     */
    private String driverCompany;

    /**
     * 预估里程
     */
    private Integer predictMileage;

    /**
     * 预估时间
     */
    private Integer predictTime;

    /**
     * 城市编码
     */
    private String cityCode;

    /**
     * 城市名称
     */
    private String cityName;


    /**
     * 代客下单：0 否；1 是
     */
    private Byte valetOrder;

    /**
     * 起点地址
     */
    private String planFromAddress;

    /**
     * 终点地址
     */
    private String planToAddress;

    /**
     * 设备系统类型：安卓、苹果等
     */
    private String deviceOs;

    /**
     * 设备机型：华为P30
     */
    private String deviceType;

}