package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderInfoExt;

public interface OrderInfoExtMapper {

    int insert(OrderInfoExt orderInfoExt);

    /**
     * 根据订单id查询订单扩展信息
     *
     * @param orderId 订单id
     * @return OrderInfoExt
     */
    OrderInfoExt selectByOrderId(Long orderId);
}