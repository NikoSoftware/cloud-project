package com.smzc.taxi.order.service;

import com.smzc.taxi.service.driver.bean.DriverWorkStateTurnVo;

/**
 * 转调其它系统服务，父类声明的属性，子类使用会失败
 *
 * @author : lufy
 * @version v1.0
 * @date : 2019/6/3
 */
public interface DriverTransposeService {
    /**
     * 司机状态扭转
     * @date: 2019/5/21 16:18
     * @param: [driverId, lastStatus]
     * @return: java.lang.Integer
     */
    void driverWorkStateTurn(DriverWorkStateTurnVo driverWorkStateTurnVo);

}
