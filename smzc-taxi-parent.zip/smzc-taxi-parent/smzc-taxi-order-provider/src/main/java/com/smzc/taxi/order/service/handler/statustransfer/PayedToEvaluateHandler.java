package com.smzc.taxi.order.service.handler.statustransfer;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.smzc.innerServices.beans.order.OrderShareBean;
import com.smzc.market.service.enums.activity.ActivityType;
import com.smzc.market.service.enums.activity.ParticipationRewardStatus;
import com.smzc.market.service.passenger.ActivityFacade;
import com.smzc.market.service.passenger.vo.UpdateParticipationRewardHistoryRequestVo;
import com.smzc.taxi.order.dao.mapper.OrderActivityMapper;
import com.smzc.taxi.order.dao.mapper.OrderPayoffDetailMapper;
import com.smzc.taxi.order.domain.OrderActivity;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.OrderDriverMarketActivityService;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.order.service.context.ProxyDiscountControl;
import com.smzc.taxi.service.order.bean.mq.MqMessageBody;
import com.smzc.taxi.service.order.emun.OrderAddType;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.emun.PayType;
import com.smzc.taxi.service.passenger.enums.CountPricelType;
import com.smzc.taxi.service.passenger.enums.OrderPriceDetailType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 正常订单，待支付流转到待评价
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/5/29 12:35
 */
@OrderServiceHandler(fromStatus = OrderStatus.WAIT_PAY, toStatus = OrderStatus.WAIT_EVALUATE)
@Slf4j
public class PayedToEvaluateHandler extends PayedToBaseHandler {

    @Resource
    OrderPayoffDetailMapper orderPayoffDetailMapper;

    @Resource
    OrderDriverMarketActivityService orderDriverMarketActivityService;

    @Reference(version = "1.0.0")
    private ActivityFacade activityFacade;

    @Resource
    OrderActivityMapper orderActivityMapper;

    @Reference(cluster = "failfast", timeout = 10000, group = "order")
    private com.smzc.innerServices.facade.order.IOrderFacade smzcOrderService;

    /**
     * 专车车辆类型：出租车
     */
    private static final int SMZC_CAR_TYPE = 2;

    @Override
    public void defaultMethod(ControlContext context) {
        // 修改司机状态为待命中
        transferDriverWorkStatus(context);

        PayType payType = (PayType) context.get("payType");

        try {
            // 通知乘客服务调整金额
            updateParticipationRewardHistoryStatus(payType, context);

            // ===================================================================================================

            // 给司机发补贴
            if (PayType.ON_LINE == payType) {
                // 如果是线上支付，则启动奖励策略
                ProxyDiscountControl
                        .getDiscountHandler(OrderAddType.getByCode(context.getEntity().getAddType()))
                        .execute(context.getEntity());
            } else {
                // 线下支付，删除优惠记录详情
                orderPayoffDetailMapper.deleteByIdAndKey(
                        context.getOrderId(),
                        Arrays.asList(
                                OrderPriceDetailType.DIRECTIONAMOUNT.getFieldName(),
                                OrderPriceDetailType.VOUCHERAMOUNT.getFieldName())
                );
            }
        } catch (Exception e) {
            log.error("用户付款成功后，给司机优惠时报错：", e);
        }

        super.defaultMethod(context);

//        行程分享
        shareTrip(context);
    }

    /**
     * 设置行程分享活动券
     *
     * @param context 参数
     */
    private void shareTrip(ControlContext context) {
        OrderShareBean orderShareBean = new OrderShareBean();
        orderShareBean.setCarType(SMZC_CAR_TYPE);
        orderShareBean.setCityCode(context.getEntity().getCityCode());
        orderShareBean.setOrderId(context.getOrderId());
        orderShareBean.setSubscriberId(context.getEntity().getSubscriberId());
        try {
            log.debug("行程分享设置活动券，开始调用专车接口。订单id={}", orderShareBean.getOrderId());
            smzcOrderService.genShareConfig(orderShareBean);
        } catch (Exception e) {
            log.error("行程分享设置活动券，调用专车接口失败。请求参数{}", JSON.toJSONString(orderShareBean), e);
        }
    }

    /**
     * 重写消息体，写入支付方式
     *
     * @param context
     * @return
     */
    @Override
    public MqMessageBody initMessage(ControlContext context) {
        MqMessageBody publicMqMsgBody = getPublicMqMsgBody(context);
        publicMqMsgBody.setPayType((PayType) context.get("payType"));
        publicMqMsgBody.setAddType(context.getEntity().getAddType());
        publicMqMsgBody.setDiscountAmount(context.getEntity().getDriverDiscountAmount());
        return publicMqMsgBody;
    }

    /**
     * 通知乘客服务调整金额
     *
     * @param payType
     * @param context
     */
    private void updateParticipationRewardHistoryStatus(PayType payType, ControlContext context) {
        // 获取乘客活动
        List<OrderActivity> orderActivities = orderActivityMapper.selectByOrderId(context.getOrderId());

        if (!CollectionUtils.isEmpty(orderActivities)) {
            List<UpdateParticipationRewardHistoryRequestVo> list = orderActivities
                    .stream()
                    .filter(f -> CountPricelType.PASSENGER.getCode() == f.getCountPricelType())
                    .map(p -> {

                        UpdateParticipationRewardHistoryRequestVo rVo = new UpdateParticipationRewardHistoryRequestVo();
                        // 通知乘客服务调整金额
                        if (PayType.ON_LINE == payType) {
                            rVo.setParticipationRewardStatus(ParticipationRewardStatus.RECEIVE);
                        } else {
                            rVo.setParticipationRewardStatus(ParticipationRewardStatus.RELEASE);
                        }
                        rVo.setActivityId(p.getActivityId());
                        rVo.setOrderId(context.getOrderId());
                        rVo.setActivityType(ActivityType.PASSENGER_SUBSIDY);
                        rVo.setSubscriberId(context.getEntity().getSubscriberId());
                        return rVo;
                    }).collect(Collectors.toList());

            orderDriverMarketActivityService.batchUpdateParticipationRewardHistoryStatus(list);
        }
    }

}
