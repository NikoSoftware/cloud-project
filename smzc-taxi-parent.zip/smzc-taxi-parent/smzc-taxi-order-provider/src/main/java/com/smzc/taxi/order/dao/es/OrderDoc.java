package com.smzc.taxi.order.dao.es;


import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

import java.util.Date;

/**
 * 订单信息文档
 * replicas 备份数
 * shards 分片数（数据分片存储）
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/5/22
 */
@Data
@Document(indexName = "taxi_order", type = "order_doc", shards = 4, replicas = 0, refreshInterval = "-1")
public class OrderDoc {

    public OrderDoc() {
    }

    @Id
    private Long id;

    /**
     * 乘客手机号
     */
    private String passengerPhone;

    /**
     * 乘客名称
     */
    private String passengerName;

    /**
     * 用户ID
     */
    private Long subscriberId;

    /**
     * 用户手机号
     */
    private String subscriberPhone;

    /**
     * 用户姓名
     */
    private String subscriberName;

    /**
     * 司机ID
     */
    private Long driverId;

    /**
     * 司机名称
     */
    private String driverName;

    /**
     * 司机手机号
     */
    private String driverPhone;

    /**
     * 调度类型  1.自动   2.人工
     */
    private Byte dispatchType;

    /**
     * 订单状态
     */
    private Byte status;

    /**
     * 订单状态名称
     */
    private String statusText;

    /**
     * 订单来源  1.出租车
     */
    private Byte fromSource;

    /**
     * 订单类型  1.出租车
     */
    private Byte type;

    /**
     * 出租车ID
     */
    private Long vehicleId;

    /**
     * 车牌号
     */
    private String vehicleNo;

    /**
     * 所属出租车公司
     */
    private String driverCompany;

    /**
     * 预估里程
     */
    private Integer predictMileage;

    /**
     * 预估时间
     */
    private Integer predictTime;

    /**
     * 城市编码
     */
    private String cityCode;

    /**
     * 城市名称
     */
    private String cityName;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 代客下单：0 否；1 是
     */
    private Byte valetOrder;

    /**
     * 计划终点
     */
    private String planToAddress;

    /**
     * 计划起点
     */
    private String planFromAddress;

    /**
     * 出租车公司id
     */
    private Long driverCompanyId;

}
