package com.smzc.taxi.order.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.order.service.OrderDispatchService;
import com.smzc.taxi.service.dispatch.bean.*;
import com.smzc.taxi.service.dispatch.exception.DispatchException;
import com.smzc.taxi.service.dispatch.facade.IDispatchFacade;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderDispatchServiceImpl implements OrderDispatchService {

    @Reference(version = "1.0.0")
    private IDispatchFacade dispatchFacade;

    @Override
    public DispatchResponse<List<RecommendedVehicle>> dispatchTaxiVehicle(DispatchTaxiVehicleBean dispatchTaxiVehicleBean) throws DispatchException {
        return dispatchFacade.dispatchTaxiVehicle(dispatchTaxiVehicleBean);
    }

    @Override
    public DispatchResponse<List<RecommendedOrder>> dispatchTaxiOrder(DispatchTaxiOrderBean dispatchTaxiOrderBean) throws DispatchException {
        return dispatchFacade.dispatchTaxiOrder(dispatchTaxiOrderBean);
    }

    @Override
    public void syncOrderStatus(OrderInfoBean orderInfoBean) throws DispatchException {
        dispatchFacade.syncOrderStatus(orderInfoBean);
    }
}
