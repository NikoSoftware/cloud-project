package com.smzc.taxi.order.domain;

import lombok.Data;

/**
 * 
 * 订单标签
 * 
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/5 14:25
 */
@Data
public class OrderTags extends BaseBean {
    /**
     * 主键
     */
    private Long id;

    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 标签名
     */
    private String tag;


}