package com.smzc.taxi.order.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 订单评价表
 * 对应表 :order_evaluate
 *
 * @author :james
 * @date :2019-05-16
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OrderEvaluate extends BaseBean {

    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 司机id
     */
    private Long driverId;

    /**
     * 评价内容
     */
    private String content;

    /**
     * 评星数1-5
     */
    private Byte score;

    /**
     * 评价标签-存标签表名称集合以分号分隔
     */
    private String tagNames;
}