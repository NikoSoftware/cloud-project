package com.smzc.taxi.order.domain;

import lombok.Data;

import java.io.Serializable;

/**
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/5/27 11:08
 */
@Data
public class OrderCancelBean implements Serializable {
    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 开始时间
     */
    private Long startTime;

    /**
     * 城市编码
     */
    private String cityCode;

    public OrderCancelBean() {
    }

    public OrderCancelBean(Long orderId, Long startTime, String cityCode) {
        this.orderId = orderId;
        this.startTime = startTime;
        this.cityCode = cityCode;
    }
}
