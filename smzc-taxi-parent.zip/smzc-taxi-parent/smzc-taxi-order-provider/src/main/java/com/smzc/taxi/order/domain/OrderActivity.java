package com.smzc.taxi.order.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * 对应表 :order_activity
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/16 14:53
 */
@Data
public class OrderActivity extends BaseBean implements Cloneable{

    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 活动ID
     */
    private Long activityId;

    /**
     * 互动名称
     */
    private String activityName;

    /**
     * 活动金额
     */
    private Integer amount;

    /**
     * 活动类型  1.司机端   2.乘客端
     */
    private Byte countPricelType;

    @Override
    public OrderActivity clone(){
        try {
            return (OrderActivity)super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

}