package com.smzc.taxi.order.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单评价标签
 * 对应表 :order_evaluate_tag
 *
 * @author :james
 * @date :2019-05-16
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OrderEvaluateTag extends BaseBean {
    /**
     * 标签名称
     */
    private String tagName;
}