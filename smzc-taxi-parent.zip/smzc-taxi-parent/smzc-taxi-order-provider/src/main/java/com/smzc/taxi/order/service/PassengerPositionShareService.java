package com.smzc.taxi.order.service;

import com.smzc.taxi.service.order.bean.vo.OrderPositionInfoRespVo;
import com.smzc.taxi.service.order.bean.vo.PassengerPositionShareVo;

/**
 * 乘客位置分享服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
public interface PassengerPositionShareService {

    /**
     * 添加乘客位置分享并推送司机
     */
    void addPassengerPositionShare(PassengerPositionShareVo vo);

    /**
     * 根据订单id获取乘客最新分享位置
     */
    PassengerPositionShareVo getLatestShareByOrderId(Long orderId);

    OrderPositionInfoRespVo selectOrderPositionInfo(Long orderId);
}
