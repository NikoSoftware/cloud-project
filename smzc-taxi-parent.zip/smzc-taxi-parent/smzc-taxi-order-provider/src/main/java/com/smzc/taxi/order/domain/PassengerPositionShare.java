package com.smzc.taxi.order.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 乘客位置分享
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class PassengerPositionShare extends BaseBean {
    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 经度
     */
    private Double longitude;

    /**
     * 纬度
     */
    private Double latitude;

    /**
     * 城市地址
     */
    private String address;

    /**
     * 街道
     */
    private String street;

    /**
     * 行政区划代码
     */
    private String divisionCode;
}
