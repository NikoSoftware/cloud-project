package com.smzc.taxi.order.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.lbs.service.bean.LBSRequest;
import com.smzc.lbs.service.bean.LBSResponse;
import com.smzc.lbs.service.bean.taxi.TaxiVehicleLocationBean;
import com.smzc.lbs.service.facade.ILBS4TaxiFacade;
import com.smzc.taxi.order.domain.OrderVirtual;
import com.smzc.taxi.order.service.OrderVirtualService;
import com.smzc.taxi.service.order.bean.vo.OrderVirtualVo;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.portal.bean.SystemConfigurationVo;
import com.smzc.taxi.service.portal.enums.SystemConfigurationEnum;
import com.smzc.taxi.service.portal.service.ISystemConfigurationFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.geo.*;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.NearQuery;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 虚拟订单服务实现类
 *
 * @author zhousong
 * @date 2019/6/18
 * @since 1.0.0
 */
@Slf4j
@Service
public class OrderVirtualServiceImpl implements OrderVirtualService {

    //匹配半径 2km
    private static final double MATCH_RADIUS = 2;
    //1经度转换为M的大小近似值
    private static final double PER_LONGITUDE_MILE = 102834.74258026089786013677476285;
    //1纬度转换为M的大小近似值
    private static final double PER_LATITUDE_MILE = 111712.69150641055729984301412873;
    //1M转换为经度的大小近似值
    private static final double PER_MILE_LONGITUDE = 0.000009724339993553411;
    //1M转换为纬度的大小近似值
    private static final double PER_MILE_LATITUDE = 0.000008951534391619382;

    @Reference(group = "lbs", version = "1.0.0")
    private ILBS4TaxiFacade lbs4TaxiFacade;

    @Resource
    private MongoTemplate mongoTemplate;

    @Reference(version = "1.0.0")
    private ISystemConfigurationFacade systemConfigurationFacade;


    @Override
    public List<OrderVirtualVo> getOrderVirtual(Long vehicleId, String cityCode) {
        AssertUtil.notNull(vehicleId, "车辆id不能为空");
        AssertUtil.notNull(cityCode, "城市编码不能为空");

        //是否开启虚拟订单
        boolean virtualOpen = false;
        try {
            List<SystemConfigurationVo> scVoList = systemConfigurationFacade.getValueByKey(SystemConfigurationEnum.ORDER_VIRTUAL_OPEN, cityCode);
            if (!CollectionUtils.isEmpty(scVoList)) {
                virtualOpen = Boolean.parseBoolean(scVoList.get(0).getConfigValue());
            }
        } catch (Exception e) {
            log.error("查询是否开启虚拟订单失败：", e);
        }
        if (!virtualOpen) {
            return Collections.EMPTY_LIST;
        }

        //查询车辆最新位置
        TaxiVehicleLocationBean reqBean = new TaxiVehicleLocationBean();
        reqBean.setVehicleId(vehicleId);
        reqBean.setAreaCode(cityCode);
        LBSResponse<TaxiVehicleLocationBean> lbsResponse = lbs4TaxiFacade.getTaxiVehicleLocation(new LBSRequest<>(reqBean));
        AssertUtil.isTrue(lbsResponse != null && lbsResponse.isSuccess(), "调用LBS服务查询司机最新位置信息失败");
        TaxiVehicleLocationBean repBean = lbsResponse.getData();
        if (repBean == null || repBean.getLat() == null || repBean.getLng() == null) {
            log.info("该车辆[vehicleId={},cityCode={}]暂无最新gps位置信息", vehicleId, cityCode);
            return Collections.EMPTY_LIST;
        }

        //查询以坐标为中心的正三角形的三个角附近距离最近的订单
        List<OrderVirtualVo> vovList = new ArrayList<>();
        double longitude = repBean.getLng();
        double latitude = repBean.getLat();
        double[] location = {longitude, latitude};
        //上角(距离中心点200-600米)
        Point upperPoint = new Point(longitude + PER_MILE_LONGITUDE * 200 + PER_MILE_LONGITUDE * 400 * Math.random(), latitude);
        OrderVirtualVo upperVo = this.selectOrderVirtual(upperPoint, location);
        if (upperVo != null) {
            vovList.add(upperVo);
        }
        //左角(距离中心点200-600米)
        Point leftPoint = new Point(longitude - PER_MILE_LONGITUDE * 100 - PER_MILE_LONGITUDE * 200 * Math.random(), latitude - PER_MILE_LATITUDE * 173.2 - PER_MILE_LATITUDE * 346.4 * Math.random());
        OrderVirtualVo leftVo = this.selectOrderVirtual(leftPoint, location);
        if (leftVo != null) {
            vovList.add(leftVo);
        }
        //右角(距离中心点200-600米)
        Point rightPoint = new Point(longitude - PER_MILE_LONGITUDE * 100 - PER_MILE_LONGITUDE * 200 * Math.random(), latitude + PER_MILE_LATITUDE * 173.2 + PER_MILE_LATITUDE * 346.4 * Math.random());
        OrderVirtualVo rightVo = this.selectOrderVirtual(rightPoint, location);
        if (rightVo != null) {
            vovList.add(rightVo);
        }

        if (vovList.size() == 0) {
            log.warn("该车辆[vehicleId={},cityCode={}]在位置[longitude={},latitude={}]没有可匹配的虚拟订单", vehicleId, cityCode, longitude, latitude);
            return Collections.EMPTY_LIST;
        }
        return vovList;
    }

    /**
     * 查找传入坐标附近最近的虚拟订单
     */
    private OrderVirtualVo selectOrderVirtual(Point point, double[] location) {
        NearQuery query = NearQuery.near(point).maxDistance(new Distance(MATCH_RADIUS, Metrics.KILOMETERS)).num(1L);
        GeoResults<OrderVirtual> geoResults = mongoTemplate.geoNear(query, OrderVirtual.class);
        if (geoResults == null || CollectionUtils.isEmpty(geoResults.getContent())) {
            return null;
        }
        OrderVirtualVo vo = new OrderVirtualVo();
        OrderVirtual orderVirtual = geoResults.getContent().get(0).getContent();
        BeanUtils.copyProperties(orderVirtual, vo);
        vo.setDistance(this.countDistance(orderVirtual.getLocation(), location));
        return vo;
    }

    /**
     * 计算两个坐标点直接的距离近似值(米)
     */
    private int countDistance(double[] point1, double[] point2) {
        double b = Math.abs((point1[0] - point2[0]) * PER_LONGITUDE_MILE);
        double a = Math.abs((point1[1] - point2[1]) * PER_LATITUDE_MILE);
        return new Double(Math.sqrt((a * a + b * b))).intValue();
    }
}
