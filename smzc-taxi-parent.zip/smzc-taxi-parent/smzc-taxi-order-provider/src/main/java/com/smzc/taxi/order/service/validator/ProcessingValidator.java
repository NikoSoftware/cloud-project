package com.smzc.taxi.order.service.validator;

import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.util.OrderRedis;
import com.smzc.taxi.service.order.bean.vo.OrderInfoVo;
import com.smzc.taxi.service.order.bean.vo.OrderPassengerVo;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 未完结订单校验
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/7/29
 */
@Component
public class ProcessingValidator implements OrderValidator<OrderPassengerVo> {

    @Resource
    OrderRedis orderRedis;

    @Resource
    OrderService orderService;

    @Override
    public ValidResult<OrderPassengerVo> valid(OrderInfoVo orderInfoVo, ValidResult<OrderPassengerVo> r) {
        Long orderId = orderRedis.getSubIntripOrder(orderInfoVo.getSubscriberId());
        if (orderId != null) {
            OrderPassengerVo vo = new OrderPassengerVo();
            vo.setOrderId(orderId);
            vo.setOrderStatus(orderService.getOrderStatusById(orderId));
            return r.error(ValidResult.R.BUS_ERROR, "存在行程中的订单", vo);
        }

        return r;
    }
}
