package com.smzc.taxi.order.domain;

import com.smzc.taxi.service.finance.enums.TfbPayChannel;
import com.smzc.taxi.service.order.emun.PayType;
import lombok.Data;

import java.util.Date;

/**
 * 订单结算
 * 对应表 :order_payoff
 *
 * @author : liuxinjie
 * @date :2019-05-16
 */
@Data
public class OrderPayoff extends BaseBean {



    /**
     * 订单号
     */
    private Long orderId;

    /**
     * 支付类型：1.线上  2.线下
     */
    private Byte payType;

    /**
     * 支付渠道 1.支付宝 2.微信
     */
    private String payChannel;

    /**
     * 订单金额
     */
    private Integer orderAmount;

    /**
     * 实际支付金额
     */
    private Integer payAmount;

    /**
     * 支付时间
     */
    private Date payTime;

    /**
     * 优惠金额
     */
    private Integer discountAmount;
}
