package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderCacheBean;
import com.smzc.taxi.order.domain.OrderInfo;
import com.smzc.taxi.order.domain.OrderPassenger;
import com.smzc.taxi.order.domain.OrderPassengerDto;
import com.smzc.taxi.service.order.bean.vo.CityInfoVo;
import com.smzc.taxi.service.order.bean.vo.OrderDrivingVo;
import com.smzc.taxi.service.order.bean.vo.OrderTripShareVo;
import com.smzc.taxi.service.portal.bean.PriceModifyInnerVo;
import com.smzc.taxi.service.portal.bean.PriceModifyRespVo;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface OrderInfoMapper {

    /**
     * 新增订单
     *
     * @param orderInfo 订单信息
     */
    int insert(OrderInfo orderInfo);

    /**
     * 根据订单ID 获取订单表中所有数据
     * 不关联其它表，如果有关联，请另加方法
     *
     * @param id
     * @return
     */
    OrderInfo selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(OrderInfo record);

    /**
     * <p> 获取改价列表（即待支付订单列表） </p>
     *
     * @param orderId     订单编号
     * @param status      订单状态
     * @param driverName  司机姓名
     * @param driverPhone 司机手机
     * @return
     */
    List<PriceModifyRespVo> getPriceModifyPage(@Param("orderId") Long orderId, @Param("status") Byte status,
                                               @Param("driverName") String driverName, @Param("driverPhone") String driverPhone);

    /**
     * <p> 获取订单改价相关信息详情 </p>
     *
     * @param orderId 订单编号
     * @return
     */
    PriceModifyInnerVo getPriceModifyInfo(Long orderId);

    List<OrderDrivingVo> queryDriverReceivedOrderList(@Param("driverId") Long driverId, @Param("list") List list);

    /**
     * 查看司机行程中的订单
     *
     * @param driverId
     * @return
     */
    List<Long> queryDrivingOrderId(@Param("driverId") Long driverId, @Param("list") List list);


    OrderDrivingVo queryDriverReceivedOrderDetail(@Param("orderId") Long orderId);

    List<OrderDrivingVo> queryDriverHistoryOrderList(@Param("driverId") Long driverId, @Param("list") List list);

    int updateStatus(@Param("id") Long id, @Param("fromStatus") Byte fromStatus, @Param("toStatus") Byte toStatus);

    /**
     * 根据乘客ID查询最新的一条数据
     *
     * @param subscriberId
     * @return
     */
    List<OrderPassenger> getOrderListByCurrentDay(@Param("subscriberId") Long subscriberId, @Param("list") List<Byte> status, @Param("date") String date);

    /**
     * 乘客查询 个人行程
     *
     * @param vo
     * @return
     */
    List<OrderPassenger> getOrderList(OrderPassengerDto vo);


    /**
     * 根据乘客ID查询行程中的订单
     *
     * @param subscriberId
     * @return
     */
    List<OrderPassenger> getInTrip(@Param("subscriberId") Long subscriberId, @Param("list") List<Byte> statusList);

    /**
     * @param orderId
     * @return
     */
    OrderInfo selectOrderInfoById(Long orderId);

    /**
     * 查询未支付的订单
     *
     * @param subscriberId
     * @param statusList
     * @return
     */
    OrderInfo selectWaitPayOrder(@Param(("subscriberId")) Long subscriberId, @Param(("list")) List<Byte> statusList);

    /**
     * 根据orderID查询司机相关信息、支付信息
     */
    OrderDrivingVo getDriverInfoByOrderId(Long orderId);

    /**
     * 根据orderID查询行程分享需要的订单信息
     */
    OrderTripShareVo getOrderTripShareInfoByOrderId(Long orderId);

    /**
     * 根据订单ID获取订单状态枚举
     *
     * @param id
     * @return
     */
    Byte getOrderStatusById(@Param("id") Long id);

    /**
     * 根据订单ID获取订单城市信息
     *
     * @param id
     * @return
     */
    CityInfoVo getCityInfoById(@Param("id") Long id);

    /**
     * 根据订单ID获取用户id
     */
    Long getSubscriberIdById(@Param("id") Long id);

    /**
     * 缓存失效后，重新刷新
     *
     * @param id
     * @return
     */
    OrderCacheBean getOrderCache(Long id);

    /**
     * 查询指定时间之内没有付款的订单
     *
     * @param date
     * @param statusList
     * @return
     */
    List<Long> selectByWaitPayAndUpdTime(@Param("date") Date date, @Param("list") List<Byte> statusList);

    /**
     * 根据用户id subscriberId统计订单数量
     */
    int countBySubscriberId(Long subscriberId);
}
