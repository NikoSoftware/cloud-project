package com.smzc.taxi.order.service.impl;

import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.order.dao.mapper.OrderEvaluateMapper;
import com.smzc.taxi.order.dao.mapper.OrderEvaluateTagMapper;
import com.smzc.taxi.order.domain.OrderCacheBean;
import com.smzc.taxi.order.domain.OrderEvaluate;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.OrderEvaluateService;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.service.context.ProxyStatusTransferControl;
import com.smzc.taxi.service.order.bean.vo.OrderEvaluateDriverDayVo;
import com.smzc.taxi.service.order.bean.vo.OrderEvaluateTagVo;
import com.smzc.taxi.service.order.bean.vo.OrderEvaluateVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.AssertUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * 订单评价服务实现类
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/21
 */
@Slf4j
@Service
public class OrderEvaluateServiceImpl implements OrderEvaluateService {

    @Resource
    private OrderEvaluateMapper orderEvaluateMapper;


    @Resource
    private OrderService orderService;

    @Resource
    private OrderEvaluateTagMapper orderEvaluateTagMapper;

    @Resource
    ProxyStatusTransferControl proxyStatusTransferControl;


    @Override
    public void addOrderEvaluate(OrderEvaluateVo vo) {
        // 验证参数
        AssertUtil.notNull(vo, "对象不能为空");
        Long orderId = vo.getOrderId();
        AssertUtil.notNull(orderId, "订单id不能为空");
        Byte score = vo.getScore();
        AssertUtil.notNull(score, "评分不能为空");
        //AssertUtil.isTrue(score >= 1 && score <= 5, "评分只能为1-5");
        OrderCacheBean orderCache = orderService.getOrderCache(orderId);
        AssertUtil.notNull(orderCache, "没有找到订单");
        vo.setDriverId(orderCache.getDriverId());


        // 调用状态流程处理
        OrderInfoContext orderInfoContext = new OrderInfoContext();
        BeanUtils.copyProperties(orderCache, orderInfoContext);
        orderInfoContext.setStatus(orderService.getOrderStatusById(orderId));
        ControlContext context = new ControlContext(orderInfoContext.getStatus(), OrderStatus.FINISH, orderInfoContext);
        context.put("orderEvaluateVo", vo);
        proxyStatusTransferControl.transfer(context);
        log.info("用户评价订单，orderId:{},用户Id:{},评星:{}", orderId, orderCache.getSubscriberId(), vo.getScore());
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public OrderEvaluateVo selectByOrderId(Long orderId) {
        AssertUtil.notNull(orderId, "订单id不能为空");
        OrderEvaluate orderEvaluate = orderEvaluateMapper.selectByOrderId(orderId);
        if (orderEvaluate == null) {
            return null;
        }
        OrderEvaluateVo vo = new OrderEvaluateVo();
        BeanUtils.copyProperties(orderEvaluate, vo);
        return vo;
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public int countByOrderId(Long orderId) {
        AssertUtil.notNull(orderId, "订单id不能为空");
        return orderEvaluateMapper.countByOrderId(orderId);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void insert(OrderEvaluateVo record) {
        OrderEvaluate orderEvaluate = new OrderEvaluate();
        BeanUtils.copyProperties(record, orderEvaluate);
        orderEvaluateMapper.insert(orderEvaluate);
    }


    @Override
    @RouterDataSource(DataSourceAddr.SLAVE)
    public List<OrderEvaluateDriverDayVo> selectDriverEvaluateDay(Date beginDate, Date endDate) {
        return orderEvaluateMapper.selectDriverEvaluateDay(beginDate, endDate);
    }

    @Override
    @RouterDataSource(DataSourceAddr.SLAVE)
    public List<OrderEvaluateDriverDayVo> selectDriverEvaluateDayByMobileList(Date beginDate, Date endDate, List<String> mobileList) {
        return orderEvaluateMapper.selectDriverEvaluateDayByMobileList(beginDate, endDate, mobileList);
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public List<OrderEvaluateTagVo> selectAllOrderEvaluateTag() {
        return orderEvaluateTagMapper.selectAllOrderEvaluateTag();
    }
}
