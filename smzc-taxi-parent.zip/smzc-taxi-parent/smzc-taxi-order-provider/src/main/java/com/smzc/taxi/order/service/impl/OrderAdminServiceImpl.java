package com.smzc.taxi.order.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.metadata.*;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.smzc.common.export.ExportComponent;
import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.common.utils.ZipUtil;
import com.smzc.taxi.order.dao.es.OrderDoc;
import com.smzc.taxi.order.dao.mapper.*;
import com.smzc.taxi.order.domain.*;
import com.smzc.taxi.order.service.OrderAdminService;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.service.OrderStatusHistoryService;
import com.smzc.taxi.order.service.gps.BaiduGPSQuery;
import com.smzc.taxi.order.service.gps.GPSQueryBuilder;
import com.smzc.taxi.order.util.StringUtils;
import com.smzc.taxi.order.util.SuperBeanUtils;
import com.smzc.taxi.service.driver.bean.DriverInformationVo;
import com.smzc.taxi.service.driver.service.IDriverInformationFacade;
import com.smzc.taxi.service.finance.enums.TfbPayChannel;
import com.smzc.taxi.service.order.bean.dto.*;
import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.OrderAddType;
import com.smzc.taxi.service.order.emun.OrderCancelSourceType;
import com.smzc.taxi.service.order.emun.OrderRejectResp;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.passenger.enums.OrderPriceDetailType;
import com.smzc.taxi.service.portal.bean.PriceModifyInnerVo;
import com.smzc.taxi.service.portal.bean.PriceModifyQryVo;
import com.smzc.taxi.service.portal.bean.PriceModifyRespVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.util.Asserts;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.Operator;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.DefaultResultMapper;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.ScrolledPage;
import org.springframework.data.elasticsearch.core.SearchResultMapper;
import org.springframework.data.elasticsearch.core.aggregation.AggregatedPage;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import static com.smzc.taxi.service.order.emun.OrderStatus.*;

/**
 * 订单后台服务
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/5/23
 */
@Slf4j
@Service
public class OrderAdminServiceImpl implements OrderAdminService, InitializingBean {

    /**
     * SCROLL_TIME_IN_MILLIS
     */
    private static long SCROLL_TIME_IN_MILLIS = 1000;

    @Resource
    private ElasticsearchTemplate elasticsearchTemplate;

    @Resource
    private OrderInfoMapper orderInfoMapper;

    @Resource
    private OrderStatusHistoryMapper orderStatusHistoryMapper;

    @Resource
    private OrderPayoffMapper orderPayoffMapper;

    @Resource
    private OrderPayoffDetailMapper orderPayoffDetailMapper;

    @Resource
    private OrderRejectMapper orderRejectMapper;

    @Resource
    private OrderCancelMapper orderCancelMapper;

    @Resource
    private OrderEvaluateMapper orderEvaluateMapper;

    @Resource
    private OrderService orderService;

    @Reference(version = "1.0.0")
    private IDriverInformationFacade driverInformationFacade;

    @Resource
    private ThreadPoolTaskExecutor threadPoolTaskExecutor;

    @Resource
    private ExportComponent exportComponent;

    @Resource
    private OrderStatusHistoryService orderStatusHistoryService;

    @Resource
    private OrderAddressMapper orderAddressMapper;

    @Resource
    private BaiduGPSQuery baiduGPSQuery;

    /**
     * gps查询构造器
     */
    private GPSQueryBuilder gpsQueryBuilder;

    @Resource
    private OrderInfoExtMapper orderInfoExtMapper;

    @Override
    public PageInfo<OrderInfoDto> queryPageOrderList(OrderQueryVo orderQueryVo) {
        SearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withQuery(combineBoolQueryBuilder(orderQueryVo))
                .withPageable(PageRequest.of(orderQueryVo.getPageNum() - 1, orderQueryVo.getPageSize()))
                .withSort(SortBuilders.fieldSort("id").order(SortOrder.DESC).unmappedType("long"))
                .build();
        AggregatedPage<OrderDoc> orderDocs = elasticsearchTemplate.queryForPage(searchQuery, OrderDoc.class);
        PageInfo<OrderInfoDto> page = new PageInfo<>();
        page.setTotal(orderDocs.getTotalElements());
        page.setPages(orderDocs.getTotalPages());
        List<OrderInfoDto> orderInfoVos = Lists.newArrayList();
        orderDocs.getContent().forEach(orderDoc -> {
            OrderInfoDto orderInfoDto = new OrderInfoDto();
            SuperBeanUtils.copy(orderDoc, orderInfoDto);
            orderInfoDto.setStatusText(OrderStatus.fromIndex(orderDoc.getStatus()).getName());
            orderInfoDto.setId(orderDoc.getId().toString());
            orderInfoVos.add(orderInfoDto);
        });
        page.setList(orderInfoVos);
        return page;
    }

    @Override
    public void queryExportOrderList(OrderQueryVo orderQueryVo) {
        final List<OrderDocDto> orderDocDtoList = Lists.newArrayList();
        final int pageSize = 1000;

//        三天前的数据
        final LocalDate now = LocalDate.now();
        final Long t1 = now.plus(-3, ChronoUnit.DAYS).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
        final Long t2 = now.plus(0, ChronoUnit.DAYS).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() - 1;

//          已完成、待评价、已驳回、已取消、自动取消
//          3天前
//          城市权限
        List<Byte> statusList = Lists.newArrayList(FINISH.getIndex(), WAIT_EVALUATE.getIndex(), REJECTED.getIndex(), CANCEL.getIndex(), SYS_CANCEL.getIndex());
        SearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withQuery(QueryBuilders.boolQuery()
                        .filter(QueryBuilders.termsQuery("status", statusList))
                        .must(QueryBuilders.rangeQuery("createdTime").gte(t1).lte(t2))
                        .must(QueryBuilders.termsQuery("cityCode", orderQueryVo.getUserCityList()))
                )
                .withSort(SortBuilders.fieldSort("id").order(SortOrder.DESC))
                .withPageable(PageRequest.of(0, pageSize))
                .build();

        SearchResultMapper searchResultMapper = new DefaultResultMapper();
        ScrolledPage<OrderDoc> orderDocPage = (ScrolledPage<OrderDoc>) elasticsearchTemplate.startScroll(SCROLL_TIME_IN_MILLIS, searchQuery, OrderDoc.class, searchResultMapper);
        while (orderDocPage.hasContent()) {
            for (OrderDoc item : orderDocPage.getContent()) {
                OrderDocDto orderDocDto = new OrderDocDto();
                SuperBeanUtils.copy(item, orderDocDto);
                orderDocDto.setId(item.getId().toString());
                orderDocDto.setStatusText(OrderStatus.fromIndex(item.getStatus()).getName());
                orderDocDto.setCreatedTimeText(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(item.getCreatedTime()));
                orderDocDtoList.add(orderDocDto);
            }
            orderDocPage = (ScrolledPage<OrderDoc>) elasticsearchTemplate.continueScroll(orderDocPage.getScrollId(), SCROLL_TIME_IN_MILLIS, OrderDoc.class, searchResultMapper);
        }

        AssertUtil.notEmpty(orderDocDtoList, "前3天不存在已完结的订单");


//        异步执行导出
        threadPoolTaskExecutor.execute(() -> {
            export(orderDocDtoList, orderQueryVo.getUserId().toString());
        });
    }

    /**
     * 导出
     *
     * @param orderDocDtoList 待导出列表
     * @param userId          用户id
     */
    private void export(final List<OrderDocDto> orderDocDtoList, final String userId) {
        final int fileRows = 20000;
        final int size = orderDocDtoList.size();
        final int totalFiles = size / fileRows + (size % fileRows == 0 ? 0 : 1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        final String fileName = "前3天已完结订单_" + sdf.format(new Date()) + ".zip";
        final String filePath = this.getClass().getResource("/").getPath() + "/temp/";
        final String fileNamePrefix = "前3天已完结订单";

        CountDownLatch countDownLatch = new CountDownLatch(totalFiles);
        try {
            for (int i = 1; i <= totalFiles; i++) {
                int start = (i - 1) * fileRows;
                int limit = i * fileRows > size ? size : i * fileRows;
                final String tempFileName = fileNamePrefix + i + "_" + new Date().getTime();
                List<OrderDocDto> tempList = orderDocDtoList.subList(start, limit);
                threadPoolTaskExecutor.execute(() -> {
                    try {
                        writeExcel(filePath, tempFileName, tempList);
                    } catch (IOException e) {
                        log.error("导出订单异常！", e);
                    }
                    countDownLatch.countDown();
                });
            }

            countDownLatch.await();
            final byte[] bytes = ZipUtil.packZip(filePath);
            exportComponent.export(fileName, userId, () -> bytes);
        } catch (Exception e) {
            log.error("导出订单异常！", e);
        }
    }

    /**
     * 写入临时文件
     *
     * @param filePath 文件地址
     * @param fileName 文件名
     * @param list     待写入数据
     * @throws IOException
     */
    private void writeExcel(String filePath, String fileName, List<? extends BaseRowModel> list) throws
            IOException {
        File file = new File(filePath + fileName + ".xlsx");
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
            file.createNewFile();
        }
        try (OutputStream out = new FileOutputStream(file)) {
            ExcelWriter writer = new ExcelWriter(out, ExcelTypeEnum.XLSX, true);
            Sheet sheet1 = new Sheet(1, 0);
            sheet1.setSheetName("sheet1");
            sheet1.setAutoWidth(Boolean.TRUE);

            //写sheet2  模型上打有表头的注解
            Table table2 = new Table(2);
            table2.setTableStyle(createTableStyle());
            table2.setClazz(OrderDocDto.class);
            writer.write(list, sheet1, table2);
            writer.finish();
        }
    }

    private static TableStyle createTableStyle() {
        TableStyle tableStyle = new TableStyle();
        Font headFont = new Font();
        headFont.setBold(true);
        headFont.setFontHeightInPoints((short) 14);
        headFont.setFontName("楷体");
        tableStyle.setTableHeadFont(headFont);

        Font contentFont = new Font();
        contentFont.setFontHeightInPoints((short) 12);
        contentFont.setFontName("黑体");
        tableStyle.setTableContentFont(contentFont);
        tableStyle.setTableContentBackGroundColor(IndexedColors.WHITE);
        return tableStyle;
    }

    /**
     * 组装BoolQueryBuilder
     *
     * @param orderQueryVo 查询参数
     * @return BoolQueryBuilder
     */
    private BoolQueryBuilder combineBoolQueryBuilder(OrderQueryVo orderQueryVo) {
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
//        城市权限
        if (StringUtils.isEmpty(orderQueryVo.getCityCode()) && !orderQueryVo.getUserCityList().isEmpty()) {
            orderQueryVo.getUserCityList().forEach(item -> {
                queryBuilder.should(QueryBuilders.matchQuery("cityCode", item).operator(Operator.OR));
            });
        }
//        订单起始时间
        if (orderQueryVo.getStartTime() != null) {
            queryBuilder.must(QueryBuilders.rangeQuery("createdTime").gte(orderQueryVo.getStartTime()).lte(orderQueryVo.getEndTime()));
        }
//        城市
        if (StringUtils.isNotEmpty(orderQueryVo.getCityCode())) {
            queryBuilder.must(QueryBuilders.matchQuery("cityCode", orderQueryVo.getCityCode()));
        }
//        订单状态
        if (orderQueryVo.getStatus() != null) {
            queryBuilder.must(QueryBuilders.matchQuery("status", orderQueryVo.getStatus()));
        }
//        订单编号
        if (StringUtils.isNotEmpty(orderQueryVo.getId())) {
            queryBuilder.must(QueryBuilders.matchQuery("id", orderQueryVo.getId()));
        }
//        下单人电话
        if (StringUtils.isNotEmpty(orderQueryVo.getSubscriberPhone())) {
            queryBuilder.must(QueryBuilders.matchQuery("subscriberPhone", orderQueryVo.getSubscriberPhone()));
        }
//        乘车人电话
        if (StringUtils.isNotEmpty(orderQueryVo.getPassengerPhone())) {
            queryBuilder.must(QueryBuilders.matchQuery("passengerPhone", orderQueryVo.getPassengerPhone()));
        }
//        司机姓名
        if (StringUtils.isNotEmpty(orderQueryVo.getDriverName())) {
            queryBuilder.must(QueryBuilders.matchQuery("driverName", orderQueryVo.getDriverName()));
        }
//        车牌号
        if (StringUtils.isNotEmpty(orderQueryVo.getVehicleNo())) {
            queryBuilder.must(QueryBuilders.matchQuery("vehicleNo", orderQueryVo.getVehicleNo()));
        }
//        司机所属公司id
        if (orderQueryVo.getDriverCompanyId() != null) {
            queryBuilder.must(QueryBuilders.matchQuery("driverCompanyId", orderQueryVo.getDriverCompanyId()));
        }
        return queryBuilder;
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public OrderDetailDto queryOrderDetail(final Long orderId) {
        OrderDetailDto orderDetailVo = new OrderDetailDto();

//        订单地址信息
        final OrderAddress orderAddress = orderAddressMapper.selectByOrderId(orderId);
        OrderAddressDto orderAddressDto = new OrderAddressDto();
        SuperBeanUtils.copy(orderAddress, orderAddressDto);
        orderDetailVo.setOrderAddress(orderAddressDto);

//         订单基本信息（订单、乘客、司机）
        final OrderInfo orderInfo = orderInfoMapper.selectOrderInfoById(orderId);
        final OrderInfoExt orderInfoExt = orderInfoExtMapper.selectByOrderId(orderId);
        final OrderStatus currentStatus = orderInfo.getStatus();//当前订单状态
        final List<OrderStatus> toStatusList = Lists.newArrayList();

        OrderInfoDto orderInfoDto = new OrderInfoDto();
        SuperBeanUtils.copy(orderInfo, orderInfoDto);
        orderInfoDto.setId(orderInfo.getId().toString());
        orderInfoDto.setStatus(currentStatus.getIndex());
        orderInfoDto.setStatusText(currentStatus.getName());
        orderInfoDto.setAddTypeText(OrderAddType.getByCode(orderInfoExt.getAddType()).getName());
        orderDetailVo.setOrderInfo(orderInfoDto);

//        展示内容容器
        Map<Byte, String> disMap = OrderStatusMap.get(currentStatus);

//        订单状态流转记录
        List<OrderStatusHistory> orderStatusHistoryList = orderStatusHistoryMapper.selectStatusHistoryListByOrderId(orderId);
        List<OrderStatusHistoryDto> statusHistoryDtoList = Lists.newArrayList();
        int size = orderStatusHistoryList.size();
        for (int i = 0; i <= size - 1; i++) {
            final OrderStatusHistory item = orderStatusHistoryList.get(i);
            final OrderStatus toStatus = item.getToStatus();

//            添加到容器，以便逻辑判断
            toStatusList.add(toStatus);

//            状态展示处理
            String statusText = disMap.get(toStatus.getIndex());
            if (statusText != null) {
                OrderStatusHistoryDto orderStatusHistoryDto = new OrderStatusHistoryDto();
                orderStatusHistoryDto.setCreatedTime(item.getCreatedTime());
                orderStatusHistoryDto.setToStatusText(statusText);
                statusHistoryDtoList.add(orderStatusHistoryDto);
            }
            if (i == size - 1) {
                if (toStatus == WAIT_PAY || toStatus == WAIT_COLLECT_MONEY) {
                    OrderStatusHistoryDto last = new OrderStatusHistoryDto();
                    last.setCreatedTime(item.getCreatedTime());
                    last.setToStatusText("待支付");
                    statusHistoryDtoList.add(last);
                }
                if (toStatus == WAIT_EVALUATE) {
                    OrderStatusHistoryDto last = new OrderStatusHistoryDto();
                    last.setCreatedTime(item.getCreatedTime());
                    last.setToStatusText("待评价");
                    statusHistoryDtoList.add(last);
                }
            }
        }
        orderDetailVo.setOrderStatusHistories(statusHistoryDtoList);

//        待支付、驳回待支付、取消待支付设置费用信息
        if (toStatusList.contains(WAIT_PAY)
                || toStatusList.contains(WAIT_PAY_REJECT)
                || toStatusList.contains(WAIT_PAY_CANCEL)) {
            orderDetailVo.setOrderFee(getOrderFee(orderId));
        }

//        待支付展示费用信息
        if (toStatusList.contains(WAIT_PAY)) {
            orderDetailVo.setShowOrderFee(true);
        }

//            待评价展示空
        if (currentStatus == WAIT_EVALUATE) {
            orderDetailVo.setOrderEvaluate(new OrderEvaluateDto());
            orderDetailVo.setShowOrderEvaluate(true);
        }

//            评价信息
        if (toStatusList.contains(FINISH)) {
            OrderEvaluate orderEvaluate = orderEvaluateMapper.selectByOrderId(orderId);
            OrderEvaluateDto orderEvaluateDto = new OrderEvaluateDto();
            SuperBeanUtils.copy(orderEvaluate, orderEvaluateDto);
            orderDetailVo.setOrderEvaluate(orderEvaluateDto);
            orderDetailVo.setShowOrderEvaluate(true);
        }

//            驳回信息
        if (toStatusList.contains(WAIT_PAY_REJECT) || toStatusList.contains(REJECTED)) {
            OrderReject orderReject = orderRejectMapper.selectRejectByOrderId(orderId);
            OrderRejectDto orderRejectDto = new OrderRejectDto();
            SuperBeanUtils.copy(orderReject, orderRejectDto);
            orderRejectDto.setRespResourceText(OrderRejectResp.fromIndex(orderReject.getRespResource()).getName());
            orderDetailVo.setOrderReject(orderRejectDto);
            orderDetailVo.setShowOrderReject(true);
        }

//            取消信息
        if (toStatusList.contains(WAIT_PAY_CANCEL) || toStatusList.contains(CANCEL)) {
            OrderCancel orderCancel = orderCancelMapper.selectCancelByOrderId(orderId);
            OrderCancelDto orderCancelDto = new OrderCancelDto();
            orderCancelDto.setCancelReason(orderCancel.getCancelReason());
            orderCancelDto.setCreatedTime(orderCancel.getCreatedTime());
            orderCancelDto.setSourceTypeText(OrderCancelSourceType.fromIndex(orderCancel.getSourceType()).getName());
            orderDetailVo.setOrderCancel(orderCancelDto);
            orderDetailVo.setShowOrderCancel(true);
        }

//            规划路线（司机到达）
//            实际路线（司机到达）
        if (toStatusList.contains(DRIVER_ARRIVE)) {
            orderDetailVo.setPlanRoute(getPlanRoute(orderId));
            orderDetailVo.setActualRoute(getActualRoute(orderInfo));
        }
        return orderDetailVo;
    }

    /**
     * 获取规划路线
     *
     * @param orderId 订单id
     * @return GPSVo
     */
    private List<GPSVo> getPlanRoute(Long orderId) {
        OrderPlanGPSVo orderPlanGPSVo = orderService.selectOrderPlanGPSByOrderId(orderId);
        if (orderPlanGPSVo != null) {
            List<GPSVo> gpsList = orderPlanGPSVo.getGpsList();
            if (!gpsList.isEmpty()) {
                return gpsList;
            }
        }
        return Lists.newArrayList();
    }

    /**
     * 获取实际路线
     *
     * @param orderInfo 订单信息
     * @return GPSVo
     */
    private List<GPSVo> getActualRoute(OrderInfo orderInfo) {
//        行程开始和结束时间（可为空）
        final OrderStartEndTimeVo orderStartEndTime = orderStatusHistoryService.getOrderStartEndTime(orderInfo.getId());

//        获取司机信息
        final DriverInformationVo driverInformationVo = driverInformationFacade.findDriverInformationByDriverId(orderInfo.getDriverId());
        final long startTime = orderStartEndTime.getStartTime().getTime();
        final long endTime = orderStartEndTime.getEndTime() == null ? System.currentTimeMillis() : orderStartEndTime.getEndTime().getTime();

        QueryGPSBean queryGPSBean = new QueryGPSBean();
        queryGPSBean.setDriverName(driverInformationVo.getName());
        queryGPSBean.setVehicleNo(orderInfo.getVehicleNo());
        queryGPSBean.setStartTime(startTime);
        queryGPSBean.setEndTime(endTime);

        return gpsQueryBuilder.execute(queryGPSBean);
    }

    /**
     * 获取订单费用
     *
     * @param orderId 订单id
     * @return OrderFeeDto
     */
    @RouterDataSource(DataSourceAddr.SLAVE)
    private OrderFeeDto getOrderFee(final Long orderId) {
        OrderFeeDto orderFeeDto = new OrderFeeDto();
        OrderPayoff orderPayoff = orderPayoffMapper.selectPayoffByOrderId(orderId);
        if (orderPayoff == null) {
            return null;
        }
        List<OrderPayoffDetail> orderPayoffDetailList = orderPayoffDetailMapper.selectListByOrderId(orderId);
        SuperBeanUtils.copy(orderPayoff, orderFeeDto);
        if (orderPayoff.getPayChannel() != null) {
            orderFeeDto.setPayChannelText(TfbPayChannel.getByCode(orderPayoff.getPayChannel()).getName());
        }
        orderPayoffDetailList.forEach(item -> {
            final String key = item.getCostKey();
            final OrderPriceDetailType orderFeeEnum = OrderPriceDetailType.fromFieldName(key);
            final Integer amount = item.getCostAmount();
            Asserts.notNull(orderFeeEnum, "订单费用类型异常，异常key=" + key);
            switch (orderFeeEnum) {
                case BASICAMOUNT:
                    orderFeeDto.setBaseFee(amount);
                    break;
                case PARKAMOUNT:
                    orderFeeDto.setParkingFee(amount);
                    break;
                case BRIDGEAMOUNT:
                    orderFeeDto.setTollFee(amount);
                    break;
                case CLEANINGAMOUNT:
                    orderFeeDto.setCleanFee(amount);
                    break;
                case CANCELAMOUNT:
                    orderFeeDto.setCancelFee(amount);
                    break;
                case REJECTAMOUNT:
                    orderFeeDto.setRejectFee(amount);
                    break;
                case DIRECTIONAMOUNT:
                    orderFeeDto.setDirectDiscount(Math.abs(amount));
                    break;
                case OTHERAMOUNT:
                default:
                    break;
            }
        });
        return orderFeeDto;
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public PageInfo<PriceModifyRespVo> getPriceModifyPage(PriceModifyQryVo query) {
        AssertUtil.notNull(query, "对象不能为空");
        AssertUtil.notNull(query.getPageNum(), "页码不能为空");
        AssertUtil.notNull(query.getPageSize(), "每页显示记录数不能为空");
        PageHelper.startPage(query.getPageNum(), query.getPageSize());
        Long orderId = org.apache.commons.lang3.StringUtils.isBlank(query.getOrderId()) ? null : Long.valueOf(query.getOrderId());
        List<PriceModifyRespVo> list = orderInfoMapper.getPriceModifyPage(orderId, OrderStatus.WAIT_PAY.getIndex(), query.getDriverName(), query.getDriverPhone());
        return PageInfo.of(list);
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public PriceModifyInnerVo getPriceModifyInfo(Long orderId) {
        AssertUtil.notNull(orderId, "订单不能为空");
        return orderInfoMapper.getPriceModifyInfo(orderId);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        gpsQueryBuilder = new GPSQueryBuilder();
        gpsQueryBuilder.addQuery(baiduGPSQuery);
    }
}