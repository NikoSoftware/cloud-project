package com.smzc.taxi.order.service.impl;

import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.order.dao.mapper.PassengerPositionShareMapper;
import com.smzc.taxi.order.domain.OrderInfo;
import com.smzc.taxi.order.domain.OrderPositionInfo;
import com.smzc.taxi.order.domain.PassengerPositionShare;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.service.PassengerPositionShareService;
import com.smzc.taxi.service.driver.bean.push.SharePositionPushVo;
import com.smzc.taxi.service.order.bean.vo.OrderPositionInfoRespVo;
import com.smzc.taxi.service.order.bean.vo.PassengerPositionShareVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.AssertUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 乘客位置分享服务实现类
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
@Slf4j
@Service
public class PassengerPositionShareServiceImpl implements PassengerPositionShareService {

    @Resource
    private PassengerPositionShareMapper passengerPositionShareMapper;

    @Resource
    private OrderService orderService;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void addPassengerPositionShare(PassengerPositionShareVo vo) {
        //验证
        AssertUtil.notNull(vo, "对象不能为空");
        Double latitude = vo.getLatitude();
        AssertUtil.notNull(latitude, "经度不能为空");
        Double longitude = vo.getLongitude();
        AssertUtil.notNull(longitude, "纬度不能为空");
        Long orderId = vo.getOrderId();
        AssertUtil.notNull(orderId, "订单id不能为空");
        OrderInfo orderInfo = orderService.selectByPrimaryKey(orderId);
        AssertUtil.notNull(orderInfo, "没有找到订单源数据，orderId=" + orderId);
        OrderStatus orderStatus = orderInfo.getStatus();
        AssertUtil.isTrue(orderStatus == OrderStatus.DRIVER_STARTING || orderStatus == OrderStatus.DRIVER_ARRIVE || orderStatus == OrderStatus.DRIVER_ARRIVE,
                "该订单状态不能分享位置");

        //保存数据
        PassengerPositionShare passengerPositionShare = new PassengerPositionShare();
        BeanUtils.copyProperties(vo, passengerPositionShare);
        passengerPositionShare.setCreatedTime(new Date());
        passengerPositionShareMapper.insert(passengerPositionShare);

        //通知司机端 乘客分享的位置
        List<Long> driverIdList = new ArrayList<>();
        driverIdList.add(orderInfo.getDriverId());
        SharePositionPushVo pspVo = new SharePositionPushVo();
        pspVo.setLng(String.valueOf(longitude));
        pspVo.setLat(String.valueOf(latitude));
        pspVo.setAddress(vo.getAddress());
        pspVo.setStreet(vo.getStreet());
        //driverMessagePushFacade.asyncPush(driverIdList, DriverMessagePushSourceChannel.PASSENGER_SHARE_POSITION, null, null, pspVo, false, true, true);
        log.info("用户[id:{},手机:{},姓名:{}]分享位置,分享信息{}", orderInfo.getSubscriberId(), orderInfo.getSubscriberPhone(), orderInfo.getSubscriberName(), passengerPositionShare);
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public PassengerPositionShareVo getLatestShareByOrderId(Long orderId) {
        PassengerPositionShare passengerPositionShare = passengerPositionShareMapper.getLatestShareByOrderId(orderId);
        if (passengerPositionShare == null) {
            return null;
        }
        PassengerPositionShareVo vo = new PassengerPositionShareVo();
        BeanUtils.copyProperties(passengerPositionShare, vo);
        return vo;
    }

    @Override
    @RouterDataSource(DataSourceAddr.SLAVE)
    public OrderPositionInfoRespVo selectOrderPositionInfo(Long orderId) {
        AssertUtil.notNull(orderId,"订单id不能为空！");
        OrderPositionInfo orderPositionInfo = passengerPositionShareMapper.getOrderPositionInfo(orderId);
        OrderPositionInfoRespVo orderPassengerRespVo = new OrderPositionInfoRespVo();
        BeanUtils.copyProperties(orderPositionInfo, orderPassengerRespVo);
        return orderPassengerRespVo;
    }
}
