package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.service.order.bean.vo.OrderCancelVo;
import com.smzc.taxi.service.order.bean.vo.OrderFixedInfoVo;
import com.smzc.taxi.service.order.bean.vo.OrderInfoVo;
import com.smzc.taxi.service.order.bean.vo.OrderRejectVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.facade.IOrderFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 订单服务提供者
 * executes 服务器端并发执行（或占用线程池线程数）
 * actives 每客户端并发执行（或占用连接的请求数）
 * connections dubbo服务占用长连接数
 * loadbalance 负载策略
 *
 * @author Tangqiandong
 * @version v1.0
 * @date 2019/5/15
 */
@Component
@Service
@Slf4j
public class OrderFacade implements IOrderFacade {

    @Resource
    private OrderService orderService;

    @Override
    public Long createOrder(OrderInfoVo vo) {
        try {
            return orderService.createOrder(vo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public boolean rejectOrder(OrderRejectVo orderRejectVo) {
        try {
            return orderService.rejectOrder(orderRejectVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public void cancelOrder(OrderCancelVo orderCancelVo) {
        try {
            orderService.cancelOrder(orderCancelVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public void fillCancelReason(OrderCancelVo orderCancelVo) {
        try {
            orderService.fillCancelReason(orderCancelVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public void autoCancelOrder(String param) {
        try {
            orderService.autoCancelOrder(param);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderStatus getOrderStatusById(Long id) {
        try {
            return orderService.getOrderStatusById(id);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderFixedInfoVo getOrderFixedInfoById(Long id) {
        try {
            return orderService.getOrderFixedInfoById(id);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

}
