package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.github.pagehelper.PageInfo;
import com.smzc.taxi.order.service.OrderAdminService;
import com.smzc.taxi.service.order.bean.dto.OrderDetailDto;
import com.smzc.taxi.service.order.bean.dto.OrderInfoDto;
import com.smzc.taxi.service.order.bean.vo.OrderQueryVo;
import com.smzc.taxi.service.order.facade.IOrderAdminFacade;
import com.smzc.taxi.service.portal.bean.PriceModifyInnerVo;
import com.smzc.taxi.service.portal.bean.PriceModifyQryVo;
import com.smzc.taxi.service.portal.bean.PriceModifyRespVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 订单后台服务
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/5/24
 */
@Component
@Service(timeout = 20000)
@Slf4j
public class OrderAdminFacade implements IOrderAdminFacade {

    @Resource
    private OrderAdminService orderAdminService;

    @Override
    public PageInfo<OrderInfoDto> queryPageOrderList(OrderQueryVo orderQueryVo) {
        try {
            return orderAdminService.queryPageOrderList(orderQueryVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderDetailDto queryOrderDetail(Long orderId) {
        try {
            return orderAdminService.queryOrderDetail(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public void queryExportOrderList(OrderQueryVo orderQueryVo) {
        try {
            orderAdminService.queryExportOrderList(orderQueryVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public PageInfo<PriceModifyRespVo> getPriceModifyPage(PriceModifyQryVo query) {
        try {
            return orderAdminService.getPriceModifyPage(query);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public PriceModifyInnerVo getPriceModifyInfo(Long orderId) {
        try {
            return orderAdminService.getPriceModifyInfo(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }
}
