package com.smzc.taxi.order.service.handler.discount;

import com.smzc.market.service.driver.enums.DriverOrderRewardTypeEnum;
import com.smzc.taxi.order.service.annotation.OrderAddTypeHandler;
import com.smzc.taxi.service.order.emun.OrderAddType;

/**
 *
 * 邀请新用户的优惠策略
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/5 15:13
 */
@OrderAddTypeHandler(discount = OrderAddType.NEW_ADD)
public class NewPassengerDiscountHandler extends BaseDiscountHandler {

    @Override
    public DriverOrderRewardTypeEnum awardType() {
        return DriverOrderRewardTypeEnum.INVITE_REWARD;
    }
}
