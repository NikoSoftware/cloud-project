package com.smzc.taxi;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
@ComponentScan(basePackages = {"com.smzc.taxi", "com.baidu.fsg.uid", "com.smzc.common.export"})
@MapperScan(basePackages = {"com.smzc.taxi.order.dao.mapper", "com.baidu.fsg.uid.worker.dao"})
@ImportResource(value = {"classpath*:dubbo-*.xml"})
public class OrderProviderApplication {

    static {
        System.setProperty("es.set.netty.runtime.available.processors", "false");
    }

    public static void main(String[] args) {
//        System.setProperty("debug", "true");
        SpringApplication.run(OrderProviderApplication.class, args);

    }


}

