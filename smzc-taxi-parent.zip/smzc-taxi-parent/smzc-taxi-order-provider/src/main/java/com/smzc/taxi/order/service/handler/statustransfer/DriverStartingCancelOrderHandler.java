package com.smzc.taxi.order.service.handler.statustransfer;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.order.domain.OrderStatusHistory;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.OrderStatusHistoryService;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.passenger.bean.price.CancelFeeVo;
import com.smzc.taxi.service.passenger.service.IPriceConfigureFacade;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.util.Asserts;

import javax.annotation.Resource;


/**
 * 司机已经出发取消订单
 *
 * @author caikun
 * @version 1.0
 * @date 2019/5/23 14:22
 */
@Slf4j
@OrderServiceHandler(fromStatus = OrderStatus.DRIVER_STARTING, toStatus = OrderStatus.CANCEL)
public class DriverStartingCancelOrderHandler extends CancelOrderHandler {

    @Resource
    OrderStatusHistoryService orderStatusHistoryService;

    @Reference(version = "1.0.0")
    private IPriceConfigureFacade iPriceConfigureFacade;

    @Override
    public void subProcess(ControlContext context) {
        OrderStatusHistory orderStatusHistory = orderStatusHistoryService.selectByOrderIdAndToStatus(context.getEntity().getId(), OrderStatus.DRIVER_STARTING);
        Asserts.notNull(orderStatusHistory, "DriverStartingCancelOrderHandler orderStatusHistory");

        long startTime = orderStatusHistory.getCreatedTime().getTime();
        long waitTime = (System.currentTimeMillis() - startTime) / 1000;

        CancelFeeVo cancelFeeVo = iPriceConfigureFacade.getCancelFeeBean(context.getEntity().getCityCode(), OrderStatus.DRIVER_STARTING);
        if (waitTime >= cancelFeeVo.getCancelTime()) {
            log.info("取消司机已出发订单[{}],等待时长[{}]秒,超过等待时长[{}]秒，需要收取取消费[{}]分",
                    context.getEntity().getId(),
                    waitTime,
                    cancelFeeVo.getCancelTime(),
                    cancelFeeVo.getCancelFee());
            setCancelPrice(context, cancelFeeVo.getCancelFee());
        } else {
            log.info("取消司机已出发订单[{}],等待时长[{}]秒，没有超过等待时长[{}]秒,无取消费",
                    context.getEntity().getId(),
                    waitTime,
                    cancelFeeVo.getCancelTime());
        }

    }
}
