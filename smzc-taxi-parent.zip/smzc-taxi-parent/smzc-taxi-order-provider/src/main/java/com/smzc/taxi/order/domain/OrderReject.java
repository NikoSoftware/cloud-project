package com.smzc.taxi.order.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单驳回记录
 * 对应表 :order_reject
 *
 * @author :james
 * @date :2019-05-16
 */
public class OrderReject extends BaseBean {

    /**
     * 订单id
     */
    private Long orderId;

    /**
     * 责任判定来源 1：乘客   2：司机
     */
    private Byte respResource;

    /**
     * 驳回原因
     */
    private String rejectReason;

    /**
     * 驳回人姓名
     */
    private String rejectBy;


    private static final long serialVersionUID = 1L;


    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Byte getRespResource() {
        return respResource;
    }

    public void setRespResource(Byte respResource) {
        this.respResource = respResource;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason == null ? null : rejectReason.trim();
    }

    public String getRejectBy() {
        return rejectBy;
    }

    public void setRejectBy(String rejectBy) {
        this.rejectBy = rejectBy == null ? null : rejectBy.trim();
    }

}