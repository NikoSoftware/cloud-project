package com.smzc.taxi.order.service;

import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.github.pagehelper.PageInfo;
import com.smzc.taxi.service.portal.bean.PriceModifyInnerVo;
import com.smzc.taxi.service.portal.bean.PriceModifyUpdVo;

import java.util.List;

/**
 * 订单结算接口
 *
 * @author liuxinjie
 * @date 2019/5/15
 * @since 1.0.0
 */
public interface OrderPayoffService {

    /**
     * 添加订单结算
     * 有二个地方需要调这个接口
     * 1. 乘客支付成功后，第三方回调时需要写入结算数据
     * 2. 司机端司机点收到现金时，内部调用此接口写入结算数据
     * <p>
     * 修改订单状态
     * 如果是线上支付需推送消息给司机。 线下支付不用发
     *
     * @return
     */
    CommonCode addPayoff(OrderPayoffVo orderPayoffVo);

    /**
     * 添加结算详情
     * @param contextVo
     * @return
     */
    CommonCode addPayOffDetails(OrderPayoffDetailContextVo contextVo);

    /**
     * 调价
     * @param list
     * @return
     */
    void updPayoffEdtails(List<OrderPayoffDetailVo> list);

    /**
     * 查询订单支付明细
     * @param orderId
     * @return
     */
    List<OrderPayoffDetailVo> queryPayoffDetailListByOrderId(Long orderId);

    /**
     * 查询订单支付明细
     * @param orderId
     * @return
     */
    List<OrderPayoffDetailDiffVo> queryPayoffDetailListByOrderId_v2(Long orderId);

    /**
     * 根据条件查询收入
     */
    PageInfo<IncomeVo> queryIncomeList(IncomeQryVo qryVo);

    /**
     * 根据订单ID查询收入
     */
    IncomeVo queryIncomeByOrderId(Long orderId);

    /**
     * 改价
     * @param updVo
     * @return
     */
    CommonCode updPayoffDetail(PriceModifyUpdVo updVo, PriceModifyInnerVo innerVo);

    /**
     * 通过订单id查询订单金额
     */
    OrderAmountVo selectOrderAmountByOrderId(Long orderId);

    /**
     * 同步支付状态
     * @param params
     */
    void syncOrderPayStatus(String params);

    /**
     * 通过订单id查询待评价、已完成订单的支付金额和优惠金额信息
     */
    OrderPayoffAmoutVo selectOrderPayoffAmountByOrderId(Long orderId);
}
