package com.smzc.taxi.order.service.handler.statustransfer;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.common.utils.DateUtils;
import com.smzc.taxi.order.dao.mapper.OrderAddressMapper;
import com.smzc.taxi.order.dao.mapper.OrderInfoExtMapper;
import com.smzc.taxi.order.dao.mapper.OrderTagsMapper;
import com.smzc.taxi.order.domain.*;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.order.util.OrderRedis;
import com.smzc.taxi.order.util.StringUtils;
import com.smzc.taxi.service.order.emun.OrderAddType;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.emun.OrderType;
import com.smzc.taxi.service.portal.service.ISystemConfigurationFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.mongodb.core.MongoTemplate;

import javax.annotation.Resource;
import java.util.Date;

/**
 * 新建订单，待处理
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/5/21
 */
@Slf4j
@OrderServiceHandler(fromStatus = OrderStatus.INIT, toStatus = OrderStatus.WAIT_RECEIVE)
public class WaitReceiveHandler extends OrderHandler {

    @Resource
    private OrderAddressMapper orderAddressMapper;

    @Resource
    OrderRedis orderRedis;

    @Resource
    private MongoTemplate mongoTemplate;

    @Resource
    OrderInfoExtMapper orderInfoExtMapper;

    @Resource
    OrderTagsMapper orderTagsMapper;

    @Override
    public void process(ControlContext context) {
        final long orderId = context.getOrderId();
        final OrderInfoContext orderInfoContext = context.getEntity();
        final OrderStatus toStatus = context.getToStatus();
        final Date createdTime = DateUtils.getDate(DateUtils.getDateString(new Date()), DateUtils.PATTERN_GENERAL_TIME_FULL);

        // 更新context
        orderInfoContext.setCreatedTime(createdTime);
        orderInfoContext.setStatus(toStatus);
        // 保存订单基本信息
        OrderInfo orderInfo = new OrderInfo();
        BeanUtils.copyProperties(orderInfoContext, orderInfo);
        orderInfo.setStatus(toStatus);
        orderInfoMapper.insert(orderInfo);

        // 保存订单地址信息
        OrderAddress orderAddress = new OrderAddress();
        BeanUtils.copyProperties(orderInfoContext.getOrderAddress(), orderAddress);
        orderAddress.setOrderId(orderId);
        orderAddress.setCreatedTime(createdTime);
        orderAddressMapper.insert(orderAddress);

        // 保存订单扩展信息
        OrderInfoExt orderInfoExt = new OrderInfoExt();
        orderInfoExt.setOrderId(orderId);
        orderInfoExt.setAddType(orderInfoContext.getAddType());
        orderInfoExt.setUseType(OrderType.REAL_ORDER.getIndex());
        orderInfoExt.setUseTime(createdTime);
        orderInfoExt.setDeviceNumber(orderInfoContext.getDeviceNumber());
        orderInfoExt.setDeviceFrom(getDeviceFrom(orderInfoContext.getDeviceOs()));
        orderInfoExtMapper.insert(orderInfoExt);

        // 保存标签信息
        OrderTags orderTags = new OrderTags();
        orderTags.setOrderId(orderId);
        orderTags.setTag(OrderAddType.getByCode(orderInfoContext.getAddType()).getName());
        orderTagsMapper.insert(orderTags);

        log.info("创建订单成功，订单id={}，下单人信息[subscriberId={}，电话={}，姓名={}]", orderId,
                orderInfoContext.getSubscriberId(), orderInfoContext.getSubscriberPhone(), orderInfoContext.getSubscriberName());
    }

    @Override
    public void defaultMethod(ControlContext context) {
        super.defaultMethod(context);
        // 写入缓存
        writeOrderCache(context.getEntity());
    }

    private Integer getDeviceFrom(String deviceOs) {

        int rnum = 2;
        if(StringUtils.isEmpty(deviceOs)){
            return rnum;
        }

        switch (deviceOs) {
            case "iOS":
                rnum = 1;
                break;
            case "安卓":
                rnum = 0;
                break;
            default:
                rnum = 2;
                break;
        }
        return rnum;
    }

    private void writeOrderCache(OrderInfoContext orderInfoContext) {
        // 写入订单必要数据缓存 12H
        OrderCacheBean orderCacheBean = new OrderCacheBean();
        orderCacheBean.setCityCode(orderInfoContext.getCityCode());
        orderCacheBean.setPredictTime(orderInfoContext.getPredictTime());
        orderCacheBean.setSubscriberId(orderInfoContext.getSubscriberId());
        orderCacheBean.setSubscriberName(orderInfoContext.getSubscriberName());
        orderCacheBean.setId(orderInfoContext.getId());
        orderCacheBean.setPlanFromStreet(orderInfoContext.getOrderAddress().getPlanFromStreet());
        orderCacheBean.setPlanFromAddress(orderInfoContext.getOrderAddress().getPlanFromAddress());
        orderCacheBean.setPlanFromLatitude(orderInfoContext.getOrderAddress().getPlanFromLatitude());
        orderCacheBean.setPlanFromLongitude(orderInfoContext.getOrderAddress().getPlanFromLongitude());
        orderCacheBean.setPlanToLongitude(orderInfoContext.getOrderAddress().getPlanToLongitude());
        orderCacheBean.setPlanToLatitude(orderInfoContext.getOrderAddress().getPlanToLatitude());
        orderCacheBean.setPlanToAddress(orderInfoContext.getOrderAddress().getPlanToAddress());
        orderCacheBean.setPlanToStreet(orderInfoContext.getOrderAddress().getPlanToStreet());
        orderCacheBean.setAddType(orderInfoContext.getAddType());
        orderCacheBean.setScheduleTime(orderInfoContext.getCreatedTime());
        orderCacheBean.setPassengerPhone(orderInfoContext.getPassengerPhone());
        orderCacheBean.setPlanFromCityCode(orderInfoContext.getCityCode());
        orderRedis.setOrderCache(orderCacheBean);

        // 存乘客下单缓存
        orderRedis.setSubIntripOrder(orderInfoContext.getSubscriberId(), orderInfoContext.getId());
    }

    /**
     * 自动进入自动调度：
     * 待处理流转自动调度
     *
     * @param context 订单上下文
     * @return 新的上下文
     */
    @Override
    public ControlContext next(ControlContext context) {
        return new ControlContext(OrderStatus.WAIT_RECEIVE, OrderStatus.AUTO_DISPATCHING, context.getEntity());
    }

    @Override
    public boolean isPushMessage(ControlContext context) {
        return false;
    }

    @Override
    public boolean isSyncTransferStatus() {
        return false;
    }

//    @Override
//    public void asyncMethod(final ControlContext context) {
//        super.asyncMethod(context);
//        try {
//            OrderInfoContext orderInfoContext = context.getEntity();
//            //是否开启虚拟订单
//            boolean virtualOpen = false;
//            List<SystemConfigurationVo> scVoList = systemConfigurationFacade.getValueByKey(SystemConfigurationEnum.ORDER_VIRTUAL_OPEN, orderInfoContext.getCityCode());
//            if (!CollectionUtils.isEmpty(scVoList)) {
//                virtualOpen = Boolean.parseBoolean(scVoList.get(0).getConfigValue());
//            }
//            if (virtualOpen) {
//                OrderAddress orderAddress = orderInfoContext.getOrderAddress();
//                double[] location = {orderAddress.getPlanFromLongitude(), orderAddress.getPlanFromLatitude()};
//                OrderVirtual orderVirtual = new OrderVirtual();
//                orderVirtual.setPlanFromAddress(orderAddress.getPlanFromAddress());
//                orderVirtual.setPlanToAddress(orderAddress.getPlanToAddress());
//                orderVirtual.setPredictMileage(orderInfoContext.getPredictMileage());
//                orderVirtual.setLocation(location);
//                mongoTemplate.save(orderVirtual);
//            }
//        } catch (Exception e) {
//            log.warn("保存虚拟订单信息失败：", e);
//        }
//    }


}