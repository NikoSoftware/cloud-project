package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.smzc.taxi.order.service.PassengerPositionShareService;
import com.smzc.taxi.service.order.bean.vo.OrderPositionInfoRespVo;
import com.smzc.taxi.service.order.bean.vo.PassengerPositionShareVo;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.order.facade.IPassengerPositionShareFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 乘客位置分享
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
@Component
@Service
@Slf4j
public class PassengerPositionShareFacade implements IPassengerPositionShareFacade {

    @Resource
    private PassengerPositionShareService passengerPositionShareService;

    @Override
    public void addPassengerPositionShare(PassengerPositionShareVo vo) {
        try {
            passengerPositionShareService.addPassengerPositionShare(vo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public PassengerPositionShareVo getLatestShareByOrderId(Long orderId) {
        try {
            return passengerPositionShareService.getLatestShareByOrderId(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderPositionInfoRespVo getOrderPositionInfo(Long orderId) {
        AssertUtil.notNull(orderId,"订单ID不能为空");
        try {
            return passengerPositionShareService.selectOrderPositionInfo(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }
}
