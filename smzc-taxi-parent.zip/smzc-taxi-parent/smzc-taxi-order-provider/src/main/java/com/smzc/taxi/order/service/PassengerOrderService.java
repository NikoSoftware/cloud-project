package com.smzc.taxi.order.service;

import com.smzc.taxi.service.order.bean.vo.OrderInfoVo;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.smzc.taxi.service.order.exception.OrderException;

public interface PassengerOrderService {

    /**
     * 邀新
     * 创建订单，流程自动流转到行程中
     * @param orderInfoVo
     * @return
     * @throws OrderException
     */
    Long createOrderOfNewPassenger(OrderInfoVo orderInfoVo);
}
