package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.smzc.core.util.BeanUtils;
import com.smzc.taxi.order.service.OrderAddressService;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.service.OrderStatusHistoryService;
import com.smzc.taxi.order.service.PassengerOrderService;
import com.smzc.taxi.order.util.JSONUtils;
import com.smzc.taxi.order.util.OrderRedis;
import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.order.exception.OrderException;
import com.smzc.taxi.service.order.facade.IPassengerOrdersFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * 乘客调用订单服务实现
 *
 * @author liuxinjie
 * @version v1.0
 * @date 2019/5/22
 */
@Component
@Service
@Slf4j
public class PassengerOrderFacade implements IPassengerOrdersFacade {

    @Resource
    private OrderAddressService orderAddressService;
    @Resource
    OrderService orderService;

    @Resource
    private OrderStatusHistoryService orderStatusHistoryService;

    @Resource
    PassengerOrderService passengerOrderService;
    @Resource
    OrderRedis orderRedis;


    @Override
    public List<OrderPassengerVo> getOrderList(OrderPassengerReqVo vo) {
        // 查个人行程
        AssertUtil.notNull(vo.getSubscriberId(), "乘客ID不能为空");

        try {
            return orderService.getOrderList(vo);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public JourneyShareOrderAppendInfoVo getOrderAddressInfoByOrderId(Long orderId) {
        try {
            return orderAddressService.getOrderAddressInfoByOrderId(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public List<OrderPassengerVo> getOrderListByCurrentDay(Long subscriberId) {
        AssertUtil.notNull(subscriberId, "乘客ID不能为空");
        try {
            return orderService.getOrderListByCurrentDay(subscriberId);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public List<OrderPassengerVo> getInTrip(Long subscriberId) {
        AssertUtil.notNull(subscriberId, "乘客ID不能为空");
        try {
            return orderService.getInTrip(subscriberId);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public OrderPassengerWaitPayVo getWaitPayOrder(Long subscriberId) {
        AssertUtil.notNull(subscriberId, "乘客ID不能为空");
        try {
            return orderService.selectWaitPayOrder(subscriberId);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public OrderDrivingVo getDriverInfoByOrderId(Long orderId) {
        try {
            return orderService.getDriverInfoByOrderId(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public Date getDriverStartTime(Long orderId) {
        try {
            return orderStatusHistoryService.getDriverStartTime(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderTripShareVo getOrderTripShareInfoByOrderId(Long orderId) {
        try {
            return orderService.getOrderTripShareInfoByOrderId(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderStartEndTimeVo getOrderStartEndTime(Long id) {
        try {
            return orderStatusHistoryService.getOrderStartEndTime(id);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public CityInfoVo getCityInfoById(Long id) {
        try {
            return orderService.getCityInfoById(id);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderRejectRespVo getOrderRejectReason(Long id) {
        try {
            return orderService.getOrderRejectReason(id);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public Long createOrderOfNewPassenger(OrderInfoNewVo orderInfoNewVo) throws OrderException {
        AssertUtil.notNull(orderInfoNewVo.getSubscriberId(), "乘客ID不能为空");

        OrderInfoVo orderInfoVo = new OrderInfoVo();
        BeanUtils.copy(orderInfoNewVo, orderInfoVo);
        try {
            return passengerOrderService.createOrderOfNewPassenger(orderInfoVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public Boolean checkNewUser(Long subscriberId) {
        return orderService.checkNewUser(subscriberId);
    }

    @Override
    public OrderPassengerVo getInTripCache(Long subscriberId) {
        Long orderId = orderRedis.getSubIntripOrder(subscriberId);
        if (orderId != null) {
            OrderPassengerVo vo = new OrderPassengerVo();
            vo.setOrderId(orderId);
            vo.setOrderStatus(orderService.getOrderStatusById(orderId));
            return vo;
        } else {
            List<OrderPassengerVo> inTrip = this.getInTrip(subscriberId);
            if(!CollectionUtils.isEmpty(inTrip)){
                return inTrip.get(0);
            }
        }
        return null;
    }
}
