package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.smzc.taxi.order.service.OrderCommonService;
import com.smzc.taxi.service.order.facade.IOrderCommonFacade;

import javax.annotation.Resource;

/**
 * 订单公共服务：
 * 1.雪花算法生成uid
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/6/17
 */
@Service
public class OrderCommonFacade implements IOrderCommonFacade {

    @Resource
    private OrderCommonService orderCommonService;

    /**
     * 雪花算法生成uid
     *
     * @return getUID
     */
    @Override
    public Long getUID() {
        return orderCommonService.getUID();
    }
}
