package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderPositionInfo;
import com.smzc.taxi.order.domain.PassengerPositionShare;

/**
 * 乘客位置分享mapper
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
public interface PassengerPositionShareMapper {

    int insert(PassengerPositionShare record);

    /**
     * 根据订单id获取乘客最新分享位置
     */
    PassengerPositionShare getLatestShareByOrderId(Long orderId);

    OrderPositionInfo getOrderPositionInfo(Long orderId);
}
