package com.smzc.taxi.order.service.handler.statustransfer;

import com.smzc.taxi.order.service.ControlContext;

/**
 * 订单状态处理接口定义
 *
 * @author liuxinjie
 * @version v1.0
 * @date 2019/5/20
 */
public interface EventHandler {


    /**
     * 处理流转到当前节点时的处理逻辑
     *
     * @param context 订单上下文
     */
    void process(ControlContext context);

    /**
     * 完成流转到当前节点时处理逻辑时所需要做的收尾工作，如更改DB状态
     *
     * @param context 订单上下文
     */
    void finish(ControlContext context);

    /**
     * 获取下一个运行状态
     *
     * @param context 订单上下文
     * @return 如果返回的状态不为null，则StatusControl会持续调度状态
     */
    ControlContext next(ControlContext context);

    /**
     * 是否同步调用next方法
     *
     * @return boolean
     */
    boolean isSyncTransferStatus();

    /**
     * 事务封装处理。内部自调 process与finish
     *
     * @param context 订单上下文
     */
    EventHandler processTransfer(ControlContext context);

    /**
     * 非事务方法
     * @param context
     */
    void processTransferNoTransaction(ControlContext context);

    /**
     * 增加休眠时间
     *
     * @return 睡眠时间
     */
    long getSleepTime();

    /**
     * 是否要推送消息
     * @return
     */
    boolean isPushMessage(ControlContext context);


}
