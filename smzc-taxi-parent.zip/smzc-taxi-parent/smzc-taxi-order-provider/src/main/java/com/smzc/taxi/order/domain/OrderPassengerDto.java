package com.smzc.taxi.order.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author liuxinjie
 * @version 1.0
 * @date 2019/5/23 15:31
 */
@Data
public class OrderPassengerDto implements Serializable {

    private int pageSize;
    private int startNo;

    // 乘客ID
    private Long subscriberId;

    // 查询时间
    private Date searchDate;
}
