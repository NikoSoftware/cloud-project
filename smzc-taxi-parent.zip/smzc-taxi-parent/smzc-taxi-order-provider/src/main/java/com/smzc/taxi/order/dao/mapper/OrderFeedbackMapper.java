package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderFeedback;

import java.util.List;

public interface OrderFeedbackMapper {
    int insert(OrderFeedback record);

    List<OrderFeedback> selectByOrderId(Long orderId);
}