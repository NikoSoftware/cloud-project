package com.smzc.taxi.order.service.handler.statustransfer;

import com.smzc.taxi.order.dao.mapper.OrderPayoffMapper;
import com.smzc.taxi.order.domain.OrderPayoff;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.PassengerTransposeService;
import com.smzc.taxi.service.order.exception.AssertUtil;

import javax.annotation.Resource;

/**
 *
 * 订单结算基础类
 *
 * @author liuxinjie
 * @version 1.0
 * @date 2019/5/24 11:07
 */
public class PayedToBaseHandler extends OrderHandler {

    @Resource
    private OrderPayoffMapper orderPayoffMapper;

    @Resource
    PassengerTransposeService passengerTransposeService;

    @Override
    public void process(ControlContext context) {
        // 修改订单结算
        OrderPayoff orderPayoff = (OrderPayoff) context.get("orderPayoff");
        int updFlag = orderPayoffMapper.updateByPrimaryKeySelective(orderPayoff);
        AssertUtil.isTrue(updFlag > 0, "OrderId:[" + context.getOrderId() + "],订单结算失败");
    }

    @Override
    public void finish(final ControlContext context) {
        super.finish(context);
        passengerTransposeService.releaseSafeCallPhone(context.getEntity().getId());
        orderRedis.delSubIntripOrder(context.getEntity().getSubscriberId());
    }
}
