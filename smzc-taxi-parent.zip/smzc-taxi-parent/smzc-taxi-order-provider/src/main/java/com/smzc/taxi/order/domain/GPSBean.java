package com.smzc.taxi.order.domain;

import lombok.Data;

import java.io.Serializable;

/**
 * GPS entity
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/23
 */
@Data
public class GPSBean implements Serializable {
    /**
     * 纬度
     */
    private Double latitude;

    /**
     * 经度
     */
    private Double longitude;
}
