package com.smzc.taxi.order.service;

import com.smzc.taxi.service.order.bean.vo.OrderVirtualVo;

import java.util.List;

/**
 * 虚拟订单服务
 *
 * @author zhousong
 * @date 2019/6/18
 * @since 1.0.0
 */
public interface OrderVirtualService {
    /**
     * 通过车辆id和城市获取至多三条虚拟订单
     */
    List<OrderVirtualVo> getOrderVirtual(Long vehicleId, String cityCode);
}
