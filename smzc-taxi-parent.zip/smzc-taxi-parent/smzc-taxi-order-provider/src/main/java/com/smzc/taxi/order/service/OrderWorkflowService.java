package com.smzc.taxi.order.service;


import com.smzc.taxi.service.order.bean.vo.OrderDrivingVo;
import com.smzc.taxi.service.portal.bean.DriverOrderReqVo;

import java.util.List;

public interface OrderWorkflowService {



    /**
     * 乘客到达指定地点
     * @param driverOrderReqVo   orderID 和 坐标位置必传
     */
    void passengerArrive(DriverOrderReqVo driverOrderReqVo);


    /**
     * 司机到达指定地点
     * @param driverOrderReqVo   orderID 和 坐标位置必传
     */
    void driverArrive(DriverOrderReqVo driverOrderReqVo);



    /**
     * 司机送达乘客，乘客已下车
     * @param driverOrderReqVo   orderID 和 坐标位置必传
     */
    void driverArriveEndPoint(DriverOrderReqVo driverOrderReqVo);


    /**
     * 查询司机已接未完成的订单
     * @param driverId
     * @return
     */
    List<OrderDrivingVo> queryDriverReceivedOrderList(Long driverId);

    /**
     * 查询司机 历史订单
     * @param driverOrderReqVo
     * @return
     */
    List<OrderDrivingVo> queryDriverHistoryOrderList(DriverOrderReqVo driverOrderReqVo);


    /**
     * 查询司机正进行中的详情
     * @param orderId
     * @return
     */
    OrderDrivingVo queryDriverReceivedOrderDetail(Long orderId);

    /**
     * 查询司机正进行中的订单ID
     * @param driverId
     * @return
     */
    Long queryDrivingOrderId(Long driverId);

}
