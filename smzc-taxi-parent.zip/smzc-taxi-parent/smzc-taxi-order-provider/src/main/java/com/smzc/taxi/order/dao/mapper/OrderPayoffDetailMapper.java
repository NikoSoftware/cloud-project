package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderPayoffDetail;
import com.smzc.taxi.service.passenger.enums.OrderPriceDetailType;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderPayoffDetailMapper {
    int insert(OrderPayoffDetail record);

    int batchInsert(@Param("list") List<OrderPayoffDetail> list);

    int batchUpdate(@Param("list") List<OrderPayoffDetail> list);

    int updateByOrderId(OrderPayoffDetail record);

    List<OrderPayoffDetail> selectListByOrderId(@Param("orderId") Long orderId);

    // 删除优惠记录
    int deleteByIdAndKey(@Param("orderId") Long orderId, @Param("list") List<String> asList);
}