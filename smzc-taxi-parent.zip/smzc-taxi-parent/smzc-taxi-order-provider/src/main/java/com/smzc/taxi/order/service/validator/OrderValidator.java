package com.smzc.taxi.order.service.validator;

import com.smzc.taxi.service.order.bean.vo.OrderInfoVo;

/**
 * 创建订单校验器接口抽象
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/7/29
 */
public interface OrderValidator<T> {

    ValidResult<T> valid(OrderInfoVo orderInfoVo, ValidResult<T> r);

}
