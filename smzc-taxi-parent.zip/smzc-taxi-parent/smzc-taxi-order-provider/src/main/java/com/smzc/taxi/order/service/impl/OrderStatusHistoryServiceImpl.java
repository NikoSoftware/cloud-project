package com.smzc.taxi.order.service.impl;

import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.order.dao.mapper.OrderStatusHistoryMapper;
import com.smzc.taxi.order.domain.OrderStatusHistory;
import com.smzc.taxi.order.service.OrderStatusHistoryService;
import com.smzc.taxi.service.order.bean.vo.OrderStartEndTimeVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.AssertUtil;
import org.springframework.stereotype.Service;


import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * 订单状态流转记录服务实现
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
@Service
public class OrderStatusHistoryServiceImpl implements OrderStatusHistoryService {
    @Resource
    private OrderStatusHistoryMapper orderStatusHistoryMapper;

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public OrderStatusHistory selectByOrderIdAndToStatus(Long orderId, OrderStatus orderStatus) {
        return orderStatusHistoryMapper.selectByOrderIdAndToStatus(orderId, orderStatus);
    }

    @Override
    public Date getDriverStartTime(Long orderId) {
        AssertUtil.notNull(orderId, "订单id不能为空");
        Date date = this.selectCreateTimeByOrderIdAndToStatus(orderId, OrderStatus.DRIVER_STARTING);
        return date;
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public Date selectCreateTimeByOrderIdAndToStatus(Long orderId, OrderStatus orderStatus) {
        return orderStatusHistoryMapper.selectCreateTimeByOrderIdAndToStatus(orderId, orderStatus);
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public OrderStartEndTimeVo getOrderStartEndTime(Long orderId) {
        OrderStartEndTimeVo orderStartEndTimeVo = new OrderStartEndTimeVo();
        orderStartEndTimeVo.setId(orderId);
        List<OrderStatusHistory> list = orderStatusHistoryMapper.selectStatusHistoryListByOrderId(orderId);
        // 开始时间
        Optional<OrderStatusHistory> startOpt = list.stream().filter(p -> OrderStatus.DRIVER_ARRIVE == p.getToStatus()).findFirst();
        orderStartEndTimeVo.setStartTime(startOpt.isPresent() ? startOpt.get().getCreatedTime() : null);

        // 结束时间
        Optional<OrderStatusHistory> endOpt = list.stream().filter(p -> OrderStatus.WAIT_COLLECT_MONEY == p.getToStatus()).findFirst();
        orderStartEndTimeVo.setEndTime(endOpt.isPresent() ? endOpt.get().getCreatedTime() : null);
        return orderStartEndTimeVo;
    }
}
