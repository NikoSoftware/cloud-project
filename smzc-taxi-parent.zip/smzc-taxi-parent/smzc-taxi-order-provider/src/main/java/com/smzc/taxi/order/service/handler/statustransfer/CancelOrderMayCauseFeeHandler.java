package com.smzc.taxi.order.service.handler.statustransfer;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.order.dao.mapper.OrderStatusHistoryMapper;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.domain.OrderStatusHistory;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.passenger.bean.price.CancelFeeVo;
import com.smzc.taxi.service.passenger.service.IPriceConfigureFacade;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;

/**
 * 司机到达取消订单处理器
 *
 * @author caikun
 * @version 1.0.0
 * @date 2019/5/21 16:02
 */
@Slf4j
@OrderServiceHandler(fromStatus = OrderStatus.DRIVER_ARRIVE, toStatus = OrderStatus.CANCEL)
public class CancelOrderMayCauseFeeHandler extends CancelOrderHandler {
    @Resource
    OrderStatusHistoryMapper orderStatusHistoryMapper;
    @Reference(version = "1.0.0")
    private IPriceConfigureFacade priceConfigureFacade;

    @Override
    public void subProcess(ControlContext context) {
        OrderInfoContext orderInfo = context.getEntity();
        OrderStatus currentStatus = context.getFromStatus();
        OrderStatusHistory orderStatusHistory = orderStatusHistoryMapper.selectByOrderIdAndToStatus(orderInfo.getId(), context.getFromStatus());
        long waitTime = (System.currentTimeMillis() - orderStatusHistory.getCreatedTime().getTime()) / 1000;
        CancelFeeVo cancelFeeVo = priceConfigureFacade.getCancelFeeBean(orderInfo.getCityCode(), currentStatus);
        Integer price = waitTime > cancelFeeVo.getCancelTime() ? cancelFeeVo.getCancelFee() : null;
        log.info("司机已到达后取消订单。订单Id={}, 取消费={}", orderInfo.getId(), price);
        setCancelPrice(context, price);
    }
}
