package com.smzc.taxi.order.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 订单反馈信息
 * 对应表 :order_feedback
 *
 * @author :james
 * @date :2019-05-16
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OrderFeedback extends BaseBean {
    /**
     * 订单id
     */
    private Long orderId;

    /**
     * 反馈类型  0：其他   1：物品遗失  2：车辆不符
     */
    private Byte feedbackType;

    /**
     * 反馈信息
     */
    private String content;
}