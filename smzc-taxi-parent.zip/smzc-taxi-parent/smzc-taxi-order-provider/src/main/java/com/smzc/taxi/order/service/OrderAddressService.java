package com.smzc.taxi.order.service;

import com.smzc.taxi.order.domain.OrderAddress;
import com.smzc.taxi.service.order.bean.vo.JourneyShareOrderAppendInfoVo;

/**
 * 订单地址服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
public interface OrderAddressService {

    /**
     * 根据订单id查询订单地址
     */
    OrderAddress selectByOrderId(Long orderId);

    /**
     * 根据订单id查询订单地址信息集合
     */
    JourneyShareOrderAppendInfoVo getOrderAddressInfoByOrderId(Long orderId);
}
