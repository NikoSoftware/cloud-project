package com.smzc.taxi.order.service;

import com.github.pagehelper.PageInfo;
import com.smzc.taxi.service.order.bean.vo.IncomeQryVo;
import com.smzc.taxi.service.order.bean.vo.IncomeVo;

/**
 * 订单报表统计服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/25
 */
public interface OrderStatisticsReportService {
    /**
     * 根据条件查询收入
     * todo 目前从mysql连表查询，后期一定要从其他地方获取数据，例如大数据或归纳入一张表
     */
    PageInfo<IncomeVo> queryIncomeList(IncomeQryVo qryVo);

    /**
     * 根据订单ID查询收入
     */
    IncomeVo queryIncomeByOrderId(Long orderId);
}
