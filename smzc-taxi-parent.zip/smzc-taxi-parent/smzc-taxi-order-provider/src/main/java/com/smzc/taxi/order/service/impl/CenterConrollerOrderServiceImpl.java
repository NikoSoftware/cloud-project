package com.smzc.taxi.order.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.smzc.taxi.common.utils.JsonUtils;
import com.smzc.taxi.order.dao.mapper.OrderInfoMapper;
import com.smzc.taxi.order.domain.OrderCacheBean;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.service.*;
import com.smzc.taxi.order.util.DistributedLockManager;
import com.smzc.taxi.order.util.OrderRedis;
import com.smzc.taxi.order.util.SuperBeanUtils;
import com.smzc.taxi.service.dispatch.bean.DispatchResponse;
import com.smzc.taxi.service.dispatch.bean.DispatchTaxiOrderBean;
import com.smzc.taxi.service.dispatch.bean.RecommendedOrder;
import com.smzc.taxi.service.dispatch.facade.IDispatchFacade;
import com.smzc.taxi.service.order.bean.vo.OrderDriverRobVo;
import com.smzc.taxi.service.order.bean.vo.OrderDriverWaitReqVo;
import com.smzc.taxi.service.order.bean.vo.OrderDriverWaitVo;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.emun.PlatformType;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.order.exception.OrderException;
import com.smzc.taxi.service.portal.bean.DriverOrderReqVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.smzc.taxi.common.consts.RedisConst.TAXI_WAIT_LOCK_ORDER;

/**
 * 中控订单服务实现
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/6/18 16:11
 */
@Slf4j
@Service
public class CenterConrollerOrderServiceImpl implements CenterControllerOrderService {

    @Resource
    OrderService orderService;

    @Resource
    OrderWorkflowService orderWorkflowService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommonCode buriedClock(DriverOrderReqVo driverOrderReqVo) {
        Long orderId = driverOrderReqVo.getOrderId();
        OrderStatus orderStatus = orderService.getOrderStatusById(orderId);

        if (OrderStatus.DRIVER_STARTING == orderStatus) {
            // 司机已出发时，从已出发流转到已到达，再从已到达流转到行程中
            orderWorkflowService.driverArrive(driverOrderReqVo);
            orderWorkflowService.passengerArrive(driverOrderReqVo);
        } else if (OrderStatus.DRIVER_ARRIVE == orderStatus) {
            // 司机已到达时，从已到达流转到行程中
            orderWorkflowService.passengerArrive(driverOrderReqVo);
        } else {
//            throw new OrderException(String.format("OrderId:%s,当前订单状态是%s,埋表失败", orderId, orderStatus.getName()));
            log.warn("OrderId:{}，当前订单状态是{}，埋表失败", orderId, orderStatus.getName());
        }
        return CommonCode.SUCCESS;
    }

    @Override
    public CommonCode riseClock(DriverOrderReqVo driverOrderReqVo) {
        Long orderId = driverOrderReqVo.getOrderId();
        OrderStatus orderStatus = orderService.getOrderStatusById(orderId);

        if (OrderStatus.IN_TRIP == orderStatus) {
            // 行程中的订单才能结束行程
            orderWorkflowService.driverArriveEndPoint(driverOrderReqVo);
        } else {
//            throw new OrderException(String.format("OrderId:%s,当前订单状态是%s,抬表失败", orderId, orderStatus.getName()));
            log.warn("OrderId:{}，当前订单状态是{}，抬表失败", orderId, orderStatus.getName());
        }
        return CommonCode.SUCCESS;
    }

}