package com.smzc.taxi.order.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.smzc.taxi.order.domain.OrderCacheBean;
import com.smzc.taxi.order.domain.OrderInfo;
import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.portal.bean.PriceModifyInnerVo;
import com.smzc.taxi.service.portal.bean.PriceModifyQryVo;
import com.smzc.taxi.service.portal.bean.PriceModifyRespVo;

/**
 * 订单服务
 *
 * @author Tangqiandong
 * @date 2019/5/15
 * @since 1.0.0
 */
public interface OrderService {

    /**
     * 更新订单表
     *
     * @param orderInfo
     * @return
     */
    int updateByPrimaryKeySelective(OrderInfo orderInfo);

    /**
     * <p> 根据orderID来查询订单信息 </p>
     *
     * @param orderId
     * @return
     */
    OrderInfo selectByPrimaryKey(Long orderId);

    /**
     * 取消订单
     *
     * @param orderCancelVo
     * @return
     */
    void cancelOrder(OrderCancelVo orderCancelVo);

    /**
     * 创建订单
     *
     * @param orderInfoVo 订单信息
     * @return 订单id
     */
    Long createOrder(OrderInfoVo orderInfoVo);
    /**
     * 驳回订单
     *
     * @param orderRejectVo 驳回信息
     * @return
     */
    Boolean rejectOrder(OrderRejectVo orderRejectVo);

    /**
     * 根据乘客ID获取当天的订单
     * @param subscriberId
     * @return
     */
    List<OrderPassengerVo> getOrderListByCurrentDay(Long subscriberId);

    /**
     * 乘客 查询个人行程
     * @param vo
     * @return
     */
    List<OrderPassengerVo> getOrderList(OrderPassengerReqVo vo);

    /**
     * 保存订单规划路线GPS记录
     */
    void saveOrderPlanGPS(OrderPlanGPSVo orderPlanGPSVo);

    /**
     * 通过订单id来查询规划路线GPS
     */
    OrderPlanGPSVo selectOrderPlanGPSByOrderId(Long orderId);

    /**
     * 返回乘客行程中的订单
     * @param subscriberId
     * @return
     */
    List<OrderPassengerVo> getInTrip(Long subscriberId);

    /**
     * 查询待支付的订单
     * @param subscriberId
     * @return
     */
    OrderPassengerWaitPayVo selectWaitPayOrder(Long subscriberId);

    /**
     * 通过订单id获得订单中司机方信息
     */
    OrderDrivingVo getDriverInfoByOrderId(Long orderId);

    /**
     * 根据orderID查询行程分享需要的订单信息
     */
    OrderTripShareVo getOrderTripShareInfoByOrderId(Long orderId);

    /**
     * 5分钟没有人接单，自动取消订单
     * @param param
     */
    void autoCancelOrder(String param);

    /**
     * 根据订单ID获取订单状态枚举
     * @param id
     * @return
     */
    OrderStatus getOrderStatusById(Long id);

    /**
     * 补充订单取消原因
     *
     */
    void fillCancelReason(OrderCancelVo orderCancelVo);

    /**
     * 根据订单ID获取订单城市信息
     */
    CityInfoVo getCityInfoById(Long id);

    /**
     * 获取驳回订单原因
     */
    OrderRejectRespVo getOrderRejectReason(Long id);

    /**
     * 获取订单缓存关键数据
     * @param id
     * @return
     */
    OrderCacheBean getOrderCache(Long id);

    /**
     * 根据用户ID subscriberId判断是否是新用户
     * @param subscriberId
     * @return
     */
    Boolean checkNewUser(Long subscriberId);

    /**
     * 根据订单ID获取订单固定信息
     *
     * @param id
     * @return
     */
    OrderFixedInfoVo getOrderFixedInfoById(Long id);
}
