package com.smzc.taxi.order.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.baidu.fsg.uid.UidGenerator;
import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.boot.mq.SmRocketMqTemplate;
import com.smzc.taxi.common.consts.MQTagsConst;
import com.smzc.taxi.common.consts.MQTopicConst;
import com.smzc.taxi.common.enums.DateTypeEnum;
import com.smzc.taxi.common.third.safetycall.util.DateUtil;
import com.smzc.taxi.common.utils.DateUtils;
import com.smzc.taxi.common.utils.JsonUtils;
import com.smzc.taxi.order.dao.mapper.OrderCancelMapper;
import com.smzc.taxi.order.dao.mapper.OrderInfoMapper;
import com.smzc.taxi.order.dao.mapper.OrderPayoffMapper;
import com.smzc.taxi.order.dao.mapper.OrderRejectMapper;
import com.smzc.taxi.order.domain.*;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.service.OrderStatusHistoryService;
import com.smzc.taxi.order.service.context.ProxyStatusTransferControl;
import com.smzc.taxi.order.util.OrderRedis;
import com.smzc.taxi.service.driver.bean.OpenCityVo;
import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.CarType;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.emun.OrderType;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.order.exception.OrderException;
import com.smzc.taxi.service.portal.bean.SystemConfigurationVo;
import com.smzc.taxi.service.portal.enums.SystemConfigurationEnum;
import com.smzc.taxi.service.portal.service.IOpenCityFacade;
import com.smzc.taxi.service.portal.service.ISystemConfigurationFacade;
import com.smzc.us.shared.facade.SubscriberFacade;
import com.smzc.us.shared.facade.vo.SubscriberVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 订单服务实现
 *
 * @author Tangqiandong
 * @version 1.0
 * @date 2019/5/15
 */
@Slf4j
@Service
public class OrderServiceImpl implements OrderService {

    @Resource
    private OrderInfoMapper orderInfoMapper;

    @Resource
    private OrderCancelMapper orderCancelMapper;

    @Resource
    private OrderRejectMapper orderRejectMapper;

    @Resource
    private OrderPayoffMapper orderPayoffMapper;

    @Resource
    private MongoTemplate mongoTemplate;

    @Resource
    private OrderStatusHistoryService orderStatusHistoryService;

    @Reference(version = "1.0.0")
    private IOpenCityFacade openCityFacade;

    @Reference(version = "1.0.0")
    private ISystemConfigurationFacade systemConfigurationFacade;

    @Resource
    OrderRedis orderRedis;

    @Resource
    SmRocketMqTemplate rocketMqTemplate;

    @Resource
    private UidGenerator uidGenerator;
    @Resource
    ProxyStatusTransferControl proxyStatusTransferControl;

    @Reference(cluster = "failfast", timeout = 30000, group = "userCenter", version = "1.0.0")
    private SubscriberFacade subscriberFacade;

    @Override
    public int updateByPrimaryKeySelective(OrderInfo orderInfo) {
        AssertUtil.notNull(orderInfo, "对象不能为null");
        return orderInfoMapper.updateByPrimaryKeySelective(orderInfo);
    }

    @Override
    public void cancelOrder(OrderCancelVo orderCancelVo) {
        Long orderId = orderCancelVo.getOrderId();
        OrderCacheBean orderCache = getOrderCache(orderId);
        AssertUtil.notNull(orderCache, "订单不存在！");

        orderCancelVo.setCancelByName(orderCache.getSubscriberName());
        OrderInfoContext orderInfoContext = new OrderInfoContext();
        BeanUtils.copyProperties(orderCache, orderInfoContext);
        orderInfoContext.setStatus(getOrderStatusById(orderId));

        ControlContext controlContext = new ControlContext(orderInfoContext.getStatus(), OrderStatus.CANCEL, orderInfoContext);
        controlContext.put("orderCancelInfo", orderCancelVo);
        proxyStatusTransferControl.transfer(controlContext);
    }

    @Override
    public Long createOrder(OrderInfoVo orderInfoVo) {
        AssertUtil.notNull(orderInfoVo.getSubscriberId(), "下单人id不能为空");
        AssertUtil.notNull(orderInfoVo.getPredictMileage(), "预估里程不能为空");
        AssertUtil.notNull(orderInfoVo.getPredictTime(), "预估里程时间不能为空");

//        地址信息校验
        AssertUtil.notNull(orderInfoVo.getPlanFromLongitude(), "订单起点经度不能为空");
        AssertUtil.notNull(orderInfoVo.getPlanFromLatitude(), "订单起点纬度不能为空");

        AssertUtil.notNull(orderInfoVo.getPlanFromAddress(), "订单起点地址不能为空");
        AssertUtil.notNull(orderInfoVo.getPlanToAddress(), "订单终点地址不能为空");

        AssertUtil.notNull(orderInfoVo.getPlanToLongitude(), "订单终点经度不能为空");
        AssertUtil.notNull(orderInfoVo.getPlanToLatitude(), "订单终点纬度不能为空");

        AssertUtil.notNull(orderInfoVo.getPlanFromCityCode(), "订单起点城市编码不能为空");
        AssertUtil.notNull(orderInfoVo.getPlanFromCityName(), "订单起点城市名称不能为空");
        AssertUtil.notNull(orderInfoVo.getPlanToCityCode(), "订单终点城市编码不能为空");
        AssertUtil.notNull(orderInfoVo.getPlanToCityName(), "订单终点城市名称不能为空");

//        如果下单城市编码或者下单城市名称，设置为下单起点城市编码和城市名称
        if (StringUtils.isEmpty(orderInfoVo.getCityCode()) || StringUtils.isEmpty(orderInfoVo.getCityName())) {
            orderInfoVo.setCityCode(orderInfoVo.getPlanFromCityCode());
            orderInfoVo.setCityName(orderInfoVo.getPlanFromCityName());
        }

//        校验城市是否开放
        final String planFromCityCode = orderInfoVo.getPlanFromCityCode();
        final List<OpenCityVo> openCityVos = openCityFacade.selectOpenCityList();

        AssertUtil.notEmpty(openCityVos, "未配置开放城市");

        Optional<OpenCityVo> first = openCityVos.stream()
                .filter(item -> item.getAreaCode().equals(planFromCityCode))
                .findFirst();
        AssertUtil.notNull(first, "订单起点所在城市[" + orderInfoVo.getPlanFromCityName() + "]未开放！");

//        获取用户信息
        SubscriberVo subscriberVo = subscriberFacade.getSubscriberById(orderInfoVo.getSubscriberId());
        AssertUtil.notNull(subscriberVo,"未获取到乘客信息。subId:"+orderInfoVo.getSubscriberId());

        orderInfoVo.setCreatedBy(subscriberVo.getName());
        orderInfoVo.setSubscriberName(subscriberVo.getName());
        orderInfoVo.setSubscriberPhone(subscriberVo.getMobileNo());

//        基本信息
        OrderInfoContext orderInfoContext = new OrderInfoContext();
        BeanUtils.copyProperties(orderInfoVo, orderInfoContext);

//        默认乘车人和下单人一样
        orderInfoContext.setPassengerName(orderInfoVo.getValetOrder() == null ? "本人" : orderInfoVo.getSubscriberName());
        orderInfoContext.setPassengerPhone(orderInfoVo.getSubscriberPhone());

//        上下车地址
        orderInfoContext.setPlanFromAddress(orderInfoVo.getPlanFromAddress());
        orderInfoContext.setPlanToAddress(orderInfoVo.getPlanToAddress());

//        地址信息
        OrderAddress orderAddress = new OrderAddress();
        BeanUtils.copyProperties(orderInfoVo, orderAddress);
        orderInfoContext.setOrderAddress(orderAddress);

        // 存缓存
        final Long orderId = uidGenerator.getUID();
        orderInfoContext.setId(orderId);

        // 邀新时，将司机ID和车辆ID同事传入流转上下文
        orderInfoContext.setDriverId(orderInfoVo.getDriverId());
        orderInfoContext.setVehicleId(orderInfoVo.getVehicleId());
        orderRedis.setTempOrderInfo(orderInfoContext);

        // 发mq
        rocketMqTemplate.syncSend(MQTopicConst.TAXI_ORDER, MQTagsConst.INIT, orderId.toString(),orderId.toString());

//        上下文
//        ControlContext context = new ControlContext(OrderStatus.INIT, OrderStatus.WAIT_RECEIVE, orderInfoContext);
//        ProxyStatusTransferControl.transfer(context);

        return orderId;
    }

    @Override
    public Boolean rejectOrder(OrderRejectVo orderRejectVo) {
        Long orderId = orderRejectVo.getOrderId();
        OrderCacheBean orderCache = getOrderCache(orderId);
        AssertUtil.notNull(orderCache, "订单不存在");

        OrderInfoContext orderInfoContext = new OrderInfoContext();
        BeanUtils.copyProperties(orderCache, orderInfoContext);
        orderInfoContext.setStatus(getOrderStatusById(orderId));

        if (orderInfoContext.getStatus() == OrderStatus.IN_TRIP ||
                orderInfoContext.getStatus() == OrderStatus.WAIT_PAY ||
                orderInfoContext.getStatus() == OrderStatus.FINISH ||
                orderInfoContext.getStatus() == OrderStatus.CANCEL) {
            throw new OrderException(String.format("当前订单%s不能驳回", orderInfoContext.getStatus().getName()));
        }

        ControlContext context = new ControlContext(orderInfoContext.getStatus(), OrderStatus.REJECTED, orderInfoContext);
        context.put("orderReject", orderRejectVo);
        proxyStatusTransferControl.transfer(context);
        return true;
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public OrderInfo selectByPrimaryKey(Long orderId) {
        AssertUtil.notNull(orderId, "orderId不能为空");
        return orderInfoMapper.selectByPrimaryKey(orderId);
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public List<OrderPassengerVo> getOrderListByCurrentDay(Long subscriberId) {
        List<Byte> statusList = Arrays.asList(
                OrderStatus.WAIT_EVALUATE.getIndex(),
                OrderStatus.WAIT_PAY.getIndex(),
                OrderStatus.FINISH.getIndex(),
                OrderStatus.WAIT_PAY_REJECT.getIndex(),
                OrderStatus.WAIT_PAY_CANCEL.getIndex()
        );
        // 昨天0点
        String date = DateUtils.getDateString(DateUtils.ofPassBeginOrEndTime(-1, new Date(), DateTypeEnum.BEGIN));
        List<OrderPassenger> orderPassenger = orderInfoMapper.getOrderListByCurrentDay(subscriberId, statusList, date);
        return transfData(orderPassenger);
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public List<OrderPassengerVo> getOrderList(OrderPassengerReqVo vo) {
        OrderPassengerDto orderPassengerDto = new OrderPassengerDto();
        BeanUtils.copyProperties(vo, orderPassengerDto);
        List<OrderPassenger> list = orderInfoMapper.getOrderList(orderPassengerDto);
        if (!CollectionUtils.isEmpty(list)) {
            List<OrderPassengerVo> opList = list.stream().map(this::transfData).collect(Collectors.toList());
            //设置订单金额
            this.batchSetPayAmount(opList);
            return opList;
        }
        return Collections.emptyList();
    }

    //批量查询设置订单金额
    private void batchSetPayAmount(List<OrderPassengerVo> opList) {
        //根据orderId集合查询订单金额map集合
        List<Long> orderIdList = new ArrayList<>();
        for (OrderPassengerVo vo : opList) {
            orderIdList.add(vo.getOrderId());
        }
        List<PayAmountVo> payAmountVoList = orderPayoffMapper.selectPayAmountByOrderIdList(orderIdList);
        Map<Long, Integer> payAmountVoMap = new HashMap<>();
        for (PayAmountVo vo : payAmountVoList) {
            payAmountVoMap.put(vo.getOrderId(), vo.getPayAmount());
        }

        //设置订单金额
        for (OrderPassengerVo vo : opList) {
            vo.setPayAmount(payAmountVoMap.get(vo.getOrderId()));
        }
    }

    // 数据转换
    private OrderPassengerVo transfData(OrderPassenger orderPassenger) {
        OrderPassengerVo passengerVo = new OrderPassengerVo();
        BeanUtils.copyProperties(orderPassenger, passengerVo);
        passengerVo.setOrderType(OrderType.getByCode(orderPassenger.getOrderType()));
        passengerVo.setCarType(CarType.getBycode(orderPassenger.getCarType()));
        passengerVo.setOrderStatus(OrderStatus.fromIndex(orderPassenger.getOrderStatus()));
        return passengerVo;
    }

    // 数据转换
    private List<OrderPassengerVo> transfData(List<OrderPassenger> orderPassenger) {
        if (!CollectionUtils.isEmpty(orderPassenger)) {
            return orderPassenger.stream().map(this::transfData).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    @Override
    public void saveOrderPlanGPS(OrderPlanGPSVo orderPlanGPSVo) {
        AssertUtil.notNull(orderPlanGPSVo, "对象不能为空");
        Long orderId = orderPlanGPSVo.getOrderId();
        AssertUtil.notNull(orderId, "订单id不能为空");
        AssertUtil.notEmpty(orderPlanGPSVo.getGpsList(), "规划路径GPS集合不能为空");
        //保存数据
        Query query = new Query(Criteria.where("order_id").is(orderId));
        Update update = Update.update("gps", orderPlanGPSVo.getGpsList()).set("create_time", DateUtil.dateToStr(new Date(), DateUtil.DATE_TIME_LINE));
        mongoTemplate.upsert(query, update, OrderPlanGPS.class);
    }

    @Override
    public OrderPlanGPSVo selectOrderPlanGPSByOrderId(Long orderId) {
        AssertUtil.notNull(orderId, "订单id不能为空");
        OrderPlanGPS orderPlanGPS = mongoTemplate.findOne(new Query(Criteria.where("order_id").is(orderId)), OrderPlanGPS.class);

        if (orderPlanGPS == null) {
            return null;
        }
        OrderPlanGPSVo orderPlanGPSVo = new OrderPlanGPSVo();
        BeanUtils.copyProperties(orderPlanGPS, orderPlanGPSVo);
        return orderPlanGPSVo;
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public List<OrderPassengerVo> getInTrip(Long subscriberId) {
        List<Byte> statusList = Arrays.asList(
                OrderStatus.WAIT_RECEIVE.getIndex(),
                OrderStatus.AUTO_DISPATCHING.getIndex(),
                OrderStatus.WAIT_DRIVER_CONFIRM.getIndex(),
                OrderStatus.DRIVER_STARTING.getIndex(),
                OrderStatus.DRIVER_ARRIVE.getIndex(),
                OrderStatus.IN_TRIP.getIndex(),
                OrderStatus.WAIT_COLLECT_MONEY.getIndex(),
                OrderStatus.WAIT_PAY_REJECT.getIndex(),
                OrderStatus.WAIT_PAY_CANCEL.getIndex(),
                OrderStatus.WAIT_PAY.getIndex()
        );

        List<OrderPassenger> list = orderInfoMapper.getInTrip(subscriberId, statusList);
        if (!CollectionUtils.isEmpty(list)) {
            return list.parallelStream().map(this::transfData).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public OrderDrivingVo getDriverInfoByOrderId(Long orderId) {
        AssertUtil.notNull(orderId, "订单id不能为空");
        OrderDrivingVo vo = null;
        OrderInfoContext tempOrderInfo = orderRedis.getTempOrderInfo(orderId);
        if (tempOrderInfo != null) {
            vo = JsonUtils.copyProperites(OrderDrivingVo.class, tempOrderInfo);
            vo.setOrderStatus(OrderStatus.WAIT_RECEIVE);
        } else {
            vo = orderInfoMapper.getDriverInfoByOrderId(orderId);
            if (vo != null) {
                OrderStatus orderStatus = OrderStatus.fromIndex(vo.getStatus());
                vo.setOrderStatus(orderStatus);

                List<OrderStatus> statusList = Arrays.asList(
                        OrderStatus.INIT,
                        OrderStatus.WAIT_RECEIVE,
                        OrderStatus.AUTO_DISPATCHING,
                        OrderStatus.WAIT_DRIVER_CONFIRM);

                if (!statusList.contains(orderStatus)) {
                    Date createdTime = orderStatusHistoryService.selectCreateTimeByOrderIdAndToStatus(orderId, OrderStatus.DRIVER_STARTING);
                    vo.setDriverStartTime(createdTime);
                }
            }
        }
        log.debug("返回的订单信息：{}", JSON.toJSONString(vo));
        return vo;
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public OrderPassengerWaitPayVo selectWaitPayOrder(Long subscriberId) {
        List<Byte> statusList = Arrays.asList(
                OrderStatus.WAIT_PAY.getIndex(),
                OrderStatus.WAIT_PAY_CANCEL.getIndex(),
                OrderStatus.WAIT_PAY_REJECT.getIndex()
        );
        OrderInfo orderInfo = orderInfoMapper.selectWaitPayOrder(subscriberId, statusList);
        if (orderInfo != null) {
            OrderPassengerWaitPayVo orderPassengerWaitPayVo = new OrderPassengerWaitPayVo();
            orderPassengerWaitPayVo.setOrderId(orderInfo.getId());
            orderPassengerWaitPayVo.setType(orderInfo.getType());
            return orderPassengerWaitPayVo;
        }
        return null;
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public OrderTripShareVo getOrderTripShareInfoByOrderId(Long orderId) {
        AssertUtil.notNull(orderId, "订单id不能为空");
        return orderInfoMapper.getOrderTripShareInfoByOrderId(orderId);
    }

    @Override
    public void autoCancelOrder(String param) {
        // 5分钟没有人接单，自动取消订单

        List<OrderStatus> noRejectist = Arrays.asList(
                OrderStatus.WAIT_RECEIVE,
                OrderStatus.AUTO_DISPATCHING,
                OrderStatus.WAIT_DRIVER_CONFIRM,
                OrderStatus.INIT);
        OrderCancelBean orderBean = null;

        try {
            do {
                // 从缓存队列中取一个
                orderBean = orderRedis.getWaitCancelOrderRightPop();
                if (orderBean == null) {
                    break;
                }

                // 从缓存中获取订单最新状态,大部分订单会走正常流程被抢，所以这里的判定有必要
                OrderStatus currentStatus = getOrderStatusById(orderBean.getOrderId());
                if (!noRejectist.contains(currentStatus)) {
                    // 已经被司机抢单，在走正常流程，跳过本次循环
                    log.debug("OrderId:{},已经被司机抢单，在走正常流程", orderBean.getOrderId());
                    continue;
                }

                // 读配置信息，获取下单等待的最大时间，如果系统未设置，或者报错。则使用默认值5分钟
                // 保证主线程能正常运行
                int maxTime = getMaxTime(orderBean.getCityCode());


                // 判定订单是否达到最大时间
                final boolean effect = overdueOrder(orderBean.getStartTime(), maxTime);
                if (effect) {
                    // 修改前读最新的订单状态
                    OrderInfoContext orderInfo = JsonUtils.copyProperites(OrderInfoContext.class, orderInfoMapper.selectByPrimaryKey(orderBean.getOrderId()));
                    if (orderInfo != null && noRejectist.contains(orderInfo.getStatus())) {

                        log.info("OrderId:{},满足系统取消条件，继续执行，订单状态流转到系统取消", orderInfo.getId());
                        // 满足条件继续执行，订单状态流转到系统取消
                        final ControlContext context =
                                new ControlContext(orderInfo.getStatus(), OrderStatus.SYS_CANCEL, orderInfo);
                        context.put("orderCancelInfo", getOrderCancel(orderBean.getOrderId()));
                        proxyStatusTransferControl.transfer(context);

                        log.info("OrderId:{},订单被自动取消", orderBean.getOrderId());
                    } else {
                        log.info("定时执行自动取消时，订单{}突然被抢，放弃本次取消任务", orderBean.getOrderId());
                    }
                } else {
                    // 没有过期,将取出的对象还回去
                    orderRedis.setWaitCancelOrderRightPush(orderBean);
                    break;
                }

            } while (true);

        } catch (Exception e) {
            // 处理异常时，将对象还回去
            log.error("OrderId:{},定时处理待取消订单时异常，将对象还回队列", orderBean.getOrderId(), e);
            orderRedis.setWaitCancelOrderRightPush(orderBean);
        }
    }

    /**
     * 获取系统设置的最大时间
     *
     * @return
     */
    private Integer getMaxTime(String cityCode) {
        //
        // 1.先从redis中取，如果没有
        // 2.再通过DUBBO到配置中心去取
        // 3.如果配置中心没有获取到数据，或者返回异常，则使用默认失效时间 5分钟
        Integer maxNum = orderRedis.getTaxiMaxCallTimeOut(cityCode);
        if (maxNum == null || maxNum <= 0) {
            SystemConfigurationVo config = null;
            try {
                config = systemConfigurationFacade.getSystemConfiguration(SystemConfigurationEnum.TAXI_CALL_TIMEOUT, cityCode);
                if (config != null && !StringUtils.isEmpty(config.getConfigValue())) {
                    int tpNum = Integer.valueOf(config.getConfigValue());
                    maxNum = tpNum <= 0 ? 5 : tpNum;
                    orderRedis.setTaxiMaxCallTimeOut(cityCode, maxNum);
                } else {
                    maxNum = 5;
                }
            } catch (Exception e) {
                log.error("读最大呼叫时间配置信息异常：", e);
                maxNum = 5;
            }
        }
        return maxNum;
    }

    @Override
    public OrderStatus getOrderStatusById(Long id) {
        OrderStatus orderStatus = orderRedis.getOrderStatus(id);
        if (orderStatus == null) {
            Byte status = orderInfoMapper.getOrderStatusById(id);
            // 无论查询结果是什么都缓存起来
            if (status == null) {
                orderRedis.setOrderStatus(id, null);
            } else {
                orderStatus = OrderStatus.fromIndex(status.byteValue());
                orderRedis.setOrderStatus(id, orderStatus);
            }
        }
        return orderStatus;
    }

    @Override
    public void fillCancelReason(OrderCancelVo orderCancelVo) {
        AssertUtil.notNull(orderCancelVo, "参数错误");
        AssertUtil.notNull(orderCancelVo.getOrderId(), "订单Id不能为空");
        AssertUtil.notNull(orderCancelVo.getCancelReason(), "原因不能为空");
        OrderCancel orderCancel = JsonUtils.copyProperites(OrderCancel.class, orderCancelVo);
        orderCancelMapper.fillReasonByOrderId(orderCancel);
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public CityInfoVo getCityInfoById(Long id) {
        AssertUtil.notNull(id, "订单Id不能为空");
        return orderInfoMapper.getCityInfoById(id);
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public OrderRejectRespVo getOrderRejectReason(Long id) {
        AssertUtil.notNull(id, "订单id不能为空！");
        OrderReject orderReject = orderRejectMapper.selectRejectByOrderId(id);
        AssertUtil.notNull(orderReject, "该订单没有被驳回！");
        OrderRejectRespVo orderRejectRespVo = new OrderRejectRespVo();
        orderRejectRespVo.setRejectReason(orderReject.getRejectReason());
        return orderRejectRespVo;
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public Boolean checkNewUser(Long subscriberId) {
        AssertUtil.notNull(subscriberId, "乘客ID不能为空");
        int count = orderInfoMapper.countBySubscriberId(subscriberId);
        return count == 0;
    }

    @Override
    public OrderFixedInfoVo getOrderFixedInfoById(Long id) {
        AssertUtil.notNull(id, "订单ID不能为空");
        OrderCacheBean orderCacheBean = this.getOrderCache(id);
        OrderFixedInfoVo vo = new OrderFixedInfoVo();
        BeanUtils.copyProperties(orderCacheBean, vo);
        return vo;
    }

    @Override
    public OrderCacheBean getOrderCache(Long id) {
        OrderCacheBean orderCache = orderRedis.getOrderCache(id);
        if (orderCache == null) {
            orderCache = orderInfoMapper.getOrderCache(id);
            if (orderCache == null) {
                orderCache = new OrderCacheBean();
                orderCache.setId(id);
            }
            orderRedis.setOrderCache(orderCache);
        }
        return orderCache;
    }

    private OrderCancelVo getOrderCancel(Long orderId) {
        OrderCancelVo orderCancelVo = new OrderCancelVo();
        orderCancelVo.setCancelByName("系统");
        orderCancelVo.setCancelBy(-1L);
        orderCancelVo.setSourceType((byte) 3);
        orderCancelVo.setCancelReason("超时未匹配到司机，订单自动取消");
        orderCancelVo.setOrderId(orderId);
        return orderCancelVo;
    }

    private boolean overdueOrder(Long startTime, int maxMinute) {
        Long currentTime = System.currentTimeMillis();
        return (currentTime - startTime) / DateUtils.SECONDS_ONE_MILLISECOND >= maxMinute;
    }
}
