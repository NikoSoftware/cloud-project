package com.smzc.taxi.order.mq;

import com.smzc.taxi.common.consts.MQGroupConst;
import com.smzc.taxi.common.consts.MQTagsConst;
import com.smzc.taxi.common.consts.MQTopicConst;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.context.ProxyStatusTransferControl;
import com.smzc.taxi.order.util.OrderRedis;
import com.smzc.taxi.service.order.emun.OrderStatus;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Arrays;

/**
 *
 * 订阅创建新订单的MQ
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/9 17:50
 */
@Component
@Slf4j
@RocketMQMessageListener(
        consumerGroup = MQGroupConst.TAXI_ORDER_GROUP_PREFIX,
        topic = MQTopicConst.TAXI_ORDER,
        selectorExpression = MQTagsConst.INIT)
public class CreateNewOrder implements RocketMQListener<MessageExt> {

    @Resource
    OrderRedis orderRedis;
    @Resource
    ProxyStatusTransferControl proxyStatusTransferControl;

    @Override
    public void onMessage(MessageExt messageExt) {
        Long orderId = Long.valueOf(new String(messageExt.getBody()));
        log.info("收到MQ消息，开始创建订单。订单ID ：{}",orderId);
        try {
            OrderInfoContext orderInfoContext = orderRedis.getTempOrderInfo(orderId);
            if(orderInfoContext != null){
                ControlContext context = new ControlContext(OrderStatus.INIT, OrderStatus.WAIT_RECEIVE, orderInfoContext);
                proxyStatusTransferControl.transfer(context);
                orderRedis.delTempOrderInfo(orderId);
            }
        } catch (DuplicateKeyException de){
            // key 重复 不处理
            log.error("添加订单MQ消费时 key 重复，此消息不用关注，OrderId：{}",orderId);
        } catch (Exception e) {
            log.error("【Order -> 创建订单MQ】消费mq失败，失败原因", e);
            throw e;
        }
    }
}
