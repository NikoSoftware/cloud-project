package com.smzc.taxi.order.service.handler.statustransfer;

import com.alibaba.fastjson.JSON;
import com.smzc.taxi.boot.mq.SmRocketMqTemplate;
import com.smzc.taxi.common.consts.MQTagsConst;
import com.smzc.taxi.common.consts.MQTopicConst;
import com.smzc.taxi.order.dao.es.OrderDoc;
import com.smzc.taxi.order.dao.es.OrderDocRepo;
import com.smzc.taxi.order.dao.mapper.OrderAddressMapper;
import com.smzc.taxi.order.dao.mapper.OrderInfoMapper;
import com.smzc.taxi.order.dao.mapper.OrderStatusHistoryMapper;
import com.smzc.taxi.order.dao.mapper.OrderStatusPositionMapper;
import com.smzc.taxi.order.domain.*;
import com.smzc.taxi.order.util.OrderMail;
import com.smzc.taxi.order.service.*;
import com.smzc.taxi.order.service.context.ProxyStatusTransferControl;
import com.smzc.taxi.order.util.OrderRedis;
import com.smzc.taxi.order.util.SuperBeanUtils;
import com.smzc.taxi.service.dispatch.bean.OrderInfoBean;
import com.smzc.taxi.service.driver.bean.DriverWorkStateTurnVo;
import com.smzc.taxi.service.driver.enums.DriverWorkStateEnum;
import com.smzc.taxi.service.driver.exception.DriverWorkStateTurnNoRetryException;
import com.smzc.taxi.service.order.bean.mq.MqMessageBody;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.OrderBusinessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.GetQuery;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * EventHandler抽象实现
 *
 * @author liuxinjie
 * @version v1.0
 * @date 2019/5/21
 */
@Slf4j
public abstract class OrderHandler implements EventHandler {

    @Resource
    protected OrderService orderService;

    @Resource
    protected ThreadPoolTaskExecutor executor;

    @Resource
    protected OrderInfoMapper orderInfoMapper;

    @Resource
    protected OrderStatusHistoryMapper orderStatusHistoryMapper;

    @Resource
    OrderDispatchService orderDispatchService;

    @Resource
    private OrderStatusPositionMapper orderStatusPositionMapper;

    @Resource
    private OrderDocRepo orderDocRepo;

    @Autowired
    private SmRocketMqTemplate rocketMqTemplate;

    @Resource
    private ElasticsearchTemplate elasticsearchTemplate;

    @Resource
    DriverTransposeService driverTransposeService;

    @Resource
    OrderAddressMapper orderAddressMapper;

    @Resource
    OrderRedis orderRedis;

    @Resource
    OrderMail orderMail;

    @Resource
    ProxyStatusTransferControl proxyStatusTransferControl;


    @Override
    @Transactional(rollbackFor = Exception.class)
    public EventHandler processTransfer(ControlContext context) {
        transactionMethod(context);
        return this;
    }

    @Override
    public void processTransferNoTransaction(ControlContext context) {

        // 非事务方法
        defaultMethod(context);

        // 异步方法
        executor.execute(() -> {
            asyncMethod(context);
        });

        // 自动进入下一个状态流程
        joinNextStatus(context);

    }


    @Override
    public long getSleepTime() {
        return 10L;
    }

    @Override
    public abstract void process(ControlContext context);

    @Override
    public boolean isSyncTransferStatus() {
        return true;
    }

    @Override
    public ControlContext next(ControlContext context) {
        return null;
    }

    // 是否要发消息
    @Override
    public boolean isPushMessage(ControlContext context) {
        return true;
    }


    /**
     * 执行事物中的方法
     *
     * @param context
     */

    public void transactionMethod(ControlContext context) {
        process(context);
        finish(context);
    }

    /**
     * 默认非事务方法
     *
     * @param context
     */
    public void defaultMethod(ControlContext context) {
        OrderInfoContext orderInfoContext = context.getEntity();
        try {
            // 存订单状态缓存
            orderRedis.setOrderStatus(context.getOrderId(), context.getToStatus());
        } catch (Exception e) {
            log.error("OrderId:{},存订单状态缓存失败", context.getOrderId(), e);
            try {
                orderRedis.delOrderStatus(context.getOrderId());
                log.debug("OrderId:{},订单状态缓存删除成功", context.getOrderId());
            } catch (Exception e2) {
                log.error("OrderId:{},订单状态缓存删除异常", context.getOrderId(), e);
            }
        }

        if (isPushMessage(context)) {
            // 消息推送
            MqMessageBody body = initMessage(context);
            String tag = context.getToStatus().toString();

            // 发给移动端
            this.pushMessage(body, MQTopicConst.TAXI_ORDER, tag);
            // 发给中控
            this.pushMessage(body, MQTopicConst.TAXI_CENTER_CONTROLLER, tag);
        }

        // 通知调度中心，同步订单状态
        syncOrderStatus(orderInfoContext, context.getFromStatus(), context.getToStatus());
    }

    @Override
    public void finish(final ControlContext context) {
        final OrderInfoContext orderInfoContext = context.getEntity();
        final OrderStatus fromStatus = context.getFromStatus();
        final OrderStatus toStatus = context.getToStatus();
        final Long orderId = orderInfoContext.getId();

        orderInfoContext.setStatus(toStatus);

        // 根据订单ID修改订单状态
        if (fromStatus != OrderStatus.INIT) {
            int effect = orderInfoMapper.updateStatus(orderId, fromStatus.getIndex(), toStatus.getIndex());
            if (effect <= 0) {

                String errMsg = String.format("订单状态流转失败，本次事务回滚，订单id是： %s . 订单状态从 %s 到 %s",
                        orderId,fromStatus.getName(),toStatus.getName());

                log.error(errMsg);
                orderMail.sendMail("订单状态流转失败",errMsg);
                // 通知前端强刷
                throw new OrderBusinessException(errMsg);
            }
        }


        // 保存状态流转记录
        saveTransferRecord(context);

        // 同步订单数据至es,失败时就回滚
        try {
            syncOrderToEs(orderInfoContext);
            log.debug("同步订单数据至es成功。订单id={},订单状态={}", orderId, toStatus.getName());
        } catch (Exception e) {
            log.error("同步订单数据至es异常，订单信息{}", JSON.toJSONString(orderInfoContext), e);

            // 如果创建订单时，ES同步异常，则回滚。保证数据同步
            // 非init 不回滚
            if (fromStatus == OrderStatus.INIT) {
                throw e;
            }
        }

        // 删除订单状态缓存
        orderRedis.delOrderStatus(context.getOrderId());
    }


    /**
     * 设置消息体
     * 默认存了订单ID，司机ID，乘客ID,from状态，to状态
     * 当消息体不一样时，子类可重写此方法
     */
    public MqMessageBody initMessage(ControlContext context) {
        return getPublicMqMsgBody(context);
    }


    /**
     * 默认消息body 中写入 订单ID，司机ID，乘客ID，fromStatus,toStatus
     * 子类可以使用，但不能重写
     *
     * @param context
     * @return
     */
    public MqMessageBody getPublicMqMsgBody(ControlContext context) {
        MqMessageBody orderStatusTransfer = new MqMessageBody();
        OrderInfoContext orderInfo = context.getEntity();
        orderStatusTransfer.setOrderId(orderInfo.getId());
        orderStatusTransfer.setDriverId(orderInfo.getDriverId());
        orderStatusTransfer.setSubscriberId(orderInfo.getSubscriberId());
        orderStatusTransfer.setFromStatus(context.getFromStatus().getIndex());
        orderStatusTransfer.setToStatus(context.getToStatus().getIndex());
        orderStatusTransfer.setVehicleId(orderInfo.getVehicleId());
        orderStatusTransfer.setPlatformType(orderInfo.getPlatformType());
        orderStatusTransfer.setAddType(orderInfo.getAddType());
        return orderStatusTransfer;
    }


    /**
     * 修改司机状态的参数封装公共方法
     * 不能重写
     *
     * @param context
     * @param driverWorkStateEnum
     * @return
     */
    public final DriverWorkStateTurnVo getDriverWorkStateTurnVo(ControlContext context, DriverWorkStateEnum driverWorkStateEnum) {
        OrderInfoContext orderInfoContext = context.getEntity();
        DriverWorkStateTurnVo driverWorkStateTurnVo = new DriverWorkStateTurnVo();
        driverWorkStateTurnVo.setDriverId(orderInfoContext.getDriverId());
        driverWorkStateTurnVo.setDriverName(orderInfoContext.getDriverName());
        driverWorkStateTurnVo.setAreaCode(orderInfoContext.getCityCode());
        driverWorkStateTurnVo.setCurrentTime(System.currentTimeMillis());
        driverWorkStateTurnVo.setNextState(driverWorkStateEnum);
        driverWorkStateTurnVo.setVehicleId(orderInfoContext.getVehicleId());
        driverWorkStateTurnVo.setVehicleNo(orderInfoContext.getVehicleNo());
        return driverWorkStateTurnVo;
    }

    /**
     * 抢单后，通知司机端订单已废弃（已取消或驳回）
     * 不能重写
     *
     * @param context
     * @return
     */
    public final void transferDriverWorkStatus(ControlContext context) {

        // 更新司机状态
        // 调用司机接口，修改司机状态为听单中
        final DriverWorkStateEnum nextStatus = DriverWorkStateEnum.DRIVER_WAITING;
        final DriverWorkStateTurnVo driverWorkStateTurnVo = getDriverWorkStateTurnVo(context, nextStatus);

        // 对司机状态修改做补偿，3次重试失败就发MQ
        try {
            driverTransposeService.driverWorkStateTurn(driverWorkStateTurnVo);
            log.info("司机ID={}，修改司机状态为，待命中,成功", context.getEntity().getDriverId());
        } catch (DriverWorkStateTurnNoRetryException dwe) {
            //业务异常，不重试,发邮件提示
            String errMsg = String.format("司机状态流转失败,业务异常,不重试. 司机Id:[%d], 参数是: %s. 异常原因: %s",
                    driverWorkStateTurnVo.getDriverId(),
                    JSON.toJSONString(driverWorkStateTurnVo),
                    dwe.getMessage());
            orderMail.sendMail("driver status transfer failed",errMsg);

            log.error("司机状态流转失败,静默处理，不重试，参数：{}" + JSON.toJSONString(driverWorkStateTurnVo), dwe);
        } catch (Exception e) {

            // 发邮件 通知
            String errMsg = String.format("司机状态流转失败.系统异常.等待重试. 司机id :[%s] 请求参数: %s, 失败原因 : %s",
                    driverWorkStateTurnVo.getDriverId(),
                    JSON.toJSONString(driverWorkStateTurnVo),
                    e.getMessage());
            orderMail.sendMail("driver status transfer failed",errMsg);

            // 第一次失败了，再使用异步的方式去同步,不能影响主流程
            log.error("司机状态流转失败。id= {} 的状态修改成{},参数：{}，失败原因：",
                    driverWorkStateTurnVo.getDriverId(),
                    nextStatus.getName(),
                    JSON.toJSONString(driverWorkStateTurnVo), e);

            executor.execute(() -> {
                int maxNum = 3;
                do {
                    try {
                        driverTransposeService.driverWorkStateTurn(driverWorkStateTurnVo);
                        log.info("司机ID={}，修改司机状态为，待命中,重试成功", context.getEntity().getDriverId());
                        break;
                    } catch (DriverWorkStateTurnNoRetryException dwe) {
                        //业务异常，不重试
                        log.error("司机状态流转失败,静默处理，不重试，参数：{}" + JSON.toJSONString(driverWorkStateTurnVo), dwe);
                        break;
                    } catch (Exception e2) {
                        if (maxNum > 1) {
                            log.error("司机状态流转失败，司机id= {} 的状态修改成{},失败原因{},尝试重试，第{}次",
                                    driverWorkStateTurnVo.getDriverId(), nextStatus.getName(), e2.getMessage(), (4 - maxNum), e2);
                            try {
                                TimeUnit.MILLISECONDS.sleep(50L);
                            } catch (InterruptedException ex) {
                                log.error(ex.getMessage(), ex);
                            }
                        } else {
                            // 发MQ消息,从服务中变更到待命中。这里要单独写，不能用公共的来发消息
                            rocketMqTemplate.syncSend(MQTopicConst.TAXI_DRIVER_WORK_STATUS, MQTagsConst.TRANSFER_DIRVER_STATUS, driverWorkStateTurnVo);
                            log.info("司机状态流转失败，三次重试失败,发送MQ消息作补偿，司机ID{},从{}状态改成{}", context.getEntity().getDriverId(),
                                    DriverWorkStateEnum.DRIVER_INSERVICE.getName(), nextStatus.getName());
                        }
                    }
                } while (--maxNum > 0);
            });
        }
    }

    /**
     * 通过mq发送消息
     *
     * @param message
     * @auther liuxinjie
     */
    public final void pushMessage(MqMessageBody message, String topic, String tags) {
        if (message != null) {
            try {
                rocketMqTemplate.syncSendOrderly(topic, tags, message, message.getOrderId().toString());
                log.debug("消息发送成功。订单{}，topic:{},tags:{}", message.getOrderId(), topic, tags);
            } catch (Exception e) {
                log.error("订单{}，mq消息推送异常,TOPIC:{},TAGS：{},消息内容：{}", message.getOrderId(), topic, tags, message.toString(), e);
            }
        }
    }


    // ------------------- 内部方法调用=====================================


    /**
     * 同步订单数据至es：新增或者更新
     */
    private void syncOrderToEs(final OrderInfoContext orderInfoContext) {
        GetQuery query = new GetQuery();
        query.setId(orderInfoContext.getId().toString());
        OrderDoc orderDoc = elasticsearchTemplate.queryForObject(query, OrderDoc.class);
        if (orderDoc == null) {
            orderDoc = new OrderDoc();
        }
        SuperBeanUtils.copy(orderInfoContext, orderDoc);
        orderDoc.setStatus(orderInfoContext.getStatus().getIndex());
        orderDoc.setStatusText(orderInfoContext.getStatus().getName());
        orderDocRepo.save(orderDoc);
    }

    /**
     * 添加订单状态坐标，从司机接单开始存
     */
    private void addStatusPosition(OrderInfoContext orderInfo, OrderStatus orderStatus) {
        final Long orderId = orderInfo.getId();
        final Double latitude = orderInfo.getLatitude();
        final Double longitude = orderInfo.getLongitude();
        OrderStatusPosition orderStatusPosition = new OrderStatusPosition();
        orderStatusPosition.setDriverId(orderInfo.getDriverId());
        orderStatusPosition.setOrderId(orderId);
        orderStatusPosition.setLatitude(latitude);
        orderStatusPosition.setLongitude(longitude);
        orderStatusPosition.setOrderStatus(orderStatus.getIndex());
        orderStatusPosition.setDivisionCode(orderInfo.getCityCode());
        int addFlag = orderStatusPositionMapper.insert(orderStatusPosition);
        if (addFlag <= 0) {
            log.error("OrderId:{}, 添加订单状态坐标失败，经度={}，纬度={}", orderId, longitude, latitude);
        }
    }

    /**
     * 与调度中心同步订单状态
     */
    private void syncOrderStatus(OrderInfoContext orderInfo, final OrderStatus fromStatus, final OrderStatus toStatus) {
        final Long orderId = orderInfo.getId();
        OrderCacheBean orderCacheBean = orderService.getOrderCache(orderId);
        OrderInfoBean orderInfoBean = new OrderInfoBean();
        orderInfoBean.setOrderNo(orderId.toString());
        orderInfoBean.setAreaCode(orderInfo.getCityCode());
        orderInfoBean.setDriverId(orderInfo.getDriverId());
        orderInfoBean.setStartLat(orderCacheBean.getPlanFromLatitude());
        orderInfoBean.setStartLng(orderCacheBean.getPlanFromLongitude());
        orderInfoBean.setEndLat(orderCacheBean.getPlanToLatitude());
        orderInfoBean.setEndLng(orderCacheBean.getPlanToLongitude());
        orderInfoBean.setOrderStatus(toStatus);
        orderInfoBean.setAssignTime(new Date());
        orderInfoBean.setVehicleId(orderInfo.getVehicleId());
        orderInfoBean.setAnticipateTime(orderInfo.getPredictTime());
        try {
            orderDispatchService.syncOrderStatus(orderInfoBean);
            log.debug("与调度中心同步订单状态成功，订单id=" + orderId + "，当前状态[" + fromStatus.getName() + "]，下一状态[" + toStatus.getName() + "]");
        } catch (Exception e) {
            log.error("与调度中心同步订单状态异常，订单id=" + orderId + "，当前状态[" + fromStatus.getName() + "]，下一状态[" + toStatus.getName() + "]", e);

            // 第一次失败了，再使用异步的方式去同步,不能影响主流程
            executor.execute(() -> {
                int startNum = 2, step = 1, index = 6;
                do {
                    try {
                        orderDispatchService.syncOrderStatus(orderInfoBean);
                        break;
                    } catch (Exception e2) {
                        log.error("订单号{}，与调度中心同步订单状态异常，重试第{}次,当前状态：{}，下一状态{}",
                                orderId,
                                (7 - index),
                                fromStatus.getName(),
                                toStatus.getName(),
                                e);
                        startNum = startNum + step;
                        step = startNum - step;
                        sleep(startNum*1000);
                    }
                } while (--index > 0);
            });
        }
    }

    /**
     * 保存状态流转记录
     */
    private void saveTransferRecord(ControlContext context) {
        final OrderInfoContext entity = context.getEntity();
        final Long orderId = entity.getId();
        final OrderStatus fromStatus = context.getFromStatus();
        final OrderStatus toStatus = context.getToStatus();
        int addFlag = orderStatusHistoryMapper.insert(new OrderStatusHistory(orderId, fromStatus, toStatus));
        if (addFlag <= 0) {
            log.error("保存状态流转记录失败，订单id=" + orderId + "，当前状态[" + fromStatus.getName() + "]，下一状态[" + toStatus.getName() + "]");
        }
    }

    /**
     * 异步执行的方法
     *
     * @param context
     */
    public void asyncMethod(final ControlContext context) {
        // 写入订单状态坐标。从司机接单~结束行程时存
        final OrderStatus toStatus = context.getToStatus();
        if (OrderStatus.DRIVER_STARTING == toStatus ||
                OrderStatus.DRIVER_ARRIVE == toStatus ||
                OrderStatus.IN_TRIP == toStatus ||
                OrderStatus.WAIT_COLLECT_MONEY == toStatus) {
            addStatusPosition(context.getEntity(), toStatus);
        }


    }

    // 进入下一个状态流程
    private void joinNextStatus(ControlContext context){
        if (isSyncTransferStatus()) {
            doNextStatus(context);
        } else {
            executor.execute(() -> {
                sleep(getSleepTime());
                doNextStatus(context);
            });
        }
    }

    /**
     * 执行下一状态调度
     * @param context
     */
    private void doNextStatus(ControlContext context){
        ControlContext backContext = next(context);
        // 自动进行下一个状态调度
        if (backContext != null) {
            proxyStatusTransferControl.transfer(backContext);
        }
    }

    /**
     * 线程睡眠时间
     * @param time
     */
    public void sleep(long time){
        if (time > 0) {
            try {
                TimeUnit.MILLISECONDS.sleep(time);
            } catch (InterruptedException ex) {
                log.error(ex.getMessage(), ex);
            }
        }
    }

}

