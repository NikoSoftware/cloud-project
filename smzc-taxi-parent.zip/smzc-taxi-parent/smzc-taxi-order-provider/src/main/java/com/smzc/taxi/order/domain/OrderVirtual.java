package com.smzc.taxi.order.domain;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.io.Serializable;

/**
 * 虚拟订单
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/6/18
 */
@Data
@Document(collection = "order_virtual")
public class OrderVirtual implements Serializable {
    /**
     * 唯一标识id,由mongo自动生成
     */
    @Id
    private String id;

    /**
     * 起点地址
     */
    @Field(value = "plan_from_address")
    private String planFromAddress;

    /**
     * 终点地址
     */
    @Field(value = "plan_to_address")
    private String planToAddress;

    /**
     * 预估里程(米)
     */
    @Field(value = "predict_mileage")
    private Integer predictMileage;

    /**
     * 位置信息 {longitude,latitude}
     */
    @GeoSpatialIndexed
    @Field(value = "location")
    private double[] location;
}
