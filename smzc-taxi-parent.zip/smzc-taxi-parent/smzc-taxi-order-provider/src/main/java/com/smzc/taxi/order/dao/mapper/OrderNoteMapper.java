package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderNote;

import java.util.List;

public interface OrderNoteMapper {
    int insert(OrderNote record);

    /**
     * 根据orderID统计留言数量
     */
    int countByOrderId(Long orderId);

    /**
     * 根据orderID查询留言列表
     */
    List<OrderNote> selectAllByOrderId(Long orderId);

    /**
     * 根据id列表批量更新留言为已读状态
     */
    void batchUpdateReadStatus(List<Long> idList);
}