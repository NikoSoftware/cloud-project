package com.smzc.taxi.order.service.handler.statustransfer;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.common.utils.JsonUtils;
import com.smzc.taxi.order.dao.mapper.OrderPayoffDetailMapper;
import com.smzc.taxi.order.dao.mapper.OrderPayoffMapper;
import com.smzc.taxi.order.dao.mapper.OrderRejectMapper;
import com.smzc.taxi.order.domain.*;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.PassengerTransposeService;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.order.bean.mq.MqMessageBody;
import com.smzc.taxi.service.order.bean.vo.OrderRejectVo;
import com.smzc.taxi.service.order.emun.OrderRejectResp;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.passenger.bean.price.CancelFeeVo;
import com.smzc.taxi.service.passenger.enums.OrderPriceDetailType;
import com.smzc.taxi.service.passenger.service.IPriceConfigureFacade;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;
import java.util.Date;
import java.util.Objects;

/**
 * 驳回订单处理器
 * 已出发流转到驳回
 * 已到达流转到驳回
 * @author luofei
 * @version v1.0
 * @date 2019/5/22
 */
@Slf4j
@OrderServiceHandler(fromStatus = {OrderStatus.DRIVER_STARTING,OrderStatus.DRIVER_ARRIVE}, toStatus = OrderStatus.REJECTED)
public class RejectOrderHandler extends OrderHandler {
    @Resource
    OrderRejectMapper orderRejectMapper;
    @Resource
    private OrderPayoffDetailMapper orderPayoffDetailMapper;
    @Resource
    private OrderPayoffMapper orderPayoffMapper;
    @Reference(version = "1.0.0")
    private IPriceConfigureFacade priceConfigureFacade;
    @Resource
    PassengerTransposeService passengerTransposeService;

    @Override
    public void process(ControlContext context) {
        OrderRejectVo orderRejectVo = (OrderRejectVo) context.get("orderReject");
        OrderReject orderReject = JsonUtils.copyProperites(OrderReject.class, orderRejectVo);
        orderReject.setCreatedTime(new Date());
        orderRejectMapper.insert(orderReject);
        Integer rejectPrice = null;
        if (!orderRejectVo.getRespResource().equals(OrderRejectResp.DRIVER_RESP.getIndex())) {
            rejectPrice = calculatePrice(context);
            saveFeeInfos(context, rejectPrice);
        }else{
            orderRedis.delSubIntripOrder(context.getEntity().getSubscriberId());
        }
        if (context.getFromStatus() == OrderStatus.DRIVER_STARTING || context.getFromStatus() == OrderStatus.DRIVER_ARRIVE) {
            transferDriverWorkStatus(context);
        }
        log.info("OrderId:{},驳回订单，驳回费用:{}", orderReject.getOrderId(), rejectPrice);
    }

    @Override
    public MqMessageBody initMessage(ControlContext context) {
        MqMessageBody orderCancelMq = getPublicMqMsgBody(context);
        OrderRejectVo orderRejectVo = (OrderRejectVo) context.get("orderReject");
        orderCancelMq.setReason(orderRejectVo.getRejectReason());
        return orderCancelMq;
    }

    @Override
    public void finish(final ControlContext context) {
        super.finish(context);
        Integer price = (Integer) context.get("FEE");
        if (price == null || price == 0) {
            passengerTransposeService.releaseSafeCallPhone(context.getEntity().getId());
        }
    }

    private Integer calculatePrice(ControlContext context) {
        OrderInfoContext orderInfo = context.getEntity();
        OrderStatusHistory orderStatusHistory = orderStatusHistoryMapper.selectByOrderIdAndToStatus(orderInfo.getId(), context.getFromStatus());
        long waitTime = (System.currentTimeMillis() - orderStatusHistory.getCreatedTime().getTime()) / 1000;
        CancelFeeVo cancelFeeVo = priceConfigureFacade.getCancelFeeBean(orderInfo.getCityCode(), context.getFromStatus());
        Integer price = waitTime > cancelFeeVo.getCancelTime() ? cancelFeeVo.getCancelFee() : null;
        context.put("FEE", price);
        if (price != null && price > 0) {
            context.setToStatus(OrderStatus.WAIT_PAY_REJECT);
            log.info("驳回订单，订单Id{},驳回费用:{}", context.getEntity().getId(), price);
        }else{
            orderRedis.delSubIntripOrder(context.getEntity().getSubscriberId());
        }
        return price;
    }

    private void saveFeeInfos(ControlContext context, Integer price) {
        if (!Objects.isNull(price) && price > 0) {
            OrderInfoContext orderInfo = context.getEntity();
            OrderPayoff orderPayoff = new OrderPayoff();
            orderPayoff.setOrderId(orderInfo.getId());
            orderPayoff.setPayTime(null);
            orderPayoff.setOrderAmount(price);
            orderPayoff.setPayAmount(price);
            orderPayoff.setPayChannel(null);
            orderPayoff.setPayType(null);
            orderPayoffMapper.insert(orderPayoff);

            OrderPayoffDetail orderPayoffDetail = new OrderPayoffDetail();
            orderPayoffDetail.setCostAmount(price);
            orderPayoffDetail.setCostKey(OrderPriceDetailType.REJECTAMOUNT.getFieldName());
            orderPayoffDetail.setOrderId(orderInfo.getId());
            orderPayoffDetailMapper.insert(orderPayoffDetail);
        }
    }

}
