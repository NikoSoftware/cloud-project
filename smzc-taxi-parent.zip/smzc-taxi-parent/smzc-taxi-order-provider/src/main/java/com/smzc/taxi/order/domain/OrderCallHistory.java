package com.smzc.taxi.order.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 司机乘客呼叫记录信息
 * 对应表 :order_call_history
 *
 * @author :james
 * @date :2019-05-16
 */
@Data
public class OrderCallHistory extends BaseBean {

    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 主叫方类型  1.司机  2.乘客
     */
    private Byte mainCallType;

    /**
     * 主叫方号码
     */
    private String mainPhone;

    /**
     * 被叫方号码
     */
    private String calledPhone;


    private static final long serialVersionUID = 1L;


    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Byte getMainCallType() {
        return mainCallType;
    }

    public void setMainCallType(Byte mainCallType) {
        this.mainCallType = mainCallType;
    }

    public String getMainPhone() {
        return mainPhone;
    }

    public void setMainPhone(String mainPhone) {
        this.mainPhone = mainPhone == null ? null : mainPhone.trim();
    }

    public String getCalledPhone() {
        return calledPhone;
    }

    public void setCalledPhone(String calledPhone) {
        this.calledPhone = calledPhone;
    }
}