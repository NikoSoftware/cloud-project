package com.smzc.taxi.order.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.order.dao.mapper.OrderNoteMapper;
import com.smzc.taxi.order.domain.OrderInfo;
import com.smzc.taxi.order.domain.OrderNote;
import com.smzc.taxi.order.service.OrderNoteService;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.service.driver.bean.push.NotePushVo;
import com.smzc.taxi.service.driver.enums.DriverMessagePushSourceChannel;
import com.smzc.taxi.service.driver.service.IDriverMessagePushFacade;
import com.smzc.taxi.service.order.bean.vo.OrderNoteVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.portal.bean.SystemConfigurationVo;
import com.smzc.taxi.service.portal.enums.SystemConfigurationEnum;
import com.smzc.taxi.service.portal.service.ISystemConfigurationFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 订单留言服务实现类
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/20
 */
@Slf4j
@Service
public class OrderNoteServiceImpl implements OrderNoteService {
    @Resource
    private OrderNoteMapper orderNoteMapper;

    @Resource
    private OrderService orderService;

    @Reference(version = "1.0.0")
    private ISystemConfigurationFacade systemConfigurationFacade;

    @Reference(version = "1.0.0")
    private IDriverMessagePushFacade driverMessagePushFacade;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void addOrderNote(OrderNoteVo vo) {
        //验证传入参数
        AssertUtil.notNull(vo, "对象不能为空");
        String content = vo.getContent();
        AssertUtil.isTrue(content != null && content.length() < 100, "订单留言为空或者超过100个字");
        Long orderId = vo.getOrderId();
        AssertUtil.notNull(orderId, "orderId不能为空");

        //验证订单信息
        OrderInfo orderInfo = orderService.selectByPrimaryKey(orderId);
        AssertUtil.notNull(orderInfo, "没有找到订单源数据，orderId=" + orderId);
        OrderStatus orderStatus = orderInfo.getStatus();
        AssertUtil.isTrue(orderStatus == OrderStatus.DRIVER_STARTING || orderStatus == OrderStatus.DRIVER_ARRIVE || orderStatus == OrderStatus.IN_TRIP, "当前状态已无法留言");
        Long driverId = orderInfo.getDriverId();
        AssertUtil.notNull(driverId, "driverId不能为空");
        //判断是否达到留言上限
        int maxTimes = 3;
        SystemConfigurationVo configVo = systemConfigurationFacade.getSystemConfiguration(SystemConfigurationEnum.ORDER_ADD_NOTES_MAX_TIMES,orderInfo.getCityCode());
        if(configVo != null && configVo.getConfigValue() != null){
            maxTimes = Integer.parseInt(configVo.getConfigValue());
        }
        int orderNoteCount = orderNoteMapper.countByOrderId(orderId);
        AssertUtil.isTrue(orderNoteCount <= maxTimes, "当前留言条数已达到最大值");

        //保存留言信息
        OrderNote orderNote = new OrderNote();
        orderNote.setOrderId(orderId);
        orderNote.setContent(content);
        orderNote.setCreatedTime(new Date());
        orderNoteMapper.insert(orderNote);

        ///通知司机端
        List<Long> driverIdList = new ArrayList<>();
        driverIdList.add(orderId);
        NotePushVo pnVo = new NotePushVo();
        pnVo.setOrderId(String.valueOf(orderId));
        pnVo.setNoteId(String.valueOf(orderNote.getId()));
        pnVo.setCreatedTime(String.valueOf(System.currentTimeMillis()));
        pnVo.setNoteContent(content);
        driverMessagePushFacade.asyncPush(driverIdList, DriverMessagePushSourceChannel.PASSENGER_NOTE, null, null, pnVo, false, true, true);
        log.info("用户[id:{}, 姓名:{}, 电话:{}]添加留言,留言信息{}", orderInfo.getSubscriberId(), orderInfo.getSubscriberName(), orderInfo.getSubscriberPhone(),  orderNote);
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public List<OrderNoteVo> getPageList(Long orderId) {
        AssertUtil.notNull(orderId, "orderId不能为空");
        List<OrderNote> orderNoteList = orderNoteMapper.selectAllByOrderId(orderId);
        if (CollectionUtils.isEmpty(orderNoteList)) {
            return new ArrayList<>();
        }
        //entity转化为vo
        List<OrderNoteVo> voList = new ArrayList<>();
        for (OrderNote orderNote : orderNoteList) {
            OrderNoteVo vo = new OrderNoteVo();
            BeanUtils.copyProperties(orderNote, vo);
            voList.add(vo);
        }
        return voList;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void batchUpdateReadStatus(List<Long> idList) {
        AssertUtil.notEmpty(idList, "已读留言id集合不能为空");
        orderNoteMapper.batchUpdateReadStatus(idList);
    }
}
