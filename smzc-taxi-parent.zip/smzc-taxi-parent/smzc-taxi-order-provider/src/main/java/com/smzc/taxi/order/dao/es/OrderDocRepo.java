package com.smzc.taxi.order.dao.es;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * 订单文档repo
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/5/22
 */
public interface OrderDocRepo extends ElasticsearchRepository<OrderDoc, Long> {
}
