package com.smzc.taxi.order.service.impl;

import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.order.dao.mapper.OrderAddressMapper;
import com.smzc.taxi.order.domain.OrderAddress;
import com.smzc.taxi.order.service.OrderAddressService;
import com.smzc.taxi.order.service.OrderStatusHistoryService;
import com.smzc.taxi.service.order.bean.vo.JourneyShareOrderAppendInfoVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.AssertUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * 订单地址信息服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
@Service
public class OrderAddressServiceImpl implements OrderAddressService {

    @Resource
    private OrderAddressMapper orderAddressMapper;

    @Resource
    private OrderStatusHistoryService orderStatusHistoryService;

    @Override
    public OrderAddress selectByOrderId(Long orderId) {
        return orderAddressMapper.selectByOrderId(orderId);
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public JourneyShareOrderAppendInfoVo getOrderAddressInfoByOrderId(Long orderId) {
        AssertUtil.notNull(orderId, "订单id不能为空");
        OrderAddress orderAddress = orderAddressMapper.selectByOrderId(orderId);
        //组装数据
        JourneyShareOrderAppendInfoVo vo = new JourneyShareOrderAppendInfoVo();
        if (orderAddress != null) {
            this.convertOrderAddress(orderAddress, vo);
        }
        //乘客上车时间
        Date fromTime = orderStatusHistoryService.selectCreateTimeByOrderIdAndToStatus(orderId, OrderStatus.IN_TRIP);
        vo.setFromTime(fromTime);

        //乘客下车时间
        Date endTime = orderStatusHistoryService.selectCreateTimeByOrderIdAndToStatus(orderId, OrderStatus.WAIT_COLLECT_MONEY);
        vo.setToTime(endTime);

        return vo;
    }

    /**
     * OrderAddress的数据转化到JourneyShareOrderAppendInfoVo
     */
    private void convertOrderAddress(OrderAddress orderAddress, JourneyShareOrderAppendInfoVo vo) {
        vo.setActFromAddress(orderAddress.getPracticalFromAddress());
        vo.setActFromStreet(orderAddress.getPracticalFromStreet());
        vo.setActFromLatitude(orderAddress.getPracticalFromLatitude());
        vo.setActFromLongitude(orderAddress.getPracticalFromLongitude());

        vo.setActToAddress(orderAddress.getPracticalToAddress());
        vo.setActToStreet(orderAddress.getPracticalToStreet());
        vo.setActToLatitude(orderAddress.getPracticalToLatitude());
        vo.setActToLongitude(orderAddress.getPracticalToLongitude());

        vo.setToAddress(orderAddress.getPlanToAddress());
        vo.setToStreet(orderAddress.getPlanToStreet());
        vo.setToLatitude(orderAddress.getPlanToLatitude());
        vo.setToLongitude(orderAddress.getPlanToLongitude());

        vo.setFromAddress(orderAddress.getPlanFromAddress());
        vo.setFromStreet(orderAddress.getPlanFromStreet());
        vo.setFromLongitude(orderAddress.getPlanFromLongitude());
        vo.setFromLatitude(orderAddress.getPlanFromLatitude());
    }
}
