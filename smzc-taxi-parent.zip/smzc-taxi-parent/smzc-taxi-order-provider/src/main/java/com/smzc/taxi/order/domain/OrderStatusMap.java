package com.smzc.taxi.order.domain;

import com.google.common.collect.Maps;
import com.smzc.taxi.service.order.emun.OrderStatus;

import java.util.Map;

/**
 * 订单状态映射
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/5/30
 */
public class OrderStatusMap {

    private static Map<OrderStatus, Map<Byte, String>> statusMap = Maps.newHashMap();

    private static Map<Byte, String> commonMap = Maps.newHashMap();

    static {
        commonMap.put(OrderStatus.WAIT_RECEIVE.getIndex(), "用户下单");
        commonMap.put(OrderStatus.AUTO_DISPATCHING.getIndex(), "推送订单");
        commonMap.put(OrderStatus.DRIVER_STARTING.getIndex(), "司机已出发");
        commonMap.put(OrderStatus.DRIVER_ARRIVE.getIndex(), "司机已到达");
        commonMap.put(OrderStatus.IN_TRIP.getIndex(), "行程中");
        commonMap.put(OrderStatus.WAIT_COLLECT_MONEY.getIndex(), "行程结束");
        commonMap.put(OrderStatus.WAIT_PAY_CANCEL.getIndex(), "取消待支付");
        commonMap.put(OrderStatus.WAIT_PAY_REJECT.getIndex(), "驳回待支付");
        commonMap.put(OrderStatus.CANCEL.getIndex(), "已取消");
        commonMap.put(OrderStatus.REJECTED.getIndex(), "已驳回");
        commonMap.put(OrderStatus.SYS_CANCEL.getIndex(), "自动取消");

//        common
        statusMap.put(OrderStatus.WAIT_RECEIVE, commonMap);
        statusMap.put(OrderStatus.AUTO_DISPATCHING, commonMap);
        statusMap.put(OrderStatus.WAIT_DRIVER_CONFIRM, commonMap);
        statusMap.put(OrderStatus.DRIVER_STARTING, commonMap);
        statusMap.put(OrderStatus.DRIVER_ARRIVE, commonMap);
        statusMap.put(OrderStatus.IN_TRIP, commonMap);
        statusMap.put(OrderStatus.WAIT_COLLECT_MONEY, commonMap);
        statusMap.put(OrderStatus.WAIT_PAY_CANCEL, commonMap);
        statusMap.put(OrderStatus.WAIT_PAY_REJECT, commonMap);
        statusMap.put(OrderStatus.WAIT_PAY, commonMap);
        statusMap.put(OrderStatus.CANCEL, commonMap);
        statusMap.put(OrderStatus.REJECTED, commonMap);
        statusMap.put(OrderStatus.SYS_CANCEL, commonMap);

//        other
        statusMap.put(OrderStatus.WAIT_EVALUATE, waitEvaluate());
        statusMap.put(OrderStatus.FINISH, finish());

    }

    private static Map<Byte, String> finish() {
        Map<Byte, String> map = Maps.newHashMap();
        setMap(map);
        map.put(OrderStatus.WAIT_EVALUATE.getIndex(), "乘客支付");
        map.put(OrderStatus.FINISH.getIndex(), "乘客评价");
        return map;
    }

    private static Map<Byte, String> waitEvaluate() {
        Map<Byte, String> map = Maps.newHashMap();
        setMap(map);
        map.put(OrderStatus.WAIT_EVALUATE.getIndex(), "乘客支付");
        return map;
    }

    private static void setMap(Map<Byte, String> map) {
        map.putAll(commonMap);
    }

    public static Map<Byte, String> get(OrderStatus status) {
        return statusMap.get(status);
    }

}
