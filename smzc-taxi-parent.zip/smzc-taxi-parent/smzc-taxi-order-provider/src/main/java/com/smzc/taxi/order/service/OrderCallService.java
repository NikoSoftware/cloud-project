package com.smzc.taxi.order.service;

import com.github.pagehelper.PageInfo;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryPageVo;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryVo;


/**
 * @Desc : .....
 * @Author : lufy
 * @Date : 2019/5/21 17:10
 */
public interface OrderCallService {
    void addOrderCallHistory(OrderCallHistoryVo orderCallHistoryVo);

    PageInfo<OrderCallHistoryVo> getPageList(OrderCallHistoryPageVo orderCallHistoryPageVo);
}
