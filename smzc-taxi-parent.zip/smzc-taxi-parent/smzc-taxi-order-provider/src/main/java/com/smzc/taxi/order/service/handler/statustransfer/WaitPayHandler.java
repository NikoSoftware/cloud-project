package com.smzc.taxi.order.service.handler.statustransfer;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.smzc.taxi.common.utils.JsonUtils;
import com.smzc.taxi.order.dao.mapper.OrderActivityMapper;
import com.smzc.taxi.order.dao.mapper.OrderInfoExtMapper;
import com.smzc.taxi.order.dao.mapper.OrderPayoffDetailMapper;
import com.smzc.taxi.order.dao.mapper.OrderPayoffMapper;
import com.smzc.taxi.order.domain.*;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.OrderActivityService;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.order.bean.vo.OrderPayoffDetailVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.OrderException;
import com.smzc.taxi.service.passenger.bean.price.*;
import com.smzc.taxi.service.passenger.enums.CountPricelType;
import com.smzc.taxi.service.passenger.enums.OrderPriceDetailType;
import com.smzc.taxi.service.passenger.service.IPriceConfigureFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


/**
 * 待收钱流转到待支付
 */
@Slf4j
@OrderServiceHandler(fromStatus = OrderStatus.WAIT_COLLECT_MONEY, toStatus = OrderStatus.WAIT_PAY)
public class WaitPayHandler extends OrderHandler{

    @Resource
    private OrderPayoffDetailMapper orderPayoffDetailMapper;

    // 计价接口
    @Reference(timeout = 10000, version = "1.0.0")
    private IPriceConfigureFacade priceConfigureFacade;

    @Resource
    OrderPayoffMapper orderPayoffMapper;
    @Resource
    OrderActivityService orderActivityService;
    @Resource
    OrderInfoExtMapper orderInfoExtMapper;


    @Override
    public void process(ControlContext context) {
        List<OrderPayoffDetailVo> list = (List<OrderPayoffDetailVo>)context.get("payoffDetailList");

        final OrderInfoContext orderInfo = context.getEntity();
        OrderPriceCalculateVo orderPriceCalculateVo = new OrderPriceCalculateVo();
        orderPriceCalculateVo.setSubscriberId(orderInfo.getSubscriberId());
        orderPriceCalculateVo.setAreaCode(orderInfo.getCityCode());

        orderPriceCalculateVo.setBasicAmount(list.stream()
                .filter(f-> OrderPriceDetailType.BASICAMOUNT.getFieldName().equals(f.getCostKey()))
                .mapToInt(OrderPayoffDetailVo::getCostAmount).sum());
        orderPriceCalculateVo.setBridgeAmount(list.stream()
                .filter(f-> OrderPriceDetailType.BRIDGEAMOUNT.getFieldName().equals(f.getCostKey()))
                .mapToInt(OrderPayoffDetailVo::getCostAmount).sum());
        orderPriceCalculateVo.setCleaningAmount(list.stream()
                .filter(f-> OrderPriceDetailType.CLEANINGAMOUNT.getFieldName().equals(f.getCostKey()))
                .mapToInt(OrderPayoffDetailVo::getCostAmount).sum());
        orderPriceCalculateVo.setParkAmount(list.stream()
                .filter(f-> OrderPriceDetailType.PARKAMOUNT.getFieldName().equals(f.getCostKey()))
                .mapToInt(OrderPayoffDetailVo::getCostAmount).sum());
        orderPriceCalculateVo.setCountPricelType(CountPricelType.PASSENGER);
        OrderCacheBean orderCache = orderService.getOrderCache(orderInfo.getId());
        orderPriceCalculateVo.setFrom(new UserPosition(orderCache.getPlanFromLongitude(),orderCache.getPlanFromLatitude()));
        orderPriceCalculateVo.setTo(new UserPosition(orderCache.getPlanToLongitude(),orderCache.getPlanToLatitude()));
        orderPriceCalculateVo.setOrderId(orderInfo.getId());

        // 新加需求 写入手机编号
        OrderInfoExt orderInfoExt = orderInfoExtMapper.selectByOrderId(context.getOrderId());
        orderPriceCalculateVo.setDeviceType(orderInfoExt.getDeviceFrom());
        orderPriceCalculateVo.setDeviceNumber(orderInfoExt.getDeviceNumber());



        final OrderPriceCalculateResultVo orderPriceCalculate = priceConfigureFacade.getOrderPriceCalculate(orderPriceCalculateVo);
        List<CalculateResultItem> priceDetailList = orderPriceCalculate.getPriceDetailList();
        List<OrderPayoffDetail> paoffDetailList = priceDetailList.parallelStream().map(m -> {
            final Integer code = m.getCode();
            if (OrderPriceDetailType.BASICAMOUNT.getCode() == code.intValue()) {
                return new OrderPayoffDetail(orderInfo.getId(), OrderPriceDetailType.BASICAMOUNT.getFieldName(), m.getAmount());
            } else if (OrderPriceDetailType.BRIDGEAMOUNT.getCode() == code.intValue()) {
                return new OrderPayoffDetail(orderInfo.getId(), OrderPriceDetailType.BRIDGEAMOUNT.getFieldName(), m.getAmount());
            } else if (OrderPriceDetailType.CLEANINGAMOUNT.getCode() == code.intValue()) {
                return new OrderPayoffDetail(orderInfo.getId(), OrderPriceDetailType.CLEANINGAMOUNT.getFieldName(), m.getAmount());
            } else if (OrderPriceDetailType.PARKAMOUNT.getCode() == code.intValue()) {
                return new OrderPayoffDetail(orderInfo.getId(), OrderPriceDetailType.PARKAMOUNT.getFieldName(), m.getAmount());
            } else if (OrderPriceDetailType.DIRECTIONAMOUNT.getCode() == code.intValue()){
                return new OrderPayoffDetail(orderInfo.getId(), OrderPriceDetailType.DIRECTIONAMOUNT.getFieldName(), -m.getAmount());
            } else if (OrderPriceDetailType.VOUCHERAMOUNT.getCode() == code.intValue()){
                return new OrderPayoffDetail(orderInfo.getId(), OrderPriceDetailType.VOUCHERAMOUNT.getFieldName(), -m.getAmount());
            } else {
                return null;
            }
        }).filter(Objects::nonNull).collect(Collectors.toList());

        DiscountVoucherResultVo resultVo = orderPriceCalculate.getDiscountVoucherResultVo();
        if(resultVo != null){
            final List<ActivityResultVo> activityList = resultVo.getActivityList();
            // 批量添加订单活动
            orderActivityService.batchAddOrderActivity(activityList,orderInfo.getId(),orderPriceCalculateVo.getCountPricelType());
        }


        // 保存订单结算信息
        OrderPayoff orderPayoff = new OrderPayoff();
        orderPayoff.setOrderId(orderInfo.getId());
        orderPayoff.setOrderAmount(orderPriceCalculate.getTotalAmount());
        orderPayoff.setDiscountAmount(orderPriceCalculate.getDiscountAllAmount());
        orderPayoff.setPayAmount(orderPriceCalculate.getPayAmount());
        orderPayoffMapper.insert(orderPayoff);
        // 保存订单明细
        int baddFlag = orderPayoffDetailMapper.batchInsert(JsonUtils.copyList(OrderPayoffDetail.class,paoffDetailList));
        if(baddFlag <= 0){
            throw new OrderException("OrderId:" + context.getOrderId() + ",批量添加订单费用明细失败");
        }
    }

}
