package com.smzc.taxi.order.service.handler.statustransfer;

import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.order.emun.OrderStatus;

/**
 *
 * 乘客支付取消费后 订单从待支付变为已经取消
 *
 * @author liuxinjie
 * @version 1.0
 * @date 2019/5/24 11:07
 */
@OrderServiceHandler(fromStatus = {OrderStatus.WAIT_PAY_CANCEL}, toStatus = OrderStatus.CANCEL)
public class PayedToCancelHandler extends PayedToBaseHandler {


}
