package com.smzc.taxi.order.service.handler.discount;

import com.smzc.market.service.driver.enums.DriverOrderRewardTypeEnum;
import com.smzc.taxi.order.domain.OrderInfoContext;

/**
 * 优惠策略接口
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/5 15:13
 */
public interface DiscountHandler {
    void execute(OrderInfoContext context);

    /**
     * 奖励类型
     * @return
     */
    DriverOrderRewardTypeEnum awardType();
}
