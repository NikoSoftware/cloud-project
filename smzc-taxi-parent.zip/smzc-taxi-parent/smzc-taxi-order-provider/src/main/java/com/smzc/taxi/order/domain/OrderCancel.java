package com.smzc.taxi.order.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单取消记录
 * 对应表 :order_cancel
 *
 * @author :james
 * @date :2019-05-16
 */
public class OrderCancel extends BaseBean {

    /**
     * 订单id
     */
    private Long orderId;

    /**
     * 取消订单人员ID
     */
    private Long cancelBy;

    /**
     * 取消订单人名
     */
    private String cancelByName;

    /**
     * 取消原因
     */
    private String cancelReason;

    /**
     * 来源类型  1：乘客  2：司机
     */
    private Byte sourceType;


    private static final long serialVersionUID = 1L;


    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getCancelBy() {
        return cancelBy;
    }

    public void setCancelBy(Long cancelBy) {
        this.cancelBy = cancelBy;
    }

    public String getCancelByName() {
        return cancelByName;
    }

    public void setCancelByName(String cancelByName) {
        this.cancelByName = cancelByName == null ? null : cancelByName.trim();
    }

    public String getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason == null ? null : cancelReason.trim();
    }

    public Byte getSourceType() {
        return sourceType;
    }

    public void setSourceType(Byte sourceType) {
        this.sourceType = sourceType;
    }

}