package com.smzc.taxi.order.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单留言记录
 * 对应表 :order_note
 *
 * @author zhousong
 * @date :2019-05-16
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OrderNote extends BaseBean {
    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 留言内容
     */
    private String content;

    /**
     * 是否已读
     */
    private Boolean isRead = false;
}