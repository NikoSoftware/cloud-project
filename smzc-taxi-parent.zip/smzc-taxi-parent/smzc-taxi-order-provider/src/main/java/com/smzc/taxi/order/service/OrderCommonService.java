package com.smzc.taxi.order.service;

/**
 * 订单公共服务：
 * 1.雪花算法生成uid
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/6/17
 */
public interface OrderCommonService {

    /**
     * 获取uid
     *
     * @return 19位uid
     */
    Long getUID();
}
