package com.smzc.taxi.order.service.gps;

import com.smzc.taxi.order.domain.QueryGPSBean;
import com.smzc.taxi.service.order.bean.vo.GPSVo;

import java.util.List;

/**
 * GPS查询接口
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/6/24
 */
public interface GPSQuery {

    List<GPSVo> execute(QueryGPSBean queryGPSBean);

}
