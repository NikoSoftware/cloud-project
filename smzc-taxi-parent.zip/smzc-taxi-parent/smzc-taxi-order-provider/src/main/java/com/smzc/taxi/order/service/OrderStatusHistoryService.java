package com.smzc.taxi.order.service;

import com.smzc.taxi.order.domain.OrderStatusHistory;
import com.smzc.taxi.service.order.bean.vo.OrderStartEndTimeVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import org.apache.ibatis.annotations.Param;

import java.util.Date;

/**
 * 订单状态流转记录服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
public interface OrderStatusHistoryService {
    OrderStatusHistory selectByOrderIdAndToStatus(@Param("orderId") Long orderId, @Param("orderStatus") OrderStatus orderStatus);

    /**
     * 通过订单id获得司机出发时间
     */
    Date getDriverStartTime(Long orderId);

    /**
     * 根据订单id、当前状态、下一状态获得记录创建时间
     */
    Date selectCreateTimeByOrderIdAndToStatus(Long orderId, OrderStatus orderStatus);

    /**
     * 获取创建时间和行程结束时间
     * @param id
     * @return
     */
    OrderStartEndTimeVo getOrderStartEndTime(Long id);
}
