package com.smzc.taxi.order.service.validator;

import com.google.common.collect.Lists;
import com.smzc.taxi.service.order.bean.vo.OrderInfoVo;
import com.smzc.taxi.service.order.bean.vo.OrderPassengerVo;

import java.util.List;

/**
 * 订单校验链
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/7/29
 */
public class OrderValidatorChain implements OrderValidator<OrderPassengerVo> {

    /**
     * 校验器组合
     */
    private List<OrderValidator<OrderPassengerVo>> validators = Lists.newArrayList();

    /**
     * 当前执行到第几个校验器
     */
    private int index;

    public OrderValidator addValidator(OrderValidator<OrderPassengerVo> validator) {
        this.validators.add(validator);
        return this;
    }

    @Override
    public ValidResult<OrderPassengerVo> valid(OrderInfoVo orderInfoVo, ValidResult<OrderPassengerVo> r) {
        if (index == validators.size()) {
            return r;
        }

        if (r.isFlag()) {
            ValidResult<OrderPassengerVo> valid = validators.get(index).valid(orderInfoVo, r);
            index++;
            return valid;
        }

        return r;
    }
}
