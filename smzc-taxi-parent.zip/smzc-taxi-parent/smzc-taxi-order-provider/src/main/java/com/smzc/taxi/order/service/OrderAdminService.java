package com.smzc.taxi.order.service;

import com.github.pagehelper.PageInfo;
import com.smzc.taxi.service.order.bean.dto.OrderDetailDto;
import com.smzc.taxi.service.order.bean.dto.OrderInfoDto;
import com.smzc.taxi.service.order.bean.vo.OrderQueryVo;
import com.smzc.taxi.service.portal.bean.PriceModifyInnerVo;
import com.smzc.taxi.service.portal.bean.PriceModifyQryVo;
import com.smzc.taxi.service.portal.bean.PriceModifyRespVo;


/**
 * 订单后台相关服务
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/5/23
 */
public interface OrderAdminService {

    /**
     * 分页查询订单列表
     *
     * @param orderQueryVo 查询条件
     * @return 数据集合
     */
    PageInfo<OrderInfoDto> queryPageOrderList(OrderQueryVo orderQueryVo);

    /**
     * 获取待导出的订单列表
     *
     * @param orderQueryVo 查询条件
     * @return 数据集合
     */
    void queryExportOrderList(OrderQueryVo orderQueryVo);

    /**
     * 查询订单详情
     *
     * @param orderId 订单id
     * @return OrderDetailDto
     */
    OrderDetailDto queryOrderDetail(Long orderId);

    /**
     * <p> 查询改价列表（即待支付订单列表）</p>
     *
     * @param query
     * @return
     */
    PageInfo<PriceModifyRespVo> getPriceModifyPage(PriceModifyQryVo query);

    /**
     * <p> 查询订单改价相关信息 </p>
     *
     * @param orderId
     * @return
     */
    PriceModifyInnerVo getPriceModifyInfo(Long orderId);
}
