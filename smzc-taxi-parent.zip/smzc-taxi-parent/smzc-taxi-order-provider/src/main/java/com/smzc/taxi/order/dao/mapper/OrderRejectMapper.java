package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderReject;

public interface OrderRejectMapper {
    int insert(OrderReject record);

    /**
     * 查询驳回信息
     *
     * @param orderId 订单id
     * @return OrderReject
     */
    OrderReject selectRejectByOrderId(Long orderId);
}