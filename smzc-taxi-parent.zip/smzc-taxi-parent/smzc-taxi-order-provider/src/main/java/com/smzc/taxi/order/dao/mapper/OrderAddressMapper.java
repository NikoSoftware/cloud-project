package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderAddress;
import org.apache.ibatis.annotations.Param;

public interface OrderAddressMapper {
    int insert(OrderAddress record);

    int updateByPrimaryKeySelective(OrderAddress record);

    OrderAddress selectByOrderId(@Param("orderId") Long orderId);
}