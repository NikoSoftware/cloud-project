package com.smzc.taxi.order.service;

import com.smzc.taxi.service.order.bean.vo.OrderFeedBackVo;

import java.util.List;

/**
 * 订单反馈服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
public interface OrderFeedbackService {
    /**
     * 添加订单反馈
     */
    void addOrderFeedback(OrderFeedBackVo vo);

    /**
     * 根据订单id查询反馈信息
     */
    List<OrderFeedBackVo> selectByOrderId(Long orderId);
}
