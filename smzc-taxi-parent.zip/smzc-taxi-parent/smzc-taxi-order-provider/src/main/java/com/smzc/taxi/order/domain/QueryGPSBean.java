package com.smzc.taxi.order.domain;

import lombok.Data;

/**
 * GPS查询参数
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/6/24
 */
@Data
public class QueryGPSBean {

    /**
     * 司机姓名
     */
    private String driverName;

    /**
     * 车牌号
     */
    private String vehicleNo;

    /**
     * 开始时间（毫秒）
     */
    private long startTime;

    /**
     * 结束时间
     */
    private long endTime;

    /**
     * 查询最大条数
     */
    private int maxSize = 3000;

}
