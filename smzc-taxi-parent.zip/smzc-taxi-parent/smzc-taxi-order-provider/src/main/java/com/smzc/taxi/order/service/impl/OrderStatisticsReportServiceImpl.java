package com.smzc.taxi.order.service.impl;

import com.github.pagehelper.PageInfo;
import com.smzc.taxi.order.service.OrderPayoffService;
import com.smzc.taxi.order.service.OrderStatisticsReportService;
import com.smzc.taxi.service.order.bean.vo.IncomeQryVo;
import com.smzc.taxi.service.order.bean.vo.IncomeVo;
import com.smzc.taxi.service.order.exception.AssertUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


/**
 * 订单报表统计服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/25
 */
@Slf4j
@Service
public class OrderStatisticsReportServiceImpl implements OrderStatisticsReportService {

    @Resource
    private OrderPayoffService orderPayoffService;

    @Override
    public PageInfo<IncomeVo> queryIncomeList(IncomeQryVo qryVo) {
        AssertUtil.notNull(qryVo, "查询参数对象不能为空");
        AssertUtil.notNull(qryVo.getPayTimeStart(), "付款查询开始时间不能为空");
        AssertUtil.notNull(qryVo.getPayTimeEnd(), "付款查询结束时间不能为空");
        return orderPayoffService.queryIncomeList(qryVo);
    }

    @Override
    public IncomeVo queryIncomeByOrderId(Long orderId) {
        AssertUtil.notNull(orderId, "订单id不能为空");
        return orderPayoffService.queryIncomeByOrderId(orderId);
    }
}
