package com.smzc.taxi.order.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.smzc.taxi.common.utils.JsonUtils;
import com.smzc.taxi.order.domain.OrderCacheBean;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.DriverOrderService;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.service.context.ProxyStatusTransferControl;
import com.smzc.taxi.order.util.DistributedLockManager;
import com.smzc.taxi.order.util.OrderRedis;
import com.smzc.taxi.order.util.SuperBeanUtils;
import com.smzc.taxi.service.dispatch.bean.DispatchResponse;
import com.smzc.taxi.service.dispatch.bean.DispatchTaxiOrderBean;
import com.smzc.taxi.service.dispatch.bean.RecommendedOrder;
import com.smzc.taxi.service.dispatch.facade.IDispatchFacade;
import com.smzc.taxi.service.order.bean.vo.OrderDriverRobVo;
import com.smzc.taxi.service.order.bean.vo.OrderDriverWaitReqVo;
import com.smzc.taxi.service.order.bean.vo.OrderDriverWaitVo;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.smzc.taxi.service.order.emun.OrderAddType;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.portal.bean.SystemConfigurationVo;
import com.smzc.taxi.service.portal.enums.SystemConfigurationEnum;
import com.smzc.taxi.service.portal.service.ISystemConfigurationFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.smzc.taxi.common.consts.RedisConst.TAXI_WAIT_LOCK_ORDER;

/**
 * 订单服务实现
 *
 * @author liuxinjie
 * @version 1.0
 * @date 2019/5/15
 */
@Slf4j
@Service
public class DriverOrderServiceImpl implements DriverOrderService {

    @Resource
    OrderService orderService;

    @Resource
    DistributedLockManager distributedLockManager;

    @Reference(version = "1.0.0")
    IDispatchFacade dispatchFacade;
    @Reference(version = "1.0.0")
    private ISystemConfigurationFacade systemConfigurationFacade;

    @Resource
    ProxyStatusTransferControl proxyStatusTransferControl;

    @Resource
    OrderRedis orderRedis;

    @Override
    public CommonCode robOrder(OrderDriverRobVo orderDriverRobVo) {
        final Long orderId = orderDriverRobVo.getOrderId();
        // 已经被抢了，又有人点了抢单，所以这里先校验待抢的订单是否还存在，不存在直接返回false.
        // 排除邀新订单，因为它没有缓存
        OrderCacheBean cacheBean = orderService.getOrderCache(orderId);
        Byte addType = cacheBean.getAddType();
        if(OrderAddType.NEW_ADD.getIndex() != addType.byteValue()){
            if (orderRedis.getWaitRobOrder(orderId) == null) {
                return CommonCode.ROB_FATIL;
            }
        }

        final String lockKey = TAXI_WAIT_LOCK_ORDER + orderId;
        final String requestId = distributedLockManager.getClientId();

        // 获取锁
        boolean effect = distributedLockManager.getLock(lockKey, requestId, 15);
        if (effect) {
            try {
                // 获取到锁
                // 执行业务逻辑
                // 2. 修改订单写入司机信息
                // 3. 记录状态流转 从待处理 到 已出发
                // 4. 写入订单状态坐标。坐标已存入缓存
                // 5. 通知调度中心，此订单状态
                // 获取订单信息
                OrderCacheBean orderCache = orderService.getOrderCache(orderId);

                AssertUtil.notNull(orderCache, "未找到此订单");

                OrderInfoContext orderInfo = JsonUtils.copyProperites(OrderInfoContext.class, orderCache);
                orderInfo.setStatus(orderService.getOrderStatusById(orderId));
                orderInfo.setLatitude(orderDriverRobVo.getLatitude());
                orderInfo.setLongitude(orderDriverRobVo.getLongitude());
                orderInfo.setDriverId(orderDriverRobVo.getDriverId());

                if (!Arrays.asList(OrderStatus.WAIT_DRIVER_CONFIRM, OrderStatus.AUTO_DISPATCHING).contains(orderInfo.getStatus())) {
                    log.error("OrderId{},当前状态是{}，不能抢单", orderInfo.getId(), orderInfo.getStatus().getName());
                    return CommonCode.ROB_FATIL;
                }

                orderInfo.setPlatformType(orderDriverRobVo.getPlatformType());
                // 初始化状态控制器
                final ControlContext context =
                        new ControlContext(orderInfo.getStatus(), OrderStatus.DRIVER_STARTING, orderInfo);

                proxyStatusTransferControl.transfer(context);

                // 抢单成功，删除这个订单的待抢缓存
                orderRedis.removeWaitRob(orderDriverRobVo.getOrderId());

                return CommonCode.SUCCESS;
            } catch (Exception e) {
                log.error("抢单异常: " + e.getMessage(), e);
                throw e;
            } finally {
                // 释放锁
                distributedLockManager.unlock(lockKey, requestId);
            }
        } else {
            // 抢单失败
            return CommonCode.ROB_FATIL;
        }
    }


    @Override
    public List<OrderDriverWaitVo> getWaitReceive(OrderDriverWaitReqVo orderDriverWaitReqVo) {

        // 司机端定时获取待抢订单
        DispatchResponse<List<RecommendedOrder>> listDispatchResponse = new DispatchResponse<>();
        try {
            listDispatchResponse = dispatchFacade.dispatchTaxiOrder(packDispatchTaxiOrderBean(orderDriverWaitReqVo));
        } catch (Exception e) {
            log.error("司机刷单，从调度获取数据异常，参数：{}", JSON.toJSONString(orderDriverWaitReqVo), e);
            return Collections.emptyList();
        }

        List<RecommendedOrder> list = listDispatchResponse.getData();
        if (!CollectionUtils.isEmpty(list)) {
            List<String> idList = list.stream().map(RecommendedOrder::getOrderNo).collect(Collectors.toList());
            int dispatchResCount = idList.size();


            // 从订单缓存中获取待抢的列表，排除为NULL的数据
            List<OrderInfoContext> orderList = orderRedis.getWaitRobOrderList(idList)
                    .stream()
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());

            if(dispatchResCount != orderList.size()){
                log.error("调度缓存与订单缓存不一致，请排查:dptct:{},orderct:{},dt:{}",
                        dispatchResCount,
                        orderList.size(),
                        Arrays.toString(idList.toArray()));
            }
            if (!CollectionUtils.isEmpty(orderList)) {
                return orderList.stream().map(orderInfoContext -> {
                    OrderDriverWaitVo waitVo = new OrderDriverWaitVo();
                    SuperBeanUtils.copy(orderInfoContext, waitVo);
                    waitVo.setOrderId(orderInfoContext.getId());
                    waitVo.setFromLatitude(orderInfoContext.getOrderAddress().getPlanFromLatitude());
                    waitVo.setFromLongitude(orderInfoContext.getOrderAddress().getPlanFromLongitude());
                    waitVo.setFromAddress(orderInfoContext.getOrderAddress().getPlanFromAddress());
                    waitVo.setToAddress(orderInfoContext.getOrderAddress().getPlanToAddress());
                    waitVo.setToLatitude(orderInfoContext.getOrderAddress().getPlanToLatitude());
                    waitVo.setToLongitude(orderInfoContext.getOrderAddress().getPlanToLongitude());
                    waitVo.setTotalDistance(orderInfoContext.getPredictMileage());
                    waitVo.setOrderStatus(orderInfoContext.getStatus());
                    waitVo.setScheduleTime(orderInfoContext.getCreatedTime());
                    return waitVo;
                }).collect(Collectors.toList());
            } else {
                return Collections.emptyList();
            }
        } else {
            return Collections.emptyList();
        }
    }

    // 包装查询参数
    private DispatchTaxiOrderBean packDispatchTaxiOrderBean(OrderDriverWaitReqVo orderDriverWaitReqVo) {
        DispatchTaxiOrderBean dispatchTaxiOrderBean = new DispatchTaxiOrderBean();
        dispatchTaxiOrderBean.setDriverId(orderDriverWaitReqVo.getDriverId());
        dispatchTaxiOrderBean.setAreaCode(orderDriverWaitReqVo.getCityCode());
        dispatchTaxiOrderBean.setLat(orderDriverWaitReqVo.getLatitude());
        dispatchTaxiOrderBean.setLng(orderDriverWaitReqVo.getLongitude());
        return dispatchTaxiOrderBean;
    }
}