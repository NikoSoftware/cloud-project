package com.smzc.taxi.order.domain;

import com.smzc.taxi.service.order.emun.OrderStatus;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单状态流转记录 order_status_history
 *
 * @author liuxinjie
 * @date 2019-05-16
 */
@Data
public class OrderStatusHistory extends BaseBean {

    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 当前状态
     */
    private OrderStatus fromStatus;

    /**
     * 下一个状态
     */
    private OrderStatus toStatus;


    private static final long serialVersionUID = 1L;

    public OrderStatusHistory() {
    }

    public OrderStatusHistory(Long orderId, OrderStatus fromStatus, OrderStatus toStatus) {
        this.orderId = orderId;
        this.fromStatus = fromStatus;
        this.toStatus = toStatus;
    }

}