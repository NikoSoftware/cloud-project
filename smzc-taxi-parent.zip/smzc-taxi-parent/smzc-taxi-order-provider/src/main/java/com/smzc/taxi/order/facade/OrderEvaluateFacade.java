package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.smzc.taxi.order.service.OrderEvaluateService;
import com.smzc.taxi.service.order.bean.vo.OrderEvaluateDriverDayVo;
import com.smzc.taxi.service.order.bean.vo.OrderEvaluateTagVo;
import com.smzc.taxi.service.order.bean.vo.OrderEvaluateVo;
import com.smzc.taxi.service.order.facade.IOrderEvaluateFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * 订单评价服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/21
 */
@Component
@Service
@Slf4j
public class OrderEvaluateFacade implements IOrderEvaluateFacade {

    @Resource
    private OrderEvaluateService orderEvaluateService;

    @Override
    public void addOrderEvaluate(OrderEvaluateVo orderEvaluateVo) {
        try {
            orderEvaluateService.addOrderEvaluate(orderEvaluateVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderEvaluateVo selectByOrderId(Long orderId) {
        try {
            return orderEvaluateService.selectByOrderId(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public List<OrderEvaluateDriverDayVo> selectDriverEvaluateDay(Date beginDate, Date endDate) {
        try {
            return orderEvaluateService.selectDriverEvaluateDay(beginDate,endDate);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }


    @Override
    public List<OrderEvaluateDriverDayVo> selectDriverEvaluateDayByMobileList(Date beginDate, Date endDate, List<String> mobileList) {
        try {
            return orderEvaluateService.selectDriverEvaluateDayByMobileList(beginDate,endDate,mobileList);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public List<OrderEvaluateTagVo> selectAllOrderEvaluateTag() {
        try {
            return orderEvaluateService.selectAllOrderEvaluateTag();
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }
}
