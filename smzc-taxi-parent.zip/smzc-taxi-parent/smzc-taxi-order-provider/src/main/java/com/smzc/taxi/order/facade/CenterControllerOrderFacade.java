package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.smzc.taxi.order.service.CenterControllerOrderService;
import com.smzc.taxi.order.service.DriverOrderService;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.service.impl.OrderWorkflowServiceImpl;
import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.order.exception.OrderException;
import com.smzc.taxi.service.order.facade.ICenterControllerOrderFacade;
import com.smzc.taxi.service.order.facade.IDriverOrderFacade;
import com.smzc.taxi.service.portal.bean.DriverOrderReqVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 *
 * 中控订单DB服务
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/6/18 16:39
 */
@Component
@Service
@Slf4j
public class CenterControllerOrderFacade implements ICenterControllerOrderFacade {

    @Resource
    private CenterControllerOrderService centerControllerOrderService;


    @Override
    public CommonCode buriedClock(DriverOrderReqVo driverOrderReqVo) {
        try {
            return centerControllerOrderService.buriedClock(driverOrderReqVo);
        } catch (OrderException orderEp) {
            log.error(orderEp.getMessage());
            return CommonCode.FTAIL;
        } catch (Exception e){
            log.error("系统错误：",e);
            return CommonCode.FTAIL;
        }

    }

    @Override
    public CommonCode riseClock(DriverOrderReqVo driverOrderReqVo) {
        try {
            return centerControllerOrderService.riseClock(driverOrderReqVo);
        } catch (OrderException orderEp) {
            log.error(orderEp.getMessage());
            return CommonCode.FTAIL;
        } catch (Exception e){
            log.error("系统错误：",e);
            return CommonCode.FTAIL;
        }
    }
}
