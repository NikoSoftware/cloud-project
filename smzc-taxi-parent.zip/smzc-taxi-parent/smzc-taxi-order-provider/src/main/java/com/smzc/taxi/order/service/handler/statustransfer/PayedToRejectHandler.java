package com.smzc.taxi.order.service.handler.statustransfer;

import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.order.emun.OrderStatus;

/**
 * 订单产生取消费或驳回费，支付完成后处理器
 * 产生驳回费后， 支付完后，订单状态流转已驳回
 * @author : lufy
 * @version v1.0
 * @date : 2019/5/25
 */
@OrderServiceHandler(fromStatus = {OrderStatus.WAIT_PAY_REJECT}, toStatus = OrderStatus.REJECTED)
public class PayedToRejectHandler extends PayedToBaseHandler {



}
