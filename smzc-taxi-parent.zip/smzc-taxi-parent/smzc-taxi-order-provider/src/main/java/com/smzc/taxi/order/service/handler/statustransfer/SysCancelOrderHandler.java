package com.smzc.taxi.order.service.handler.statustransfer;

import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.order.emun.OrderStatus;

/**
 * 下单后5分钟 没有匹配到司机 或则没有司机抢单，系统自动取消
 * 待处理时取消
 * 自动调度时取消
 * 抢单中取消
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/6/27 15:28
 */
@OrderServiceHandler(fromStatus = {OrderStatus.WAIT_RECEIVE, OrderStatus.AUTO_DISPATCHING, OrderStatus.WAIT_DRIVER_CONFIRM}, toStatus = OrderStatus.SYS_CANCEL)
public class SysCancelOrderHandler extends CancelOrderHandler {
    @Override
    public void subProcess(ControlContext context) {
    }

}
