package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderActivity;
import com.smzc.taxi.service.passenger.bean.price.ActivityResultVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderActivityMapper {
    int deleteByPrimaryKey(Long id);

    int insert(OrderActivity record);

    OrderActivity selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(OrderActivity record);

    int updateByPrimaryKey(OrderActivity record);

    int batchAdd(@Param("list") List<OrderActivity> list);

    /**
     * 根据订单ID获取订单活动
     * @param orderId
     * @return
     */
    List<OrderActivity> selectByOrderId(Long orderId);

    /**
     * 根据订单ID删除
     * @param orderId
     * @return
     */
    int delOrderActivity(Long orderId);
}