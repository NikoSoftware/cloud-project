package com.smzc.taxi.order.dao.typehandler;

import com.smzc.taxi.service.finance.enums.TfbPayChannel;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedTypes;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 支付渠道
 *
 * @author liuxinjie
 * @version v1.0
 * @date 2019/5/22
 */
@MappedTypes(TfbPayChannel.class)
public class PayChannelHandler extends BaseTypeHandler<TfbPayChannel> {
    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, TfbPayChannel tfbPayChannel, JdbcType jdbcType) throws SQLException {

        preparedStatement.setObject(i, tfbPayChannel.getCode());
    }

    @Override
    public TfbPayChannel getNullableResult(ResultSet resultSet, String s) throws SQLException {
        final String index = resultSet.getString(s);
        if (resultSet.wasNull()) {
            return null;
        }
        return TfbPayChannel.getByCode(index);
    }

    @Override
    public TfbPayChannel getNullableResult(ResultSet resultSet, int i) throws SQLException {
        final String aByte = resultSet.getString(i);
        if (resultSet.wasNull()) {
            return null;
        }
        return TfbPayChannel.getByCode(aByte);
    }

    @Override
    public TfbPayChannel getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        final String index = callableStatement.getString(i);
        if (callableStatement.wasNull()) {
            return null;
        }
        return TfbPayChannel.getByCode(index);
    }
}
