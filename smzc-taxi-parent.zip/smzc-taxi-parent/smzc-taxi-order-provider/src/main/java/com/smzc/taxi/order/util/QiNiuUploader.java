package com.smzc.taxi.order.util;

import com.smzc.common.qiniu.QiNiuExportConfig;
import com.smzc.common.qiniu.QiNiuUploadUtil;
import com.smzc.taxi.QiNiuConfig;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 七牛云上传工具
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/6/12
 */
@Component
public class QiNiuUploader implements CommandLineRunner {

    @Resource
    private QiNiuConfig qiNiuConfig;

    /**
     * 上传文件
     *
     * @param fileFullName 文件名+后缀
     * @param uploadBytes  文件字节数组
     * @return 下载链接
     * @throws Exception
     */
    public String upload(String fileFullName, byte[] uploadBytes) throws Exception {
        return QiNiuUploadUtil.upload(fileFullName, uploadBytes);
    }

    @Override
    public void run(String... args) throws Exception {
        QiNiuExportConfig.instance().initQiNiuUpload(qiNiuConfig.getAccessKey(),
                qiNiuConfig.getSecretKey(),
                qiNiuConfig.getBucket(),
                qiNiuConfig.getBaseUri());
    }
}
