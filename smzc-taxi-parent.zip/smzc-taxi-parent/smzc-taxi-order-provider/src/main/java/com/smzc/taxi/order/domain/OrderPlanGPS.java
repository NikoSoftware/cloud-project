package com.smzc.taxi.order.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.io.Serializable;
import java.util.List;

/**
 * 订单规划路线GPS
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/23
 */
@Getter
@Setter
@NoArgsConstructor
@Document(collection = "order_plan_gps")
@CompoundIndexes({
        @CompoundIndex(name = "order_id", def = "{'order_id': 1}")})
public class OrderPlanGPS implements Serializable {
    /**
     * 唯一标识id,由mongo自动生成
     */
    @Id
    private String id;

    /**
     * 订单ID
     */
    @Field(value = "order_id")
    private Long orderId;

    /**
     * GPS集合
     */
    @Field(value = "gps")
    private List<GPSBean> gpsList;

    /**
     * 创建时间
     */
    @Field(value = "create_time")
    private String createTime;
}
