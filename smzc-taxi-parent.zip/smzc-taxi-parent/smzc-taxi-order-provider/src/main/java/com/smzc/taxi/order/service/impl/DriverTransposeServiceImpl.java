package com.smzc.taxi.order.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.order.service.DriverTransposeService;
import com.smzc.taxi.service.driver.bean.DriverWorkStateTurnVo;
import com.smzc.taxi.service.driver.service.IDriverFacade;
import org.springframework.stereotype.Service;

/**
 * @author : lufy
 * @version v1.0
 * @date : 2019/6/3
 */
@Service
public class DriverTransposeServiceImpl implements DriverTransposeService {

    @Reference(version = "1.0.0")
    private IDriverFacade driverFacade;

    @Override
    public void driverWorkStateTurn(DriverWorkStateTurnVo driverWorkStateTurnVo) {
        driverFacade.driverWorkStateTurn(driverWorkStateTurnVo);
    }
}
