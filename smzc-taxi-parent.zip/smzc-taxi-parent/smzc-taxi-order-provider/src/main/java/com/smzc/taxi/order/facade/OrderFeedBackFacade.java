package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.smzc.taxi.order.service.OrderFeedbackService;
import com.smzc.taxi.service.order.bean.vo.OrderFeedBackVo;
import com.smzc.taxi.service.order.facade.IOrderFeedBackFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 订单反馈服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
@Component
@Service
@Slf4j
public class OrderFeedBackFacade implements IOrderFeedBackFacade {
    @Resource
    private OrderFeedbackService orderFeedbackService;

    @Override
    public void addOrderFeedback(OrderFeedBackVo vo) {
        try {
            orderFeedbackService.addOrderFeedback(vo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public List<OrderFeedBackVo> selectByOrderId(Long orderId) {
        try {
            return orderFeedbackService.selectByOrderId(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }
}
