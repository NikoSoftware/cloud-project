package com.smzc.taxi.order.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/23 9:48
 */
@Component
public class OrderMail {

    @Autowired
    Environment en;

    private final String MAIL_FROM_KEY = "spring.mail.from";
    private final String MAIL_TO_KEY = "spring.mail.to";
    private final String MAIL_SUBJECT_KEY = "spring.mail.subject";
    private final String DEFAULT_MAIL_FROM_VALUE = "fortest@sm.vvip-u.com";
    private final String DEFAULT_MAIL_TO_VALUE = "liuxinjie@sm.vvip-u.com";
    private final String DEFAULT_MAIL_SUBJECT_VALUE = "taxi-order-error";

    @Resource
    JavaMailSender mailSender;

    @Resource
    protected ThreadPoolTaskExecutor executor;

    public void sendMail(String content) {
        executor.execute(() -> {
            mailSender.send(getMailMessage(en.getProperty(MAIL_SUBJECT_KEY, String.class, DEFAULT_MAIL_SUBJECT_VALUE), content));
        });
    }

    public void sendMail(String subject, String content) {
        executor.execute(() -> {
            mailSender.send(getMailMessage(subject, content));
        });
    }

    private SimpleMailMessage getMailMessage(String subject, String content) {
        SimpleMailMessage mail = new SimpleMailMessage();
        mail.setTo(en.getProperty(MAIL_TO_KEY, String.class, DEFAULT_MAIL_TO_VALUE));
        mail.setFrom(en.getProperty(MAIL_FROM_KEY, String.class, DEFAULT_MAIL_FROM_VALUE));
        mail.setSubject(subject);
        mail.setText(content);
        return mail;
    }


}
