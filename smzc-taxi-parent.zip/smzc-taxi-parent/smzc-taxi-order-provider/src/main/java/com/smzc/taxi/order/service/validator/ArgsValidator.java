package com.smzc.taxi.order.service.validator;

import com.smzc.taxi.service.order.bean.vo.OrderInfoVo;
import org.springframework.stereotype.Component;

/**
 * 参数校验
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/7/29
 */
@Component
public class ArgsValidator implements OrderValidator {

    @Override
    public ValidResult valid(OrderInfoVo orderInfoVo, ValidResult r) {
//        基本信息
        if (orderInfoVo.getSubscriberId() == null) {
            return r.error("下单人id不能为空");
        }

        if (orderInfoVo.getPredictMileage() == null) {
            return r.error("预估里程不能为空");
        }

        if (orderInfoVo.getPredictTime() == null) {
            return r.error("预估里程时间不能为空");
        }

//        地址信息
        if (orderInfoVo.getPlanFromLongitude() == null) {
            return r.error("订单起点经度不能为空");
        }

        if (orderInfoVo.getPlanFromLatitude() == null) {
            return r.error("订单起点纬度不能为空");
        }

        if (orderInfoVo.getPlanFromAddress() == null) {
            return r.error("订单起点地址不能为空");
        }

        if (orderInfoVo.getPlanToAddress() == null) {
            return r.error("订单终点地址不能为空");
        }

        if (orderInfoVo.getPlanToLongitude() == null) {
            return r.error("订单终点经度不能为空");
        }

        if (orderInfoVo.getPlanToLatitude() == null) {
            return r.error("订单终点纬度不能为空");
        }

        if (orderInfoVo.getPlanFromCityCode() == null) {
            return r.error("订单起点城市编码不能为空");
        }

        if (orderInfoVo.getPlanFromCityName() == null) {
            return r.error("订单起点城市名称不能为空");
        }

        if (orderInfoVo.getPlanToCityCode() == null) {
            return r.error("订单终点城市编码不能为空");
        }

        if (orderInfoVo.getPlanToCityName() == null) {
            return r.error("订单终点城市名称不能为空");
        }

        return r;
    }

}
