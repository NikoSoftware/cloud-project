package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderStatusPosition;

public interface OrderStatusPositionMapper {

    int insert(OrderStatusPosition record);

}