package com.smzc.taxi.order.service;

import com.smzc.taxi.service.order.bean.vo.OrderEvaluateDriverDayVo;
import com.smzc.taxi.service.order.bean.vo.OrderEvaluateTagVo;
import com.smzc.taxi.service.order.bean.vo.OrderEvaluateVo;

import java.util.Date;
import java.util.List;

/**
 * 订单评价服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/21
 */
public interface OrderEvaluateService {
    /**
     * 乘客添加评价
     */
    void addOrderEvaluate(OrderEvaluateVo record);

    /**
     * 根据订单id来查询评价
     */
    OrderEvaluateVo selectByOrderId(Long orderId);

    /**
     * 根据订单id统计评价数量
     */
    int countByOrderId(Long orderId);

    /**
     * 保存乘客评价评价
     */
    void insert(OrderEvaluateVo record);

    /**
     * 返回司机每天的总分数和被评价次数
     */
    List<OrderEvaluateDriverDayVo> selectDriverEvaluateDay(Date beginDate, Date endDate);

    List<OrderEvaluateDriverDayVo> selectDriverEvaluateDayByMobileList(Date beginDate, Date endDate,List<String> mobileList);
    /**
     * 获取所有的评价标签
     */
    List<OrderEvaluateTagVo> selectAllOrderEvaluateTag();
}
