package com.smzc.taxi.order.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单结算明细
 * 对应表 :order_payoff_detail
 *
 * @author :james
 * @date :2019-05-16
 */
public class OrderPayoffDetail extends BaseBean {

    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 订单费用key  停车费, 路桥费, 清洁费, 取消费用, 驳回费用……
     */
    private String costKey;

    /**
     * 对应  消费金额
     */
    private Integer costAmount;


    private static final long serialVersionUID = 1L;


    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getCostKey() {
        return costKey;
    }

    public void setCostKey(String costKey) {
        this.costKey = costKey == null ? null : costKey.trim();
    }

    public Integer getCostAmount() {
        return costAmount;
    }

    public void setCostAmount(Integer costAmount) {
        this.costAmount = costAmount;
    }

    public OrderPayoffDetail(){}
    public OrderPayoffDetail(Long orderId,String costKey,Integer costAmount){
        this.orderId = orderId;
        this.costKey = costKey;
        this.costAmount = costAmount;
    }

}