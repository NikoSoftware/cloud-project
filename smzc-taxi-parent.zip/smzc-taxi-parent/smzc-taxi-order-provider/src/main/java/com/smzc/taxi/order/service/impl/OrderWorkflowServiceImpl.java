package com.smzc.taxi.order.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.order.dao.mapper.OrderInfoMapper;
import com.smzc.taxi.order.dao.mapper.OrderPayoffMapper;
import com.smzc.taxi.order.domain.OrderCacheBean;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.domain.OrderPayoff;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.service.OrderWorkflowService;
import com.smzc.taxi.order.service.context.ProxyStatusTransferControl;
import com.smzc.taxi.service.order.bean.vo.OrderDrivingVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.portal.bean.DriverOrderReqVo;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * 司机订单服务
 *
 * @author chenzhongqin
 * @version 1.0
 * @date 2019/5/23
 */
@Service
public class OrderWorkflowServiceImpl implements OrderWorkflowService {

    @Resource
    private OrderInfoMapper orderInfoMapper;

    @Resource
    private OrderService orderService;

    @Resource
    private OrderPayoffMapper orderPayoffMapper;

    @Resource
    ProxyStatusTransferControl proxyStatusTransferControl;

    @Override
    public void passengerArrive(DriverOrderReqVo driverOrderReqVo) {
        OrderInfoContext orderInfo = checkAndTransform(driverOrderReqVo);
        proxyStatusTransferControl.transfer(new ControlContext(orderInfo.getStatus(), OrderStatus.IN_TRIP, orderInfo));
    }

    @Override
    public void driverArrive(DriverOrderReqVo driverOrderReqVo) {
        OrderInfoContext orderInfo = checkAndTransform(driverOrderReqVo);
        proxyStatusTransferControl.transfer(new ControlContext(orderInfo.getStatus(), OrderStatus.DRIVER_ARRIVE, orderInfo));
    }

    @Override
    public void driverArriveEndPoint(DriverOrderReqVo driverOrderReqVo) {
        OrderInfoContext orderInfo = checkAndTransform(driverOrderReqVo);
        proxyStatusTransferControl.transfer(new ControlContext(orderInfo.getStatus(), OrderStatus.WAIT_COLLECT_MONEY, orderInfo));
    }

    @Override
    @RouterDataSource(DataSourceAddr.SLAVE)
    public List<OrderDrivingVo> queryDriverReceivedOrderList(Long driverId) {
        AssertUtil.notNull(driverId, "司机Id不能为空");
        List<Byte> list = Arrays.asList(
                OrderStatus.DRIVER_STARTING.getIndex(),
                OrderStatus.DRIVER_ARRIVE.getIndex(),
                OrderStatus.IN_TRIP.getIndex(),
                OrderStatus.WAIT_COLLECT_MONEY.getIndex()
        );
        return orderInfoMapper.queryDriverReceivedOrderList(driverId, list);
    }

    @Override
    @RouterDataSource(DataSourceAddr.SLAVE)
    public List<OrderDrivingVo> queryDriverHistoryOrderList(DriverOrderReqVo query) {
        AssertUtil.notNull(query, "对象不能为空");
        AssertUtil.notNull(query.getDriverId(), "driverId不能为空");
        AssertUtil.notNull(query.getPageNum(), "页码不能为空");
        AssertUtil.notNull(query.getPageSize(), "每页显示记录数不能为空");

        List<Byte> list = new ArrayList<>();
        list.add(OrderStatus.WAIT_PAY.getIndex()); //待支付
        list.add(OrderStatus.WAIT_EVALUATE.getIndex());//待评价
        list.add(OrderStatus.CANCEL.getIndex());//已取消
        list.add(OrderStatus.FINISH.getIndex());//已完成
        list.add(OrderStatus.REJECTED.getIndex());//已驳回
        list.add(OrderStatus.WAIT_PAY_REJECT.getIndex());//驳回待支付
        list.add(OrderStatus.WAIT_PAY_CANCEL.getIndex());//取消待支付
        PageHelper.startPage(query.getPageNum(), query.getPageSize(), false);
        List<OrderDrivingVo> orderDrivingVos = orderInfoMapper.queryDriverHistoryOrderList(query.getDriverId(), list);
        PageInfo<OrderDrivingVo> pageInfo = new PageInfo<>(orderDrivingVos);
        return pageInfo.getList();
    }

    @Override
    @RouterDataSource(DataSourceAddr.SLAVE)
    public OrderDrivingVo queryDriverReceivedOrderDetail(Long orderId) {
        AssertUtil.notNull(orderId, "orderId不能为空");

        // 查询优化
        // 订单状态 未发起收款时，全部从缓存中读订单数据
        // 订单状态 发起收款后，payoff中的数据从缓存中读

        List<OrderStatus> noPaytist = Arrays.asList(
                OrderStatus.WAIT_PAY,
                OrderStatus.WAIT_PAY_CANCEL,
                OrderStatus.WAIT_PAY_REJECT,
                OrderStatus.WAIT_EVALUATE,
                OrderStatus.REJECTED,
                OrderStatus.FINISH,
                OrderStatus.CANCEL
                );

        // 从缓存读数据
        OrderDrivingVo orderDrivingVo = getOrderDataFromCache(orderId);

        if(noPaytist.contains(orderDrivingVo.getOrderStatus())){
            OrderPayoff orderPayoff = orderPayoffMapper.selectPayoffByOrderId(orderId);
            if(orderPayoff != null){
                orderDrivingVo.setOrderAmount(orderPayoff.getOrderAmount());
                orderDrivingVo.setPayAmount(orderPayoff.getPayAmount());
                orderDrivingVo.setPayChannel(orderPayoff.getPayChannel());
                orderDrivingVo.setPayType(orderPayoff.getPayType() == null ? null : orderPayoff.getPayType().intValue());
            }
        }
        return orderDrivingVo;
    }

    /**
     * 从缓存读数据
     */
    private OrderDrivingVo getOrderDataFromCache(Long orderId) {
        OrderDrivingVo orderDrivingVo = new OrderDrivingVo();

        final OrderCacheBean orderCache = orderService.getOrderCache(orderId);
        orderDrivingVo.setOrderId(orderCache.getId());
        orderDrivingVo.setDriverId(orderCache.getDriverId());
        orderDrivingVo.setPassengerPhone(orderCache.getPassengerPhone());
        orderDrivingVo.setCityCode(orderCache.getCityCode());
        orderDrivingVo.setDriverPhone(orderCache.getDriverPhone());

        orderDrivingVo.setVehicleId(orderCache.getVehicleId());
        orderDrivingVo.setVehicleNo(orderCache.getVehicleNo());

        orderDrivingVo.setFromLongitude(orderCache.getPlanFromLongitude());
        orderDrivingVo.setFromLatitude(orderCache.getPlanFromLatitude());
        orderDrivingVo.setPlanFromCityCode(orderCache.getPlanFromCityCode());
        orderDrivingVo.setFromAddress(orderCache.getPlanFromAddress());
        orderDrivingVo.setFromStreet(orderCache.getPlanFromStreet());

        orderDrivingVo.setToLongitude(orderCache.getPlanToLongitude());
        orderDrivingVo.setToLatitude(orderCache.getPlanToLatitude());
        orderDrivingVo.setToAddress(orderCache.getPlanToAddress());
        orderDrivingVo.setToStreet(orderCache.getPlanToStreet());

        orderDrivingVo.setAddType(orderCache.getAddType());
        orderDrivingVo.setScheduleTime(orderCache.getScheduleTime());

        orderDrivingVo.setOrderStatus(orderService.getOrderStatusById(orderId));

        return orderDrivingVo;

    }

    @Override
    @RouterDataSource(DataSourceAddr.SLAVE)
    public Long queryDrivingOrderId(Long driverId) {
        AssertUtil.notNull(driverId, "司机Id不能为空");
        List<Byte> list = new ArrayList<>();
        list.add(OrderStatus.DRIVER_STARTING.getIndex());//司机已出发
        list.add(OrderStatus.DRIVER_ARRIVE.getIndex());//司机已到达
        list.add(OrderStatus.IN_TRIP.getIndex());//行程中
        list.add(OrderStatus.WAIT_COLLECT_MONEY.getIndex());//待收款
        list.add(OrderStatus.WAIT_PAY.getIndex());//待支付
        List<Long> orderIdList = orderInfoMapper.queryDrivingOrderId(driverId, list);
        return orderIdList.size() > 0 ? orderIdList.get(0) : null;
    }

    /**
     * 转换为 orderInfo
     *
     * @param driverOrderReqVo
     * @return
     */
    @RouterDataSource(DataSourceAddr.SLAVE)
    public OrderInfoContext checkAndTransform(DriverOrderReqVo driverOrderReqVo) {
        AssertUtil.notNull(driverOrderReqVo.getOrderId(), "订单Id不能为空");
        AssertUtil.notNull(driverOrderReqVo.getLatitude(), "纬度不能为空");
        AssertUtil.notNull(driverOrderReqVo.getLongitude(), "经度不能为空");
        AssertUtil.notNull(driverOrderReqVo.getPlatformType(), "设备类型不为空");

        OrderCacheBean orderCache = orderService.getOrderCache(driverOrderReqVo.getOrderId());
        AssertUtil.notNull(orderCache, "没有找到订单源数据，orderId=" + driverOrderReqVo.getOrderId());
        OrderInfoContext orderInfoContext = new OrderInfoContext();
        BeanUtils.copyProperties(orderCache, orderInfoContext);
        orderInfoContext.setStatus(orderService.getOrderStatusById(driverOrderReqVo.getOrderId()));
        orderInfoContext.setLatitude(driverOrderReqVo.getLatitude());
        orderInfoContext.setLongitude(driverOrderReqVo.getLongitude());
        orderInfoContext.setPlatformType(driverOrderReqVo.getPlatformType());
        orderInfoContext.setPracticalAddress(driverOrderReqVo.getAddress());
        orderInfoContext.setPracticalStreet(driverOrderReqVo.getStreet());
        return orderInfoContext;
    }

}