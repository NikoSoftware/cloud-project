package com.smzc.taxi.order.service.validator;

import lombok.Data;

/**
 * 校验结果信息
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/7/29
 */
@Data
public class ValidResult<T> {

    /**
     * 校验结果：成功/失败
     */
    private boolean flag;

    /**
     * 校验结果编码
     */
    private int code = R.SUCCESS;

    /**
     * 校验信息
     */
    private String msg;

    /**
     * 校验返回对象
     */
    private T data;

    public ValidResult<T> error(String msg) {
        this.code = R.ERROR;
        this.msg = msg;
        return this;
    }

    public ValidResult<T> error(int code, String msg, T data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
        return this;
    }


    static class R {
        /**
         * 成功
         */
        static final int SUCCESS  = 200;

        /**
         * 失败：直接抛出异常
         */
        static final int ERROR = -1;

        /**
         * 失败：不抛异常，需要业务处理
         */
        static final int BUS_ERROR = 500;
    }
}
