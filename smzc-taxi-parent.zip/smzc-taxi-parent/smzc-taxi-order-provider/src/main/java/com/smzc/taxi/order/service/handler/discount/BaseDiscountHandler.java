package com.smzc.taxi.order.service.handler.discount;

import com.alibaba.fastjson.JSON;
import com.smzc.market.service.driver.bean.DriverMarketActPrizeInfoVo;
import com.smzc.market.service.driver.bean.MarketActivityPrizeReqVo;
import com.smzc.market.service.driver.bean.balance.BalanceVo;
import com.smzc.market.service.driver.bean.subsidy.SubsidyActPrizeInfoReqVo;
import com.smzc.market.service.driver.enums.*;
import com.smzc.taxi.boot.mq.SmRocketMqTemplate;
import com.smzc.taxi.common.consts.MQTagsConst;
import com.smzc.taxi.common.consts.MQTopicConst;
import com.smzc.taxi.order.dao.mapper.OrderActivityMapper;
import com.smzc.taxi.order.dao.mapper.OrderInfoExtMapper;
import com.smzc.taxi.order.domain.OrderActivity;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.domain.OrderInfoExt;
import com.smzc.taxi.order.service.OrderActivityService;
import com.smzc.taxi.order.service.OrderDriverMarketActivityService;
import com.smzc.taxi.service.finance.bean.PayRewardVo;
import com.smzc.taxi.service.passenger.bean.price.ActivityResultVo;
import com.smzc.taxi.service.passenger.enums.CountPricelType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * 基础类
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/5 15:13
 */
@Slf4j
public abstract class BaseDiscountHandler implements DiscountHandler {

    @Resource
    OrderDriverMarketActivityService orderDriverMarketActivityService;
    @Resource
    SmRocketMqTemplate rocketMqTemplate;
    @Resource
    OrderActivityService orderActivityService;
    @Resource
    OrderInfoExtMapper orderInfoExtMapper;

    @Override
    public void execute(OrderInfoContext context) {
        List<DriverMarketActPrizeInfoVo> openingMarketActivityList = null;
        try {
            OrderInfoExt orderInfoExt = orderInfoExtMapper.selectByOrderId(context.getId());
            MarketActivityPrizeReqVo reqVo = new MarketActivityPrizeReqVo(
                    BusinessTypeEnum.SM_TAXI,
                    DriverTypeEnum.TAXI_DRIVER,
                    context.getCityCode(),
                    DeviceTypeEnum.fromType(orderInfoExt.getDeviceFrom()),
                    orderInfoExt.getDeviceNumber(),
                    getSubsidyActPrizeInfoReqVo(context));

            openingMarketActivityList = orderDriverMarketActivityService.getDriverMarketActPrizeInfo(reqVo);
        } catch (Exception e) {
            log.error("获取司机活动报错：OrderId:{}",context.getId(), e);
        }

        // 防止因为未知的异常导致后续的逻辑无法执行的问题
        Long driverDiscountCount = 0L;
        try {
            if (!CollectionUtils.isEmpty(openingMarketActivityList)) {

                driverDiscountCount = openingMarketActivityList.stream().mapToLong(p -> {
                    long amount = 0L;
                    List<DriverPrizeTypeEnum> prizeTypeList = p.getPrizeTypeList();
                    if(!CollectionUtils.isEmpty(prizeTypeList)){
                        if (prizeTypeList.contains(DriverPrizeTypeEnum.BALANCE)) {
                            List<BalanceVo> bvList = p.getBalancePrizeList();
                            amount = bvList.stream().mapToLong(m -> m.getBalanceAmount() * m.getBalanceRewardsAmount()).sum();
                        }
                    }
                    return amount;
                }).sum();

                List<ActivityResultVo> activityList = openingMarketActivityList.stream().map(p->{
                    int amount = CollectionUtils.isEmpty(p.getBalancePrizeList()) ? 0 : (int)p.getBalancePrizeList()
                            .stream()
                            .mapToLong(m -> m.getBalanceAmount() * m.getBalanceRewardsAmount())
                            .sum();
                    return new ActivityResultVo(
                            p.getActivityId(),
                            p.getName(),
                            amount);
                }).collect(Collectors.toList());

                orderActivityService.batchAddOrderActivity(activityList,context.getId(),CountPricelType.DRIVER);
            }
        } catch (Exception e) {
            log.error("司机活动数据有问题，无法解析。OrderId:{},返回的数据：{}",
                    context.getId(),
                    JSON.toJSONString(openingMarketActivityList), e);
        }


        PayRewardVo payRewardVo = new PayRewardVo();

        payRewardVo.setDriverDiscountCount(driverDiscountCount.intValue());
        payRewardVo.setDriverId(context.getDriverId());
        payRewardVo.setRewardType(awardType().getType());
        payRewardVo.setOrderId(context.getId());
        payRewardVo.setHasDiscount(context.getDiscountAmount() != null && context.getDiscountAmount() > 0);
        payRewardVo.setPassengerDiscountCount(context.getDiscountAmount());
        context.setDriverDiscountAmount(driverDiscountCount.intValue());
        try {
            orderDriverMarketActivityService.reWardDriver(payRewardVo);
            log.info("司机补贴执行成功，OrderId:{},司机补贴{}元，乘客优惠{}元",context.getId(),driverDiscountCount,context.getDiscountAmount());
        } catch (Exception e) {
            log.error("司机补贴执行异常，进入MQ重试流程，OrderId:{},参数：{}", context.getId(), JSON.toJSONString(payRewardVo), e);
            rocketMqTemplate.syncSend(MQTopicConst.TAXI_ORDER, MQTagsConst.TAXI_ORDER_DRIVER_SUBSIDY, payRewardVo,payRewardVo.getOrderId().toString());
        }
    }

    @Override
    public abstract DriverOrderRewardTypeEnum awardType();

    private SubsidyActPrizeInfoReqVo getSubsidyActPrizeInfoReqVo(OrderInfoContext context){
        SubsidyActPrizeInfoReqVo subsidyActPrizeInfoReqVo = new SubsidyActPrizeInfoReqVo();
        subsidyActPrizeInfoReqVo.setDriverId(context.getDriverId());
        subsidyActPrizeInfoReqVo.setDriverMobilePhone(context.getDriverPhone());
        subsidyActPrizeInfoReqVo.setDriverName(context.getDriverName());
        subsidyActPrizeInfoReqVo.setDriverType(DriverTypeEnum.TAXI_DRIVER);
        subsidyActPrizeInfoReqVo.setOrderId(context.getId());
        subsidyActPrizeInfoReqVo.setSubscriberId(context.getSubscriberId());
        subsidyActPrizeInfoReqVo.setSubscriberMobilePhone(context.getSubscriberPhone());
        subsidyActPrizeInfoReqVo.setOrderAmount(context.getOrderAmount().longValue());
        subsidyActPrizeInfoReqVo.setSubsidyOrderRewardType(awardType());
        return subsidyActPrizeInfoReqVo;
    }

}
