package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.smzc.taxi.order.service.OrderAdminService;
import com.smzc.taxi.order.service.OrderPayoffService;
import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.emun.PayType;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.order.exception.OrderException;
import com.smzc.taxi.service.order.facade.IOrderPayoffFacade;
import com.smzc.taxi.service.portal.bean.PriceModifyInnerVo;
import com.smzc.taxi.service.portal.bean.PriceModifyUpdVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 订单结算
 *
 * @author liuxinjie
 * @version v1.0
 * @date 2019/5/21
 */
@Component
@Service
@Slf4j
public class OrderPayoffFacade implements IOrderPayoffFacade {

    @Resource
    private OrderPayoffService orderPayoffService;

    @Resource
    private OrderAdminService orderAdminService;


    @Override
    public CommonCode addPayoff(OrderPayoffVo orderPayoffVo) {
        // 订单状态从待支付流转到待评价
        AssertUtil.notNull(orderPayoffVo, "参数不能为空");
        AssertUtil.notNull(orderPayoffVo.getOrderId(), "订单ID不能为空");
        AssertUtil.notNull(orderPayoffVo.getPayType(), "支付类型不能为空");
        AssertUtil.notNull(orderPayoffVo.getPayAmount(), "支付金额不能为空");
        AssertUtil.notNull(orderPayoffVo.getPayTime(), "支付时间不能为空");
        if (PayType.ON_LINE.equals(orderPayoffVo.getPayType())) {
            AssertUtil.notNull(orderPayoffVo.getPayChannel(), "支付类型是线上支付。支付渠道不能为空");
        }
        // log.info("支付回调订单结算：参数：{}", orderPayoffVo.toString());
        try {
            return orderPayoffService.addPayoff(orderPayoffVo);
        } catch (OrderException oe){
            log.error("OrderId:{},支付回调订单结算业务异常，不用重试。参数：{}", orderPayoffVo.getOrderId(), JSON.toJSONString(orderPayoffVo), oe);
            return CommonCode.BUS_EXCEPTION;
        }catch (Exception e) {
            log.error("OrderId:{},支付回调订单结算异常，要重试。参数：{}", orderPayoffVo.getOrderId(), JSON.toJSONString(orderPayoffVo), e);
            return CommonCode.FTAIL;
        }
    }

    @Override
    public CommonCode addPayOffDetails(OrderPayoffDetailContextVo contextVo) {
        // 添加订单结算明细，
        // 司机输入完费用后点发起收款时调用
        // 订单状态只能从待收款到待支付
        // 判定订单当前状态
        if (contextVo == null) {
            throw new OrderException("参数不能为空");
        }
        return orderPayoffService.addPayOffDetails(contextVo);
    }

    @Override
    public CommonCode updPayoffDetail(PriceModifyUpdVo updVo) {
        AssertUtil.notNull(updVo, "对象不能为空");
        Long orderId = Long.valueOf(updVo.getOrderId());
        PriceModifyInnerVo innerVo = orderAdminService.getPriceModifyInfo(orderId);
        if (innerVo == null) {
            log.error("订单改价：订单[id={}]不存在", updVo.getOrderId());
            throw new OrderException("订单不存在");
        }
        if (!innerVo.getStatus().equals(OrderStatus.WAIT_PAY.getIndex())) {
            log.error("订单改价：订单id={}状态已改变为{}，不可进行改价", updVo.getOrderId(), OrderStatus.fromIndex(innerVo.getStatus()).getName());
            throw new OrderException("待支付的订单才能调价");
        }

        return orderPayoffService.updPayoffDetail(updVo, innerVo);
    }

    @Override
    public List<OrderPayoffDetailVo> queryPayoffDetailListByOrderId(Long orderId) {
        AssertUtil.notNull(orderId, "参数不能为空");
        return orderPayoffService.queryPayoffDetailListByOrderId(orderId);
    }
    @Override
    public OrderPayoffDetailContextDiffVo queryPayoffDetailListByOrderId_v2(Long orderId) {
        AssertUtil.notNull(orderId, "参数不能为空");
        List<OrderPayoffDetailDiffVo> list = orderPayoffService.queryPayoffDetailListByOrderId_v2(orderId);
        OrderAmountVo orderAmountVo = orderPayoffService.selectOrderAmountByOrderId(orderId);
        try {
            return new OrderPayoffDetailContextDiffVo(orderAmountVo.getPayAmount(), list);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderAmountVo selectOrderAmountByOrderId(Long orderId) {
        AssertUtil.notNull(orderId, "参数不能为空");
        try {
            return orderPayoffService.selectOrderAmountByOrderId(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public void syncOrderPayStatus(String params) {
        try {
            orderPayoffService.syncOrderPayStatus(params);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderPayoffAmoutVo selectOrderPayoffAmountByOrderId(Long orderId) {
        try {
            return orderPayoffService.selectOrderPayoffAmountByOrderId(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }
}
