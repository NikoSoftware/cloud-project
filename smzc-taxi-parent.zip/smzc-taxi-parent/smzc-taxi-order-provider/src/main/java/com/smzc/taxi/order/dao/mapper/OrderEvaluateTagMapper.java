package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.service.order.bean.vo.OrderEvaluateTagVo;

import java.util.List;

public interface OrderEvaluateTagMapper {

    List<OrderEvaluateTagVo> selectAllOrderEvaluateTag();

}