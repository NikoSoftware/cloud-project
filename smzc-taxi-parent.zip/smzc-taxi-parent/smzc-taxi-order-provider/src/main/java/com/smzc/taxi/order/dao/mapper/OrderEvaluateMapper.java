package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderEvaluate;
import com.smzc.taxi.service.order.bean.vo.OrderEvaluateDriverDayVo;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface OrderEvaluateMapper {
    int insert(OrderEvaluate record);

    OrderEvaluate selectByOrderId(Long orderId);

    int countByOrderId(Long orderId);

    List<OrderEvaluateDriverDayVo> selectDriverEvaluateDay(@Param("beginDate") Date beginDate, @Param("endDate") Date endDate);

    List<OrderEvaluateDriverDayVo> selectDriverEvaluateDayByMobileList(@Param("beginDate") Date beginDate, @Param("endDate") Date endDate, @Param("list") List<String> mobileList);
}