package com.smzc.taxi.order.domain;

import lombok.Data;

import java.util.Date;

/**
 *
 * 订单扩展信息
 * 对应表 :order_info_ext
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/5 14:25
 */
@Data
public class OrderInfoExt extends BaseBean {
    /**
     * 主键
     */
    private Long id;

    /**
     * 订单ID
     */
    private Long orderId;

    /**
     * 创建类型 1。自建  2。邀新  3。代建
     */
    private Byte addType;

    /**
     * 用车类型  1,即时用车,2.预约用
     */
    private Byte useType;

    /**
     * 用车时间
     */
    private Date useTime;

    /**
     * 设备号
     */
    private String deviceNumber;


    private Integer deviceFrom;

}