package com.smzc.taxi.order.service.handler.statustransfer;


import com.smzc.taxi.boot.mq.SmRocketMqTemplate;
import com.smzc.taxi.order.domain.OrderAddress;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.order.emun.OrderStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * 到达目的地 发起收款实现类
 * 行程中流转到待收钱（司机结束行程）
 * @author chenzhongqin
 * @version 1.0
 * @date 2019/5/23
 */
@Slf4j
@OrderServiceHandler(fromStatus = OrderStatus.IN_TRIP, toStatus = OrderStatus.WAIT_COLLECT_MONEY)
public class CollectMoneyHandler extends OrderHandler {

    @Autowired
    private SmRocketMqTemplate rocketMqTemplate;

    @Override
    public void process(ControlContext context) {
        // 存实际的下车点
        OrderInfoContext orderInfo = context.getEntity();
        OrderAddress orderAddress = orderAddressMapper.selectByOrderId(orderInfo.getId());
        OrderAddress param = new OrderAddress();
        param.setId(orderAddress.getId());
        param.setPracticalToAddress(orderInfo.getPracticalAddress());
        param.setPracticalToStreet(orderInfo.getPracticalStreet());
        param.setPracticalToLongitude(orderInfo.getLongitude());
        param.setPracticalToLatitude(orderInfo.getLatitude());
        int updEffect = orderAddressMapper.updateByPrimaryKeySelective(param);
        if (updEffect > 0) {
            log.debug("OrderId:{},更新实际下车点成功",context.getOrderId());
        } else {
            log.error("OrderId:{},更新实际下车点 失败,参数{}", context.getOrderId(), param.toString());
        }
    }

    @Override
    public void asyncMethod(final ControlContext context) {
        super.asyncMethod(context);

        //        先不上线，上线的时候放开
        //log.info("形成结束发消息给互相娱乐屏幕,id:{}",context.getOrderId());
        //rocketMqTemplate.syncSend(MQTopicConst.TAXI_OPEN_ORDER_INFO, MQTagsConst.TAXI_ORDER_FINISH_TRIP,new MQHYPBody(context.getOrderId()));
    }

}
