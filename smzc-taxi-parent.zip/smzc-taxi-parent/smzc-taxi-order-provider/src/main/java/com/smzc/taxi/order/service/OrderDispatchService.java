package com.smzc.taxi.order.service;

import com.smzc.taxi.service.dispatch.bean.*;
import com.smzc.taxi.service.dispatch.exception.DispatchException;

import java.util.List;

/**
 * 订单调度处理包装服务层：
 * 解决在OrderHandler无法注入dubbo服务（主要是因为dubbo@Reference注解没有添加@Inherited）
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/5/26
 */
public interface OrderDispatchService {
    /**
     * Returns recommended vehicles for current order.If {@link DispatchResponse#data} is empty,it means that there is no vehicle recommended.
     *
     * @param dispatchTaxiVehicleBean a bean {@link DispatchTaxiVehicleBean} that describes the order.
     * @return recommended vehicles for current order.
     * @throws DispatchException
     */
    DispatchResponse<List<RecommendedVehicle>> dispatchTaxiVehicle(DispatchTaxiVehicleBean dispatchTaxiVehicleBean) throws DispatchException;

    /**
     * Returns recommended orders for current vehicle.If @see{@link DispatchResponse#data} is empty,it means that there is no order recommended.
     *
     * @param dispatchTaxiOrderBean a bean {@link DispatchTaxiOrderBean} that describes the vehicle.
     * @return recommended vehicles for current order.
     * @throws DispatchException
     */
    DispatchResponse<List<RecommendedOrder>> dispatchTaxiOrder(DispatchTaxiOrderBean dispatchTaxiOrderBean) throws DispatchException;

    /**
     * This method should be called immediately when order status changed.
     *
     * @param orderInfoBean a bean {@link OrderInfoBean} that describes the order.
     * @throws DispatchException
     */
    void syncOrderStatus(OrderInfoBean orderInfoBean) throws DispatchException;
}
