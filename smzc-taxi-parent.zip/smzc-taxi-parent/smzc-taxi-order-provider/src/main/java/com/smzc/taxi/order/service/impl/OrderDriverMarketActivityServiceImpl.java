package com.smzc.taxi.order.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.market.service.driver.bean.*;
import com.smzc.market.service.driver.enums.BusinessTypeEnum;
import com.smzc.market.service.driver.enums.DriverTypeEnum;
import com.smzc.market.service.driver.service.IDriverMarketActivityFacade;
import com.smzc.market.service.passenger.ActivityFacade;
import com.smzc.market.service.passenger.vo.UpdateParticipationRewardHistoryRequestVo;
import com.smzc.taxi.order.service.OrderDriverMarketActivityService;
import com.smzc.taxi.service.finance.bean.PayRewardVo;
import com.smzc.taxi.service.finance.exception.FinanceException;
import com.smzc.taxi.service.finance.facade.IPayRewardFacade;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/17 16:03
 */
@Service
public class OrderDriverMarketActivityServiceImpl implements OrderDriverMarketActivityService {

    @Reference(group = "smzc-market",version = "1.0.0",cluster = "failfast",timeout = 10000)
    IDriverMarketActivityFacade driverMarketActivityFacade;

    @Reference(version = "1.0.0")
    IPayRewardFacade payRewardFacade;

    @Reference(group = "smzc-market",version = "1.0.0",cluster = "failfast",timeout = 10000)
    ActivityFacade activityFacade;


    @Override
    public List<DriverMarketActPrizeInfoVo> getDriverMarketActPrizeInfo(MarketActivityPrizeReqVo marketActivityPrizeReqVo) {
        return driverMarketActivityFacade.getDriverMarketActPrizeInfo(marketActivityPrizeReqVo);
    }

    @Override
    public void reWardDriver(PayRewardVo payRewardVo) throws FinanceException {
        payRewardFacade.reWardDriver(payRewardVo);
    }

    @Override
    public void batchUpdateParticipationRewardHistoryStatus(List<UpdateParticipationRewardHistoryRequestVo> list) {
        activityFacade.batchUpdateParticipationRewardHistoryStatus(list);
    }
}
