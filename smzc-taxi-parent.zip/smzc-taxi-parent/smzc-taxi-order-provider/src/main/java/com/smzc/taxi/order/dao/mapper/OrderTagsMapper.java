package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderTags;

public interface OrderTagsMapper {

    int insert(OrderTags orderTags);
}