package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.smzc.taxi.order.service.DriverOrderService;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.service.OrderVirtualService;
import com.smzc.taxi.order.service.impl.OrderWorkflowServiceImpl;
import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.order.exception.OrderBusinessException;
import com.smzc.taxi.service.order.facade.IDriverOrderFacade;
import com.smzc.taxi.service.portal.bean.DriverOrderReqVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 司机订单
 *
 * @author liuxinjie
 * @version 1.0
 * @date 2019/5/23 14:25
 */
@Component
@Service
@Slf4j
public class DriverOrderFacade implements IDriverOrderFacade {

    @Resource
    private OrderService orderService;

    @Resource
    private DriverOrderService driverOrderService;

    @Resource
    private OrderWorkflowServiceImpl orderWorkflowService;

    @Resource
    private OrderVirtualService orderVirtualService;

    @Override
    public List<OrderDriverWaitVo> getWaitReceive(OrderDriverWaitReqVo orderDriverWaitReqVo) {
        try {
            return driverOrderService.getWaitReceive(orderDriverWaitReqVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public List<OrderDrivingVo> queryDriverReceivedOrderList(Long driverId) {
        try {
            return orderWorkflowService.queryDriverReceivedOrderList(driverId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public List<OrderDrivingVo> queryDriverHistoryOrderList(DriverOrderReqVo driverOrderReqVo) {
        try {
            return orderWorkflowService.queryDriverHistoryOrderList(driverOrderReqVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public Long queryDrivingOrderId(Long driverId) {
        try {
            return orderWorkflowService.queryDrivingOrderId(driverId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderDrivingVo queryDriverReceivedOrderDetail(Long orderId) {
        try {
            return orderWorkflowService.queryDriverReceivedOrderDetail(orderId);
        } catch (Exception e) {
            log.error("OrderId:{}",orderId,e);
            throw e;
        }
    }

    @Override
    public CommonCode driverArriveStartPoint(DriverOrderReqVo driverOrderReqVo) {
        AssertUtil.notNull(driverOrderReqVo.getOrderId(), "订单Id不能为空");
        AssertUtil.notNull(driverOrderReqVo.getLatitude(), "纬度不能为空");
        AssertUtil.notNull(driverOrderReqVo.getLongitude(), "经度不能为空");
        try {
            orderWorkflowService.driverArrive(driverOrderReqVo);
        } catch(OrderBusinessException oe){
            return CommonCode.BUS_EXCEPTION;
        }catch (Exception e) {
            log.error("司机已到达操作失败，参数：{}", JSON.toJSONString(driverOrderReqVo), e);
            return CommonCode.FTAIL;
        }
        return CommonCode.SUCCESS;
    }

    @Override
    public CommonCode driverReceivePassenger(DriverOrderReqVo driverOrderReqVo) {
        AssertUtil.notNull(driverOrderReqVo.getOrderId(), "订单Id不能为空");
        AssertUtil.notNull(driverOrderReqVo.getLatitude(), "纬度不能为空");
        AssertUtil.notNull(driverOrderReqVo.getLongitude(), "经度不能为空");
        try {
            orderWorkflowService.passengerArrive(driverOrderReqVo);
        } catch(OrderBusinessException oe){
            return CommonCode.BUS_EXCEPTION;
        } catch (Exception e) {
            log.error("乘客上车操作失败，参数：{}", driverOrderReqVo.toString(), e);
            return CommonCode.FTAIL;
        }
        return CommonCode.SUCCESS;
    }

    @Override
    public CommonCode driverArriveEndPoint(DriverOrderReqVo driverOrderReqVo) {
        AssertUtil.notNull(driverOrderReqVo.getOrderId(), "订单Id不能为空");
        AssertUtil.notNull(driverOrderReqVo.getLatitude(), "纬度不能为空");
        AssertUtil.notNull(driverOrderReqVo.getLongitude(), "经度不能为空");
        try {
            orderWorkflowService.driverArriveEndPoint(driverOrderReqVo);
        } catch(OrderBusinessException oe){
            return CommonCode.BUS_EXCEPTION;
        } catch (Exception e) {
            log.error("乘客下车操作失败，参数：{}", driverOrderReqVo.toString(), e);
            return CommonCode.FTAIL;
        }
        return CommonCode.SUCCESS;
    }

    /**
     * 抢单
     *
     * @param orderDriverRobVo
     * @return
     */
    @Override
    public CommonCode robOrder(OrderDriverRobVo orderDriverRobVo) {
        //  1. 参数校验
        AssertUtil.notNull(orderDriverRobVo.getOrderId(), "订单ID不能为空");
        AssertUtil.notNull(orderDriverRobVo.getDriverId(), "司机ID不能为空");
        AssertUtil.notNull(orderDriverRobVo.getLatitude(), "纬度不能为空");
        AssertUtil.notNull(orderDriverRobVo.getLongitude(), "经度不能为空");
        try {
            return driverOrderService.robOrder(orderDriverRobVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            return CommonCode.ROB_FATIL;
        }

    }

    @Override
    public void saveOrderPlanGPS(OrderPlanGPSVo orderPlanGPSVo) {
        try {
            orderService.saveOrderPlanGPS(orderPlanGPSVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public OrderPlanGPSVo selectOrderPlanGPSByOrderId(Long orderId) {
        try {
            return orderService.selectOrderPlanGPSByOrderId(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }

    }

    @Override
    public List<OrderVirtualVo> getOrderVirtual(Long vehicleId, String cityCode) {
        try {
            return orderVirtualService.getOrderVirtual(vehicleId, cityCode);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }
}
