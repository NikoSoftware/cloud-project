package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderPayoff;
import com.smzc.taxi.service.order.bean.vo.IncomeQryVo;
import com.smzc.taxi.service.order.bean.vo.IncomeVo;
import com.smzc.taxi.service.order.bean.vo.OrderPayoffAmoutVo;
import com.smzc.taxi.service.order.bean.vo.PayAmountVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderPayoffMapper {
    int deleteByPrimaryKey(Long id);

    int insert(OrderPayoff record);

    int updateByPrimaryKeySelective(OrderPayoff record);

    /**
     * 根据条件查询收入列表
     */
    List<IncomeVo> queryIncomeList(IncomeQryVo qryVo);

    /**
     * 查询订单结算信息
     *
     * @param orderId 订单id
     * @return OrderPayoff
     */
    OrderPayoff selectPayoffByOrderId(Long orderId);

    /**
     * 根据订单ID修改结算价格
     * @param orderPayoff
     * @return
     */
    int updateByOrderId(OrderPayoff orderPayoff);

    /**
     * 根据订单ID集合查找支付金额集合
     * @param orderIdList
     * @return
     */
    List<PayAmountVo> selectPayAmountByOrderIdList(@Param("list") List<Long> orderIdList);

    /**
     * 通过订单id查询订单金额
     */
    Integer selectOrderAmountByOrderId(@Param("orderId")Long orderId);

    /**
     * 通过订单id查询待评价、已完成订单的支付金额和优惠金额信息
     */
    OrderPayoffAmoutVo selectOrderPayoffAmountByOrderId(@Param("orderId")Long orderId);
}