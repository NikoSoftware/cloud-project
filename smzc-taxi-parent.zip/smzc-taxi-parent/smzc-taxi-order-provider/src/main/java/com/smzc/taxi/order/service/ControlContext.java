package com.smzc.taxi.order.service;

import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.service.order.emun.OrderStatus;
import lombok.Data;

import java.util.HashMap;

/**
 * 订单状态上下文
 *
 * @author liuxinjie
 * @version v.10
 * @date 2019-5-20
 */
@Data
public class ControlContext extends HashMap<String, Object> {

    /**
     * 订单ID
     */
    private Long orderId;
    /**
     * 开始状态
     */
    private OrderStatus fromStatus;
    /**
     * 结束状态
     */
    private OrderStatus toStatus;
    /**
     * 参数对象
     */
    private OrderInfoContext entity;

    /**
     * 是否流转到下一个流程
     */
    private boolean isTransferNextStatus = true;

    public ControlContext() {

    }

    public ControlContext(OrderStatus fromStatus, OrderStatus toStatus, OrderInfoContext entity) {
        this.fromStatus = fromStatus;
        this.toStatus = toStatus;
        this.entity = entity;
        this.orderId = entity.getId();
    }


}
