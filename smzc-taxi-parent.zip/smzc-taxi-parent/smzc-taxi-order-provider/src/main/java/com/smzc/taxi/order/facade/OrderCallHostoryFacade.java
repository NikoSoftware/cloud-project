package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.github.pagehelper.PageInfo;
import com.smzc.taxi.order.service.OrderCallService;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryPageVo;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryVo;
import com.smzc.taxi.service.order.facade.IOrderCallhistoryFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 *
 * 这里是你的描述信息
 *
 * @author luofei
 * @version 1.0
 * @date 2019/5/23 14:25
 */
@Component
@Service
@Slf4j
public class OrderCallHostoryFacade implements IOrderCallhistoryFacade {

    @Resource
    OrderCallService orderCallService;

    @Override
    public void add(OrderCallHistoryVo orderCallHistoryVo) {
        try {
            orderCallService.addOrderCallHistory(orderCallHistoryVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public PageInfo<OrderCallHistoryVo> getPageList(OrderCallHistoryPageVo orderCallHistoryPageVo) {
        try {
            return orderCallService.getPageList(orderCallHistoryPageVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }
}
