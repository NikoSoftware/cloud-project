package com.smzc.taxi.order.service.impl;

import com.smzc.taxi.order.service.DriverOrderService;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.order.service.OrderWorkflowService;
import com.smzc.taxi.order.service.PassengerOrderService;
import com.smzc.taxi.service.order.bean.vo.OrderDriverRobVo;
import com.smzc.taxi.service.order.bean.vo.OrderInfoVo;
import com.smzc.taxi.service.order.emun.OrderAddType;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.emun.PlatformType;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.portal.bean.DriverOrderReqVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

/**
 * 乘客订单服务
 */
@Service
@Slf4j
public class PassengerOrderServiceImpl implements PassengerOrderService {

    @Resource
    DriverOrderService driverOrderService;
    @Resource
    OrderService orderService;
    @Resource
    OrderWorkflowService orderWorkflowService;

    //1经度转换为M的大小近似值
    private static final double PER_LONGITUDE_MILE = 102834.74258026089786013677476285;
    //1纬度转换为M的大小近似值
    private static final double PER_LATITUDE_MILE = 111712.69150641055729984301412873;
    // 每分钟跑多少米
    private static final int METER_MIN = 500;

    @Override
    public Long createOrderOfNewPassenger(OrderInfoVo orderInfoVo) {
        // 校验该用户是否是新用户
        Boolean isNewUser = orderService.checkNewUser(orderInfoVo.getSubscriberId());
        AssertUtil.isTrue(isNewUser, "您不是新用户，不能进入邀新流程");

        setDefaultOrderInfo(orderInfoVo);

        // 设置为邀新
        orderInfoVo.setAddType(OrderAddType.NEW_ADD.getIndex());

        // 创建订单
        Long orderId = orderService.createOrder(orderInfoVo);
        orderInfoVo.setId(orderId);

        // 自动完成司机抢单
        // 创建订单流程中使用了异步线程调用自动调度流程，所以需要循环检查订单状态，当订单状态为自动调度或者待抢单时，才执行下一个流程
        int maxNum = 30;//最多等待30秒
        while (maxNum-- > 0) {
            OrderStatus orderStatus = orderService.getOrderStatusById(orderId);
            if (Arrays.asList(OrderStatus.AUTO_DISPATCHING, OrderStatus.WAIT_DRIVER_CONFIRM).contains(orderStatus)) {
                robOrder(orderInfoVo);
                break;
            }
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        AssertUtil.isTrue(OrderStatus.DRIVER_STARTING == orderService.getOrderStatusById(orderId), "OrderId:[" + orderId + "],订单状态不正确无法进行下一个流程");

        // 调用司机到达流程
        driverArrive(orderId);

        // 订单状态流转为行程中
        passengerArrive(orderInfoVo);

        return orderId;
    }

    /**
     * 邀新，订单信息补偿
     */
    private void setDefaultOrderInfo(OrderInfoVo orderInfoVo) {
        double[] point1 = {orderInfoVo.getPlanFromLongitude(), orderInfoVo.getPlanToLongitude()};
        double[] point2 = {orderInfoVo.getPlanFromLatitude(), orderInfoVo.getPlanToLatitude()};
        int predictMileage = countDistance(point1, point2);
        orderInfoVo.setPredictMileage(predictMileage);
        // 按1分钟500米计算预估时间
        orderInfoVo.setPredictTime(predictMileage / METER_MIN);
    }

    private int countDistance(double[] point1, double[] point2) {
        double b = Math.abs((point1[0] - point2[0]) * PER_LONGITUDE_MILE);
        double a = Math.abs((point1[1] - point2[1]) * PER_LATITUDE_MILE);
        return new Double(Math.sqrt((a * a + b * b))).intValue();
    }

    private void robOrder(OrderInfoVo orderInfoVo) {
        OrderDriverRobVo vo = new OrderDriverRobVo();
        vo.setDriverId(orderInfoVo.getDriverId());
        vo.setLongitude(104.070354D);
        vo.setLatitude(30.546986D);
        vo.setOrderId(orderInfoVo.getId());
        vo.setPlatformType(PlatformType.ANDROID_PHONE);
        driverOrderService.robOrder(vo);
    }

    private void driverArrive(Long id) {
        DriverOrderReqVo driverOrderReqVo = new DriverOrderReqVo();
        driverOrderReqVo.setOrderId(id);
        driverOrderReqVo.setLongitude(104.070354D);
        driverOrderReqVo.setLatitude(30.546986D);
        driverOrderReqVo.setPlatformType(PlatformType.ANDROID_PHONE);
        orderWorkflowService.driverArrive(driverOrderReqVo);
    }

    private void passengerArrive(OrderInfoVo orderInfoVo) {
        DriverOrderReqVo driverOrderReqVo = new DriverOrderReqVo();
        driverOrderReqVo.setOrderId(orderInfoVo.getId());
        driverOrderReqVo.setLongitude(104.070354D);
        driverOrderReqVo.setLatitude(30.546986D);
        driverOrderReqVo.setAddress(orderInfoVo.getPlanFromAddress());
        driverOrderReqVo.setPlatformType(PlatformType.ANDROID_PHONE);
        orderWorkflowService.passengerArrive(driverOrderReqVo);
    }
}
