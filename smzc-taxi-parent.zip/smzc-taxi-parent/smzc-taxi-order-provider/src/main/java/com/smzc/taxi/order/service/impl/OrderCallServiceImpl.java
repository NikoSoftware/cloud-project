package com.smzc.taxi.order.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.common.utils.JsonUtils;
import com.smzc.taxi.order.dao.mapper.OrderCallHistoryMapper;
import com.smzc.taxi.order.domain.OrderCallHistory;
import com.smzc.taxi.order.service.OrderCallService;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryPageVo;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryVo;
import com.smzc.taxi.service.order.exception.AssertUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;

/**
 * 订单通话历史记录
 *
 * @author : luofei
 * @version : 1.0
 * @date : 2019/5/21 17:11
 */
@Service
public class OrderCallServiceImpl implements OrderCallService {
    @Resource
    OrderCallHistoryMapper orderCallHistoryMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addOrderCallHistory(OrderCallHistoryVo orderCallHistoryVo) {
        AssertUtil.notNull(orderCallHistoryVo, "对象不能为空");
        OrderCallHistory orderCallHistory = JsonUtils.copyProperites(OrderCallHistory.class,orderCallHistoryVo);
        orderCallHistory.setCreatedTime(new Date());
        orderCallHistoryMapper.insert(orderCallHistory);
    }

    @Override
    @RouterDataSource(DataSourceAddr.SLAVE)
    public PageInfo<OrderCallHistoryVo> getPageList(OrderCallHistoryPageVo orderCallHistoryPageVo) {
        PageHelper.startPage(orderCallHistoryPageVo.getPageNum(), orderCallHistoryPageVo.getPageSize());
        PageInfo<OrderCallHistory> result = new PageInfo<>(orderCallHistoryMapper.queryPagedList(orderCallHistoryPageVo.getOrderId(), orderCallHistoryPageVo.getStartNo(), orderCallHistoryPageVo.getPageSize()));
        return JsonUtils.copyPageList(OrderCallHistoryVo.class,result);
    }
}
