package com.smzc.taxi.order.service;

import com.smzc.taxi.service.order.bean.vo.OrderNoteVo;

import java.util.List;

/**
 * 订单留言服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/20
 */
public interface OrderNoteService {

    /**
     * 添加订单留言并推送司机
     */
    void addOrderNote(OrderNoteVo vo);

    /**
     * 根据orderID查询订单留言列表
     */
    List<OrderNoteVo> getPageList(Long orderId);

    /**
     * 根据id列表批量更新留言为已读状态
     */
    void batchUpdateReadStatus(List<Long> idList);
}
