package com.smzc.taxi.order.service;

import com.smzc.market.service.driver.bean.*;
import com.smzc.market.service.driver.enums.BusinessTypeEnum;
import com.smzc.market.service.driver.enums.DriverTypeEnum;
import com.smzc.market.service.passenger.vo.UpdateParticipationRewardHistoryRequestVo;
import com.smzc.taxi.service.dispatch.bean.*;
import com.smzc.taxi.service.dispatch.exception.DispatchException;
import com.smzc.taxi.service.finance.bean.PayRewardVo;
import com.smzc.taxi.service.finance.exception.FinanceException;

import java.util.List;

/**
 *
 * 司机活动服务接口封装
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/17 16:02
 */
public interface OrderDriverMarketActivityService {

    List<DriverMarketActPrizeInfoVo> getDriverMarketActPrizeInfo(MarketActivityPrizeReqVo marketActivityPrizeReqVo);

    void reWardDriver(PayRewardVo payRewardVo)  throws FinanceException;

    void batchUpdateParticipationRewardHistoryStatus(List<UpdateParticipationRewardHistoryRequestVo> list);
}
