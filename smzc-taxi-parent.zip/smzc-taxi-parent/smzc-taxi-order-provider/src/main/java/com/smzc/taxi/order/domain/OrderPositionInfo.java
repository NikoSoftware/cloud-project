package com.smzc.taxi.order.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * .....
 *
 * @author : lufy
 * @version v1.0
 * @date : 2019/5/27
 */
@Data
public class OrderPositionInfo implements Serializable {
    /**
     * 实际上车地址
     */
    private String actFromAddress;
    /**
     * 实际上车纬度
     */
    private Double actFromLatitude;
    /**
     * 实际上车经度
     */
    private Double actFromLongitude;
    /**
     * 实际下车地址
     */
    private String actToAddress;
    /**
     * 实际下车纬度
     */
    private Double actToLatitude;
    /**
     * 实际下车经度
     */
    private Double actToLongitude;
    /**
     * 开始服务时间
     */
    private Date fromTime;
    /**
     * 结束服务时间
     */
    private Date toTime;
    /**
     * 下单上车地址
     */
    private String fromAddress;
    /**
     * 下单上车纬度
     */
    private Double fromLatitude;
    /**
     * 下单上车经度
     */
    private Double fromLongitude;
    /**
     * 下单下车地址
     */
    private String toAddress;
    /**
     * 下单下车纬度
     */
    private Double toLatitude;
    /**
     * 下单下车经度
     */
    private Double toLongitude;

}
