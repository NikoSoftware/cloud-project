package com.smzc.taxi.order.service;

import com.smzc.taxi.service.order.bean.vo.OrderDriverRobVo;
import com.smzc.taxi.service.order.bean.vo.OrderDriverWaitReqVo;
import com.smzc.taxi.service.order.bean.vo.OrderDriverWaitVo;
import com.smzc.taxi.service.order.emun.CommonCode;

import java.util.List;

/**
 * 司机订单服务
 *
 * @author liuxinjie
 * @date 2019/5/15
 * @since 1.0.0
 */
public interface DriverOrderService {

    // 抢单
    CommonCode robOrder(OrderDriverRobVo orderDriverRobVo);

    // 司机 刷新待抢列表
    List<OrderDriverWaitVo> getWaitReceive(OrderDriverWaitReqVo orderDriverWaitReqVo);
}
