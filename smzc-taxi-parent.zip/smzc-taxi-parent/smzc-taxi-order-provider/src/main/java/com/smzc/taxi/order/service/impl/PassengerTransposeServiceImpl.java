package com.smzc.taxi.order.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.order.service.OrderAddressService;
import com.smzc.taxi.order.service.PassengerTransposeService;
import com.smzc.taxi.service.passenger.service.ISafeCallBindFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * .....
 *
 * @author : lufy
 * @version v1.0
 * @date : 2019/6/10
 */
@Service
@Slf4j
public class PassengerTransposeServiceImpl implements PassengerTransposeService {

    @Reference(version = "1.0.0")
    ISafeCallBindFacade iSafeCallBindFacade;

    @Resource
    OrderAddressService orderAddressService;

    @Override
    public void releaseSafeCallPhone(Long orderId) {
        String areaCode = orderAddressService.selectByOrderId(orderId).getPlanFromCityCode();
        try {
            iSafeCallBindFacade.releaseSafeCallPhone(orderId, areaCode);
        } catch (Exception e) {
            log.error("解绑隐号异常，订单id={}，城市编码={}", orderId, areaCode, e);
        }
    }
}
