package com.smzc.taxi.order.service;

import com.github.pagehelper.PageInfo;
import com.smzc.taxi.order.domain.OrderActivity;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryPageVo;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryVo;
import com.smzc.taxi.service.passenger.bean.price.ActivityResultVo;
import com.smzc.taxi.service.passenger.enums.CountPricelType;

import java.util.List;


/**
 *
 * 订单活动
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/19 11:23
 */
public interface OrderActivityService {
    /**
     *
     * @param activityList
     * @param orderId
     * @param countPricelType
     */
    void batchAddOrderActivity(List<ActivityResultVo> activityList, Long orderId, CountPricelType countPricelType);
}
