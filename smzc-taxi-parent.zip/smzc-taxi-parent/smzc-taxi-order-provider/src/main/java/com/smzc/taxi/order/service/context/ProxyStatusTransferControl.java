package com.smzc.taxi.order.service.context;

import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.handler.statustransfer.EventHandler;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.order.util.OrderMail;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.OrderBusinessException;
import com.smzc.taxi.service.order.exception.OrderException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 订单状态控制类
 *
 * @author liuxinjie
 * @version v1.0
 * @date 2019/5/20
 */
@Slf4j
@Component
public class ProxyStatusTransferControl implements SmartInitializingSingleton {

    @Autowired
    private List<EventHandler> eventHandlerLists;
    @Resource
    OrderMail orderMail;

    private final static Map<String, EventHandler> eventHandlerContainer = new HashMap<>(32);

    @Override
    public void afterSingletonsInstantiated() {
        for(EventHandler e : eventHandlerLists){
            OrderServiceHandler orderStatusHandler = AopUtils.getTargetClass(e).getAnnotation(OrderServiceHandler.class);
            if(orderStatusHandler != null){
                OrderStatus[] orderStatuses = orderStatusHandler.fromStatus();
                OrderStatus toStatus = orderStatusHandler.toStatus();
                for (OrderStatus os : orderStatuses) {
                    String key = getMapperKey(os,toStatus);
                    if(eventHandlerContainer.get(key) != null){
                        log.error("OrderStatus：中出现重复的KEY");
                        continue;
                    }
                    eventHandlerContainer.put(key, e);
                }
            }
        }
    }


    private String getMapperKey(OrderStatus from, OrderStatus to) {
        return from + "->" + to;
    }


    private EventHandler getEventHandler(OrderStatus from, OrderStatus to) {
        return eventHandlerContainer.get(getMapperKey(from, to));
    }

    public void transfer(final ControlContext context) {
        final EventHandler eventHandler = getEventHandler(context.getFromStatus(), context.getToStatus());
        if (eventHandler == null) {
            String errMsg = String.format("不被允许的状态流转!订单ID=%s，从[%s]到[%s]状态",context.getOrderId(), context.getFromStatus().getName(), context.getToStatus().getName());
            log.error(errMsg);
            orderMail.sendMail("订单状态流转失败",errMsg);
            throw new OrderBusinessException(errMsg);
        }
        eventHandler.processTransfer(context).processTransferNoTransaction(context);
    }






}
