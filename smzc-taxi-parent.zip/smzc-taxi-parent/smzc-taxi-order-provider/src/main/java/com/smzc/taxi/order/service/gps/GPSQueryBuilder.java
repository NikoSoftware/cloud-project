package com.smzc.taxi.order.service.gps;

import com.smzc.taxi.order.domain.QueryGPSBean;
import com.smzc.taxi.service.order.bean.vo.GPSVo;
import org.apache.commons.compress.utils.Lists;

import java.util.ArrayList;
import java.util.List;

/**
 * GPS查询Builder
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/6/24
 */
public class GPSQueryBuilder implements GPSQuery {

    /**
     * 查询器
     */
    private List<GPSQuery> gpsQueries = Lists.newArrayList();

    public GPSQueryBuilder addQuery(GPSQuery query) {
        gpsQueries.add(query);
        return this;
    }

    @Override
    public List<GPSVo> execute(QueryGPSBean queryGPSBean) {
        for (GPSQuery gpsQuery : gpsQueries) {
            List<GPSVo> gpsVoList = gpsQuery.execute(queryGPSBean);
            if (!gpsVoList.isEmpty()) {
                return gpsVoList;
            }
        }
        return Lists.newArrayList();
    }
}
