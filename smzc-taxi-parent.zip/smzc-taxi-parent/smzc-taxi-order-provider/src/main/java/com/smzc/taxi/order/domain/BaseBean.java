package com.smzc.taxi.order.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author :james
 * @date :2019-05-16
 * 对应表 :order_info
 */
@Data
public class BaseBean implements Serializable {

    /**
     * id
     */
    private Long id;

    /**
     * 是否有效 1：有效 0：无效
     */
    private Byte delFlag = 1;

    /**
     * 版本
     */
    private Integer version = 1;

    /**
     * 创建人名
     */
    private String createdBy;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 更新人名
     */
    private String updatedBy;

    /**
     * 更新时间
     */
    private Date updatedTime;
}