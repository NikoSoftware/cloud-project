package com.smzc.taxi.order.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.common.utils.JsonUtils;
import com.smzc.taxi.order.dao.mapper.OrderActivityMapper;
import com.smzc.taxi.order.dao.mapper.OrderCallHistoryMapper;
import com.smzc.taxi.order.domain.OrderActivity;
import com.smzc.taxi.order.domain.OrderCallHistory;
import com.smzc.taxi.order.service.OrderActivityService;
import com.smzc.taxi.order.service.OrderCallService;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryPageVo;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryVo;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.passenger.bean.price.ActivityResultVo;
import com.smzc.taxi.service.passenger.enums.CountPricelType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * 订单活动
 *
 * @author LiuXinJie
 * @version 1.0
 * @date 2019/7/19 11:29
 */
@Service
public class OrderActivityServiceImpl implements OrderActivityService {

    @Resource
    OrderActivityMapper orderActivityMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void batchAddOrderActivity(List<ActivityResultVo> activityList, Long id, CountPricelType countPricelType) {
        if(!CollectionUtils.isEmpty(activityList)){

            OrderActivity orderAct = new OrderActivity();
            orderAct.setCountPricelType((byte)countPricelType.getCode());
            orderAct.setOrderId(id);
            List<OrderActivity> list = activityList.stream().map(p -> {
                OrderActivity oa = orderAct.clone();
                oa.setActivityId(p.getActivityId());
                oa.setActivityName(p.getActivityName());
                oa.setAmount(p.getAmount());
                return oa;
            }).collect(Collectors.toList());

            orderActivityMapper.batchAdd(list);
        }
    }
}
