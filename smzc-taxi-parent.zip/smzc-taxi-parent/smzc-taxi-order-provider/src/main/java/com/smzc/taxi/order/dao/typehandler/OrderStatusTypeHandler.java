package com.smzc.taxi.order.dao.typehandler;

import com.smzc.taxi.service.order.emun.OrderStatus;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedTypes;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by smzcck on 2019/5/22.
 */
@MappedTypes(OrderStatus.class)
public class OrderStatusTypeHandler extends BaseTypeHandler<OrderStatus> {
    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, OrderStatus orderStatus, JdbcType jdbcType) throws SQLException {
        preparedStatement.setObject(i, orderStatus.getIndex());
    }

    @Override
    public OrderStatus getNullableResult(ResultSet resultSet, String s) throws SQLException {
        final byte index = resultSet.getByte(s);
        if (resultSet.wasNull()) {
            return null;
        }
        return OrderStatus.fromIndex(index);
    }

    @Override
    public OrderStatus getNullableResult(ResultSet resultSet, int i) throws SQLException {
        final byte index = resultSet.getByte(i);
        if (resultSet.wasNull()) {
            return null;
        }
        return OrderStatus.fromIndex(index);
    }

    @Override
    public OrderStatus getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        final byte index = callableStatement.getByte(i);
        if (callableStatement.wasNull()) {
            return null;
        }
        return OrderStatus.fromIndex(index);
    }
}
