package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.order.domain.OrderCancel;

public interface OrderCancelMapper {
    int insert(OrderCancel record);

    int fillReasonByOrderId(OrderCancel record);

    /**
     * 查询订单取消信息（乘客取消）
     *
     * @param orderId 订单id
     * @return OrderCancel
     */
    OrderCancel selectCancelByOrderId(Long orderId);

}