package com.smzc.taxi.order.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author liuxinjie
 * @version 1.0
 * @date 2019/5/23 15:31
 */
@Data
public class OrderPassenger implements Serializable {

    /**
     * 订单id
     */
    private Long orderId;

    // 订单类型  1.即时单 2.预约
    private Byte orderType = 1;

    /**
     * 类型 ： 1.出租车
     */
    private Byte carType;

    /**
     * 计划出发经度
     */
    private Double fromLongitude;

    /**
     * 计划出发纬度
     */
    private Double fromLatitude;

    /**
     * 订单目的经度
     */
    private Double toLongitude;

    /**
     * 订单目的地纬度
     */
    private Double toLatitude;

    // 总行程
    private Integer totalDistance;

    // 出发地址
    private String fromAddress;

    // 到达地址
    private String toAddress;

    /**
     * 订单状态
     */
    private Byte orderStatus;

    // 打车时间
    private Date scheduleTime;

    /**
     * 乘客名称
     */
    private String passengerName;

    /**
     * 乘客电话
     */
    private String passengerPhone;

     private Integer payAmount;
}
