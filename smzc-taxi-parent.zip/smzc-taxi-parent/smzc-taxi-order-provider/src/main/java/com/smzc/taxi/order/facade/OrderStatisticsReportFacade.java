package com.smzc.taxi.order.facade;

import com.alibaba.dubbo.config.annotation.Service;
import com.github.pagehelper.PageInfo;
import com.smzc.taxi.order.service.OrderStatisticsReportService;
import com.smzc.taxi.service.order.bean.vo.IncomeQryVo;
import com.smzc.taxi.service.order.bean.vo.IncomeVo;
import com.smzc.taxi.service.order.facade.IOrderStatisticsReportFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 订单报表统计服务
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/25
 */
@Component
@Service
@Slf4j
public class OrderStatisticsReportFacade implements IOrderStatisticsReportFacade {

    @Resource
    private OrderStatisticsReportService orderStatisticsReportService;

    @Override
    public PageInfo<IncomeVo> queryIncomeList(IncomeQryVo qryVo) {
        try {
            return orderStatisticsReportService.queryIncomeList(qryVo);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }

    @Override
    public IncomeVo queryIncomeByOrderId(Long orderId) {
        try {
            return orderStatisticsReportService.queryIncomeByOrderId(orderId);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        }
    }
}
