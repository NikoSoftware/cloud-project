package com.smzc.taxi.order.service.handler.statustransfer;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.order.dao.mapper.OrderEvaluateMapper;
import com.smzc.taxi.order.domain.OrderEvaluate;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.driver.bean.DriverEvaluateProviderVo;
import com.smzc.taxi.service.driver.service.IDriverFacade;
import com.smzc.taxi.service.order.bean.vo.OrderEvaluateVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.AssertUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;

import javax.annotation.Resource;
import java.util.Date;

/**
 * 用户评价流程处理实现类
 * 待评价流转到已完成
 * @author zhousong
 * @version v1.0
 * @date 2019/5/21
 */
@Slf4j
@OrderServiceHandler(fromStatus = OrderStatus.WAIT_EVALUATE, toStatus = OrderStatus.FINISH)
public class PassengerEvaluateOrderHandler extends OrderHandler {
    @Resource
    private OrderEvaluateMapper orderEvaluateMapper;

    @Reference(version = "1.0.0")
    private IDriverFacade driverFacade;

    @Override
    public void process(ControlContext context) {
        //验证
        OrderEvaluateVo orderEvaluateVo = (OrderEvaluateVo) context.get("orderEvaluateVo");
        AssertUtil.notNull(orderEvaluateVo, "没有找到评价信息");
        Long orderId = orderEvaluateVo.getOrderId();
        AssertUtil.notNull(orderId, "订单id不为空");
        int count = orderEvaluateMapper.countByOrderId(orderId);
        AssertUtil.isTrue(count == 0, "订单已被评价，请不要重复评价哦");
        //保存数据
        OrderEvaluate orderEvaluate = new OrderEvaluate();
        BeanUtils.copyProperties(orderEvaluateVo, orderEvaluate);
        orderEvaluate.setCreatedTime(new Date());
        orderEvaluateMapper.insert(orderEvaluate);
        //更新司机评分
        DriverEvaluateProviderVo driverEvaluateProviderVo = new DriverEvaluateProviderVo();
        driverEvaluateProviderVo.setDriverId(orderEvaluateVo.getDriverId());
        driverEvaluateProviderVo.setEvaluateScore(Integer.parseInt(orderEvaluateVo.getScore().toString()));
        try {
            driverFacade.updateDriverEvaluate(driverEvaluateProviderVo);
        } catch (Exception e) {
            log.error("更新司机评分失败,评价信息[订单id:{},评星数:{}],失败原因:{}", orderId, orderEvaluateVo.getScore(), e);
        }
    }


    @Override
    public ControlContext next(ControlContext context) {
        return super.next(context);
    }
}
