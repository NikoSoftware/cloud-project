package com.smzc.taxi.order.service.impl;

import com.baidu.fsg.uid.UidGenerator;
import com.smzc.taxi.order.service.OrderCommonService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * 订单公共服务：
 * 1.雪花算法生成uid
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/6/17
 */
@Service
public class OrderCommonServiceImpl implements OrderCommonService {

    @Resource
    private UidGenerator uidGenerator;

    @Override
    public Long getUID() {
        return uidGenerator.getUID();
    }
}
