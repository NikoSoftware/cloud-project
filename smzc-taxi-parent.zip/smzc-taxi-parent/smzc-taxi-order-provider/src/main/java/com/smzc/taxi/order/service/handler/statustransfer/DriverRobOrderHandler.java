package com.smzc.taxi.order.service.handler.statustransfer;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.smzc.taxi.order.domain.OrderCacheBean;
import com.smzc.taxi.order.domain.OrderInfo;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.driver.bean.DriverVehicleInfoProvideVo;
import com.smzc.taxi.service.driver.bean.DriverWorkStateTurnVo;
import com.smzc.taxi.service.driver.enums.DriverWorkStateEnum;
import com.smzc.taxi.service.driver.service.IDriverFacade;
import com.smzc.taxi.service.order.emun.OrderAddType;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.AssertUtil;
import com.smzc.taxi.service.order.exception.OrderException;
import lombok.extern.slf4j.Slf4j;

/**
 * 司机抢单成功实现类
 * 抢单成功 抢单中流转到 已出发
 *
 * @author liuxinjie
 * @version 1.0
 * @date 2019/5/24 9:28
 */
@Slf4j
@OrderServiceHandler(fromStatus = {OrderStatus.WAIT_DRIVER_CONFIRM, OrderStatus.AUTO_DISPATCHING}, toStatus = OrderStatus.DRIVER_STARTING)
public class DriverRobOrderHandler extends OrderHandler {

    @Reference(version = "1.0.0")
    private IDriverFacade driverFacade;

    @Override
    public void process(ControlContext context) {
        // 修改订单写入司机信息
        OrderInfoContext orderInfo = context.getEntity();

        // 调用司机接口根据司机ID获取司机名称，电话，所属出租车公司名称,出租车ID，车牌号
        DriverVehicleInfoProvideVo driverBean = getDriverVehicleInfoByDriverId(orderInfo.getDriverId());
        AssertUtil.notNull(driverBean, "获取司机数据异常");
        AssertUtil.notNull(driverBean.getVehicleId(), "车辆ID不能为空");
        AssertUtil.hasText(driverBean.getVehicleNo(), "车牌号不能为空");
        AssertUtil.notNull(driverBean.getDriverCompanyId(), "所属公司ID不能为空");
        AssertUtil.hasText(driverBean.getDriverCompany(), "所属公司名称不能为空");
        AssertUtil.hasText(driverBean.getMobilePhone(), "司机联系电话不能为空");

        // 司机抢单成功后  修改订单表的司机信息
        updateDriverInfo(orderInfo, driverBean);
    }

    @Override
    public void defaultMethod(ControlContext context) {
        super.defaultMethod(context);

        // 写入缓存
        OrderInfoContext orderInfo = context.getEntity();
        // 修改缓存内容
        OrderCacheBean orderCache = orderService.getOrderCache(orderInfo.getId());
        if (orderCache != null) {
            orderCache.setDriverId(orderInfo.getDriverId());
            orderCache.setDriverPhone(orderInfo.getDriverPhone());
            orderCache.setDriverName(orderInfo.getDriverName());
            orderCache.setVehicleId(orderInfo.getVehicleId());
            orderCache.setVehicleNo(orderInfo.getVehicleNo());
            orderRedis.setOrderCache(orderCache);
        }
    }

    @Override
    public void transactionMethod(ControlContext context) {
        super.transactionMethod(context);

        OrderInfoContext orderInfo = context.getEntity();
        // 更新司机状态
        final DriverWorkStateEnum nextStatus = DriverWorkStateEnum.DRIVER_INSERVICE;
        final DriverWorkStateTurnVo driverWorkStateTurnVo = super.getDriverWorkStateTurnVo(context, nextStatus);
        driverWorkStateTurnVo.setNextState(nextStatus);

        try {
            driverFacade.driverWorkStateTurn(driverWorkStateTurnVo);
            log.info("订单ID: {} 被司机：{} 抢，修改司机状态为{}，成功", context.getOrderId(), orderInfo.getDriverName(), nextStatus.getName());
        } catch (Exception e) {
            log.error("司机状态流转失败，主业务回滚。司机id={}的状态修改成[{}]，参数：{}。失败原因{}",
                    driverWorkStateTurnVo.getDriverId(),
                    nextStatus.getName(), JSON.toJSONString(driverWorkStateTurnVo), e);
            throw e;
        }
    }

    private void updateDriverInfo(OrderInfoContext orderInfo, DriverVehicleInfoProvideVo driverBean) {
        OrderInfo param = new OrderInfo();

        param.setId(orderInfo.getId());
        param.setDriverId(orderInfo.getDriverId());
        param.setDriverName(driverBean.getDriverName());
        param.setDriverPhone(driverBean.getMobilePhone());
        param.setDriverCompany(driverBean.getDriverCompany());
        param.setDriverCompanyId(driverBean.getDriverCompanyId());
        param.setVehicleId(driverBean.getVehicleId());
        param.setVehicleNo(driverBean.getVehicleNo());

        orderInfo.setVehicleId(driverBean.getVehicleId());
        orderInfo.setVehicleNo(driverBean.getVehicleNo());
        orderInfo.setDriverCompanyId(driverBean.getDriverCompanyId());
        orderInfo.setDriverCompany(driverBean.getDriverCompany());
        orderInfo.setDriverName(driverBean.getDriverName());
        orderInfo.setDriverPhone(driverBean.getMobilePhone());

        int updFlag = orderService.updateByPrimaryKeySelective(param);
        if (updFlag <= 0) {
            throw new OrderException("抢单成功，但给订单绑定司机时失败");
        }
    }

    /**
     * 调用司机接口根据司机ID获取司机名称，电话，所属出租车公司名称,出租车ID，车牌号
     *
     * @param driverId
     * @return
     */
    private DriverVehicleInfoProvideVo getDriverVehicleInfoByDriverId(Long driverId) {
        DriverVehicleInfoProvideVo driverBean = null;
        log.debug("开始调用司机接口，司机ID：{}", driverId);
        try {
            driverBean = driverFacade.getDriverVehicleInfoByDriverId(driverId);

            log.debug("司机端返回数据:{}", JSON.toJSONString(driverBean));

        } catch (Exception e) {
            log.error("司机ID：{}，抢单获取司机信息异常。", driverId, e);
        }
        return driverBean;
    }

    @Override
    public boolean isPushMessage(ControlContext context) {
        return context.getEntity().getAddType() != OrderAddType.NEW_ADD.getIndex();
    }
}
