package com.smzc.taxi.order.service.handler.statustransfer;

import com.alibaba.fastjson.JSON;
import com.smzc.taxi.order.domain.OrderAddress;
import com.smzc.taxi.order.domain.OrderInfoContext;
import com.smzc.taxi.order.service.ControlContext;
import com.smzc.taxi.order.service.annotation.OrderServiceHandler;
import com.smzc.taxi.service.dispatch.bean.DispatchResponse;
import com.smzc.taxi.service.dispatch.bean.DispatchTaxiVehicleBean;
import com.smzc.taxi.service.dispatch.bean.RecommendedVehicle;
import com.smzc.taxi.service.order.emun.OrderAddType;
import com.smzc.taxi.service.order.emun.OrderStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * 自动调度实现类
 * 待处理 流转到自动调度
 *
 * @author liuinjie
 * @version 1.0
 * @date 2019-5-21
 */
@Slf4j
@OrderServiceHandler(fromStatus = OrderStatus.WAIT_RECEIVE, toStatus = OrderStatus.AUTO_DISPATCHING)
public class AutoDispatchHandler extends OrderHandler {


    @Override
    public void process(ControlContext context) {
        OrderInfoContext orderInfo = context.getEntity();

        // 从待处理流转到自动调度需要处理的业务
        // 2.调用调度系统掇单
        // 3.调用司机系统推送消息

        // 调用调度接口计算出哪此司机可抢此订单

        // 邀新订单 指定司机和车辆
        List<RecommendedVehicle> list;
        if (OrderAddType.NEW_ADD.getIndex() == orderInfo.getAddType().byteValue()) {
            RecommendedVehicle rv = new RecommendedVehicle();
            rv.setDriverId(orderInfo.getDriverId());
            rv.setVehicleId(orderInfo.getVehicleId());
            list = Collections.singletonList(rv);
        } else {
            list = dispatchTaxiVehicle(orderInfo);
        }

        if (CollectionUtils.isEmpty(list)) {
            // 撮单失败，不流转到下一个流程
            context.setTransferNextStatus(false);
            log.info("OrderId:{},撮单失败，不流转到下一个流程", context.getOrderId());
        } else {
            log.info("OrderId:{},撮单成功，司机列表：{}", context.getOrderId(), JSON.toJSONString(list));
            context.put("vehicleList", list);
        }

    }

    private List<RecommendedVehicle> dispatchTaxiVehicle(OrderInfoContext orderInfo) {
        final Long orderId = orderInfo.getId();
        OrderAddress orderAddress = orderInfo.getOrderAddress();
        DispatchTaxiVehicleBean vehicleBean = new DispatchTaxiVehicleBean();
        vehicleBean.setSubscriberId(orderInfo.getSubscriberId());
        vehicleBean.setAreaCode(orderInfo.getCityCode());
        vehicleBean.setOrderNo(orderId.toString());
        vehicleBean.setAssignTime(new Date());
        vehicleBean.setStartLat(orderAddress.getPlanFromLatitude());
        vehicleBean.setStartLng(orderAddress.getPlanFromLongitude());
        vehicleBean.setEndLat(orderAddress.getPlanToLatitude());
        vehicleBean.setEndLng(orderAddress.getPlanToLongitude());
        vehicleBean.setFictitiousOrder(false);
        DispatchResponse<List<RecommendedVehicle>> resp = new DispatchResponse<>();

        log.info("进入调度：[经度{}，纬度{}]", orderAddress.getPlanFromLongitude(), orderAddress.getPlanFromLatitude());
        int maxNum = 3;
        do {
            try {
                resp = orderDispatchService.dispatchTaxiVehicle(vehicleBean);

                // 如果没有异常就结束循环
                break;
            } catch (Exception e) {
                log.error("调用调度中心，获取撮单列表异常！第{}次进入循环调度。订单id={}，经度{}，纬度{}", (4 - maxNum), orderId, orderAddress.getPlanToLongitude(), orderAddress.getPlanToLatitude(), e);
                sleep(500);
            }
        } while (--maxNum > 0);
        return resp.getData();
    }

    @Override
    public ControlContext next(ControlContext context) {
        // 自动调度结束后订单状态自动流转到司机抢单中
        // 撮单失败，不流转到下一个流程
        if (context.isTransferNextStatus()) {
            ControlContext resContext = new ControlContext();
            BeanUtils.copyProperties(context, resContext);
            resContext.setFromStatus(context.getToStatus());
            resContext.setToStatus(OrderStatus.WAIT_DRIVER_CONFIRM);
            resContext.put("vehicleList", context.get("vehicleList"));
            return resContext;
        }
        return super.next(context);
    }


    @Override
    public boolean isPushMessage(ControlContext context) {
        return false;
    }

    @Override
    public void defaultMethod(ControlContext context) {
        super.defaultMethod(context);
        // 写入缓存,邀新订单不写待抢缓存和待取消缓存，可避免被其它司机抢到单
        Byte addType = context.getEntity().getAddType();
        if (OrderAddType.NEW_ADD.getIndex() != addType.byteValue()) {
            writeOrderCache(context.getEntity());
        }
    }

    private void writeOrderCache(OrderInfoContext orderInfoContext) {
        // 写入待抢缓存，最多保留5分钟,时间可配置
        orderRedis.setWaitRobOrder(orderInfoContext);

        // 写入缓存列表，等待定时任务检测是否达到取消的标准
        orderRedis.setWaitCancelOrderLeftPush(orderInfoContext);
    }

}
