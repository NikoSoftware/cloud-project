package com.smzc.taxi.order.service.context;

import com.smzc.taxi.order.service.annotation.OrderAddTypeHandler;
import com.smzc.taxi.order.service.handler.discount.DiscountHandler;
import com.smzc.taxi.service.order.emun.OrderAddType;
import com.smzc.taxi.service.order.exception.AssertUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 奖励优惠代理控制
 *
 * @author liuxinjie
 * @version v1.0
 * @date 2019/5/20
 */
@Slf4j
@Component
public class ProxyDiscountControl implements SmartInitializingSingleton {

    @Autowired
    private List<DiscountHandler> discountHandlers;

    private final static Map<String, DiscountHandler> eventHandlerContainer = new HashMap<>();

    @Override
    public void afterSingletonsInstantiated() {
        for (DiscountHandler e : discountHandlers) {
            OrderAddTypeHandler orderAddTypeHandler = AopUtils.getTargetClass(e).getAnnotation(OrderAddTypeHandler.class);
            if (orderAddTypeHandler != null) {
                OrderAddType orderStatuses = orderAddTypeHandler.discount();
                String discount = orderStatuses.getDiscount();
                if (eventHandlerContainer.get(discount) != null) {
                    log.error("discountHandlers：中出现重复的KEY");
                }
                eventHandlerContainer.put(discount, e);
            }
        }
    }
    public static DiscountHandler getDiscountHandler(OrderAddType type) {
        DiscountHandler handler = eventHandlerContainer.get(type.getDiscount());
        AssertUtil.notNull(handler,"未打到奖励优惠策略实现");
        return handler;
    }

}
