package com.smzc.taxi.order.service.impl;

import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;
import com.smzc.taxi.order.dao.mapper.OrderFeedbackMapper;
import com.smzc.taxi.order.domain.OrderFeedback;
import com.smzc.taxi.order.service.OrderFeedbackService;
import com.smzc.taxi.service.order.bean.vo.OrderFeedBackVo;
import com.smzc.taxi.service.order.exception.AssertUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 订单反馈服务实现类
 *
 * @author zhousong
 * @version v1.0
 * @date 2019/5/22
 */
@Slf4j
@Service
public class OrderFeedbackServiceImpl implements OrderFeedbackService {
    @Resource
    private OrderFeedbackMapper orderFeedbackMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addOrderFeedback(OrderFeedBackVo vo) {
        //验证
        AssertUtil.notNull(vo, "对象不能为空");
        AssertUtil.notNull(vo.getFeedbackType(), "反馈类型不能为空");
        AssertUtil.notNull(vo.getOrderId(), "订单id不能为空");

        //保存数据
        OrderFeedback orderFeedback = new OrderFeedback();
        BeanUtils.copyProperties(vo, orderFeedback);
        orderFeedback.setCreatedTime(new Date());
        orderFeedbackMapper.insert(orderFeedback);
        log.info("用户添加反馈，订单id:{},反馈类型:{}", vo.getOrderId(),vo.getFeedbackType());
    }

    @RouterDataSource(DataSourceAddr.SLAVE)
    @Override
    public List<OrderFeedBackVo> selectByOrderId(Long orderId) {
        AssertUtil.notNull(orderId, "订单id不能为空");
        List<OrderFeedback> feedbackList = orderFeedbackMapper.selectByOrderId(orderId);
        if (CollectionUtils.isEmpty(feedbackList)) {
            return new ArrayList<>();
        }
        List<OrderFeedBackVo> voList = new ArrayList<>();
        for (OrderFeedback orderFeedback : feedbackList) {
            OrderFeedBackVo vo = new OrderFeedBackVo();
            BeanUtils.copyProperties(orderFeedback, vo);
            voList.add(vo);
        }
        return voList;
    }
}
