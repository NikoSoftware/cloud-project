package com.smzc.taxi.order.test.bean;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * .....
 *
 * @author : lufy
 * @version v1.0
 * @date : 2019/5/30
 */
@Data
public class Fa {
    private String name;
}
