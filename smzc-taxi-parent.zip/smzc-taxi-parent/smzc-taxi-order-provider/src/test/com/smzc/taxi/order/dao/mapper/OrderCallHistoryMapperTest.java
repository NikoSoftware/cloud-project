package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.OrderProviderApplication;
import com.smzc.taxi.order.domain.OrderCallHistory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {OrderProviderApplication.class})
public class OrderCallHistoryMapperTest {
    @Resource
    OrderCallHistoryMapper orderCallHistoryMapper;

    @Test
    public void queryPagedList() {
        List<OrderCallHistory> result =  orderCallHistoryMapper.queryPagedList(3279843323097694208L,1,20);
        System.out.println(result.size());
    }
}