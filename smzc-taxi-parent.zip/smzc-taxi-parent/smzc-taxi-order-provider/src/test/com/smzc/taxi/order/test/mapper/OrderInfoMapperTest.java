package com.smzc.taxi.order.test.mapper;

import com.smzc.taxi.order.domain.OrderInfo;
import com.smzc.taxi.order.domain.OrderPassenger;
import com.smzc.taxi.order.domain.OrderPassengerDto;
import com.smzc.taxi.service.order.bean.vo.CityInfoVo;
import com.smzc.taxi.service.order.bean.vo.OrderDrivingVo;
import com.smzc.taxi.service.order.bean.vo.OrderTripShareVo;
import com.smzc.taxi.service.portal.bean.PriceModifyInnerVo;
import com.smzc.taxi.service.portal.bean.PriceModifyRespVo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderInfoMapperTest {
    List<OrderInfo> selectAllOrders();
}
