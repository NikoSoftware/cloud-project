package com.smzc.taxi.order.test;

import com.smzc.taxi.common.utils.JsonUtils;
import com.smzc.taxi.order.test.bean.Fa;
import com.smzc.taxi.order.test.bean.Son;
import com.smzc.taxi.order.test.bean.SonVo;
import com.smzc.taxi.order.util.SuperBeanUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.BeanUtils;

/**
 * .....
 *
 * @author : lufy
 * @version v1.0
 * @date : 2019/5/30
 */
public class BeanUtilTest {
    @Test
    public void copyPrsTest() {
        Son son = new Son();
        SonVo sonVo = new SonVo();
        sonVo.setAge(10);
        sonVo.setName("lufy");
        BeanUtils.copyProperties(sonVo, son);
        Assert.assertEquals(sonVo.getName(), son.getName());
        Assert.assertEquals("lufy", son.getName());
    }

    @Test
    public void copyDePrsTest() {
        SonVo sonVo = new SonVo();
        Son son = new Son();
        son.setAge(10);
        son.setName("lufy");
        SonVo sonVo1 = JsonUtils.copyProperites(SonVo.class, son);
        BeanUtils.copyProperties(son, sonVo);
        Assert.assertEquals(sonVo.getName(), son.getName());
        Assert.assertEquals("lufy", son.getName());
    }

    @Test
    public void copySePrsTest() {
        Son sonVo = new Son();
        Son son = new Son();
        son.setAge(10);
        son.setName("lufy");
        BeanUtils.copyProperties(son, sonVo);
        Assert.assertEquals(sonVo.getName(), son.getName());
        Assert.assertEquals("lufy", son.getName());
    }

    @Test
    public void test() {
        Fa f1 = new Fa();
        f1.setName("father");
        Son s1 = new Son();
        s1.setAge(11);
        s1.setName("fa");

        Fa f2 = new Fa();
        f2.setName("father");
        Son s2 = new Son();
        s2.setAge(11);

        SuperBeanUtils.copy(s2, s1);
        System.out.println();
    }
}
