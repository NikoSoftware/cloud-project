package com.smzc.taxi.order.test.bean;

import lombok.Data;

/**
 * .....
 *
 * @author : lufy
 * @version v1.0
 * @date : 2019/5/30
 */
@Data
public class SonVo {
    private String name;
    private int age;
}
