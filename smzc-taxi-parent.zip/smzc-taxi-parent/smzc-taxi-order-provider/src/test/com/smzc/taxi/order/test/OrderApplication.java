package com.smzc.taxi.order.test;

import com.smzc.taxi.OrderProviderApplication;
import com.smzc.taxi.boot.mq.SmRocketMqTemplate;
import com.smzc.taxi.common.consts.MQTagsConst;
import com.smzc.taxi.common.consts.MQTopicConst;
import com.smzc.taxi.common.utils.JsonUtils;
import com.smzc.taxi.order.dao.es.OrderDocRepo;
import com.smzc.taxi.order.service.*;
import com.smzc.taxi.order.util.DistributedLockManager;
import com.smzc.taxi.order.util.OrderRedis;
import com.smzc.taxi.service.order.bean.mq.MqMessageBody;
import com.smzc.taxi.service.order.bean.vo.OrderPassengerVo;
import com.smzc.taxi.service.order.emun.*;
import com.smzc.taxi.service.portal.bean.PriceModifyInnerVo;
import com.smzc.taxi.service.portal.bean.PriceModifyUpdVo;
import com.smzc.taxi.service.portal.enums.PriceModifyReasonEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.Message;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 测试
 */
@SpringBootTest(classes = OrderProviderApplication.class)
@RunWith(SpringRunner.class)
@Slf4j
public class OrderApplication {


    @Resource
    private OrderDocRepo orderDocRepo;

    @Resource
    private ElasticsearchTemplate elasticsearchTemplate;

    @Resource
    private OrderService orderService;

    @Resource
    private OrderAdminService orderAdminService;

    @Resource
    private DriverOrderService driverOrderService;

    @Resource
    private DistributedLockManager distributedLockManager;

    @Resource
    OrderWorkflowService orderWorkflowService;

    @Resource
    OrderPayoffService orderPayoffService;
    @Resource
    OrderStatusHistoryService orderStatusHistoryService;
    @Resource
    OrderRedis orderRedis;

    @Resource
    RedisTemplate redisTemplate;
    @Autowired
    private SmRocketMqTemplate rocketMqTemplate;






    static {
        System.setProperty("es.set.netty.runtime.available.processors", "false");
    }

    /**
     * 执行开始时间（毫秒）
     */
    private Long startTime;

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");


    /**
     * 自动取消
     */
    @Test
    public void rejectOrder() {
        orderService.autoCancelOrder("");
    }





    @Test
    public void sendMsg() {
        try {
            MqMessageBody orderStatusTransfer = new MqMessageBody();
            orderStatusTransfer.setOrderId(1111L);
            orderStatusTransfer.setSubscriberId(27L);
            orderStatusTransfer.setFromStatus(OrderStatus.DRIVER_STARTING.getIndex());
            orderStatusTransfer.setToStatus(OrderStatus.DRIVER_STARTING.getIndex());

            // 发送
            rocketMqTemplate.syncSend(MQTopicConst.TAXI_ORDER,MQTagsConst.WAIT_PAY_CANCEL,orderStatusTransfer);

            log.info("消息发送成功。订单{}，{}子主题", 1111L);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("订单{}，mq消息推送异常状态流转：{}", 1111L);
        }
    }

    @Test
    public void updatePayOff(){

        Long orderId = 3317851996963217409L;
        PriceModifyInnerVo innerVo = orderAdminService.getPriceModifyInfo(orderId);

        PriceModifyUpdVo updVo = new PriceModifyUpdVo();
        updVo.setOrderId(orderId.toString());
        updVo.setReasonType(PriceModifyReasonEnum.OPERERR.getIndex());
        updVo.setReason("jsdlfjal");
        updVo.setAdjustBasicAmount("1");
        updVo.setAdjustBridgeAmount("1");
        updVo.setAdjustCleanAmount("1");
        updVo.setAdjustParkAmount("1");
        updVo.setUpdatedBy("sllsdjlasdf");
        orderPayoffService.updPayoffDetail(updVo,innerVo);
    }

    @Test
    public void getOrderListByCurrentDay() {

        List<OrderPassengerVo> orderListByCurrentDay = orderService.getOrderListByCurrentDay(1L);
        System.out.println(orderListByCurrentDay.toString());
    }

    /**
     * 清所有缓存
     */
    @Test
    public void clearRedisAll() {
        orderRedis.clearAll();
        orderDocRepo.deleteAll();
    }


    @Before
    public void before() {
        System.out.println();
        System.out.println();
        log.debug("----------------------test uint start--------------------------------------------");
        Date now = new Date();
        this.startTime = now.getTime();
        log.debug("执行开始时间{}", sdf.format(now));
        System.out.println();
    }

    @After
    public void after() {
        System.out.println();
        log.debug("-----------------------test uint end---------------------------------------------");
        Date now = new Date();
        log.debug("执行结束时间{}，总耗时：{}毫秒", sdf.format(now), now.getTime() - startTime);
        System.out.println();
        System.out.println();
    }

}
