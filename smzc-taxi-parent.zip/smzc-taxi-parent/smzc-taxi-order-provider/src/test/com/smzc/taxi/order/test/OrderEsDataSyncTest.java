package com.smzc.taxi.order.test;

import com.google.common.collect.Lists;
import com.smzc.taxi.OrderProviderApplication;
import com.smzc.taxi.order.dao.es.OrderDoc;
import com.smzc.taxi.order.dao.es.OrderDocRepo;
import com.smzc.taxi.order.domain.OrderInfo;
import com.smzc.taxi.order.service.OrderAdminService;
import com.smzc.taxi.order.test.mapper.OrderInfoMapperTest;
import com.smzc.taxi.order.util.SuperBeanUtils;
import com.smzc.taxi.service.order.bean.dto.OrderDocDto;
import com.smzc.taxi.service.order.bean.vo.OrderQueryVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.DefaultResultMapper;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.ScrolledPage;
import org.springframework.data.elasticsearch.core.SearchResultMapper;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static com.smzc.taxi.service.order.emun.OrderStatus.*;

/**
 * todo
 *
 * @author tangqiandong
 * @version v1.0
 * @date 2019/6/3
 */
@SpringBootTest(classes = OrderProviderApplication.class)
@MapperScan(basePackages = {"com.smzc.taxi.order.test.mapper"})
@RunWith(SpringRunner.class)
@Slf4j
public class OrderEsDataSyncTest {

    static {
        System.setProperty("es.set.netty.runtime.available.processors", "false");
    }

    /**
     * 执行开始时间（毫秒）
     */
    private Long startTime;

    /**
     * 日期格式化
     */
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");

    @Resource
    private OrderDocRepo orderDocRepo;

    @Resource
    private OrderInfoMapperTest orderInfoMapperTest;

    @Resource
    private OrderAdminService orderAdminService;

    @Before
    public void before() {
        System.out.println();
        System.out.println();
        log.debug("----------------------test uint start--------------------------------------------");
        Date now = new Date();
        this.startTime = now.getTime();
        log.debug("执行开始时间{}", sdf.format(now));
        System.out.println();
    }

    @After
    public void after() {
        System.out.println();
        log.debug("-----------------------test uint end---------------------------------------------");
        Date now = new Date();
        log.debug("执行结束时间{}，总耗时：{}毫秒", sdf.format(now), now.getTime() - startTime);
        System.out.println();
        System.out.println();
    }

    @Test
    public void clear() {
        orderDocRepo.deleteAll();
    }

    @Test
    public void printAll() {
        Iterable<OrderDoc> all = orderDocRepo.findAll();
        all.forEach(System.out::println);
    }

    @Test
    public void syncDbToEs() {
//        clear();
//        printAll();
        List<OrderInfo> orderInfoList = orderInfoMapperTest.selectAllOrders();
        List<OrderDoc> orderDocList = orderInfoList.parallelStream().map(item -> {
            OrderDoc orderDoc = new OrderDoc();
            BeanUtils.copyProperties(item, orderDoc);
            orderDoc.setStatus(item.getStatus().getIndex());
            return orderDoc;
        }).collect(Collectors.toList());
        orderDocRepo.saveAll(orderDocList);
//        printAll();
    }

    @Test
    public void test() {
        OrderQueryVo orderQueryVo = new OrderQueryVo();
        orderAdminService.queryExportOrderList(orderQueryVo);
    }

    /**
     * SCROLL_TIME_IN_MILLIS
     */
    private static long SCROLL_TIME_IN_MILLIS = 1000;

    @Resource
    private ElasticsearchTemplate elasticsearchTemplate;


    @Test
    public void queryByTpl() {
        final List<OrderDocDto> orderDocDtoList = Lists.newArrayList();
        final int pageSize = 1000;

//        三天前的数据
        final LocalDate now = LocalDate.now();
        final Long t1 = now.plus(-3, ChronoUnit.DAYS).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
        final Long t2 = now.plus(0, ChronoUnit.DAYS).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() - 1;

//          已完成、待评价、已驳回、已取消、自动取消
//          3天前
//          城市权限
        List<Byte> statusList = Lists.newArrayList(FINISH.getIndex(), WAIT_EVALUATE.getIndex(), REJECTED.getIndex(), CANCEL.getIndex(), SYS_CANCEL.getIndex());
        SearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withQuery(QueryBuilders.boolQuery()
                        .filter(QueryBuilders.termsQuery("status", statusList))
                        .must(QueryBuilders.rangeQuery("createdTime").gte(t1).lte(t2))
                        .must(QueryBuilders.termsQuery("cityCode", "028"))
                )
                .withSort(SortBuilders.fieldSort("id").order(SortOrder.DESC))
                .withPageable(PageRequest.of(0, pageSize))
                .build();

        SearchResultMapper searchResultMapper = new DefaultResultMapper();
        ScrolledPage<OrderDoc> orderDocPage = (ScrolledPage<OrderDoc>) elasticsearchTemplate.startScroll(SCROLL_TIME_IN_MILLIS, searchQuery, OrderDoc.class, searchResultMapper);
        while (orderDocPage.hasContent()) {
            for (OrderDoc item : orderDocPage.getContent()) {
                OrderDocDto orderDocDto = new OrderDocDto();
                SuperBeanUtils.copy(item, orderDocDto);
                orderDocDto.setId(item.getId().toString());
                orderDocDto.setStatusText(OrderStatus.fromIndex(item.getStatus()).getName());
                orderDocDto.setCreatedTimeText(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(item.getCreatedTime()));
                orderDocDtoList.add(orderDocDto);
            }
            orderDocPage = (ScrolledPage<OrderDoc>) elasticsearchTemplate.continueScroll(orderDocPage.getScrollId(), SCROLL_TIME_IN_MILLIS, OrderDoc.class, searchResultMapper);
        }
        System.out.println(orderDocDtoList.size());
        List<OrderDocDto> orderDocDtoList1 = orderDocDtoList.subList(0, 712);
        System.out.println(orderDocDtoList1.size());
//        orderDocDtoList.forEach(System.out::println);
    }
}
