package com.smzc.taxi.order.facade;

import com.smzc.taxi.OrderProviderApplication;
import com.smzc.taxi.order.dao.mapper.OrderInfoMapper;
import com.smzc.taxi.order.dao.mapper.OrderPayoffMapper;
import com.smzc.taxi.order.dao.mapper.OrderStatusHistoryMapper;
import com.smzc.taxi.order.domain.OrderInfo;
import com.smzc.taxi.order.domain.OrderPayoff;
import com.smzc.taxi.order.service.OrderService;
import com.smzc.taxi.service.order.bean.vo.OrderCancelVo;
import com.smzc.taxi.service.order.bean.vo.OrderRejectRespVo;
import com.smzc.taxi.service.order.bean.vo.OrderRejectVo;
import com.smzc.taxi.service.order.emun.OrderStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {OrderProviderApplication.class})
public class OrderFacadeTest {
    @Resource
    private OrderService orderService;
    @Resource
    private OrderInfoMapper orderInfoMapper;
    @Resource
    private OrderPayoffMapper orderPayoffMapper;
    @Resource
    private OrderStatusHistoryMapper orderStatusHistoryMapper;

    static {
        System.setProperty("es.set.netty.runtime.available.processors", "false");
    }

    @Before
    public void initData() {
//        resetData(3285127644699090944L,OrderStatus.DRIVER_STARTING);
//        resetData(3285152005753618432L,OrderStatus.DRIVER_ARRIVE);
//        resetData(3285162485473828864L,OrderStatus.DRIVER_STARTING);
//        resetData(3285152005753618432L,OrderStatus.DRIVER_ARRIVE);
    }

    @Test
    public void cancelOrderWithoutFee() {
        resetData(3302117435812610055L, OrderStatus.DRIVER_STARTING);
        cancelOrderTest(3302117435812610055L, "has fee");
    }

    @Test
    public void cancelOrderWithFee() {
        resetData(3302117435812610055L, OrderStatus.DRIVER_ARRIVE);
        cancelOrderTest(3302117435812610055L, "");
    }

    @Test
    public void rejectOrderWithFee() {
        resetData(3285162485473828864L, OrderStatus.DRIVER_STARTING);
        rejectOrder(3285162485473828864L, "");
    }

    @Test
    public void rejectOrderWithOutFee() {
        resetData(3285152005753618432L, OrderStatus.DRIVER_ARRIVE);
        rejectOrder(3285166436843765760L, "has fee");
    }

    @Test
    public void fillCancelReasonTest() {
        OrderCancelVo orderCancelVo = new OrderCancelVo();
        orderCancelVo.setOrderId(3282329731203022848L);
        orderCancelVo.setCancelReason("fillCancelReasonTest1");
        orderService.fillCancelReason(orderCancelVo);
        try {
            Thread.sleep(10000);//内部有异步
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void getRejectOrderReasonTest() {
        OrderRejectRespVo orderRejectRespVo = orderService.getOrderRejectReason(3282329731203022848L);
    }

    private void rejectOrder(Long orderId, String tag) {
        OrderRejectVo orderRejectVo = new OrderRejectVo();
        orderRejectVo.setOrderId(orderId);
        orderRejectVo.setRejectBy("lufy");
        orderRejectVo.setRejectReason("驳回理由 " + tag);
        orderRejectVo.setRespResource((byte) 1);
        orderService.rejectOrder(orderRejectVo);
        try {
            Thread.sleep(10000);//内部有异步
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void cancelOrderTest(Long orderId, String tag) {
        OrderCancelVo orderCancelVo = new OrderCancelVo();
        orderCancelVo.setOrderId(orderId);
        orderCancelVo.setCancelBy(1L);
        orderCancelVo.setCancelReason("cancel " + tag);
        orderCancelVo.setCancelByName("LiuXinJie");
        orderCancelVo.setSourceType((byte) 1);
        orderService.cancelOrder(orderCancelVo);
        try {
            Thread.sleep(10000);//内部有异步
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    private void resetData(Long orderId, OrderStatus toStatus) {
        OrderInfo cancelOrderInfoStarting = orderInfoMapper.selectByPrimaryKey(orderId);
        Assert.assertNotNull("测试数据已被删除",cancelOrderInfoStarting);
        orderInfoMapper.updateStatus(cancelOrderInfoStarting.getId(), cancelOrderInfoStarting.getStatus().getIndex(), toStatus.getIndex());
        OrderPayoff orderPayoff = orderPayoffMapper.selectPayoffByOrderId(orderId);
        if (orderPayoff != null)
            orderPayoffMapper.deleteByPrimaryKey(orderPayoff.getId());
    }

}