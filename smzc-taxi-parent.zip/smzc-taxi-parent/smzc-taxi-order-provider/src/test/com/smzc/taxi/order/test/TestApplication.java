package com.smzc.taxi.order.test;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageInfo;
import com.smzc.taxi.OrderProviderApplication;
import com.smzc.taxi.order.dao.es.OrderDoc;
import com.smzc.taxi.order.dao.es.OrderDocRepo;
import com.smzc.taxi.order.domain.OrderInfo;
import com.smzc.taxi.order.service.*;
import com.smzc.taxi.order.util.DistributedLockManager;
import com.smzc.taxi.service.finance.enums.TfbPayChannel;
import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.CommonCode;
import com.smzc.taxi.service.order.emun.PayType;
import com.smzc.taxi.service.order.emun.PlatformType;
import com.smzc.taxi.service.passenger.enums.OrderPriceDetailType;
import com.smzc.taxi.service.portal.bean.DriverOrderReqVo;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.GetQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * 测试
 */
@SpringBootTest(classes = OrderProviderApplication.class)
@RunWith(SpringRunner.class)
@Slf4j
public class TestApplication {

    @Resource
    private OrderDocRepo orderDocRepo;

    @Resource
    private ElasticsearchTemplate elasticsearchTemplate;

    @Resource
    private OrderService orderService;

    @Resource
    private DriverOrderService driverOrderService;

    @Resource
    private DistributedLockManager distributedLockManager;

    @Resource
    OrderWorkflowService orderWorkflowService;

    @Resource
    OrderPayoffService orderPayoffService;

    @Resource
    OrderEvaluateService orderEvaluateService;

    @Resource
    OrderStatusHistoryService orderStatusHistoryService;


    static {
        System.setProperty("es.set.netty.runtime.available.processors", "false");
    }

    /**
     * 执行开始时间（毫秒）
     */
    private Long startTime;

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");

    @Before
    public void before() {
        System.out.println();
        System.out.println();
        log.debug("----------------------test uint start--------------------------------------------");
        Date now = new Date();
        this.startTime = now.getTime();
        log.debug("执行开始时间{}", sdf.format(now));
        System.out.println();
    }

    @After
    public void after() {
        System.out.println();
        log.debug("-----------------------test uint end---------------------------------------------");
        Date now = new Date();
        log.debug("执行结束时间{}，总耗时：{}毫秒", sdf.format(now), now.getTime() - startTime);
        System.out.println();
        System.out.println();
    }

    @Test
    public void syncOrderPayStatus(){
        orderPayoffService.syncOrderPayStatus("36000");
    }


    @Test
    public void getOrderStartEndTime() {

        OrderStartEndTimeVo orderStartEndTime = orderStatusHistoryService.getOrderStartEndTime(3282543551855050752L);
        System.out.println(orderStartEndTime.toString());
    }

    public void test1() {
        Map map = new HashMap();
        Map map2 = new WeakHashMap();
        map2.put(1,"abc");
        //Object obj = map2.get(1);
        System.gc();
    }


    /**
     * 正常流程 从创建订单到已完成
     *
     * @throws Exception
     */
    @Test
    public void run() throws Exception {
         Long driverId = 1L;
         long orderId = 3284787483289108480L;


        // 创建订单
        orderId = newOrder();

        sleep();


//        // 抢单
//        robOrder(orderId, driverId);
//
//        sleep();
//
//        // 司机已到达时，修改状态
//        driverArrive(orderId);
//
//        sleep();
//
//        //乘客已上车，订单状态为行程中
//        passengerArrive(orderId);
//
//        sleep();
//
//        // 行程结束
//        driverArriveEndPoint(orderId);
//
//        sleep();
//
//        // 司机输入完费用后，点发起收款
//        addPayOffDetails(orderId);
//
//        sleep();
//
//        // 司机点收到现金，订单流转到待评价
//        addPayoff(orderId);
//
//        sleep();
//
//        // 乘客评价
//        addOrderEvaluate(orderId,driverId);
//
//
//        sleep();


    }

    @Test
    public void getWaitOrder(){
        OrderDriverWaitReqVo reqVo = new OrderDriverWaitReqVo();
        reqVo.setDriverId(13L);
        reqVo.setCityCode("028");
        reqVo.setLongitude(104.075175);
        reqVo.setLatitude(30.552622);
        List<OrderDriverWaitVo> waitReceive = driverOrderService.getWaitReceive(reqVo);
        System.out.println(JSON.toJSONString(waitReceive));
    }

    @Test
    public void getDriverInfoByOrderId(){
        OrderDrivingVo driverInfoByOrderId = orderService.getDriverInfoByOrderId(3323356427050795028L);
        System.out.println(JSON.toJSONString(driverInfoByOrderId));
    }



    /**
     * 抢单之前人工取消
     */
    @Test
    public void BeforeRobCancel() throws InterruptedException {
        Long driverId = 21L;
        List<Long> ids = new ArrayList<>();
        for(int i=0;i<5;i++){
            long orderId = 3281620924159582208L;
            // 创建订单
            orderId = newOrder();
            TimeUnit.MILLISECONDS.sleep(300);
            ids.add(orderId);

        }
        List<OrderInfo> list = new ArrayList<>();
        ids.stream().forEach(p->{
            OrderInfo orderInfo = orderService.selectByPrimaryKey(p);
            list.add(orderInfo);

        });
        list.stream().forEach(p->{
            System.out.println(p.getCreatedTime());
        });
    }



    /**
     * 抢单之前系统取消
     */
    @Test
    public void beforeRobSysCancel() throws InterruptedException {
        Long driverId = 1L;
        long orderId = 3281620924159582208L;

        // 创建订单
        orderId = newOrder();

        // 自动取消 需要等5分钟
        orderService.autoCancelOrder("");

        // 取消
//        cancelOrder(3276908932720508928L);
        //订单详情
        // queryDriverReceivedOrderDetail();
    }


    /**
     * 抢单之后示乘客取消
     */
    @Test
    public void afterRobSysCancel() throws InterruptedException {

        Long driverId = 1L;
        long orderId = 3281620924159582208L;

        // 创建订单
        orderId = newOrder();

        // 自动取消 需要等5分钟
        orderService.autoCancelOrder("");

    }


    @Test
    public void rejectOrder() {
        OrderRejectVo orderRejectVo = new OrderRejectVo();
        orderRejectVo.setOrderId(3275886696143200256L);
        orderRejectVo.setRejectBy("罗飞");
        orderRejectVo.setRejectReason("驳回不需要理由");
        orderRejectVo.setRespResource((byte) 1);
        orderService.rejectOrder(orderRejectVo);

    }

    /**
     * 查询司机正进行中的详情
     *
     * @return
     */
    @Test
    public void queryDriverReceivedOrderDetail() {

        OrderDrivingVo orderDrivingVo = orderWorkflowService
                .queryDriverReceivedOrderDetail(3282195212827107328l);
        String str = JSON.toJSONString(orderDrivingVo);
        System.out.println(str);

    }


    private void addOrderEvaluate(long orderId, long driverId) {
        OrderEvaluateVo orderEvaluateVo = new OrderEvaluateVo();
        orderEvaluateVo.setDriverId(driverId);
        orderEvaluateVo.setOrderId(orderId);
        orderEvaluateVo.setContent("神马专车，专车中的头等仓");
        orderEvaluateVo.setCreatedBy("罗飞");
        orderEvaluateVo.setCreatedTime(new Date());
        orderEvaluateVo.setScore((byte) 5);
        orderEvaluateService.addOrderEvaluate(orderEvaluateVo);
    }

    @Test
    public void queryDriverHistoryOrderList() {
        DriverOrderReqVo query = new DriverOrderReqVo();
        query.setDriverId(21L);
        query.setPageNum(1);
        query.setPageSize(1);
        List<OrderDrivingVo> data = orderWorkflowService.queryDriverHistoryOrderList(query);
        query.setPageNum(3);
         data = orderWorkflowService.queryDriverHistoryOrderList(query);
    }

    private void cancelOrder(Long id) {
        OrderCancelVo orderCancelVo = new OrderCancelVo();
        orderCancelVo.setOrderId(id);
        orderCancelVo.setCancelBy(123L);
        orderCancelVo.setCancelByName("罗飞");
        orderCancelVo.setCancelReason("我高兴");
        orderCancelVo.setSourceType((byte) 1);
        orderService.cancelOrder(orderCancelVo);
    }

    /**
     * 订单结算详情
     */
    @Test
    public void queryPayoffDetailListByOrderId() {

//        List<OrderPayoffDetailVo> orderPayoff = orderPayoffService.queryPayoffDetailListByOrderId(3282195212827107329l);
//        String str = JSON.toJSONString(orderPayoff);
//        System.out.println(str);
    }

    private void addPayoff(long id) {
        OrderPayoffVo orderPayoffVo = new OrderPayoffVo();
        orderPayoffVo.setOrderId(id);
        orderPayoffVo.setPayChannel(TfbPayChannel.OFFLINE_PAY);
        orderPayoffVo.setPayTime(new Date());
        orderPayoffVo.setPayType(PayType.OFF_LINE);
        orderPayoffVo.setPlatformType(PlatformType.ANDROID_PAD);
        orderPayoffVo.setOrderAmount(1500);
        orderPayoffVo.setPayAmount(1500);
        orderPayoffService.addPayoff(orderPayoffVo);
    }

    private void addPayOffDetails(long id) {
        OrderPayoffDetailContextVo orderPayoffDetailContextVo = new OrderPayoffDetailContextVo();
        List<OrderPayoffDetailVo> dvList = new ArrayList<>();
        dvList.add(new OrderPayoffDetailVo(id, OrderPriceDetailType.BASICAMOUNT.getFieldName(), 1500));
        dvList.add(new OrderPayoffDetailVo(id, OrderPriceDetailType.PARKAMOUNT.getFieldName(), 0));
        dvList.add(new OrderPayoffDetailVo(id, OrderPriceDetailType.CLEANINGAMOUNT.getFieldName(), 0));
        dvList.add(new OrderPayoffDetailVo(id, OrderPriceDetailType.BRIDGEAMOUNT.getFieldName(), 0));
        orderPayoffDetailContextVo.setList(dvList);
        orderPayoffDetailContextVo.setPlatformType(PlatformType.ANDROID_PAD);
        orderPayoffService.addPayOffDetails(orderPayoffDetailContextVo);
    }

    private void driverArrive(Long id) {
        DriverOrderReqVo driverOrderReqVo = new DriverOrderReqVo();
        driverOrderReqVo.setOrderId(id);
        driverOrderReqVo.setLongitude(104.070354D);
        driverOrderReqVo.setLatitude(30.546986D);
        driverOrderReqVo.setPlatformType(PlatformType.ANDROID_PAD);
        orderWorkflowService.driverArrive(driverOrderReqVo);
    }

    private void passengerArrive(Long id) {
        DriverOrderReqVo driverOrderReqVo = new DriverOrderReqVo();
        driverOrderReqVo.setOrderId(id);
        driverOrderReqVo.setLongitude(104.070354D);
        driverOrderReqVo.setLatitude(30.546986D);
        driverOrderReqVo.setAddress("人在我人有的笔和主主");
        driverOrderReqVo.setStreet("lllllllll");
        driverOrderReqVo.setPlatformType(PlatformType.ANDROID_PAD);
        orderWorkflowService.passengerArrive(driverOrderReqVo);
    }

    private void driverArriveEndPoint(Long id) {
        DriverOrderReqVo driverOrderReqVo = new DriverOrderReqVo();
        driverOrderReqVo.setOrderId(id);
        driverOrderReqVo.setLongitude(104.070354D);
        driverOrderReqVo.setLatitude(30.546986D);
        driverOrderReqVo.setAddress("中国人");
        driverOrderReqVo.setStreet("www");
        driverOrderReqVo.setPlatformType(PlatformType.ANDROID_PAD);
        orderWorkflowService.driverArriveEndPoint(driverOrderReqVo);
    }

    private long newOrder() {
        OrderInfoVo orderInfoVo = new OrderInfoVo();
        orderInfoVo.setSubscriberId(1L);
        orderInfoVo.setSubscriberPhone("17713256328");
        orderInfoVo.setSubscriberName("罗飞test");
        orderInfoVo.setPredictMileage(12);
        orderInfoVo.setPredictTime(10);
        orderInfoVo.setCityCode("028");
        orderInfoVo.setCityName("成都市");
        orderInfoVo.setPlanFromCityCode("028");
        orderInfoVo.setPlanFromCityName("成都市");
        orderInfoVo.setPlanToCityCode("028");
        orderInfoVo.setPlanToCityName("成都市");
        orderInfoVo.setPlanFromAddress("成都市天府三街太平洋大厦");
        orderInfoVo.setPlanFromLongitude(104.070354D);
        orderInfoVo.setPlanFromLatitude(30.546986D);
        orderInfoVo.setPlanToAddress("成都市天府三街太平洋大厦2");
        orderInfoVo.setPlanToLongitude(104.070354D);
        orderInfoVo.setPlanToLatitude(30.546986D);
        orderInfoVo.setCreatedBy("test");
        long id = orderService.createOrder(orderInfoVo);
        System.out.println("订单id=:::::::::::::" + id);
        return id;

    }

    private void robOrder(Long orderId, long driverId) {
        OrderDriverRobVo vo = new OrderDriverRobVo();
        vo.setDriverId(driverId);
        vo.setLatitude(30.546986D);
        vo.setLongitude(104.070354D);
        vo.setOrderId(orderId);
        vo.setPlatformType(PlatformType.ANDROID_PAD);
        CommonCode commonCode = driverOrderService.robOrder(vo);
        System.out.println(commonCode.getMessage());
    }


    private void updateOrder() throws ParseException {
        fetchIndividualCustomers();
        OrderDoc orderDoc = new OrderDoc();
        orderDoc.setId(1L);
        orderDoc.setPassengerName("张三2");
        orderDocRepo.save(orderDoc);
        fetchIndividualCustomers();
    }

    private void fetchAllCustomers() {
        System.out.println("Customers found with findAll():");
        System.out.println("-------------------------------");
        for (OrderDoc customer : this.orderDocRepo.findAll()) {
            System.out.println(JSON.toJSONString(customer));
        }
        System.out.println();
    }

    private void fetchIndividualCustomers() throws ParseException {
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        queryBuilder.must(QueryBuilders.matchQuery("id", 1000000000001L));
        SearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withQuery(queryBuilder)
                .build();
//        AggregatedPage<OrderDoc> orderDocs = elasticsearchTemplate.queryForPage(searchQuery, OrderDoc.class);
        GetQuery query = new GetQuery();
        query.setId("1000000000001");
        OrderDoc orderDoc = elasticsearchTemplate.queryForObject(query, OrderDoc.class);
        System.out.println("查询数据：：：：：：：" + JSON.toJSONString(orderDoc));
    }

    @Test
    public void syncToEs() throws ParseException {
        OrderDoc orderDoc = new OrderDoc();
        orderDoc.setId(1000000000001L);
        orderDoc.setPassengerName("tdddd");
        orderDoc.setCityName("成都");
        fetchIndividualCustomers();

        GetQuery query = new GetQuery();
        query.setId("1000000000001");
        OrderDoc _orderDoc = elasticsearchTemplate.queryForObject(query, OrderDoc.class);
        if (_orderDoc == null) {
            _orderDoc = new OrderDoc();
        }
        BeanUtils.copyProperties(orderDoc, _orderDoc);
        System.out.println("------------------------------");
        orderDocRepo.save(_orderDoc);

        fetchIndividualCustomers();
    }


    private void sleep(int time) throws InterruptedException {
        System.out.println("休眠" + time + "秒");
        TimeUnit.MILLISECONDS.sleep(time * 2000);
    }

    private void sleep() throws InterruptedException {

        sleep(3);
    }
}
