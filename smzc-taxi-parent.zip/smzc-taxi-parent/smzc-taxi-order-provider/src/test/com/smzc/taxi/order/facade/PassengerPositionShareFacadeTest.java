package com.smzc.taxi.order.facade;

import com.smzc.taxi.OrderProviderApplication;
import com.smzc.taxi.order.service.PassengerPositionShareService;
import com.smzc.taxi.service.order.bean.vo.OrderPositionInfoRespVo;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {OrderProviderApplication.class})
public class PassengerPositionShareFacadeTest {
    @Autowired
    private PassengerPositionShareService passengerPositionShareService;
    @Test
    public void getOrderPositionInfo() {
        OrderPositionInfoRespVo orderPositionInfoRespVo = passengerPositionShareService.selectOrderPositionInfo(3273918501609349120L);
        Assert.assertNotNull(orderPositionInfoRespVo);
    }
}