package com.smzc.taxi.order.dao.mapper;

import com.smzc.taxi.OrderProviderApplication;
import com.smzc.taxi.order.domain.OrderAddress;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {OrderProviderApplication.class})
public class OrderAddressMapperTest {
    @Resource
    OrderAddressMapper orderAddressMapper;
    @Test
    public void selectByOrderId() {
        OrderAddress orderAddress = orderAddressMapper.selectByOrderId(3273918501609349120L);
        Assert.assertNotNull(orderAddress);
    }
}