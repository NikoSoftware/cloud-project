package com.smzc.taxi.order.facade;

import com.github.pagehelper.PageInfo;
import com.smzc.taxi.OrderProviderApplication;
import com.smzc.taxi.order.service.OrderCallService;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryPageVo;
import com.smzc.taxi.service.order.bean.vo.OrderCallHistoryVo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {OrderProviderApplication.class})
public class OrderCallHostoryFacadeTest {
    @Autowired
    OrderCallService orderCallService;
    @Test
    public void getPageList() {
        OrderCallHistoryPageVo pageVo = new OrderCallHistoryPageVo();
        pageVo.setOrderId(1L);
        pageVo.setPageNum(1);
        pageVo.setPageSize(2);
        PageInfo<OrderCallHistoryVo> result =  orderCallService.getPageList(pageVo);
        System.out.println(result.getTotal());
    }
    @Test
    public void addCall() {
        for (int i = 0;i<0;i++){
            OrderCallHistoryVo pageVo = new OrderCallHistoryVo();
            pageVo.setOrderId(1L);
            pageVo.setCalledPhone("177");
            pageVo.setMainCallType((byte)1);
            pageVo.setMainPhone("178");
            orderCallService.addOrderCallHistory(pageVo);
        }

    }
}
