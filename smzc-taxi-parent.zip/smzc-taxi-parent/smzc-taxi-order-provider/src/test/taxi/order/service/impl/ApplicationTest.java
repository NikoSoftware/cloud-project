package taxi.order.service.impl;

import com.smzc.taxi.OrderProviderApplication;
import com.smzc.taxi.order.domain.OrderStatusHistory;
import com.smzc.taxi.order.service.OrderStatusHistoryService;
import com.smzc.taxi.service.order.emun.OrderStatus;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.lang.annotation.Target;

/**
 * Created by smzcck on 2019/5/22.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {OrderProviderApplication.class})
public class ApplicationTest {

    @Resource
    OrderStatusHistoryService orderStatusHistoryService;

    @Test
    public void testOrderStatus() {
        try {
            OrderStatusHistory history = orderStatusHistoryService.selectByOrderIdAndToStatus(111L, OrderStatus.CANCEL);
            System.out.println(history);
        } catch (Exception e) {

        }
    }
}
