package taxi.order.service.impl;

import com.smzc.taxi.OrderProviderApplication;
import com.smzc.taxi.order.service.impl.OrderServiceImpl;
import com.smzc.taxi.service.order.bean.vo.OrderCancelVo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


/**
 * 取消订单
 *
 * @author : lufy
 * @version v1.0
 * @date : 2019/5/24
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {OrderProviderApplication.class})
public class CancelOrderTest {
    @Autowired
    @InjectMocks
    private OrderServiceImpl orderService;
//    @MockBean
//    private StatusTransferControl orderStatusControl;
    @Before
    private void initMock(){
//        ReflectionTestUtils.setField(orderService, "orderStatusControl", orderStatusControl);
    }
    @Test
    public void cancelOrderTest(){
        OrderCancelVo orderCancelVo = new OrderCancelVo();
        orderCancelVo.setOrderId(3266649183561457664L);
        orderCancelVo.setCancelBy(1L);
        orderCancelVo.setCancelReason("test");
        orderCancelVo.setCancelByName("test");
        orderCancelVo.setSourceType((byte)1);
        orderService.cancelOrder(orderCancelVo);
    }
}
