package com.smzc.taxi.passenger.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smzc.common.util.CommonUtil;
import com.smzc.innerServices.BaseRequest;
import com.smzc.innerServices.BaseResponse;
import com.smzc.innerServices.ResponseStatus;
import com.smzc.innerServices.beans.passenger.PassengerCommonBean;
import com.smzc.innerServices.beans.passenger.ShareLinkVoucherBean;
import com.smzc.innerServices.facade.passenger.IGrantVoucherFacade;
import com.smzc.innerServices.facade.passenger.ISubscriberFacade;
import com.smzc.taxi.passenger.web.PhoneValidateUtil;
import com.smzc.taxi.passenger.web.configuration.ApiVisitorIntercept;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.passenger.web.configuration.su.RequestContextUtil;
import com.smzc.taxi.service.passenger.bean.CityVo;
import com.smzc.taxi.service.passenger.bean.NamedVo;
import com.smzc.taxi.service.passenger.bean.ValidateCodeRequestVo;
import com.smzc.taxi.service.passenger.exception.PassengerException;
import com.smzc.taxi.service.portal.bean.SystemConfigurationVo;
import com.smzc.taxi.service.portal.enums.SystemConfigurationEnum;
import com.smzc.taxi.service.portal.service.ISystemConfigurationFacade;
import com.smzc.taxi.service.su.PassengerBaseResponse;
import com.smzc.taxi.service.su.PassengerResponseStatus;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.regex.Pattern;

/**
 * @author shishun.wang
 * @version 1.0
 * @date 2019/6/15 11:15
 * @describe
 */
@Slf4j
@Validated
@RestController
@Api(tags = "领取优惠卷—王仕顺")
@RequestMapping(PassengerCommonDef.RestfulApi.PREFIX + "/grantVoucher")
public class GrantVoucherController {
    @Reference(cluster="failfast", retries = 0, timeout = 30000, group="passenger", init = true)
    ISubscriberFacade subscriberFacade;

    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private ISystemConfigurationFacade systemConfigurationFacade;

    @Reference(cluster = "failfast", retries = 0, timeout = 30000, group = "passenger")
    private IGrantVoucherFacade grantVoucherFacade;
    @Autowired
    private ObjectMapper objectMapper;

    private static final String ERROR_PHONENO_NOTE = "抱歉！ 该号码为虚拟号码，不可注册！";

    private static final String ERROR_PHONENO_CODE = "ERR_LOGIN_004";

    @PostMapping("/taxiCallTimeOutSwitchSpecialOrder")
    @ApiOperation("出租车下单呼叫超时,切换专车下单,可参与领取活动优惠卷配置")
    public PassengerBaseResponse<NamedVo> taxiCallTimeOutSwitchSpecialOrder(final @RequestBody CityVo cityVo) {
        log.info("用户{}，呼叫城市[{}]出租车超时,切换专车下单,参与领取优惠卷活动", RequestContextUtil.getCurrentUserId(), cityVo.getAreaCode());
        if (CommonUtil.isAnyEmpty(RequestContextUtil.getCurrentUserId(), cityVo.getAreaCode())) {
            throw PassengerException.warn("城市code、参与抽奖用户id不能为空");
        }

        try {
            SystemConfigurationVo systemConfiguration = systemConfigurationFacade.getSystemConfiguration(SystemConfigurationEnum.TAXI_CREATE_ORDER_TIME_OUT_SWITCH_SPECIAL_ACTIVITY_GRANT_VOUCHER, cityVo.getAreaCode());
            if (CommonUtil.isEmpty(systemConfiguration)){
                log.info("用户{}，呼叫城市[{}]出租车超时,切换专车下单,没找到可参与领取优惠卷活动");
                return new PassengerBaseResponse(new NamedVo());
            }
            NamedVo namedVo = objectMapper.readValue(systemConfiguration.getConfigValue(),NamedVo.class);
            if (namedVo.getId() == -1){
                log.info("用户{}，呼叫城市[{}]出租车超时,切换专车下单,可参与领取优惠卷活动已停止");
                return new PassengerBaseResponse(new NamedVo());
            }

            BaseRequest<PassengerCommonBean> baseRequest = new BaseRequest<>();
            PassengerCommonBean passengerCommon = new PassengerCommonBean();
            {
                passengerCommon.setCityCode(cityVo.getAreaCode());
                passengerCommon.setUserId(RequestContextUtil.getCurrentUserId());
                passengerCommon.setSource("internal-act-"+namedVo.getId());
                passengerCommon.setMarketingActivityId(namedVo.getId());
                baseRequest.setData(passengerCommon);
            }
            grantVoucherFacade.grantVoucher(baseRequest);
            log.info("用户{}，呼叫城市[{}]出租车超时,切换专车下单,参与领取优惠卷活动成功", RequestContextUtil.getCurrentUserId(), cityVo.getAreaCode());
            return new PassengerBaseResponse(namedVo);
        } catch (Exception e) {
            log.error("用户" + RequestContextUtil.getCurrentUserId() + "，呼叫城市[" + cityVo.getAreaCode() + "]出租车超时,切换专车下单,参与领取优惠卷活动失败", e);
            return new PassengerBaseResponse(new NamedVo());
        }
    }
    @PostMapping(value = "/shareLinkVoucher")
    @ApiOperation("行程分享领卷")
    @ApiVisitorIntercept(visitor = true)
    public PassengerBaseResponse<Object> shareLinkVoucher(@RequestBody ShareLinkVoucherBean shareLinkVoucherBean){
        log.info("行程分享领卷，入参为{}", JSON.toJSONString(shareLinkVoucherBean));
        PassengerBaseResponse<Object> result = new PassengerBaseResponse<>();
        if (StringUtils.isEmpty(shareLinkVoucherBean.getPhoneNo()) || !Pattern.matches("\\d{11}", shareLinkVoucherBean.getPhoneNo())) {
            result.setStatus(PassengerResponseStatus.ERROR);
            result.setErrorCode("ERR_SHARE_004");
            result.setErrorMsg("手机号码格式错误");
        } else {
            BaseResponse<Object> baseResponse= subscriberFacade.shareLinkVoucherTaxi(shareLinkVoucherBean);
            if(baseResponse.getStatus()==ResponseStatus.ERROR){
                result.setStatus(PassengerResponseStatus.ERROR);
                result.setErrorCode(baseResponse.getErrorCode());
                result.setErrorMsg(baseResponse.getErrorMsg());
                return result;
            }
            result.setData(baseResponse.getData());
            log.info("行程分享领卷，调用结果为{}", JSON.toJSONString(baseResponse.getData()));
        }
        return result;

    }
    @PostMapping(value = "/checkSubscriberExist")
    @ApiOperation("行程分享领卷-检查是否为新用户")
    public PassengerBaseResponse<Object> checkSubscriberExist(@RequestBody ValidateCodeRequestVo validateCodeRequestVo){
        PassengerBaseResponse<Object> result = new PassengerBaseResponse<>();
        if (StringUtils.isEmpty(validateCodeRequestVo.getPhone()) || !Pattern.matches("\\d{11}", validateCodeRequestVo.getPhone())) {
            result.setStatus(PassengerResponseStatus.ERROR);
            result.setErrorCode("ERR_SHARE_004");
            result.setErrorMsg("手机号码格式错误");
        } else {
            BaseResponse<Boolean> baseResponse= subscriberFacade.checkSubscriberExist(validateCodeRequestVo.getPhone());
            if(baseResponse.getStatus()==ResponseStatus.ERROR){
                result.setErrorCode(baseResponse.getErrorCode());
                result.setErrorMsg(baseResponse.getErrorMsg());
                result.setStatus(PassengerResponseStatus.ERROR);
            }
            result.setData(baseResponse.getData());
        }
        return result;

    }
}
