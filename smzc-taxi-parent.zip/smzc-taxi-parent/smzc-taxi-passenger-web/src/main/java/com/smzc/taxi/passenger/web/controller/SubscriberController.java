package com.smzc.taxi.passenger.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.service.passenger.ISubscriberFacade;
import com.smzc.taxi.service.passenger.bean.FastAlarmVo;
import com.smzc.taxi.service.su.PassengerBaseResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @description
 * @author qiukaihong
 * @date 2019/5/22 18:21
 */
@Slf4j
@Validated
@RestController
@Api(tags = "乘客")
@RequestMapping(PassengerCommonDef.RestfulApi.PREFIX +"/subscriber")
public class SubscriberController {

    @Reference(version = "1.0.0")
    private ISubscriberFacade subscriberFacade;

    /**
     * @description
     * @param alarmVo
     * @return com.smzc.taxi.boot.response.Response
     * @date 2019/5/22 18:21
     * @author qiukaihong
     */
    @ApiOperation(value = "一键报警")
    @PostMapping("/fastAlarm")
    @ApiResponses(@ApiResponse(code = 200, message = ""))
    public PassengerBaseResponse fastAlarm(@RequestBody FastAlarmVo alarmVo) {
        subscriberFacade.fastAlarm(alarmVo);
        return new PassengerBaseResponse();
    }
}
