package com.smzc.taxi.passenger.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.smzc.common.util.CommonUtil;
import com.smzc.core.util.StringUtils;
import com.smzc.innerServices.BaseRequest;
import com.smzc.innerServices.beans.Page;
import com.smzc.innerServices.beans.order.OrderShareBean;
import com.smzc.innerServices.beans.passenger.GetMyBalanceResp;
import com.smzc.innerServices.facade.passenger.IMyWalletFacade;
import com.smzc.lbs.service.bean.LBSRequest;
import com.smzc.lbs.service.bean.LBSResponse;
import com.smzc.lbs.service.bean.taxi.TaxiVehicleLocationBean;
import com.smzc.lbs.service.facade.ILBS4TaxiFacade;
import com.smzc.taxi.common.consts.RedisConst;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.passenger.web.configuration.su.RequestContextUtil;
import com.smzc.taxi.passenger.web.controller.helper.FeedbackOrderHandler;
import com.smzc.taxi.passenger.web.controller.helper.bean.*;
import com.smzc.taxi.service.driver.bean.DriverCurrentTrajectoryVo;
import com.smzc.taxi.service.driver.bean.DriverPointVo;
import com.smzc.taxi.service.driver.bean.DriverWorkStateRedisVo;
import com.smzc.taxi.service.driver.enums.DriverWorkStateEnum;
import com.smzc.taxi.service.driver.service.IDriverFacade;
import com.smzc.taxi.service.driver.service.IPositionFacade;
import com.smzc.taxi.service.order.bean.vo.*;
import com.smzc.taxi.service.order.emun.OrderStatus;
import com.smzc.taxi.service.order.exception.OrderBusinessException;
import com.smzc.taxi.service.order.facade.*;
import com.smzc.taxi.service.passenger.bean.*;
import com.smzc.taxi.service.passenger.bean.FeedbackInfoOrderVo;
import com.smzc.taxi.service.passenger.bean.price.OrderPriceCalculateResultVo;
import com.smzc.taxi.service.passenger.bean.price.OrderPriceCalculateVo;
import com.smzc.taxi.service.passenger.bean.price.SafeCallPhoneVo;
import com.smzc.taxi.service.passenger.enums.ErrorCode;
import com.smzc.taxi.service.passenger.enums.OrderPriceDetailType;
import com.smzc.taxi.service.passenger.exception.PassengerException;
import com.smzc.taxi.service.passenger.service.IPassengerOrderFacade;
import com.smzc.taxi.service.passenger.service.IPriceConfigureFacade;
import com.smzc.taxi.service.passenger.service.ISafeCallBindFacade;
import com.smzc.taxi.service.portal.bean.SystemConfigurationVo;
import com.smzc.taxi.service.portal.enums.SystemConfigurationEnum;
import com.smzc.taxi.service.portal.service.ISystemConfigurationFacade;
import com.smzc.taxi.service.su.PassengerBaseRequest;
import com.smzc.taxi.service.su.PassengerBaseResponse;
import com.smzc.taxi.service.su.PassengerResponseStatus;
import com.smzc.us.shared.facade.SubscriberFacade;
import com.smzc.us.shared.facade.SubscriberShareConfigFacade;
import com.smzc.us.shared.facade.vo.SubscriberVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Allen
 * @version 1.0
 * @date 2019/5/21 16:25
 */
@Slf4j
@RestController
@RequestMapping(PassengerCommonDef.RestfulApi.PREFIX + "/passengerOrder")
@Api(tags = "用户订单")
public class PassengerOrderController {
    @Reference(group = "lbs", version = "1.0.0")
    private ILBS4TaxiFacade lbs4TaxiFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IPassengerOrderFacade passengerOrderFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private ISafeCallBindFacade iSafeCallBindFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IOrderCallhistoryFacade orderCallHostoryFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IPriceConfigureFacade iPriceConfigureFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IOrderNoteFacade orderNoteFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IOrderEvaluateFacade orderEvaluateFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IOrderPayoffFacade orderPayoffFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IOrderFacade orderFacade;

    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IPositionFacade positionFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IPassengerOrdersFacade passengerOrdersFacade;

    @Reference(cluster = "failfast", timeout = 30000, group = "order")
    private com.smzc.innerServices.facade.order.IOrderFacade orderService;
    @Reference(cluster = "failfast", timeout = 30000, group = "passenger", init = true)
    private IMyWalletFacade myWalletFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "userCenter", version = "1.0.0")
    private SubscriberFacade subscriberFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IDriverFacade driverFacade;
    @Reference(version = "1.0.0")
    private ISystemConfigurationFacade systemConfigurationFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "userCenter", version = "1.0.0")
    private SubscriberShareConfigFacade subscriberShareConfigFacade;


    @Autowired
    private FeedbackOrderHandler feedbackOrderHandler;

    @Autowired
    private RedisTemplate redisTemplate;

    @SuppressWarnings("Duplicates")
    @PostMapping("/getMyTrip")
    @ApiOperation(value = "分页获取我的行程k'l（仅出租车）", notes = "TAXI-201906V001；1633；乘客端：分页展示我的行程；dev->李长春；")
    public PassengerBaseResponse<Page<UnifiedOrderInfoVo>> getMyTrip(@RequestBody PassengerBaseRequest req) {
        if (CommonUtil.isAllEmpty(req, req.getPageNo(), req.getRows())) {
            throw PassengerException.warning(ErrorCode.PARAMETERS_MISSING, "pageNo,rows");
        }
        log.info("分页获取我的行程，请求参数：pageNo={}, rows={}", req.getPageNo(), req.getRows());

        // 获取当前用户ID
        Long subscriberId = RequestContextUtil.getCurrentUserId();
        if (subscriberId == null) {
            log.error("没有获取到当前用户ID");
            throw PassengerException.warn("没有获取到当前用户ID");
        }

        // 获取用户信息
        SubscriberVo subscriberVo = subscriberFacade.getSubscriberById(subscriberId);
        if (subscriberVo == null) {
            log.error("当前用户[{}]不存在", subscriberId);
            throw PassengerException.warn(String.format("当前用户[%d]不存在", subscriberId));
        }

        // 出租车：分页获取我的行程
        OrderPassengerReqVo reqVo = new OrderPassengerReqVo();
        reqVo.setSubscriberId(subscriberId);
        reqVo.setPageNum(req.getPageNo());
        reqVo.setPageSize(req.getRows());
        List<OrderPassengerVo> orderPassengerVoList = passengerOrdersFacade.getOrderList(reqVo);
        List<UnifiedOrderInfoVo> taxiOrderList = UnifiedOrderInfoVo.valueOfTaxi(orderPassengerVoList);

        // 处理乘客是否为本人。
        // 当乘客为本人时，前端希望同专车保持一致将乘客姓名展示为“本人”
        String selfStr = "本人";
        if (taxiOrderList != null && !taxiOrderList.isEmpty() && !CommonUtil.isEmpty(subscriberVo.getMobileNo())) {
            taxiOrderList.forEach(o -> {
                if (subscriberVo.getMobileNo().equals(o.getPassengerMobile())) {
                    o.setPassengerName(selfStr);
                }
            });
        }

        // 兼容专车的返回数据结构
        Page<UnifiedOrderInfoVo> page = new Page<>();
        page.setRows(taxiOrderList);
        page.setPageNo(req.getPageNo());
        page.setPageSize(req.getRows());

        log.info("分页获取我的行程，响应数据：{}", taxiOrderList);
        return new PassengerBaseResponse<>(page);
    }

    @PostMapping("/callPhone")
    @ApiOperation("获取司机号码-付家明")
    public PassengerBaseResponse<String> getSafeCallPhone(@RequestBody SafeCallPhoneVo safeCallPhoneVo) {
        log.info("获取司机号码,入参为：{}", safeCallPhoneVo);
        return new PassengerBaseResponse(iSafeCallBindFacade.getSafeCallPhone(safeCallPhoneVo));
    }

    @PostMapping("/orderPriceCalculate")
    @ApiOperation("获取订单计价-付家明")
    public PassengerBaseResponse<OrderPriceCalculateResultVo> getOrderPriceCalculate(@Validated @RequestBody OrderPriceCalculateVo orderPriceCalculateVo) {
        log.info("获取订单计价,入参为：{}", orderPriceCalculateVo);
        return new PassengerBaseResponse(iPriceConfigureFacade.getOrderPriceCalculate(orderPriceCalculateVo));
    }

    @PostMapping("/orderCancelFee")
    @ApiOperation("获取订单取消费-付家明")
    public PassengerBaseResponse<OrderCancelFeeInfoVo> getCancelFeeBean(@Validated @RequestBody OrderCancelFeeBean orderCancelFeeBean) {
        log.info("获取订单取消费,入参为：{}", orderCancelFeeBean);
        return new PassengerBaseResponse(passengerOrderFacade.getOrderCancelFeeInfo(orderCancelFeeBean.getOrderId()));
    }

    @PostMapping("/callRecords")
    @ApiOperation("订单电话拨打记录-付家明")
    public PassengerBaseResponse saveCallRecords(@RequestBody OrderCallHistoryVo orderCallHistoryVo) {
        log.info("订单电话拨打记录,入参为：{}", orderCallHistoryVo);
        orderCallHistoryVo.setCreatedTime(new Date());
        orderCallHistoryVo.setMainCallType((byte) 2);
        orderCallHostoryFacade.add(orderCallHistoryVo);
        return new PassengerBaseResponse();
    }

    @PostMapping("/driverCurrentTrajectory")
    @ApiOperation("获取订单轨迹-付家明")
    public PassengerBaseResponse<List<DriverPointVo>> driverCurrentTrajectory(@RequestBody CurrentTrajectoryVo currentTrajectoryVo) {
        log.info("获取订单轨迹,入参为：{}", currentTrajectoryVo);
        DriverCurrentTrajectoryVo driverCurrentTrajectoryVo = new DriverCurrentTrajectoryVo();
        OrderStartEndTimeVo orderStartEndTimeVo = passengerOrdersFacade.getOrderStartEndTime(currentTrajectoryVo.getOrderId());
        if (orderStartEndTimeVo == null || orderStartEndTimeVo.getStartTime() == null) {
            log.info("订单{}没找到订单行驶轨迹开始、结束时间", currentTrajectoryVo.getOrderId());
            return new PassengerBaseResponse();
        }
        driverCurrentTrajectoryVo.setVehicleNo(currentTrajectoryVo.getVehicleNo());
        driverCurrentTrajectoryVo.setDriverName(currentTrajectoryVo.getDriverName());
        driverCurrentTrajectoryVo.setStartTime(orderStartEndTimeVo.getStartTime().getTime() / 1000);
        Date endTime = orderStartEndTimeVo.getEndTime() == null ? new Date() : orderStartEndTimeVo.getEndTime();
        driverCurrentTrajectoryVo.setEndTime(endTime.getTime() / 1000);
        return new PassengerBaseResponse(positionFacade.driverCurrentTrajectory(driverCurrentTrajectoryVo));
    }

    @PostMapping("/driverLocation")
    @ApiOperation("获取司机位置-付家明")
    public PassengerBaseResponse driverLocation(@Validated @RequestBody DriverLocationBean driverLocationBean) {
        log.info("获取司机位置,入参为：{}", JSONObject.toJSONString(driverLocationBean));
        TaxiVehicleLocationBean taxiVehicleLocationBean = new TaxiVehicleLocationBean();
        taxiVehicleLocationBean.setAreaCode(driverLocationBean.getAreaCode());
        taxiVehicleLocationBean.setVehicleId(driverLocationBean.getVehicleId());
        LBSResponse<TaxiVehicleLocationBean> locationBeanLBSResponse = lbs4TaxiFacade.getTaxiVehicleLocation(LBSRequest.instance().data(taxiVehicleLocationBean));
        if (locationBeanLBSResponse.isSuccess() && Objects.nonNull(locationBeanLBSResponse.getData())) {
            return new PassengerBaseResponse(new DriverLocationVo(locationBeanLBSResponse.getData().getLng(), locationBeanLBSResponse.getData().getLat()));
        } else {
            return new PassengerBaseResponse();
        }

    }

    @PostMapping("/createOrder")
    @ApiOperation("创建订单-巨人旗")
    public PassengerBaseResponse<OrderCreateResultVo> createOrder(@RequestBody OrderInfoVo orderInfoVo) {
        //  获取当前用户ID
        Long subscriberId = RequestContextUtil.getCurrentUserId();
        log.info("{}创建订单，请求参数:{}",subscriberId, JSONObject.toJSONString(orderInfoVo));
        if (CommonUtil.isEmpty(subscriberId)) {
            log.info("创建订单-没有获取到当前用户ID");
            throw PassengerException.warn(ErrorCode.SESSION_TIME_OUT.getDescribe());
        }
        orderInfoVo.setDeviceNumber(subscriberFacade.getSubscriberById(subscriberId).getImei());
        GetMyBalanceResp myBalanceResp = myWalletFacade.getMyAccountBalance(new BaseRequest(subscriberId));
        if (CommonUtil.isEmpty(myBalanceResp)) {
            log.error("创建订单,获取用户{},账户余额失败", subscriberId);
        } else {
            log.info("创建订单,获取用户{},账户余额信息:{}", subscriberId, JSON.toJSONString(myBalanceResp));
            if (myBalanceResp.getUsableBalance() < 0) {
                throw PassengerException.warning(ErrorCode.ERR_NEW_ORDER_130);
            }
        }
        orderInfoVo.setSubscriberId(subscriberId);
        PassengerBaseResponse<OrderCreateResultVo> response = new PassengerBaseResponse<OrderCreateResultVo>(passengerOrderFacade.createOrder(orderInfoVo));
        log.info("创建订单，用户id:{}，响应数据:{}", subscriberId, JSONObject.toJSONString(response));
        return response;
    }

    @PostMapping("/cancelOrder")
    @ApiOperation("取消订单-巨人旗")
    public PassengerBaseResponse cancelOrder(@RequestBody OrderCancelVo orderCancelVo) {
        log.info("取消订单，请求参数:{}", JSONObject.toJSONString(orderCancelVo));
        if (CommonUtil.isEmpty(orderCancelVo.getOrderId())) {
            log.info("取消订单失败，必填参数缺失！");
            throw PassengerException.warn(ErrorCode.REQUIRED_PARAMETERS_MISSING.getDescribe());
        }
        //  获取当前用户ID
        Long subscriberId = RequestContextUtil.getCurrentUserId();
        if (CommonUtil.isEmpty(subscriberId)) {
            log.info("取消订单-没有获取到当前用户ID");
            throw PassengerException.warn(ErrorCode.SESSION_TIME_OUT.getDescribe());
        }
        orderCancelVo.setCancelBy(subscriberId);
        orderCancelVo.setSourceType(new Byte("1"));
        try {
            orderFacade.cancelOrder(orderCancelVo);
        } catch (OrderBusinessException e) {
            log.info("取消订单-订单扭转状态异常",e);
            throw PassengerException.warn(ErrorCode.ERR_CANCEL_ORDER_STATUS_ERR.getDescribe());
        }
        PassengerBaseResponse response = new PassengerBaseResponse();
        log.info("取消订单，响应数据:{}", JSONObject.toJSONString(response));
        return response;
    }

    @PostMapping("/orderCancelReason")
    @ApiOperation("保存取消订单原因-巨人旗")
    public PassengerBaseResponse orderCancelReason(@RequestBody OrderCancelVo orderCancelVo) {
        log.info("保存取消订单原因，请求参数:{}", JSONObject.toJSONString(orderCancelVo));
        if (CommonUtil.isAnyEmpty(orderCancelVo.getOrderId(), orderCancelVo.getCancelReason())) {
            log.info("保存取消订单原因失败，必填参数缺失！");
            throw PassengerException.warn(ErrorCode.REQUIRED_PARAMETERS_MISSING.getDescribe());
        }
        orderFacade.fillCancelReason(orderCancelVo);
        PassengerBaseResponse response = new PassengerBaseResponse();
        log.info("保存取消订单原因，响应数据:{}", JSONObject.toJSONString(response));
        return response;
    }

    @PostMapping("/addOrderNote")
    @ApiOperation("添加订单留言-巨人旗")
    public PassengerBaseResponse addOrderNote(@RequestBody OrderNoteVo orderNoteVo) {
        log.info("添加订单留言，请求参数:{}", JSONObject.toJSONString(orderNoteVo));
        boolean isEmp = CommonUtil.isAnyEmpty(orderNoteVo.getOrderId(), orderNoteVo.getContent());
        if (isEmp) {
            log.info("添加订单留言失败，必填参数缺失！");
            throw PassengerException.warn("添加订单留言失败，必填参数缺失！");
        }
        orderNoteFacade.addNote(orderNoteVo);
        PassengerBaseResponse response = new PassengerBaseResponse();
        log.info("添加订单留言，响应数据:{}", JSONObject.toJSONString(response));
        return response;
    }

    @PostMapping("/getOrderNoteList")
    @ApiOperation("根据订单id查询留言列表-巨人旗")
    public PassengerBaseResponse<List<OrderNoteVo>> getOrderNoteList(@RequestBody OrderVo orderVo) {
        log.info("根据订单查询留言列表,请求参数:{}", JSONObject.toJSONString(orderVo));
        if (CommonUtil.isEmpty(orderVo.getOrderId())) {
            log.info("根据订单id查询留言列表失败，必填参数缺失！");
            throw PassengerException.warn("根据订单id查询留言列表失败，必填参数缺失！");
        }
        List<OrderNoteVo> orderNoteVos = orderNoteFacade.getPageList(orderVo.getOrderId());
        PassengerBaseResponse<List<OrderNoteVo>> response = new PassengerBaseResponse<List<OrderNoteVo>>(orderNoteVos);
        log.info("根据订单查询留言列表,响应数据:{}", JSONObject.toJSONString(response));
        return response;
    }

    @PostMapping("/addOrderEvaluate")
    @ApiOperation("添加订单评价-巨人旗")
    public PassengerBaseResponse addOrderEvaluate(@RequestBody OrderEvaluateVo orderEvaluateVo) {
        log.info("添加订单评价，请求参数:{}", JSONObject.toJSONString(orderEvaluateVo));
        boolean isEmp = CommonUtil.isAnyEmpty(orderEvaluateVo.getOrderId(), orderEvaluateVo.getScore());
        if (isEmp) {
            log.info("添加订单评价失败，必填参数缺失！");
            throw PassengerException.warn("添加订单评价失败，必填参数缺失！");
        }
        orderEvaluateFacade.addOrderEvaluate(orderEvaluateVo);
        PassengerBaseResponse response = new PassengerBaseResponse();
        log.info("添加订单评价，响应数据:{}", JSONObject.toJSONString(response));
        return response;
    }

    @PostMapping("/getOrderEvaluate")
    @ApiOperation("根据订单id查询订单评价-巨人旗")
    public PassengerBaseResponse<OrderEvaluateVo> getOrderEvaluate(@RequestBody OrderVo orderVo) {
        log.info("根据订单id查询订单评价，请求参数:{}", JSONObject.toJSONString(orderVo));
        if (CommonUtil.isEmpty(orderVo.getOrderId())) {
            log.info("根据订单id查询订单评价失败，必填参数缺失！请求参数为：{}", orderVo.getOrderId());
            throw PassengerException.warn("根据订单id查询订单评价失败，必填参数缺失！");
        }
        OrderEvaluateVo orderEvaluateVo = orderEvaluateFacade.selectByOrderId(orderVo.getOrderId());
        PassengerBaseResponse<OrderEvaluateVo> response = new PassengerBaseResponse<OrderEvaluateVo>(orderEvaluateVo);
        log.info("根据订单id查询订单评价，响应数据:{}", JSONObject.toJSONString(response));
        return response;
    }

    @PostMapping("/getPayoffDetail")
    @ApiOperation("加载订单费用详情：加载订单费用详情{baseFee=基本费用,parkingFee=停车费,tollFee=路桥费,cleanFee=清洁费,cancelFee=取消费,rejectFee=驳回费}")
    public PassengerBaseResponse<PayoffDetailResBean> getPayoffDetail(@RequestBody PassengerBaseRequest<Long> req) {
        if (CommonUtil.isAllEmpty(req, req.getData())) {
            throw PassengerException.warning(ErrorCode.PARAMETERS_MISSING);
        }
        log.info("加载订单费用详情，请求参数：orderId={}", req.getData());

        // 费用详情
        List<OrderPayoffDetailVo> detailVoList = orderPayoffFacade.queryPayoffDetailListByOrderId(req.getData());
        if (detailVoList != null) {
            // 过滤掉值为0的费用项
            detailVoList = detailVoList.stream()
                    .filter(vo -> {
                        // 将 驳回费 对前端展示为 取消费
                        if (vo != null && OrderPriceDetailType.REJECTAMOUNT.getFieldName().equals(vo.getCostKey())) {
                            vo.setCostKey(OrderPriceDetailType.CANCELAMOUNT.getFieldName());
                            vo.setKeyName(OrderPriceDetailType.CANCELAMOUNT.getName());
                        }

                        return vo.getCostAmount() != null && vo.getCostAmount() > 0;
                    })
                    .collect(Collectors.toList());
        }

        // 城市信息
        CityInfoVo cityInfoVo = passengerOrdersFacade.getCityInfoById(req.getData());

        PayoffDetailResBean resBean = new PayoffDetailResBean();
        resBean.setDetail(detailVoList);
        if (cityInfoVo != null) {
            resBean.setCityCode(cityInfoVo.getCityCode());
            resBean.setCityName(cityInfoVo.getCityName());
        }
        log.info("加载订单[{}]费用详情，响应数据：{}", req.getData(), resBean);
        return new PassengerBaseResponse<>(resBean);
    }

    @PostMapping("/getPayoffDetail_v2")
    @ApiOperation("新版：加载订单费用详情：加载订单费用详情{baseFee=基本费用,parkingFee=停车费,tollFee=路桥费,cleanFee=清洁费,cancelFee=取消费,rejectFee=驳回费}")
    public PassengerBaseResponse<PayoffDetailResBean2> getPayoffDetailV2(@RequestBody PassengerBaseRequest<Long> req) {
        log.info("加载订单费用详情，请求参数：orderId={}", req.getData());
        // 城市信息
        CityInfoVo cityInfoVo = passengerOrdersFacade.getCityInfoById(req.getData());
        PayoffDetailResBean2 resBean = new PayoffDetailResBean2();
        resBean.setDetail(orderPayoffFacade.queryPayoffDetailListByOrderId_v2(req.getData()));
        if (cityInfoVo != null) {
            resBean.setCityCode(cityInfoVo.getCityCode());
            resBean.setCityName(cityInfoVo.getCityName());
        }
        log.info("加载订单[{}]费用详情，响应数据：{}", req.getData(), resBean);
        return new PassengerBaseResponse<>(resBean);
    }

    @PostMapping("/getMyAcceptance")
    @ApiOperation(value = "获取当前乘客受理中的订单（专车&出租车）", notes = "TAXI-201906V001；1689；展示乘客当前行程中的订单列表；dev->李长春；")
    public PassengerBaseResponse<?> getMyAcceptance() {
        //  获取当前用户ID
        Long subscriberId = RequestContextUtil.getCurrentUserId();
        log.info("获取用户受理中的订单，subscriberId={}", subscriberId);
        if (CommonUtil.isAnyEmpty(subscriberId)) {
            log.error("没有获取到当前用户ID");
            throw PassengerException.warn("没有获取到当前用户ID");
        }

        // 专车：受理中的订单
        BaseRequest req = new BaseRequest();
        req.setUserId(subscriberId);
        List<UnifiedOrderInfoVo> smzcOrderList = UnifiedOrderInfoVo.valueOfSmzc(orderService.getMyAcceptance(req));

        // 出租车：受理中的订单
        List<UnifiedOrderInfoVo> taxiOrderList = UnifiedOrderInfoVo.valueOfTaxi(passengerOrdersFacade.getInTrip(subscriberId));

        // 合并订单
        List<UnifiedOrderInfoVo> orderList = new ArrayList<>();
        if (CommonUtil.isNotEmpty(smzcOrderList)) {
            orderList.addAll(smzcOrderList);
        }
        if (CommonUtil.isNotEmpty(taxiOrderList)) {
            orderList.addAll(taxiOrderList);
        }

        // 倒序排序
        Collections.sort(orderList, (o1, o2) -> o2.getCreatedTime().compareTo(o1.getCreatedTime()));
        log.info("获取用户[{}]受理中的订单，响应数据：{}", subscriberId, orderList);
        return new PassengerBaseResponse<>(orderList);
    }

    @PostMapping("/getOrderDetailInfo")
    @ApiOperation("根据订单号获取订单详细信息-王仕顺")
    public PassengerBaseResponse<OrderDetailInfoVo> getOrderDetailInfo(@RequestBody OrderDetailInfoVo request) {
        log.info("用户{}，加载订单{}详细信息", RequestContextUtil.getCurrentUserId(), request.getOrderId());
        OrderDetailInfoVo orderDetailInfo = passengerOrderFacade.getOrderDetailInfo(request.getOrderId());
        if(orderDetailInfo.getOrderStatus() == OrderStatus.WAIT_EVALUATE 
                || orderDetailInfo.getOrderStatus() == OrderStatus.FINISH){
            String uid = subscriberShareConfigFacade.getSubscriberShareConfigUid(orderDetailInfo.getOrderId());
            if(!StringUtils.isEmpty(uid)){
                //设置分享链接信息
                SystemConfigurationVo systemConfigurationVo = systemConfigurationFacade.getSystemConfiguration(SystemConfigurationEnum.TAXI_ORDER_SHARED_LINK,orderDetailInfo.getCityCode());
                orderDetailInfo.setLink(systemConfigurationVo.getConfigValue() + new StringBuffer().append("?uuid=").append(uid).append("&cityCode=").append(orderDetailInfo.getCityCode()).append("&carbonDisplacement=0").toString());
                orderDetailInfo.setLinkTitle("Hi，送你乘车优惠券~");
                orderDetailInfo.setLinkContent("告诉你一个小秘密，打车后分享可领乘车优惠券，记得分享哦");
            }
        }
        return new PassengerBaseResponse<OrderDetailInfoVo>(orderDetailInfo);
    }

    @PostMapping("/getOrderStatusByOrderId")
    @ApiOperation("根据订单号获取订单状态-王仕顺")
    public PassengerBaseResponse<PollingOrderStatusVo> getOrderStatusByOrderId(@RequestBody PassengerBaseRequest<Long> request) {
        log.info("用户{}，加载订单{}详细信息", RequestContextUtil.getCurrentUserId(), request.getData());

        String redisKey = RedisConst.TAXI_ORDER_STATUS + request.getData();
        Object obj = redisTemplate.opsForValue().get(redisKey);
        if (obj != null) {
            OrderStatus orderStatus = OrderStatus.fromIndex((byte) obj);
            if (orderStatus == null) {
                throw PassengerException.warn("获取缓存订单" + request.getData() + ",订单状态失败");
            }
            return new PassengerBaseResponse<PollingOrderStatusVo>(new PollingOrderStatusVo(orderStatus, orderStatus.getDisplayName(), orderStatus.getIndex()));
        }

        OrderStatus orderStatus = orderFacade.getOrderStatusById(request.getData());
        if (CommonUtil.isEmpty(orderStatus)) {
            throw PassengerException.warning(ErrorCode.DATA_NOT_FOUND, "订单" + request.getData());
        }

        return new PassengerBaseResponse<PollingOrderStatusVo>(new PollingOrderStatusVo(orderStatus, orderStatus.getDisplayName(), orderStatus.getIndex()));
    }

    @PostMapping("/findEvaluateTags")
    @ApiOperation("加载系统配置出租车评价标签-王仕顺")
    public PassengerBaseResponse<List<OrderEvaluateTagVo>> findEvaluateTags() {
        List<OrderEvaluateTagVo> vos = orderEvaluateFacade.selectAllOrderEvaluateTag();
        if (CommonUtil.isEmpty(vos)) {
            return new PassengerBaseResponse<List<OrderEvaluateTagVo>>();
        }
        return new PassengerBaseResponse<List<OrderEvaluateTagVo>>(vos);
    }

    @PostMapping("/getFeedbackInfoOrderList")
    @ApiOperation("加载客服中心最近订单-王仕顺")
    public PassengerBaseResponse<Page<FeedbackInfoOrderVo>> getFeedbackInfoOrderList(@RequestBody PassengerBaseRequest request) {
        Long subscriberId = RequestContextUtil.getCurrentUserId();
        log.info("用户{}加载客服中心最近订单,请求参数{}", subscriberId, request.getPageNo()+";"+request.getRows());
        if (CommonUtil.isEmpty(subscriberId)) {
            return new PassengerBaseResponse<Page<FeedbackInfoOrderVo>>(new Page<FeedbackInfoOrderVo>(0, request.getPageNo(), request.getRows(), Collections.EMPTY_LIST));
        }
        List<FeedbackInfoOrderVo> vos = feedbackOrderHandler.pageFeedbackInfoOrderList(subscriberId, request);
        if (vos == null) {
            return new PassengerBaseResponse<Page<FeedbackInfoOrderVo>>(new Page<FeedbackInfoOrderVo>(0, request.getPageNo(), request.getRows(), Collections.EMPTY_LIST));
        }

        return new PassengerBaseResponse<Page<FeedbackInfoOrderVo>>(new Page<FeedbackInfoOrderVo>(0, request.getPageNo(), request.getRows(), vos));
    }

    @PostMapping("/marketingCreateOrder")
    @ApiOperation("营销活动下单")
    public PassengerBaseResponse<String> marketingCreateOrder(@RequestBody OrderInfoNewVo orderInfoNewVo) {
        PassengerBaseResponse<String> passengerBaseResponse=new PassengerBaseResponse<>();
        passengerBaseResponse.setStatus(PassengerResponseStatus.ERROR);
        Long subscriberId=orderInfoNewVo.getSubscriberId();
        GetMyBalanceResp myBalanceResp = myWalletFacade.getMyAccountBalance(new BaseRequest(subscriberId));
        if (CommonUtil.isEmpty(myBalanceResp)) {
            log.error("创建订单,获取用户{},账户余额失败", subscriberId);
        } else {
            log.info("创建订单,获取用户{},账户余额信息:{}", subscriberId, myBalanceResp.toString());
            if (myBalanceResp.getUsableBalance()!=null&&myBalanceResp.getUsableBalance() < 0) {
                passengerBaseResponse.setErrorMsg("您的账户已欠费，请缴费充值后再使用服务哦~");
                return  passengerBaseResponse;
            }
        }
        DriverWorkStateRedisVo driverWorkStateRedisVo=driverFacade.getDriverCurrentWorkState(orderInfoNewVo.getDriverId());
        Integer workState=driverWorkStateRedisVo.getWorkState();
        if(driverWorkStateRedisVo.getWorkState()!= DriverWorkStateEnum.DRIVER_WAITING.getCode()){

            passengerBaseResponse.setErrorMsg("您扫描的神马出租车司机正在"+DriverWorkStateEnum.getItem(workState).getName());
            return passengerBaseResponse;
        }
        return passengerOrderFacade.marketingCreateOrder(orderInfoNewVo);
    }

//    @PostMapping("shareOrderEmissionReductionInfo")
//    @ApiOperation("出租车订单减排分享")
//    public PassengerBaseResponse<Object> shareOrderEmissionReductionInfo(@RequestBody PassengerBaseRequest<Long> request){
//        return passengerOrderFacade.shareOrderEmissionReductionInfo(request.getData());
//    }

}
