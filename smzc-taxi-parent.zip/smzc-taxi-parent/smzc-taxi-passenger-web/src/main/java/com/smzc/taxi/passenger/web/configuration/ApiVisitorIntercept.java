package com.smzc.taxi.passenger.web.configuration;

import java.lang.annotation.*;

/**
 * @author shishun.wang
 * @version 1.0
 * @date 2019/5/23 10:18
 * @describe
 */
@Inherited
@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface ApiVisitorIntercept {

    boolean visitor() default false;

    long visitRate() default 3000;


}
