package com.smzc.taxi.passenger.web.controller.helper.bean;

import lombok.Data;

/***
 *
 * @author : yanzhidong
 * @date : 2019/7/15 
 * @version : V1.0
 *   用于多个销售活动时的筛选计算
 */
@Data
public class SubscriberActicityCalculateBean {

    /**
     * 订单折扣类型 1:固定抵扣 2：比例折扣 3：随机抵扣
     */
    private Integer orderDiscountType;

    /**
     * 最低抵扣金额
     */
    private Long minDeduction;
    /**
     * 最高抵扣金额
     */
    private Long maxDeduction;
}
