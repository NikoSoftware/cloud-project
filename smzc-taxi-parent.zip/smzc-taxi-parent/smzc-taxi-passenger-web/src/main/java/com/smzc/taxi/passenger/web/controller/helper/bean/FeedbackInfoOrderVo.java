package com.smzc.taxi.passenger.web.controller.helper.bean;

import com.smzc.innerServices.beans.order.*;
import com.smzc.innerServices.beans.passenger.OrderDriverBean;
import com.smzc.innerServices.beans.passenger.OrderPayEvaluateBean;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author shishun.wang
 * @version 1.0
 * @date 2019/5/31 17:42
 * @describe
 */
@Data
public class FeedbackInfoOrderVo implements Serializable {

    private static final long serialVersionUID = -2897811278531998794L;
    private OrderInfoTimesBean orderInfoTimes;

    private Integer status;// 状态

    private String statusName;

    private Date createdTime; // 订单创建时间

    private Date scheduleTime;// 乘客指定出发时间

    private String passengerName;// 订单人姓名

    private String passengerMobile;// 订单人号码

    private String realPassengerMobile;// 订单人真实显示号码

    private String fromAddress; // 出发地点

    private Double fromLongitude;// 出发地点纬度

    private Double fromLatitude;// 出发地点经度

    private Long carbonEmissions;// 碳排放量

    private Integer shareDays;// 分享天数

    private String link;// 分享链接

    private String linkTitle;// 链接title

    private String linkContent;// 链接内容

    private Long appointDriverId; // 指定的司机ID

    private int appointDriver = 1;// 是否指定司机 1:否，2:是

    private Integer specialdriverAmount;//指定管家费用

    private String toAddress;// 到达地点

    private Double toLongitude;// 到达纬度

    private Double toLatitude;// 到达地点经度

    private Integer orderType;// 订单类型

    private String orderTypeName;// 订单类型

    private Long vehicleType; // 车型

    private String vehicleTypeName; // 车型名称

    private String vehicleTypeEngName; // 车型英文名称

    private String vehicleTypeCategory;// 车型分类名

    private Integer vehicleTypeCategoryId;// 车型分类ID

    private String orderSourceName;

    private Integer orderSource;

    private Long customRouteId; // 定制线路ID

    private String orderId;// 订单ID

    private Integer payAmount;// 金额

    private Long voucherCost;// 优惠券金额

    private Long voucherId;// 优惠券Id

    private Long subscriberVoucherId;// 用户绑定优惠券ID

    private Integer predictPrice;// 预估价

    private Integer predictKM;// 预估公里数

    private Integer predictTime = 0;// 预估时间

    private Integer oldPredictTime = 0; // 原预估时间（更改目的地之前）

    private Integer totalKM;// 实际用车公里数

    private Integer elapsedTime;// 实际行程消耗时间

    private OrderExtBean orderExtBean;

    private OrderPayEvaluateBean orderEvaluate;// 订单评价

    private OrderDriverBean driver;// 司机信息

    private OrderUserPositionBean userPosition;

    private List<OrderSatisfactionBean> satisfactionList;

    private Long carId;

    private Integer priority;

    private String drinkCode;

    private String drinkName;

    private Long emptyId;

    private boolean recommend;

    private Date dispatchTime;

    private String areaCode;

    private String toCityCode;

    private Long payAccountId;

    private boolean hasNotes;

    private Date downCarTime; // 下车时间

    // 司机产值
    private Integer driverAmount;

    /**
     * 定价ID
     */
    private Long valuationId;

    private String flightNumber;

    private Date flightDate;

    private Long balance;

    /**
     * 是否是代打车 1:否，2:是
     */
    private Integer entrustOrder;

    private String fromStreet;

    private String toStreet;

    private boolean notifyPassenger;

    /**
     * 是否允许修改目的地
     */
    private boolean allowDestChange;

    // 允许更改下车点的最大次数
    private int maxDestChangeTime;

    // 更改目的地的次数
    private int destChanged;

    private Long subscriberId;

    private String subscriberName;

    private String subscriberMobile;

    private String fromCityCode;

    private List<OrderNotesBean> orderNotesList;

    // 订单状态说明
    private String orderStatusDescription;

    // 等候时长(s)
    private Long waitingTime = 0L;

    // 司机端等候时长
    private Long driverWaitingTime = 0L;

    /**
     * 车辆业务线类型: 0 专车 1快车(默认专车)
     */
    private Integer carTypeLevel;

    private String carTypeLevelName;

    /**
     * 广告投放资源ID
     */
    private Long adRuleId;

    /**
     * 领取广告优惠活动类型(0, "固定金额" 1, "比例抵扣" 2,"随机抵扣")
     */
    private Integer discountType;

    /**
     * 领取广告后订单折扣金额
     */
    private Integer discountAmount;

    /**
     * 比例抵扣优惠的最高上限金额
     */
    private Integer maxAmount;

    private boolean isShowCallPolice=true;// 是否显示一键报警

    private boolean isUseConsumeCard;//订单是否使用消费卡

    /**
     * 消费卡类型（1年、2季、3月、4周、5日、6半年卡）
     */
    private Integer cardType;

    //年卡订单，年卡抵扣里程
    private Long consumeCardDistance=0L;
    //年卡订单，年卡抵扣时长
    private Long consumeCardCostTime=0L;
}
