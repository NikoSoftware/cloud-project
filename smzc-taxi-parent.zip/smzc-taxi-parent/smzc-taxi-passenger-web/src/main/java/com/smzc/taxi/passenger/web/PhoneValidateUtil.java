package com.smzc.taxi.passenger.web;

import org.springframework.util.Assert;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @Description : 手机号码验证工具
 * @Author : Yb.Z
 * @Date : 2019/07/30 - 11:40
 */
public class PhoneValidateUtil {

    // 170号段电话号码验证正则表达式
    public static final String phoneNoRegexString = "^[1]+[7]+[0]+\\d{8}$";

    private static final String EMPTY_REGEX_NOTE = "正则不能为空";

    private static final String EMPTY_PHONENO_NOTE = "电话号码不能为空";

    /**
     * @Description: 验证电话号码是否是170号段
     * @param phoneNo
     * @Author: Yb.Z
     * @create: 2019/07/30 14:23
     * @return: boolean
     */
    public static boolean validate170PhoneNo(String phoneNo){
        return validateInvalidPhoneNo(phoneNoRegexString,phoneNo);
    }

    /**
     * @Description: 验证非法电话号码
     * @param validateRegexString 验证使用的正则
     * @param phoneNo
     * @Author: Yb.Z
     * @create: 2019/07/30 14:23
     * @return: boolean
     */
    public static boolean validateInvalidPhoneNo(String validateRegexString, String phoneNo){
        Assert.hasLength(validateRegexString,EMPTY_REGEX_NOTE);
        Assert.hasLength(phoneNo,EMPTY_PHONENO_NOTE);
        Pattern pattern = Pattern.compile(validateRegexString);
        Matcher matcher = pattern.matcher(phoneNo);
        boolean result = false;
        if (matcher.matches()) {
            result = true;
        }
        return result;
    }

}
