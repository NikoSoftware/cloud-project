package com.smzc.taxi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication(exclude= {DataSourceAutoConfiguration.class,MongoAutoConfiguration.class})
@ImportResource(value={"classpath*:dubbo-*.xml"})
public class PassengerWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PassengerWebApplication.class, args);
	}


}
