package com.smzc.taxi.passenger.web.controller.helper.bean;

import com.smzc.taxi.service.order.bean.vo.OrderPayoffDetailVo;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author Allen
 * @version 1.0
 * @date 2019/6/1 18:12
 */
@Data
public class PayoffDetailResBean implements Serializable {
    private static final long serialVersionUID = 4272872136513228275L;
    //private OrderPayoffDetailContextDiffVo detail;
    private List<OrderPayoffDetailVo> detail;
    private String cityCode;
    private String cityName;
}
