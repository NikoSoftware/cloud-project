package com.smzc.taxi.passenger.web.configuration.su;

import com.smzc.innerServices.BaseResponse;
import com.smzc.innerServices.ResponseStatus;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.service.finance.exception.FinanceException;
import com.smzc.taxi.service.passenger.exception.PassengerException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * @author shishun.wang
 * @version 1.0
 * @date 2019/5/23 20:25
 * @describe
 */
@Slf4j
@ResponseBody
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(value = Exception.class)
    public Object serviceExceptionHandler(HttpServletRequest request, Exception e) throws Exception {
        log.error("乘客端统一异常处理===>"+e.getMessage(), e);

        BaseResponse<Object> response = new BaseResponse<Object>();
        response.setStatus(ResponseStatus.ERROR);
        if (e.toString().contains(PassengerException.class.getName())) {
            PassengerException serviceException = (PassengerException) e;

            response.setErrorCode(serviceException.getCode() == null ? PassengerCommonDef.COMMON_ERROR_CODE:serviceException.getCode());
            response.setErrorMsg(serviceException.getMessage());
            return response;
        }
        if (e.toString().contains(FinanceException.class.getName())) {
            FinanceException serviceException = (FinanceException) e;

            response.setErrorCode(serviceException.getCode() == null ?PassengerCommonDef.COMMON_ERROR_CODE:serviceException.getCode());
            response.setErrorMsg(serviceException.getMessage());
            return response;
        }

        response.setErrorCode(PassengerCommonDef.COMMON_ERROR_CODE);
        response.setErrorMsg(e.getMessage());
        return response;
    }
}
