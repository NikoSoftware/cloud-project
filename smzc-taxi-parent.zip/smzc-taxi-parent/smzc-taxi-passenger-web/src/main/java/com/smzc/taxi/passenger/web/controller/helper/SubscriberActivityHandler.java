package com.smzc.taxi.passenger.web.controller.helper;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.market.service.enums.activity.ActivityType;
import com.smzc.market.service.enums.activity.BusinessType;
import com.smzc.market.service.passenger.ActivityFacade;
import com.smzc.market.service.passenger.vo.*;
import com.smzc.taxi.passenger.web.controller.helper.bean.SubscriberActicityCalculateBean;
import com.smzc.taxi.service.passenger.bean.ActivityQueryVo;
import com.smzc.taxi.service.passenger.bean.ActivityResponseVo;
import com.smzc.taxi.service.passenger.enums.ActivityMessageEnum;
import com.smzc.us.shared.facade.SubscriberTagFacade;
import com.smzc.us.shared.su.NamedVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/***
 *
 * @author : yanzhidong
 * @date : 2019/7/15 
 * @version : V1.0
 *  营销活动拉取展示处理类
 */
@Slf4j
@Component
public class SubscriberActivityHandler {


    @Reference(cluster = "failfast", timeout = 3000, group = "userCenter", version = "1.0.0")
    private SubscriberTagFacade subscriberFacade;


    @Reference(cluster = "failfast", timeout = 3000, group = "smzc-market", version = "1.0.0")
    private ActivityFacade activityFacade;

    /**
     * 分转换元的进制
     */
    private static BigDecimal SCALE = new BigDecimal(100);


    /**
     * 拉取用户能参与的最优活动
     * 最优:减钱最多的活动,若存在比例折扣则展示比例折扣
     *
     * @param currentUserId
     * @param activityQueryVo
     * @return
     */
    public ActivityResponseVo getBest(Long currentUserId, ActivityQueryVo activityQueryVo) {
        ActivityResponseVo activityResponseVo = new ActivityResponseVo();
        activityResponseVo.setDetail(new ArrayList<>(3));
        //查询用户标签
        List<NamedVo> subscriberAvailableTags = subscriberFacade.getSubscriberAvailableTags(currentUserId);
        List<Long> userTagIds = subscriberAvailableTags.stream().map(NamedVo::getId).collect(Collectors.toList());
        //查询用户可参与的活动
        List<ActivityVo> activityList = activityFacade.findActivityList(BusinessType.TAXI, currentUserId, activityQueryVo.getCityCode(), userTagIds);
        if (CollectionUtils.isEmpty(activityList)) {
            return activityResponseVo;
        } else {
            //组装用户上下车点数据
            List<DirectionalAreaRidingPointVo> pointVos = assemblyPoints(activityQueryVo);
            //查询活动详情
            String activityMessage = calculateBestActivity(activityList, pointVos, activityQueryVo.getFromSource());
            if (!Objects.isNull(activityMessage)) {
                activityResponseVo.getDetail().add(activityMessage);
            }
        }
        return activityResponseVo;
    }


    /**
     * 计算最优活动
     * 最优:减钱最多的活动,若存在比例折扣则展示比例折扣
     *
     * @param activityList
     * @return
     */
    private String calculateBestActivity(List<ActivityVo> activityList, List<DirectionalAreaRidingPointVo> pointVos, int fromSource) {
        List<SubscriberActicityCalculateBean> calculateBeans = new ArrayList<>();
        for (ActivityVo activity : activityList) {
            ParticipationActivityVo<Object> participationActivityVo = ParticipationActivityVo.builder()
                    .activityId(activity.getId())
                    .activityName(activity.getName())
                    .activityType(ActivityType.transform(activity.getActivityType()))
                    .extParam(pointVos)
                    .build();
            ParticipationActivityInfoVo participationActivityInfoVo = activityFacade.participationInfo(participationActivityVo);
            if (Objects.isNull(participationActivityInfoVo)) {
                continue;
            }
            ParticipationDirectionalAreaRidingVo activityRule = (ParticipationDirectionalAreaRidingVo) participationActivityInfoVo.getActivityRule();
            if (Objects.isNull(activityRule)) {
                return null;
            }
            List<ParticipationPassengerActivityRuleRewardVo> participationPassengerActivityRuleRewardVos = activityRule.getParticipationPassengerActivityRuleRewardVos();
            for (ParticipationPassengerActivityRuleRewardVo rule : participationPassengerActivityRuleRewardVos) {
                //订单折扣类型 1:固定抵扣 2：比例折扣 3：随机抵扣
                Integer orderDiscountType = rule.getMoneyDiscountType();
                SubscriberActicityCalculateBean calculateBean = new SubscriberActicityCalculateBean();
                calculateBean.setOrderDiscountType(orderDiscountType);
                switch (orderDiscountType) {
                    case 1:
                        calculateBean.setMaxDeduction(rule.getFixedDeduction());
                        break;
                    case 3:
                        List<PassengerActivityRuleRewardRandomDeductionVo> randomDeductionVos = rule.getRandomDeductionVos();
                        if (CollectionUtils.isEmpty(randomDeductionVos)) {
                            log.error("获取用户可参与的营销活动，randomDeductionVos:为空");
                            break;
                        }
                        if (randomDeductionVos.size() == 1) {
                            calculateBean.setMinDeduction(randomDeductionVos.get(0).getStartAmount().longValue());
                            calculateBean.setMaxDeduction(randomDeductionVos.get(0).getEndAmount().longValue());
                        } else {
                            List<Integer> startAmounts = randomDeductionVos.stream().map(PassengerActivityRuleRewardRandomDeductionVo::getStartAmount).collect(Collectors.toList());
                            List<Integer> endAmounts = randomDeductionVos.stream().map(PassengerActivityRuleRewardRandomDeductionVo::getEndAmount).collect(Collectors.toList());
                            startAmounts.addAll(endAmounts);
                            Collections.sort(startAmounts);
                            calculateBean.setMinDeduction(startAmounts.get(0).longValue());
                            calculateBean.setMaxDeduction(startAmounts.get(startAmounts.size() - 1).longValue());
                        }
                        break;
                    default:
                        return selectMessage(ActivityMessageEnum.MESSAGE_001, fromSource);
                }
                calculateBeans.add(calculateBean);
            }
        }
        if (!CollectionUtils.isEmpty(calculateBeans)) {
            Optional<SubscriberActicityCalculateBean> max = calculateBeans.stream().max(Comparator.comparing(SubscriberActicityCalculateBean::getMaxDeduction));
            SubscriberActicityCalculateBean acticityCalculateBean = max.get();
            if (acticityCalculateBean.getOrderDiscountType() == 1) {
                return String.format(selectMessage(ActivityMessageEnum.MESSAGE_002, fromSource), getYuan(acticityCalculateBean.getMaxDeduction()));
            } else {
                return String.format(selectMessage(ActivityMessageEnum.MESSAGE_003, fromSource), getYuan(acticityCalculateBean.getMinDeduction()), getYuan(acticityCalculateBean.getMaxDeduction()));
            }
        }
        log.error("获取用户可参与的营销活动，获取活动详情失败:{}", activityList.toArray());
        return null;
    }


    /**
     * 组装上下车点坐标
     *
     * @return
     */
    private List<DirectionalAreaRidingPointVo> assemblyPoints(ActivityQueryVo activityQueryVo) {
        // 上下车点 1：上车2：下车
        List<DirectionalAreaRidingPointVo> pointVos = new ArrayList<>();
        //上车点
        DirectionalAreaRidingPointVo pointVo1 = new DirectionalAreaRidingPointVo();
        pointVo1.setGeton(1);
        pointVo1.setLatitude(activityQueryVo.getPlanFromLatitude());
        pointVo1.setLongitude(activityQueryVo.getPlanFromLongitude());
        //下车点
        DirectionalAreaRidingPointVo pointVo2 = new DirectionalAreaRidingPointVo();
        pointVo2.setGeton(2);
        pointVo2.setLatitude(activityQueryVo.getPlanToLatitude());
        pointVo2.setLongitude(activityQueryVo.getPlanToLongitude());
        pointVos.add(pointVo1);
        pointVos.add(pointVo2);
        return pointVos;
    }

    /**
     * 根据来源选择文案格式
     *
     * @param activityMessageEnum
     * @param fromSource
     * @return
     */
    private String selectMessage(ActivityMessageEnum activityMessageEnum, int fromSource) {
        return fromSource == 0 ? activityMessageEnum.getAppMessage() : activityMessageEnum.getH5Message();
    }

    /**
     * 将分转换为元用于前台展示
     *
     * @param penny
     * @return
     */
    private String getYuan(long penny) {
        return new BigDecimal(penny).divide(SCALE).toString();
    }


}
