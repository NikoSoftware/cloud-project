package com.smzc.taxi.passenger.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.passenger.web.controller.helper.bean.ConsumerServiceBean;
import com.smzc.taxi.service.passenger.service.IConsumerServiceFacade;
import com.smzc.taxi.service.su.PassengerBaseResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Classname ConsumerServiceController
 * @Description TODO
 * @Date 2019/5/21 10:16
 * @Created by fujiaming
 */
@Slf4j
@Validated
@RestController
@Api(tags = "客服信息")
@RequestMapping(PassengerCommonDef.RestfulApi.PREFIX +"/consumerService")
public class ConsumerServiceController {
    @Reference(cluster = "failfast", timeout = 30000,group = "smzc-taxi" , version = "1.0.0")
    private IConsumerServiceFacade consumerServiceFacade;

    @PostMapping("/getPhoneByAreaCode")
    @ApiOperation("通过城市code获取客服电话-付家明")
    public PassengerBaseResponse<List<String>> getBusinessTypeListByAreaCode(@RequestBody ConsumerServiceBean consumerServiceBean) {
        return new PassengerBaseResponse(consumerServiceFacade.getConsumerServiceByAreaCode(consumerServiceBean.getAreaCode()));
    }
    @PostMapping("/consumerServicePhones")
    @ApiOperation("获取所有客服电话-付家明")
    public PassengerBaseResponse<List<String>> getBusinessTypeList(){
        return new PassengerBaseResponse(consumerServiceFacade.getConsumerServicePhones());
    }
}
