package com.smzc.taxi.passenger.web.controller.helper;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.common.util.CommonUtil;
import com.smzc.innerServices.beans.Page;
import com.smzc.innerServices.beans.passenger.OrderInfoBean;
import com.smzc.innerServices.beans.passenger.OrderMyTripReqBean;
import com.smzc.taxi.service.order.bean.vo.OrderPassengerVo;
import com.smzc.taxi.service.order.facade.IPassengerOrdersFacade;
import com.smzc.taxi.service.passenger.bean.FeedbackInfoOrderVo;
import com.smzc.taxi.service.passenger.enums.BusinessTypeEnum;
import com.smzc.taxi.service.su.PassengerBaseRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author shishun.wang
 * @version 1.0
 * @date 2019/5/31 16:26
 * @describe
 */
@Slf4j
@Component
public class FeedbackOrderHandler {

    @Reference(cluster="failfast", retries = 0, timeout = 30000, group="order", init = true)
    private com.smzc.innerServices.facade.order.IOrderFacade smzcOrderFacade;

    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IPassengerOrdersFacade passengerOrdersFacade;

    public List<FeedbackInfoOrderVo> pageFeedbackInfoOrderList(Long subscriberId,PassengerBaseRequest request){
        OrderMyTripReqBean vo = new OrderMyTripReqBean();
        {
            vo.setUserId(subscriberId);
            vo.setPageNo(request.getPageNo());
            vo.setRows(Integer.MAX_VALUE);
        }
        Page<OrderInfoBean> zcOrders = smzcOrderFacade.getFeedbackInfoOrder(vo);
        List<OrderPassengerVo> taxiOrders = passengerOrdersFacade.getOrderListByCurrentDay(subscriberId);
        if (CommonUtil.isAllEmpty(zcOrders.getRows(),taxiOrders)){
            return null;
        }

        List<FeedbackInfoOrderVo> zcOrderRows = new ArrayList<FeedbackInfoOrderVo>();
        List<FeedbackInfoOrderVo> taxiOrderRows = new ArrayList<FeedbackInfoOrderVo>();

        if (CommonUtil.isNotEmpty(zcOrders.getRows())){
            zcOrderRows = zcOrders.getRows().stream().map(item ->{
                FeedbackInfoOrderVo feedbackInfoOrderVo = new FeedbackInfoOrderVo();
                feedbackInfoOrderVo.setBusinessType(BusinessTypeEnum.SPECIAL);
                BeanUtils.copyProperties(item,feedbackInfoOrderVo);
                return feedbackInfoOrderVo;
            }).collect(Collectors.toList());
        }

        if (CommonUtil.isNotEmpty(taxiOrders)){
            taxiOrderRows = taxiOrders.stream().map(item ->{
                FeedbackInfoOrderVo feedbackInfoOrderVo = new FeedbackInfoOrderVo();
                {
                    feedbackInfoOrderVo.setBusinessType(BusinessTypeEnum.TAXI);
                    feedbackInfoOrderVo.setOrderId(String.valueOf(item.getOrderId()));
                    feedbackInfoOrderVo.setStatus(item.getOrderStatus().getIndex().intValue());
                    feedbackInfoOrderVo.setStatusName(item.getOrderStatus().getDisplayName());
                    feedbackInfoOrderVo.setPayAmount(item.getPayAmount());
                    feedbackInfoOrderVo.setCreatedTime(item.getScheduleTime());

                    feedbackInfoOrderVo.setFromAddress(item.getFromAddress());
                    feedbackInfoOrderVo.setToAddress(item.getToAddress());
                    feedbackInfoOrderVo.setPassengerName(item.getPassengerName());
                    feedbackInfoOrderVo.setPassengerMobile(item.getPassengerPhone());
                }

                return feedbackInfoOrderVo;
            }).collect(Collectors.toList());
        }

        if (CommonUtil.isNotEmpty(zcOrderRows) && CommonUtil.isEmpty(taxiOrderRows)){
            return subList(request,zcOrderRows);
        }

        if (CommonUtil.isNotEmpty(taxiOrderRows) && CommonUtil.isEmpty(zcOrderRows)){
            return subList(request,taxiOrderRows);
        }

        zcOrderRows.addAll(taxiOrderRows);
        Collections.sort(zcOrderRows, (o1, o2) -> o1.getCreatedTime().compareTo(o2.getCreatedTime()));

        return subList(request,zcOrderRows);
    }

    private List<FeedbackInfoOrderVo> subList(PassengerBaseRequest request, List<FeedbackInfoOrderVo> result){
        int end = request.getPageNo()*request.getRows();
        if ((request.getPageNo()-1)*request.getRows() >= result.size()){
            return Collections.EMPTY_LIST;
        }

        return result.subList((request.getPageNo()-1)*request.getRows(),(end >= result.size())?result.size():end);
    }

}
