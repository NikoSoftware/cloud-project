package com.smzc.taxi.passenger.web.controller;
import com.alibaba.dubbo.common.utils.Assert;
import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.smzc.innerServices.BaseRequest;
import com.smzc.innerServices.BaseResponse;
import com.smzc.innerServices.enums.PayStatus;
import com.smzc.taxi.passenger.web.configuration.ApiVisitorIntercept;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.passenger.web.configuration.su.RequestContextUtil;
import com.smzc.taxi.service.finance.bean.TransactionReqVo;
import com.smzc.taxi.service.finance.bean.TransactionRspVo;
import com.smzc.taxi.service.finance.enums.PaymentStatus;
import com.smzc.taxi.service.finance.enums.PaymentType;
import com.smzc.taxi.service.finance.facade.IPayPriceCalculateFacade;
import com.smzc.taxi.service.passenger.bean.PassengerPayAsynNotifyLogVo;
import com.smzc.taxi.service.passenger.service.IPassengerPayAsynNotifyLogFacade;
import com.smzc.taxi.service.su.PassengerBaseResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Slf4j
@Validated
@RestController
@Api(tags = "乘客交易")
@RequestMapping(PassengerCommonDef.RestfulApi.PREFIX +"/trade")
public class TradeController {

    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IPayPriceCalculateFacade payPriceCalculateFacade;

    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    IPassengerPayAsynNotifyLogFacade  passengerPayAsynNotifyLogFacade;

    @PostMapping("/tradeMyWallet")
    @ApiOperation("乘客支付")
    public PassengerBaseResponse<Map<String, ?>> tradeMyWallet(@RequestBody TransactionReqVo vo) {
        Long subscriberId = RequestContextUtil.getCurrentUserId();
        Assert.notNull(subscriberId, "获取用户ID错误");
        vo.setUserId(subscriberId);
        String tradeNo = vo.getTradeNo();
        Assert.notNull(vo.getDriverId(),"未传递司机信息");
        Assert.notNull(vo.getTradeType(),"未传递支付渠道");
        Assert.notNull(vo.getTotalAmount(),"充值金额不能为空");
        Assert.notNull(tradeNo,"交易订单号不能为空");
        Assert.notNull(vo.getDevice().getIp(),"用户IP地址不能为空");
        Map<String, ?> map = payPriceCalculateFacade.transactionSign(vo);
        log.info("成功创建一笔消费记录，tradeNo={},userId={}",tradeNo,subscriberId);
        return new PassengerBaseResponse<>(map);
    }

    @PostMapping("/notify/tf/result")
    @ApiVisitorIntercept(visitor=true)
    public void tfTradeResultCallback(HttpServletRequest request, HttpServletResponse response) {
        Map<String, String[]> parameterMap = request.getParameterMap();
        log.info("接收到天府银行支付回调,data={},notify_id={}",parameterMap,request.getParameter("notify_id"));
        Map writeAbleMap = new HashMap();
        try {
            Enumeration enums =request.getParameterNames();
            StringBuffer sb = new StringBuffer();
            while (enums.hasMoreElements()) {
                String paramName = (String) enums.nextElement();
                String paramValue = request.getParameter(paramName);
                sb.append(paramName).append("=").append(paramValue);
                writeAbleMap.put(paramName, paramValue);
            }
            log.info("接收天府银行支付回调参数 dataString={}",sb.toString());
            String  resultCallback =  payPriceCalculateFacade.transactionResultCallback(writeAbleMap, PaymentType.TIANFU_PAY);
            response.setContentType("text/xml;charset=UTF-8");
            if(String.valueOf(HttpStatus.SC_OK).equals(resultCallback)){
                response.setStatus(HttpStatus.SC_OK);
            }
            response.getWriter().write("success");
            return ;
        }
        catch (Exception e) {
            log.error("天府银行支付回调错误", e);
            //失败后写入失败日志表
            log.info("返回参数："+JSON.parseObject(JSON.toJSONString(writeAbleMap)));
            PassengerPayAsynNotifyLogVo passengerPayAsynNotifyLogVo = JSON.parseObject(JSON.toJSONString(writeAbleMap), PassengerPayAsynNotifyLogVo.class);
            passengerPayAsynNotifyLogFacade.insert(passengerPayAsynNotifyLogVo);
            response.setStatus(HttpStatus.SC_GATEWAY_TIMEOUT);
            return ;
        }
    }
    @PostMapping("/result")
    @ApiOperation("查询结果")
    public PassengerBaseResponse<TransactionRspVo> tradeResult(@RequestBody TransactionReqVo request) {
        Long subscriberId = RequestContextUtil.getCurrentUserId();
        Assert.notNull(subscriberId, "获取用户ID错误");
        String tradeNo = request.getTradeNo();
        Assert.notNull(tradeNo,"交易订单号不能为空");
        log.info("开始查询交易结果，subscriberId={},tradeNo={}",subscriberId,tradeNo);
        TransactionRspVo payStatus = payPriceCalculateFacade.tradeResult(request);
        log.info("查询交易结果,tradeNo={},result={}", payStatus.getTradeNo(), payStatus.toString());
        return new PassengerBaseResponse(payStatus);
    }

    @PostMapping("/notify/tf/returnUrL")
    @ApiVisitorIntercept(visitor=true)
    public void tfTradeResultReturnUrL(HttpServletRequest request, HttpServletResponse response) {
        Map<String, String[]> parameterMap = request.getParameterMap();
        log.info("接收到天府银行支付returnURl请求,data={}",parameterMap);
        try {
            Map writeAbleMap = new HashMap();
            Enumeration enums =request.getParameterNames();
            StringBuffer sb = new StringBuffer();
            while (enums.hasMoreElements()) {
                String paramName = (String) enums.nextElement();
                String paramValue = request.getParameter(paramName);
                sb.append(paramName).append("=").append(paramValue);
                writeAbleMap.put(paramName, paramValue);
            }
            log.info("接收到天府银行支付returnURl请求参数 dataString={}",sb.toString());
        }
        catch (Exception e) {

        }
    }

    @PostMapping("/notify/tf/showUrL")
    @ApiVisitorIntercept(visitor=true)
    public void tfTradeResultShowUrL(HttpServletRequest request, HttpServletResponse response) {
        Map<String, String[]> parameterMap = request.getParameterMap();
        log.info("接收到天府银行支付showUrL请求,data={}",parameterMap);
        try {
            Map writeAbleMap = new HashMap();
            Enumeration enums =request.getParameterNames();
            StringBuffer sb = new StringBuffer();
            while (enums.hasMoreElements()) {
                String paramName = (String) enums.nextElement();
                String paramValue = request.getParameter(paramName);
                sb.append(paramName).append("=").append(paramValue);
                writeAbleMap.put(paramName, paramValue);
            }
            log.info("接收到天府银行支付showUrL请求参数 dataString={}",sb.toString());
        }
        catch (Exception e) {

        }
    }
}
