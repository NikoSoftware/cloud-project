package com.smzc.taxi.passenger.web.controller;

import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.passenger.web.configuration.su.RequestContextUtil;
import com.smzc.taxi.passenger.web.controller.helper.SubscriberActivityHandler;
import com.smzc.taxi.service.passenger.bean.ActivityQueryVo;
import com.smzc.taxi.service.passenger.bean.ActivityResponseVo;
import com.smzc.taxi.service.su.PassengerBaseResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

/***
 *
 * @author : yanzhidong
 * @date : 2019/7/12 
 * @version : V1.0
 *
 */
@Slf4j
@Validated
@RestController
@Api(tags = "用户营销活动")
@RequestMapping(PassengerCommonDef.RestfulApi.PREFIX + "/activity")
public class SubscriberActivityController {

    @Autowired
    private SubscriberActivityHandler subscriberActivityHandler;


    @PostMapping("/getBest")
    @ApiOperation("乘客输入上下车点后拉取能参与的最优活动")
    public PassengerBaseResponse<ActivityResponseVo> getBest(@RequestBody ActivityQueryVo activityQueryVo) {
        Long currentUserId = RequestContextUtil.getCurrentUserId();
        log.info("获取用户可参与的营销活动,用户:{},请求参数:{}", currentUserId, activityQueryVo);
        ActivityResponseVo bestActivity;
        try {
            bestActivity = subscriberActivityHandler.getBest(currentUserId, activityQueryVo);
        } catch (Exception e) {
            log.error("获取用户可参与的营销活动,异常:", e);
            bestActivity = new ActivityResponseVo();
            bestActivity.setDetail(new ArrayList<>(1));
        }
        return new PassengerBaseResponse<>(bestActivity);
    }


}
