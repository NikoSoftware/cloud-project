package com.smzc.taxi.passenger.web.controller.helper.bean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Classname ConsumerServiceBean
 * @Description TODO
 * @Date 2019/5/30 11:18
 * @Created by fujiaming
 */
@ApiModel("获取客服电话请求参数")
@Data
@NoArgsConstructor
public class ConsumerServiceBean  implements Serializable {
    private static final long serialVersionUID = -5757635752335040142L;
    /**
     * 区域code
     */
    @ApiModelProperty(value = "区域code", required = true, example = "028")
    private String areaCode;
}
