package com.smzc.taxi.passenger.web.controller.helper.bean;

import com.smzc.innerServices.beans.passenger.OrderInfoBean;
import com.smzc.taxi.service.order.bean.vo.OrderPassengerVo;
import com.smzc.taxi.service.passenger.enums.BusinessTypeEnum;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 统一订单vo
 * 用于同时兼容专车和出租车的订单
 */
@Data
public class UnifiedOrderInfoVo implements Serializable {
    private static final long serialVersionUID = -5050450761401707458L;

    private String orderId;
    private Integer carTypeLevel;
    private String carTypeLevelName;
    private Integer orderType;
    private String orderTypeName;
    private Integer orderSource;
    private String orderSourceName;
    private Integer status;
    private String statusName;
    private Date createdTime;
    private String passengerName;
    private String passengerMobile;
    private String fromAddress;
    private String toAddress;

    private String businessType;
    private String businessTypeName;

    private Integer payAmount;

    /**
     * 专车后付费:支付状态,0:等待支付，1：已付款
     */
    private Integer payStatus ;
    /**
     * 专车后付费:支付状态,0:等待支付，1：已付款
     */
    private String payStatusDisplay;
    /**
     * 订单付费模式：1.预付费，3.后付费
     */
    private Integer paymentModel;
    /**
     * 前端需要时间戳
     */
    public Long getCreatedTime() {
        return createdTime == null ? null : createdTime.getTime();
    }

    public static UnifiedOrderInfoVo valueOfSmzc(OrderInfoBean orderInfoBean) {
        if (orderInfoBean == null) {
            return null;
        }
        UnifiedOrderInfoVo vo = new UnifiedOrderInfoVo();
        vo.setOrderId(orderInfoBean.getOrderId());
        vo.setCarTypeLevel(orderInfoBean.getCarTypeLevel());
        vo.setCarTypeLevelName(orderInfoBean.getCarTypeLevelName());
        vo.setOrderType(orderInfoBean.getOrderType());
        vo.setOrderTypeName(orderInfoBean.getOrderTypeName());
        vo.setOrderSource(orderInfoBean.getOrderSource());
        vo.setOrderSourceName(orderInfoBean.getOrderSourceName());
        vo.setStatus(orderInfoBean.getStatus());
        vo.setStatusName(orderInfoBean.getStatusName());
        vo.setCreatedTime(orderInfoBean.getCreatedTime());
        vo.setPassengerName(orderInfoBean.getPassengerName());
        vo.setPassengerMobile(orderInfoBean.getPassengerMobile());
        vo.setFromAddress(orderInfoBean.getFromAddress());
        vo.setToAddress(orderInfoBean.getToAddress());
        vo.setBusinessType(BusinessTypeEnum.SPECIAL.getCode());
        vo.setBusinessTypeName(BusinessTypeEnum.SPECIAL.getDisplay());
        vo.setPaymentModel(orderInfoBean.getPaymentModel());

        if (null != orderInfoBean.getPayStatus()){
            vo.setPayStatus(orderInfoBean.getPayStatus());
            vo.setPayStatusDisplay(orderInfoBean.getPayStatus() == 0?"等待支付":"已付款");
        }

        vo.setPayAmount(orderInfoBean.getPayAmount());
        return vo;
    }

    public static UnifiedOrderInfoVo valueOfTaxi(OrderPassengerVo orderInfoVo) {
        if (orderInfoVo == null) {
            return null;
        }
        UnifiedOrderInfoVo vo = new UnifiedOrderInfoVo();
        vo.setOrderId(orderInfoVo.getOrderId() == null ? null : String.valueOf(orderInfoVo.getOrderId()));
        if (orderInfoVo.getCarType() != null) {
            vo.setCarTypeLevel((int) orderInfoVo.getCarType().getIndex());
            vo.setCarTypeLevelName(orderInfoVo.getCarType().getName());
        }
        if (orderInfoVo.getOrderType() != null) {
            vo.setOrderType((int) orderInfoVo.getOrderType().getIndex());
            vo.setOrderTypeName(orderInfoVo.getOrderType().getName());
        }
        vo.setOrderSource(null);
        vo.setOrderSourceName(null);
        if (orderInfoVo.getOrderStatus() != null) {
            vo.setStatus((int) orderInfoVo.getOrderStatus().getIndex());
            vo.setStatusName(orderInfoVo.getOrderStatus().getDisplayName());
        }
        vo.setCreatedTime(orderInfoVo.getScheduleTime());
        vo.setPassengerName(orderInfoVo.getPassengerName());
        vo.setPassengerMobile(orderInfoVo.getPassengerPhone());
        vo.setFromAddress(orderInfoVo.getFromAddress());
        vo.setToAddress(orderInfoVo.getToAddress());
        vo.setBusinessType(BusinessTypeEnum.TAXI.getCode());
        vo.setBusinessTypeName(BusinessTypeEnum.TAXI.getDisplay());

        vo.setPayAmount(orderInfoVo.getPayAmount());
        return vo;
    }

    public static List<UnifiedOrderInfoVo> valueOfSmzc(List<OrderInfoBean> beanList) {
        if (beanList == null) {
            return null;
        }
        return beanList.stream().map(UnifiedOrderInfoVo::valueOfSmzc).collect(Collectors.toList());
    }

    public static List<UnifiedOrderInfoVo> valueOfTaxi(List<OrderPassengerVo> voList) {
        if (voList == null) {
            return null;
        }
        return voList.stream().map(UnifiedOrderInfoVo::valueOfTaxi).collect(Collectors.toList());
    }
}
