package com.smzc.taxi.passenger.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.innerServices.BaseResponse;
import com.smzc.innerServices.ResponseStatus;
import com.smzc.innerServices.beans.passenger.SubscriberLoginGPSBean;
import com.smzc.innerServices.facade.IUserService;
import com.smzc.taxi.boot.sms.SmsTemplate;
import com.smzc.taxi.boot.sms.enums.SmsTypeEnum;
import com.smzc.taxi.boot.sms.properties.SmsParams;
import com.smzc.taxi.boot.sms.properties.SmsResult;
import com.smzc.taxi.common.consts.RedisConst;
import com.smzc.taxi.common.consts.SmsTemplateConst;
import com.smzc.taxi.common.utils.SmsValidateCodeUtil;
import com.smzc.taxi.passenger.web.PhoneValidateUtil;
import com.smzc.taxi.passenger.web.configuration.ApiVisitorIntercept;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.service.order.facade.IPassengerOrdersFacade;
import com.smzc.taxi.service.passenger.bean.*;
import com.smzc.taxi.service.passenger.service.ILoginFacade;
import com.smzc.taxi.service.su.PassengerBaseResponse;
import com.smzc.taxi.service.su.PassengerResponseStatus;
import com.smzc.us.shared.facade.SubscriberFacade;
import com.smzc.us.shared.facade.vo.SubscriberVo;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * @Classname LoginController
 * @Description
 * @Date 2019/7/5 15:41
 * @Created by fujiaming
 */
@Slf4j
@RestController
@RequestMapping(PassengerCommonDef.RestfulApi.PREFIX + "/login")
public class LoginController {
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private ILoginFacade loginFacade;
    @Reference(cluster = "failfast", timeout = 30000, group = "userCenter", init = true)
    private IUserService userService;
    @Autowired
    private RedisTemplate<String, String> slaveRedisTemplate;
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IPassengerOrdersFacade passengerOrdersFacade;
    @Autowired
    private SmsTemplate smsTemplate;
    @Reference(cluster = "failfast", timeout = 30000, group = "userCenter", version = "1.0.0")
    private SubscriberFacade subscriberFacade;

    private static final String ERROR_PHONENO_NOTE = "抱歉！ 该号码为虚拟号码，不可注册！";

    private static final String ERROR_PHONENO_CODE = "ERR_LOGIN_004";


    @PostMapping("/checkDiscount")
    @ApiOperation("检查是否登录和是否为新用户")
    public PassengerBaseResponse<CheckDisCountResponseVo> checkEnjoyDisCount(@RequestBody CheckDisCountRequestVo checkDisCountVo, HttpServletRequest request) {
        log.info("检查是否登录和是否为新用户，入参：{}", checkDisCountVo.toString());
        if (request.getHeader(PassengerCommonDef.REQUEST_ID) != null) {
            checkDisCountVo.setSubscriberId(Long.parseLong(PassengerCommonDef.REQUEST_ID));
        }
        return new PassengerBaseResponse(loginFacade.checkEnjoyDisCount(checkDisCountVo));
    }

    @PostMapping("/sendValidateCode")
    @ApiOperation("获取短信验证码")
    @ApiVisitorIntercept(visitor = true)
    public PassengerBaseResponse<SendValidateCodeResponseVo> sendValidateCode(@RequestBody ValidateCodeRequestVo validateCodeRequestVo) {
        log.info("获取登录验证码入参:{}", validateCodeRequestVo.toString());
        SendValidateCodeResponseVo sendValidateCodeResponseVo = new SendValidateCodeResponseVo();
        sendValidateCodeResponseVo.setNewUser(true);
        boolean registedNewUser = isRegistedNewUser(validateCodeRequestVo, sendValidateCodeResponseVo);
        if (!sendValidateCodeResponseVo.isNewUser()) {
            return new PassengerBaseResponse<>(sendValidateCodeResponseVo);
        }
        if (PhoneValidateUtil.validate170PhoneNo(validateCodeRequestVo.getPhone()) && !registedNewUser) {
            PassengerBaseResponse<SendValidateCodeResponseVo> response = new PassengerBaseResponse<>();
            response.setErrorCode(ERROR_PHONENO_CODE);
            response.setErrorMsg(ERROR_PHONENO_NOTE);
            response.setStatus(PassengerResponseStatus.ERROR);
            return response;
        }
        return new PassengerBaseResponse<>(sendCode(validateCodeRequestVo));
    }

    @PostMapping("/loginValidate")
    @ApiOperation("登录")
    @ApiVisitorIntercept(visitor = true)
    public PassengerBaseResponse<Object> login(@RequestBody LoginRegVo loginRegVo, HttpServletRequest httpServletRequest) {
        log.info("登录入参：{}", loginRegVo.toString());
        Map<String, String> params = new HashMap<String, String>();
        params.put("phoneNo", loginRegVo.getPhone());
        params.put("validateCode", loginRegVo.getValidateCode());
        params.put("deviceNo", loginRegVo.getDeviceNo());
        params.put("osType", String.valueOf(loginRegVo.getOsType()));
        params.put("imei", loginRegVo.getImei());
        params.put("imsi", loginRegVo.getImsi());
        params.put("deviceMac", loginRegVo.getDeviceMac());
        params.put("sessionId", httpServletRequest.getSession().getId());
        params.put("lastLoginCityCode", loginRegVo.getLastLoginCityCode());
        params.put("passwd", loginRegVo.getPasswd());
        params.put("source", StringUtils.isEmpty(loginRegVo.getSource()) ? "internal-h5" : loginRegVo.getSource());
        PassengerBaseResponse<Object> passengerBaseResponse = new PassengerBaseResponse<>();
        com.smzc.innerServices.beans.passenger.SubscriberLoginGPSBean loginGPSBean = new SubscriberLoginGPSBean();
        BaseResponse<Object> h5Register = userService.validateSmsValidateCode(params, loginGPSBean);
        if (h5Register.getStatus().equals(ResponseStatus.ERROR)) {
            passengerBaseResponse.setErrorCode(h5Register.getErrorCode());
            passengerBaseResponse.setErrorMsg(h5Register.getErrorMsg());
            passengerBaseResponse.setStatus(PassengerResponseStatus.ERROR);
        }
        passengerBaseResponse.setData(h5Register.getData());
        return passengerBaseResponse;
    }

    @PostMapping("/h5Register")
    @ApiOperation("h5注册")
    @ApiVisitorIntercept(visitor = true)
    public PassengerBaseResponse<Object> h5Register(@RequestBody LoginRegVo loginRegVo, HttpServletRequest httpServletRequest) {
        log.info("登录入参：{}", loginRegVo.toString());
        Map<String, String> params = new HashMap<String, String>();
        params.put("phoneNo", loginRegVo.getPhone());
        params.put("validateCode", loginRegVo.getValidateCode());
        params.put("deviceNo", loginRegVo.getDeviceNo());
        params.put("osType", String.valueOf(loginRegVo.getOsType()));
        params.put("imei", loginRegVo.getImei());
        params.put("imsi", loginRegVo.getImsi());
        params.put("deviceMac", loginRegVo.getDeviceMac());
        params.put("sessionId", httpServletRequest.getSession().getId());
        params.put("lastLoginCityCode", loginRegVo.getLastLoginCityCode());
        params.put("passwd", loginRegVo.getPasswd());
        params.put("source", StringUtils.isEmpty(loginRegVo.getSource()) ? "internal-h5" : loginRegVo.getSource());
        PassengerBaseResponse<Object> passengerBaseResponse = new PassengerBaseResponse<>();
        com.smzc.innerServices.beans.passenger.SubscriberLoginGPSBean loginGPSBean = new SubscriberLoginGPSBean();
        BaseResponse<Object> h5Register = userService.h5Register(params, loginGPSBean);
        if (h5Register.getStatus().equals(ResponseStatus.ERROR)) {
            passengerBaseResponse.setErrorCode(h5Register.getErrorCode());
            passengerBaseResponse.setErrorMsg(h5Register.getErrorMsg());
            passengerBaseResponse.setStatus(PassengerResponseStatus.ERROR);
        }
        passengerBaseResponse.setData(h5Register.getData());
        return passengerBaseResponse;
    }

    @PostMapping("/checkScan")
    @ApiOperation("检查扫描是否成功")
    @ApiVisitorIntercept(visitor = true)
    public PassengerBaseResponse<CheckDriverStatusResponseVo> checkDriverStatus(@RequestBody CheckDriverStatusRequestVo checkDisCountRequestVo) {
        log.info("检查扫描是否成功入参：{}", checkDisCountRequestVo.toString());
        return new PassengerBaseResponse<>(loginFacade.checkDriverStatus(checkDisCountRequestVo));
    }

    private SendValidateCodeResponseVo sendCode(ValidateCodeRequestVo sendValidateRequestVo) {
        SendValidateCodeResponseVo sendValidateCodeResponseVo = new SendValidateCodeResponseVo();
        String validateCode = SmsValidateCodeUtil.genValidateCode();
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("code", validateCode);
        SmsParams smsParams = new SmsParams();
        smsParams.setMobileNo(sendValidateRequestVo.getPhone());
        smsParams.setTemplateCode(SmsTemplateConst.LOGIN_REGIST);
        smsParams.setParams(params);
        SmsResult smsResult = smsTemplate.send(SmsTypeEnum.VERIFICATION_CODE, smsParams);
        sendValidateCodeResponseVo.setSend(smsResult.isSuccess());
        if (smsResult.isSuccess()) {
            log.debug("短信发送成功, 发送成功: {}", smsParams);
            sendValidateCodeResponseVo.setNewUser(true);
            //生成验证码，存入Redis
            slaveRedisTemplate.opsForValue().set(RedisConst.PASSENGER_VALIDATE_CODE_BUCKET + sendValidateRequestVo.getPhone(),
                    validateCode, 300, TimeUnit.SECONDS);
            return sendValidateCodeResponseVo;
        } else {
            log.error("短信发送失败, 发送参数: {}, 失败原因: {}", smsParams, smsResult.getMsg());
        }
        return sendValidateCodeResponseVo;
    }

    /**
     * @Description: 判断是否为注册过的新用户
     *              因为注册过的170老用户没下过单在邀新活动中算新用户，但在发送短信验证码时不能屏蔽此类用户
     * @param sendValidateRequestVo
     * @param sendValidateCodeResponseVo
     * @Author: Yb.Z
     * @create: 2019/08/12 14:53
     * @return: boolean
     */
    private boolean isRegistedNewUser(ValidateCodeRequestVo sendValidateRequestVo, SendValidateCodeResponseVo sendValidateCodeResponseVo) {
        boolean registed = false;
        SubscriberVo subscriberVo = subscriberFacade.getSubscriberByMobileNo(sendValidateRequestVo.getPhone());
        if (Objects.nonNull(subscriberVo)) {
            registed = true;
            Boolean newUser = passengerOrdersFacade.checkNewUser(subscriberVo.getId());
            sendValidateCodeResponseVo.setNewUser(newUser);
            if (!newUser) {
                log.info("该用户不是新用户：{}", subscriberVo.getId());
                sendValidateCodeResponseVo.setMsg("您已使用过神马出租车!\n该活动仅有新用户才能扫码享受优惠");
            }
        }
        return registed;
    }
}
