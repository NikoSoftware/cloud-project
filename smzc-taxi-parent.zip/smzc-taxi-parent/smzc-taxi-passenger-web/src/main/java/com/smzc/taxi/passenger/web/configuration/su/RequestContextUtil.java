package com.smzc.taxi.passenger.web.configuration.su;

import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.ServletWebRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author shishun.wang
 * @version 1.0
 * @date 2019/5/23 11:08
 * @describe
 */
public class RequestContextUtil {
    /**
     * 获取当前请求HttpServletRequest实例
     * @return
     */
    public static HttpServletRequest getCurrentRequest(){
        return ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
    }

    /**
     * 获取当前响应HttpServletResponse实例
     * @return
     */
    public static HttpServletResponse getCurrentResponse(){
        return ((ServletWebRequest) RequestContextHolder.getRequestAttributes()).getResponse();
    }
    /**
     * 获取当前用户id
     * @return
     */
    public static Long getCurrentUserId(){
        Object attribute = getCurrentRequest().getAttribute(PassengerCommonDef.USERID);
        if (attribute == null || attribute.toString().equalsIgnoreCase("null")) {
            return null;
        }
        return Long.valueOf(String.valueOf(attribute));
    }
}
