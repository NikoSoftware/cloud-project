package com.smzc.taxi.passenger.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.smzc.lbs.service.bean.taxi.TaxiVehicleLocationBean;
import com.smzc.taxi.boot.response.HttpResponseEnum;
import com.smzc.taxi.boot.response.Response;
import com.smzc.taxi.passenger.web.configuration.ApiVisitorIntercept;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.service.driver.bean.DriverPointVo;
import com.smzc.taxi.service.passenger.IJourneyShareFacade;
import com.smzc.taxi.service.passenger.bean.JourneyShareResultVo;
import com.smzc.taxi.service.passenger.bean.ShortUrlMongoVo;
import com.smzc.taxi.service.su.PassengerBaseResponse;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.Assert;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @description 行程分享
 * @author qiukaihong
 * @date 2019/5/16 18:09
 */
@Slf4j
@RestController
@Api(tags = "行程分享")
@RequestMapping(PassengerCommonDef.RestfulApi.PREFIX +"/journeyShare")
public class JourneyShareController {

    @Reference(version = "1.0.0")
    private IJourneyShareFacade journeyShareFacade;

    /**
     * @description 获取行程分享结果 支持json
     * @param response
     * @param callback
     * @param orderId
     * @return void
     * @date 2019/5/22 11:11
     * @author qiukaihong
     */
    @ApiOperation("获取行程分享结果")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "callback", value = "回调函数"),
            @ApiImplicitParam(name = "orderId", value = "订单id", required = true)
    })
    @GetMapping("/getShareResult/{orderId}")
    @ApiVisitorIntercept(visitor = true)
    public void getShareResult(HttpServletResponse response, String callback, @PathVariable Long orderId) {
        log.info("获取行程分享结果，orderId：{}", orderId);
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/javascript;charset=UTF-8");
        Response resp;
        try(PrintWriter out = response.getWriter()) {
            if(null == orderId) {
                resp = Response.instance().result(HttpResponseEnum.ORDER_ID_EMPTY).build();
                if(StringUtils.isNotEmpty(callback)) {
                    out.write(callback + "(" + JSON.toJSONString(resp) + ")");
                    return;
                }
                out.write(JSON.toJSONString(resp));
                return;
            }
            resp = Response.instance().data(journeyShareFacade.getShareResult(orderId));
            log.info("获取行程分享结果：{}", JSON.toJSONString(resp.getData()));
            if(StringUtils.isNotEmpty(callback)) {
                out.write(callback + "(" + JSON.toJSONString(resp) + ")");// 返回jsonp格式数据
                return;
            }
            out.write(JSON.toJSONString(resp));
        } catch(Exception e) {
            log.error("获取行程分享数据出错!", e);
        }

    }

    /**
     * @description 获取行程轨迹，支持jsonp
     * @param response
     * @param callback
     * @param orderId
     * @return void
     * @date 2019/5/22 18:16
     * @author qiukaihong
     */
    @ApiOperation("获取行程轨迹")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "callback", value = "回调函数"),
            @ApiImplicitParam(name = "orderId", value = "订单id", required = true)
    })
    @GetMapping("/getOrderOrbit/{orderId}")
    @ApiVisitorIntercept(visitor = true)
    public void getOrderOrbit(HttpServletResponse response, String callback,
                              @PathVariable Long orderId) {
        log.info("获取行程轨迹，orderId:{}", orderId);
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/javascript;charset=UTF-8");
        try(PrintWriter out = response.getWriter()) {
            List<TaxiVehicleLocationBean> list = journeyShareFacade.getOrderTrajectory(orderId);
            log.info("获取行程轨迹结果：{}", JSON.toJSONString(list));
            if(StringUtils.isNotEmpty(callback)) {
                out.write(callback + "(" + JSON.toJSONString(list) + ")");// 返回jsonp格式数据
                return;
            }
            out.write(JSON.toJSONString(list));
        } catch(Exception e) {
            log.error("获取行程分享轨迹出错!", e);
        }

    }
    /**
     * @description 获取行程分享短信短链接
     * @param paramJson
     * @return com.smzc.taxi.boot.response.Response
     * @date 2019/5/22 18:17
     * @author qiukaihong
     */
    @ApiOperation("获取行程分享短信短链接")
    @PostMapping("/getShortMessageUrl")
    public PassengerBaseResponse getShortMessageUrl(@RequestBody String paramJson) {
        log.info("获取行程分享短信短链接，param:{}", paramJson);
        Map<String, String> map = Maps.newHashMap();
        map.put("title", "");
        map.put("content", "");
        map.put("url", journeyShareFacade.getShortMessageUrl(paramJson));
        log.info("获取行程分享短信短链接结果：{}", JSON.toJSONString(map));
        return new PassengerBaseResponse(map);
    }

    /**
     * @description 短链接重定向
     * @param response
     * @param code
     * @return void
     * @date 2019/5/22 18:17
     * @author qiukaihong
     */
    @ApiOperation("短链接重定向")
    @GetMapping("/redirectUrl")
    @ApiImplicitParams(
            @ApiImplicitParam(name = "code", value = "code", required = true)
    )
    @ApiVisitorIntercept(visitor = true)
    public void redirectUrl(HttpServletResponse response, String code) throws IOException {
        log.info("行程分享短链接重定向参数code:{}", code);
        Assert.hasLength(code, "code不能为空！");
        if(code.startsWith("/")) {
            code = code.substring(1);
        }
        String url = journeyShareFacade.getLongUrl(code);
        log.info("行程分享短链接重定向url:{}", url);
        if(StringUtils.isEmpty(url)) {
            response.setCharacterEncoding("UTF-8");
            response.setContentType("text/javascript;charset=UTF-8");
            try(PrintWriter writer = response.getWriter()) {
                writer.write("无此链接,请检查链接的正确性!");
            } catch(IOException e) {
                log.error("短链接重定向失败！", e);
            }
        } else {
            response.sendRedirect(url);
        }
    }
}
