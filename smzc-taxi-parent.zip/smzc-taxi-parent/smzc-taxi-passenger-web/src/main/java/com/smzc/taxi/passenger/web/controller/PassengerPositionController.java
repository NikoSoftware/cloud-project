package com.smzc.taxi.passenger.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.common.util.CommonUtil;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.passenger.web.configuration.su.RequestContextUtil;
import com.smzc.taxi.service.passenger.bean.PassengerPositionVo;
import com.smzc.taxi.service.passenger.exception.PassengerException;
import com.smzc.taxi.service.passenger.service.IPassengerPositionFacade;
import com.smzc.taxi.service.su.PassengerBaseResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Allen
 * @version 1.0
 * @date 2019/5/17 15:23
 */
@RestController
@RequestMapping(PassengerCommonDef.RestfulApi.PREFIX + "/passengerPosition")
@Api(tags = "乘客GPS位置")
@Slf4j
public class PassengerPositionController {
    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IPassengerPositionFacade passengerPositionFacade;

    @PostMapping("/report")
    @ApiOperation(value = "上报乘客最新GPS位置", notes = "TAXI-201906V001；1652；乘客端：获取用户用车，乘客最新gps位置；dev->李长春；")
    public PassengerBaseResponse reportPassengerPosition(@Validated @RequestBody PassengerPositionVo vo) {
        log.info("上报乘客最新GPS位置，请求参数：vo={}", vo);
        //  获取当前用户ID
        Long subscriberId = RequestContextUtil.getCurrentUserId();
        if (CommonUtil.isAnyEmpty(subscriberId)) {
            log.error("没有获取到当前用户ID");
            throw PassengerException.warn("没有获取到当前用户ID");
        }

        passengerPositionFacade.reportPassengerPosition(subscriberId, vo);
        return new PassengerBaseResponse<>();
    }
}
