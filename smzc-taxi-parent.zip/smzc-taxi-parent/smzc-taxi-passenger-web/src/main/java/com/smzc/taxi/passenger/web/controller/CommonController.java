package com.smzc.taxi.passenger.web.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.smzc.common.util.CommonUtil;
import com.smzc.innerServices.facade.passenger.ICityFacade;
import com.smzc.taxi.boot.redis.RedisLock;
import com.smzc.taxi.common.consts.RedisConst;
import com.smzc.taxi.passenger.web.configuration.ApiVisitorIntercept;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.service.passenger.bean.BusinessTypeVo;
import com.smzc.taxi.service.passenger.bean.CityVo;
import com.smzc.taxi.service.passenger.enums.BusinessTypeEnum;
import com.smzc.taxi.service.portal.bean.SystemConfigurationVo;
import com.smzc.taxi.service.portal.enums.SystemConfigurationEnum;
import com.smzc.taxi.service.portal.service.IOpenCityFacade;
import com.smzc.taxi.service.portal.service.ISystemConfigurationFacade;
import com.smzc.taxi.service.su.CacheContent;
import com.smzc.taxi.service.su.PassengerBaseResponse;
import com.smzc.us.shared.facade.SubscriberFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author shishun.wang
 * @version 1.0
 * @date 2019/5/20 17:07
 * @describe
 */
@Slf4j
@Validated
@ResponseBody
@RestController
@Api(tags = "公共管理—王仕顺")
@RequestMapping(PassengerCommonDef.RestfulApi.COMMON_PREFIX  + "/common")
public class CommonController {

    @Reference(cluster = "failfast", timeout = 30000, group = "passenger")
    private ICityFacade cityFacade;

    @Reference(cluster = "failfast", timeout = 30000, group = "userCenter", version = "1.0.0")
    private SubscriberFacade subscriberFacade;

    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private IOpenCityFacade openCityFacade;

    @Reference(cluster = "failfast", timeout = 30000, group = "smzc-taxi", version = "1.0.0")
    private ISystemConfigurationFacade systemConfigurationFacade;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private TaskExecutor taskExecutor;

    @Autowired
    private RedisLock redisLock;

    @PostMapping("/business/type")
    @ApiVisitorIntercept(visitor = true)
    @ApiOperation("通过城市CODE获取乘客打车业务线配置")
    public PassengerBaseResponse<List<BusinessTypeVo>> getBusinessTypeListByAreaCode(final @RequestBody CityVo cityVo) {
        log.info("通过城市CODE获取乘客打车业务线配置,请求参数:{}", cityVo);
        if (CommonUtil.isEmpty(cityVo.getAreaCode())) {
            return new PassengerBaseResponse<List<BusinessTypeVo>>(Collections.EMPTY_LIST);
        }

        SystemConfigurationVo systemConfiguration = systemConfigurationFacade.getSystemConfiguration(SystemConfigurationEnum.TAXI_BUSINESS, cityVo.getAreaCode());
        if (systemConfiguration != null && !Boolean.parseBoolean(systemConfiguration.getConfigValue())) {//检测出租车业务线是否开通
            return new PassengerBaseResponse<List<BusinessTypeVo>>(Collections.EMPTY_LIST);
        }

        CacheContent  content = (CacheContent) Optional.ofNullable(redisTemplate.opsForValue().get(RedisConst.TAXI_PASSENGER_BUSINESS_TYPE)).orElseGet(() -> {
            CacheContent cacheContent = new CacheContent(findBusinessType(cityVo.getAreaCode()));
            taskExecutor.execute(() -> redisTemplate.opsForValue().set(RedisConst.TAXI_PASSENGER_BUSINESS_TYPE, cacheContent));
            return cacheContent;
        });

        if (content.getExpireTime() <= System.currentTimeMillis()){
            taskExecutor.execute(() -> redisTemplate.opsForValue().set(RedisConst.TAXI_PASSENGER_BUSINESS_TYPE, new CacheContent(findBusinessType(cityVo.getAreaCode()))));
        }
        return new PassengerBaseResponse<List<BusinessTypeVo>>((List<BusinessTypeVo>) Optional.ofNullable(content.getContent()).orElseGet(() ->Collections.EMPTY_LIST));
    }

    private List<BusinessTypeVo> findBusinessType(String areaCode){
        List<BusinessTypeVo> vos = new ArrayList<BusinessTypeVo>();
        if (Optional.ofNullable(cityFacade.getCityList()).orElseGet(ArrayList::new).parallelStream().map(item -> {
            if (!areaCode.equals(String.valueOf(item.get("areaCode")))) {
                return null;
            }
            return item;
        }).filter(CommonUtil::isNotEmpty).collect(Collectors.toList()).size() > 0) {
            BusinessTypeVo vo = new BusinessTypeVo();
            vo.setCode(BusinessTypeEnum.SPECIAL.getCode());
            vo.setName(BusinessTypeEnum.SPECIAL.getDisplay());
            vo.setSerialNumber(BusinessTypeEnum.SPECIAL.getSerialNumber());
            vos.add(vo);
        }

        if (Optional.ofNullable(openCityFacade.selectOpenCityList()).orElseGet(ArrayList::new).parallelStream().map(item -> {
            if (!item.getAreaCode().equals(areaCode)) {
                return null;
            }
            return item;
        }).filter(CommonUtil::isNotEmpty).collect(Collectors.toList()).size() > 0) {
            BusinessTypeVo vo = new BusinessTypeVo();
            vo.setCode(BusinessTypeEnum.TAXI.getCode());
            vo.setName(BusinessTypeEnum.TAXI.getDisplay());
            vo.setSerialNumber(BusinessTypeEnum.TAXI.getSerialNumber());

            vos.add(vo);
        }

        return vos;
    }

    @PostMapping("/open/citys")
    @ApiVisitorIntercept(visitor = true)
    @ApiOperation("获取专车及出租车开通城市列表")
    public PassengerBaseResponse<List<Map<String, Object>>> openCityList() {
        CacheContent  content = (CacheContent) Optional.ofNullable(redisTemplate.opsForValue().get(RedisConst.TAXI_PASSENGER_OPEN_CITYS)).orElseGet(() -> {
            CacheContent cacheContent = new CacheContent(findOpenCity());
            taskExecutor.execute(() -> redisTemplate.opsForValue().set(RedisConst.TAXI_PASSENGER_OPEN_CITYS, cacheContent));
            return cacheContent;
        });
        if (content.getExpireTime() <= System.currentTimeMillis()){
            taskExecutor.execute(() -> redisTemplate.opsForValue().set(RedisConst.TAXI_PASSENGER_OPEN_CITYS, new CacheContent(findOpenCity())));
        }
        return new PassengerBaseResponse<List<Map<String, Object>>>((List<Map<String, Object>>) Optional.ofNullable(content.getContent()).orElseGet(() ->Collections.EMPTY_LIST));
    }

    private List<Map<String, Object>> findOpenCity(){
        List<String> taxiCityCodes = Optional.ofNullable(openCityFacade.selectOpenCityList()).orElseGet(ArrayList::new)
                .parallelStream().map(item -> item.getAreaCode()).collect(Collectors.toList());
        return Optional.ofNullable(cityFacade.getCityList()).orElseGet(ArrayList::new).parallelStream().map(item -> {
            if (taxiCityCodes.contains(item.get("areaCode"))) {
                item.put("openBusinessTypes", Arrays.asList(BusinessTypeEnum.SPECIAL, BusinessTypeEnum.TAXI));
            } else {
                item.put("openBusinessTypes", Arrays.asList(BusinessTypeEnum.SPECIAL));
            }
            return item;
        }).collect(Collectors.toList());
    }

}
