package com.smzc.taxi.passenger.web.configuration;

/**
 * @author shishun.wang
 * @version 1.0
 * @date 2019/5/23 10:35
 * @describe
 */
public interface PassengerCommonDef {

    String REQUESTER_ID = "client";
    String AUTHORIZATION = "Authorization";
    String REQUEST_ID = "Request-Id";
    String USERID = "userId";

    String ENCODE = "utf-8";
    String COMMON_ERROR_CODE = "ERR_COMMON_001";

    boolean isDev = true;
    Long DEV_DEFAULT_USER_ID = 1l;

    public interface RestfulApi{

        String VERSION = "1.0";

        String PREFIX = "taxi/restful/api/"+VERSION;

        String COMMON_PREFIX = "ommo/restful/api/"+VERSION;
    }
}
