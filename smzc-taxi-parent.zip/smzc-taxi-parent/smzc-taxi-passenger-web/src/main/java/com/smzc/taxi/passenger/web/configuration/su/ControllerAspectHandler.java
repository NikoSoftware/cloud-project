package com.smzc.taxi.passenger.web.configuration.su;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smzc.common.util.AesUtil;
import com.smzc.common.util.StringUtil;
import com.smzc.innerServices.BaseResponse;
import com.smzc.innerServices.ResponseStatus;
import com.smzc.innerServices.beans.passenger.SubscriberTokenBean;
import com.smzc.taxi.passenger.web.configuration.ApiVisitorIntercept;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * @author shishun.wang
 * @version 1.0
 * @date 2019/5/23 10:27
 * @describe
 */
@Slf4j
@Aspect
@Component
public class ControllerAspectHandler {

    @Autowired
    private RedisTemplate slaveRedisTemplate;

    //专车存放登录用户token   customer:login:token:1
    public static final String LOGIN_SESSION_TOKEN_BUCKET = "customer:login:token:";

    @Around("execution(* com.smzc.taxi.passenger.web.controller.**Controller.*(..))")
    public Object process(ProceedingJoinPoint point) throws Throwable {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();

        /*if (PassengerCommonDef.isDev){
            log.info("=========开发环境（配置默认访问用户）=======");
            request.setAttribute(PassengerCommonDef.USERID, PassengerCommonDef.DEV_DEFAULT_USER_ID);
            return point.proceed();
        }*/

        Method method = ((MethodSignature) point.getSignature()).getMethod();
        ApiVisitorIntercept intercept = method.getAnnotation(ApiVisitorIntercept.class);
        if (intercept != null && intercept.visitor()){
            return point.proceed();
        }

        String token = request.getHeader(PassengerCommonDef.AUTHORIZATION);

        log.info("客户端请求token==>{}",token);
        String[] decryptTokenStrs = null;
        if (StringUtil.isNotBlankOrNull(token)){
            try {
                decryptTokenStrs = AesUtil.aesDecrypt(token).split(":");
            } catch (Exception e) {
                log.error("非法的token:("+token+")"+e.getMessage(),e);
                putJson(response,"非法的token:("+token+")");
                return null;
            }
        }

        if (null == decryptTokenStrs || decryptTokenStrs.length ==0){
            putJson(response,"非法的请求,token不存在");
            return null;
        }

        String checkLoginUserId = request.getHeader(PassengerCommonDef.REQUEST_ID);
        long generationTokenTime = System.currentTimeMillis();
        if (StringUtils.isBlank(checkLoginUserId)) {
            checkLoginUserId = decryptTokenStrs[0];
            generationTokenTime = Long.parseLong(decryptTokenStrs[1]);
        } else {
            checkLoginUserId = "GROUP-"+checkLoginUserId;
            request.setAttribute(PassengerCommonDef.REQUESTER_ID, checkLoginUserId);
        }
        request.setAttribute(PassengerCommonDef.USERID, decryptTokenStrs[0]);

        if (StringUtils.isBlank(checkLoginUserId)) {
            putJson(response,"Token无效.token="+ Arrays.toString(decryptTokenStrs));
            return null;
        }

        Object obj = slaveRedisTemplate.opsForValue().get(LOGIN_SESSION_TOKEN_BUCKET + checkLoginUserId);
        if (obj == null){
            putJson(response,"非法的请求.token="+ token);
            return null;
        }

        if (JSON.parseObject(obj.toString(), SubscriberTokenBean.class).getGenerationTokenTime() != generationTokenTime){
            putJson(response,"非法的请求.token="+ token+",已失效");
            return null;
        }

        return point.proceed();
    }

    public void putJson(HttpServletResponse response,String message){
        try(PrintWriter writer = response.getWriter()){
            response.setCharacterEncoding("UTF-8");
            response.setContentType("application/json;charset=UTF-8");

            BaseResponse<Object> errorResponse = new BaseResponse<Object>();
            errorResponse.setStatus(ResponseStatus.ERROR);
            errorResponse.setErrorCode(PassengerCommonDef.COMMON_ERROR_CODE);
            errorResponse.setErrorMsg(message);
            writer.write(new ObjectMapper().writeValueAsString(errorResponse));
            writer.flush();
        }catch (Exception e){
            log.error("aop输出json错误",e);
        }
    }
}
