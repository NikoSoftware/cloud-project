package com.smzc.taxi.passenger.web.controller.helper.bean;

import com.smzc.taxi.service.order.bean.vo.OrderPayoffDetailContextDiffVo;
import lombok.Data;

import java.io.Serializable;

@Data
public class PayoffDetailResBean2 implements Serializable {
    private OrderPayoffDetailContextDiffVo detail;
    private String cityCode;
    private String cityName;
}

