package com.smzc.taxi.passenger.web.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSONObject;
import com.smzc.common.util.CommonUtil;
import com.smzc.taxi.common.third.safetycall.constant.YtxConstant;
import com.smzc.taxi.passenger.web.configuration.ApiVisitorIntercept;
import com.smzc.taxi.passenger.web.configuration.PassengerCommonDef;
import com.smzc.taxi.service.passenger.bean.price.OrderPriceCalculateVo;
import com.smzc.taxi.service.passenger.bean.price.PhoneCallBackResult;
import com.smzc.taxi.service.passenger.bean.price.PhoneCallDetailVo;
import com.smzc.taxi.service.passenger.bean.price.SafeCallPhoneVo;
import com.smzc.taxi.service.passenger.bean.price.UserPosition;
import com.smzc.taxi.service.passenger.enums.ErrorCode;
import com.smzc.taxi.service.passenger.exception.PassengerException;
import com.smzc.taxi.service.passenger.service.IPriceConfigureFacade;
import com.smzc.taxi.service.passenger.service.ISafeCallBindFacade;
import com.smzc.taxi.service.su.PassengerBaseResponse;

/**
 * @Description: 隐号管理
 * @author zhukai
 * @date 2019年5月22日 下午8:12:36
 */
@Slf4j
@Validated
@ResponseBody
@RestController
@Api(tags = "隐号管理")
@RequestMapping(PassengerCommonDef.RestfulApi.PREFIX + "/safecall")
public class SafeCallBindController {

    @Reference(group = "smzc-taxi", version = "1.0.0")
    private ISafeCallBindFacade safeCallBindFacade;
    @Reference(group = "smzc-taxi", version = "1.0.0")
    private IPriceConfigureFacade priceConfigureFacade;

    /**
     * 定义隐号回调接口,记录通话详情,请不要随意更改返回参数结构,否则会造成第三方连续通知
     * 
     * @author zhukai
     * @date 2019年5月28日 下午3:06:32
     * @param req
     * @param rep
     * @return
     */
    @ApiVisitorIntercept(visitor = true)
    @PostMapping("/saveCallDetail")
    public PhoneCallBackResult saveCallDetail(HttpServletRequest req, HttpServletResponse rep) {

        PhoneCallBackResult phoneCallBackResult = new PhoneCallBackResult();
        InputStream is = null;
        try {
            req.setCharacterEncoding("utf-8");
            is = req.getInputStream();
            ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int n = 0;
            while(-1 != (n = is.read(buffer))) {
                byteArray.write(buffer, 0, n);
            };
            String result = new String(byteArray.toByteArray(), "utf-8");
            safeCallBindFacade.safePhoneCallDetail(JSONObject.parseObject(result, PhoneCallDetailVo.class));
            // 返回成功标志通知第三方
            phoneCallBackResult.setStatusCode(YtxConstant.SUCESS);
        } catch(Exception e) {
            phoneCallBackResult.setStatusCode(YtxConstant.SUCESS);
            log.error("保存通话详情记录失败,待查找原因:", e);
        } finally {
            if(null != is) {
                try {
                    is.close();
                } catch(IOException e) {
                    log.error("隐号关闭流失败:", e);
                }
            }
        }
        return phoneCallBackResult;
    }

    @ApiOperation("释放隐号-巨人旗")
    @PostMapping("/releaseSafeCallPhone")
    public PassengerBaseResponse releaseSafeCallPhone(@RequestBody SafeCallPhoneVo safeCallPhoneVo){
        log.info("释放隐号，请求参数：{}", JSONObject.toJSONString(safeCallPhoneVo));
        if(CommonUtil.isAnyEmpty(safeCallPhoneVo.getOrderId(),safeCallPhoneVo.getAreaCode())){
            throw PassengerException.warn(ErrorCode.REQUIRED_PARAMETERS_MISSING.getDescribe());
        }
        safeCallBindFacade.releaseSafeCallPhone(safeCallPhoneVo.getOrderId(), safeCallPhoneVo.getAreaCode());
        PassengerBaseResponse response = new PassengerBaseResponse();
        log.info("释放隐号，响应数据:{}", JSONObject.toJSONString(response));
        return response;
    }

}
