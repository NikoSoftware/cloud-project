package com.smzc.taxi.passenger.web.controller.helper.bean;

import com.smzc.innerServices.BaseRequest;
import com.smzc.taxi.service.order.emun.OrderStatus;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@ApiModel("订单取消费请求参数")
@Data
@NoArgsConstructor
public class OrderCancelFeeBean implements Serializable {
    private static final long serialVersionUID = 2923414685824169711L;
    /**
     * 城市code
     */
    @ApiModelProperty(value = "订单Code", required = true, example = "1")
    private Long orderId;


}
