package com.smzc.taxi.passenger.web.controller.helper.bean;

import com.smzc.innerServices.BaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@ApiModel("获取订单司机位置请求参数")
@Data
@NoArgsConstructor
public class DriverLocationBean implements Serializable {
    private static final long serialVersionUID = 1657306661258221732L;
    /**
     * 车辆Id
     */
    @ApiModelProperty(value = "车辆Id", required = true, example = "1")
    private Long vehicleId;
    /**
     * 区域code
     */
    @ApiModelProperty(value = "区域code", required = true, example = "028")
    private String areaCode;


}
