package com.smzc.taxi.boot.sms;

import com.smzc.taxi.boot.sms.enums.SmsTypeEnum;
import com.smzc.taxi.boot.sms.properties.SmsParams;
import com.smzc.taxi.boot.sms.properties.SmsResult;

/**
 * @description 短信发送模板接口
 * @author qiukaihong
 * @date 2019/5/29 10:15
 */
public interface ISmsTemplate {
    /**
     * @description
     * @param smsType 短信类型 {@link SmsTypeEnum}
     * @param smsParams 短信参数
     * @return com.smzc.taxi.boot.sms.properties.SmsResult
     * @date 2019/5/29 10:15
     * @author qiukaihong
     */
    SmsResult send(SmsTypeEnum smsType, SmsParams smsParams);
}
