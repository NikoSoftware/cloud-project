package com.smzc.taxi.boot.jpush.properties;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import lombok.Data;

@Data
public class JpushParams {
	
	/**
	 * 设备编号
	 * **/
	private Set<String> deviceNos;
	
	/**
	 * 对应在yml内的参数名称
	 * **/
	private Map<String, Object> parmas;
	
	
	private Map<String, String> extrasParam= new HashMap<String, String>();
	
	/**
	 * 设备对应tag
	 * **/
	private Set<String> deviceTags;
	
	
}	

