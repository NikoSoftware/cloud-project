package com.smzc.taxi.boot.jpush.properties;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

@ConfigurationProperties("jpush")
@Data
public class JpushProperties {
	
	private String masterSecret;
	
	private String appKey;

	private Boolean apns;
    
	private Map<String, JpushMsgTemplate> msgTemplate;

}
