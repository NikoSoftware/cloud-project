package com.smzc.taxi.boot.jpush.context;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import com.smzc.taxi.boot.jpush.properties.JpushParams;

public class JpushContext {
	static ThreadLocal<WeakReference<JpushContext>> jpushActionContext = ThreadLocal
			.withInitial(() -> new WeakReference<>(new JpushContext(new ArrayList<>())));

	private List<JpushParams> jpushContext;

	private JpushContext(List<JpushParams> jpushContext) {
		this.jpushContext = jpushContext;
	}

	public static void setJpushContext(WeakReference<JpushContext> jpushContext) {
		jpushActionContext.set(jpushContext);
	}

	public static JpushContext getJpushContext() {
		if (jpushActionContext.get() == null) {
			JpushContext jpushContext = new JpushContext(new ArrayList<>());
			WeakReference<JpushContext> weakReference = new WeakReference<JpushContext>(jpushContext);
			jpushActionContext.set(weakReference);
			return weakReference.get();
		} else
			return jpushActionContext.get().get();
	}

	public void put(JpushParams jpushParams) {
		jpushContext.add(jpushParams);
	}

	public List<JpushParams> getJpushParams() {
		return jpushContext;
	}

}
