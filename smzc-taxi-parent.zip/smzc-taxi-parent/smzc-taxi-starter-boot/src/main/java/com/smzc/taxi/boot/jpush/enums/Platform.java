package com.smzc.taxi.boot.jpush.enums;

public enum Platform {

	ANDROID(0, "安卓"),
	
	IOS(1, "苹果"), 
	
	ALL(2, "ALL");

	private int code;
	private String name;

	private Platform(int code, String name) {
		this.code = code;
		this.name = name;
	}

	public static Platform fromCode(int code) {
		for (Platform item : values()) {
			if (item.code == code) {
				return item;
			}
		}
		return Platform.ALL;
	}

	public int getCode() {
		return code;
	}

	public String getName() {
		return this.name;
	}

}
