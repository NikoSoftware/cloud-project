package com.smzc.taxi.boot.sms.enums;

import com.smzc.taxi.boot.sms.HuaWeiSmsTemplate;
import com.smzc.taxi.boot.sms.ISmsTemplate;
import com.smzc.taxi.boot.sms.SmsTemplate;

public enum SmsChannelEnum {

    ALI_YUN(SmsTemplate.class),
    HUA_WEI(HuaWeiSmsTemplate.class);

    private Class<? extends ISmsTemplate> template;

    SmsChannelEnum(Class<? extends ISmsTemplate> template) {
        this.template = template;
    }

    public Class<? extends ISmsTemplate> getTemplate() {
        return template;
    }
}
