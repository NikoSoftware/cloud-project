package com.smzc.taxi.boot.jpush;

import cn.jpush.api.JPushClient;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Message;
import cn.jpush.api.push.model.Options;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.AndroidNotification;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;
import com.alibaba.fastjson.JSON;
import com.smzc.taxi.boot.jpush.context.JpushContext;
import com.smzc.taxi.boot.jpush.properties.JpushBody;
import com.smzc.taxi.boot.jpush.properties.JpushProperties;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.http.HttpStatus;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

@Slf4j
@NoArgsConstructor
public class JpushTemplate implements InitializingBean, DisposableBean {

	private JPushClient jPushClient;

	private JpushProperties jpushProperties;

	public JpushTemplate(JpushProperties jpushProperties) {
		this.jpushProperties = jpushProperties;
		this.jPushClient = new JPushClient(jpushProperties.getMasterSecret(), jpushProperties.getAppKey());

	}

	@Override
	public void afterPropertiesSet() {
		Assert.notNull(jpushProperties.getAppKey(), "appkey is null ");
		Assert.notNull(jpushProperties.getMasterSecret(), "masterSecret is null ");
		log.info("jpush init success,appkey [{}],masterSecret [{}]", jpushProperties.getAppKey(),jpushProperties.getMasterSecret());
	}

	@Override
	public void destroy() {
		JpushContext.setJpushContext(null);
	}

	public boolean send(JpushBody jpushBody) {
		Assert.notNull(jpushBody, "jpushBody is null");
		Assert.notNull(jpushBody.getTitle(), "jpush title is null");
		Assert.notNull(jpushBody.getContent(), "jpush content is null");
		Assert.notNull(jpushBody.getPlatform(), "jpush platform is null");
		log.info("jpush send body [{}],推送设备号:[{}],标签组:[{}],分群码:[{}]",
				JSON.toJSONString(jpushBody), jpushBody.getDeviceNos(),jpushBody.getDeviceTags(),jpushBody.getDeviceSegment());
		boolean result = false;
		try {
			PushPayload.Builder pushPayload = buildPushPayload(jpushBody);
			PushResult pushResult = jPushClient.sendPush(pushPayload.build());
			if (pushResult.getResponseCode() == HttpStatus.OK.value()) {
				log.info("jpush send result [{}]", pushResult.getResponseCode());
				result = true;
			}
		} catch (Exception e) {
			log.error("jpush send exception body [{}]", JSON.toJSONString(jpushBody));
			log.error("发送JPush消息异常", e);
		}

		return result;
	}

	private PushPayload.Builder buildPlatform(PushPayload.Builder builder, JpushBody jpushBody) {
		switch (jpushBody.getPlatform()) {
		case ANDROID:
			builder.setPlatform(Platform.android());
			buildAndroid(builder, jpushBody);
			break;
		case IOS:
			builder.setPlatform(Platform.ios());
			buildIOS(builder, jpushBody);
			break;
		default:
			Options options = Options.sendno();
			options.setApnsProduction(jpushProperties.getApns());
			builder.setPlatform(Platform.android_ios());
			builder.setNotification(Notification.newBuilder()
					.addPlatformNotification(AndroidNotification.newBuilder().setAlert(jpushBody.getContent())
							.setTitle(jpushBody.getTitle()).addExtras(jpushBody.getExtrasParam()).build())
					.addPlatformNotification(getNotificationApnsMessage(jpushBody)).build());
			builder.setOptions(options);
			break;
		}

		return builder;
	}

	private PushPayload.Builder buildPushPayload(JpushBody jpushBody) {

		PushPayload.Builder builder = PushPayload.newBuilder();
		switch (jpushBody.getPushMode()) {
		case GROUP:
			/**
			 * 1、首先取所有 all
			 * 2、deviceSegment有值，就 segment
			 * 3、deviceTags有值, 就 tag
			 * **/
			Audience audience = Audience.all();
			if (Strings.isNotBlank(jpushBody.getDeviceSegment())){
				audience = Audience.segment(jpushBody.getDeviceSegment());
			} else if (!CollectionUtils.isEmpty(jpushBody.getDeviceTags())){
				audience = Audience.tag(jpushBody.getDeviceTags());
			}
			builder.setAudience(audience);
			break;

		default:
			Assert.notNull(jpushBody.getDeviceNos(), "deviceNo is null ");
			builder.setAudience(Audience.registrationId(jpushBody.getDeviceNos()));
			break;
		}

		return buildPlatform(builder, jpushBody);
	}

	private PushPayload.Builder buildIOS(PushPayload.Builder builder, JpushBody jpushBody) {

		Options options = Options.sendno();
		/**
		 * /指定开发环境 true为生产模式 false 为测试模式 (android不区分模式,ios区分模式)
		 * */
		options.setApnsProduction(jpushProperties.getApns());
		switch (jpushBody.getMessageType()) {
		case BOTH:
			builder.setMessage(Message.newBuilder().addExtras(jpushBody.getExtrasParam()).addExtra("m_title",jpushBody.getTitle())
					.setMsgContent(jpushBody.getContent()).build());
			builder.setNotification(
					Notification.newBuilder().addPlatformNotification(getNotificationApnsMessage(jpushBody)).build());
			break;
		case NOTIFICATION:
			builder.setNotification(
					Notification.newBuilder().addPlatformNotification(getNotificationApnsMessage(jpushBody)).build());
		
			break;
		default:
			builder.setMessage(Message.newBuilder().addExtras(jpushBody.getExtrasParam()).addExtra("m_title",jpushBody.getTitle())
					.setMsgContent(jpushBody.getContent()).build());
			break;
		}
		
		builder.setOptions(options);
		return builder;
	}

	private IosNotification getNotificationApnsMessage(JpushBody jpushBody) {
		return IosNotification.newBuilder().setAlert(jpushBody.getContent()).setSound("push_alert.wav").setBadge(0)
				.addExtras(jpushBody.getExtrasParam()).addExtra("m_title", jpushBody.getTitle()).build();
	}

	/**
	 * 
	 * **/
	private PushPayload.Builder buildAndroid(PushPayload.Builder builder, JpushBody jpushBody) {
		switch (jpushBody.getMessageType()) {
		case NOTIFICATION:
			builder.setNotification(
					Notification.android(jpushBody.getContent(), jpushBody.getTitle(), jpushBody.getExtrasParam()));
			break;
		case BOTH:
			builder.setMessage(Message.newBuilder().addExtras(jpushBody.getExtrasParam()).setTitle(jpushBody.getTitle())
					.setMsgContent(jpushBody.getContent()).build());
			builder.setNotification(
					Notification.android(jpushBody.getContent(), jpushBody.getTitle(), jpushBody.getExtrasParam()));
			break;
		default:
			builder.setMessage(Message.newBuilder().addExtras(jpushBody.getExtrasParam()).setTitle(jpushBody.getTitle())
					.setMsgContent(jpushBody.getContent()).build());
			break;
		}

		return builder;
	}
}
