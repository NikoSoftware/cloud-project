package com.smzc.taxi.boot.mail;

import java.io.File;

import javax.mail.internet.MimeMessage;

import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.smzc.taxi.boot.mail.properties.MailInfo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SendMailTemplate{
	
   
    private JavaMailSender javaMailSender;
    
    
    public  SendMailTemplate(JavaMailSender javaMailSender) {
    	this.javaMailSender = javaMailSender;
    }
    
    public void sendSimpleTextMail(MailInfo mailInfo) {
    	Assert.notNull(StringUtils.isEmpty(mailInfo.getFromMail()), "fromMail is null");
    	Assert.notEmpty(mailInfo.getToMails(), "toMail is null");
    	Assert.notNull(StringUtils.isEmpty(mailInfo.getSubject()), "subject is null");
    	Assert.notNull(StringUtils.isEmpty(mailInfo.getContent()), "content is null");

    	SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setFrom(mailInfo.getFromMail());
        mailMessage.setTo(mailInfo.getToMails().iterator().next());
        if(!CollectionUtils.isEmpty(mailInfo.getCcMails())) {
        	mailMessage.setCc(mailInfo.getCcMails().iterator().next());
        }
        mailMessage.setSubject(mailInfo.getSubject());
        mailMessage.setText(mailInfo.getContent());
        try {
            javaMailSender.send(mailMessage);
            log.info("邮件发送成功,主题：{}",mailInfo.getSubject());
        } catch (Exception e) {
        	 log.error("发送邮件失败：{}",e);
        }
    }

	public void sendHtmlMail(MailInfo mailInfo) {
    	Assert.notNull(StringUtils.isEmpty(mailInfo.getFromMail()), "fromMail is null");
    	Assert.notEmpty(mailInfo.getToMails(),"toMail is null");
    	Assert.notNull(StringUtils.isEmpty(mailInfo.getSubject()), "subject is null");
    	Assert.notNull(StringUtils.isEmpty(mailInfo.getContent()), "content is null");

		MimeMessage mimeMailMessage = null;
        try {
            mimeMailMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMailMessage, true);
            mimeMessageHelper.setFrom(mailInfo.getFromMail());
            for(String to : mailInfo.getToMails()){
            	mimeMessageHelper.addTo(to);
            }
            if(!CollectionUtils.isEmpty(mailInfo.getCcMails())) {
	            for(String cc : mailInfo.getCcMails()){
		            mimeMessageHelper.addCc(cc);
	            }
            }
            mimeMessageHelper.setSubject(mailInfo.getSubject());
            mimeMessageHelper.setText(mailInfo.getContent(), true);
            javaMailSender.send(mimeMailMessage);
            log.info("邮件发送成功,主题:{}",mailInfo.getSubject());
        } catch (Exception e) {
        	 log.error("发送邮件失败：{}",e); 	
        }
	} 
	
	public void sendAttachmentMail(MailInfo mailInfo) {
    	Assert.notNull(StringUtils.isEmpty(mailInfo.getFromMail()), "fromMail is null");
    	Assert.notEmpty(mailInfo.getToMails(),"toMail is null");
    	Assert.notNull(StringUtils.isEmpty(mailInfo.getSubject()), "subject is null");
    	Assert.notNull(StringUtils.isEmpty(mailInfo.getContent()), "content is null");
    	Assert.notEmpty(mailInfo.getFiles(), "attachment is null");

		MimeMessage mimeMailMessage = null;
        try {
            mimeMailMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMailMessage, true);
            mimeMessageHelper.setFrom(mailInfo.getFromMail());
            for(String to : mailInfo.getToMails()){
            	mimeMessageHelper.addTo(to);
            }
            if(!CollectionUtils.isEmpty(mailInfo.getCcMails())) {
	            for(String cc : mailInfo.getCcMails()){
		            mimeMessageHelper.addCc(cc);
	            }
            }
            mimeMessageHelper.setSubject(mailInfo.getSubject());
            mimeMessageHelper.setText(mailInfo.getContent(),true);
            for(File attachment : mailInfo.getFiles()) {
                FileSystemResource file = new FileSystemResource(new File(attachment.getAbsolutePath()));
                mimeMessageHelper.addAttachment(file.getFilename(),file);	
            }
            javaMailSender.send(mimeMailMessage);
            log.info("邮件发送成功,主题：{}",mailInfo.getSubject());
        } catch (Exception e) {
           log.error("发送附件邮件失败：{}",e);
        }
    }
}
