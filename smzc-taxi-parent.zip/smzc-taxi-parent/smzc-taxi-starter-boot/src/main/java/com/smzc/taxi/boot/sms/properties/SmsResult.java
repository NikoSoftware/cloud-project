package com.smzc.taxi.boot.sms.properties;

/**
 * @Description: 短信调用返回结果
 * @author James
 * @time 下午3:45:38
 */
public class SmsResult{
    private boolean success;
	private String code;
	private String subCode;
	private String msg;

	public SmsResult(){
	}

	public SmsResult(boolean success, String code, String subCode, String msg) {
	    super();
	    this.success = success;
	    this.code = code;
	    this.subCode = subCode;
	    this.msg = msg;
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		if("isv.BUSINESS_LIMIT_CONTROL".equals(this.getSubCode())){
			this.msg = "发送短信频率过高,请稍后再试";
		}else if("isv.TEMPLATE_MISSING_PARAMETERS".equals(this.getSubCode())){
			this.msg = "短信模板参数缺失!";
		}
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getSubCode() {
	    return subCode;
    }

	public void setSubCode(String subCode) {
	    this.subCode = subCode;
    }

}
