package com.smzc.taxi.boot.operationlog.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("log")
public class OperationLogProperties {

}
