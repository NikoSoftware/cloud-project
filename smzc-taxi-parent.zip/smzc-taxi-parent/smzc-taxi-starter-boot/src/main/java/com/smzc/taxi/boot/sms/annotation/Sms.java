package com.smzc.taxi.boot.sms.annotation;

import com.smzc.taxi.boot.sms.enums.SmsChannelEnum;
import com.smzc.taxi.boot.sms.enums.SmsTypeEnum;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Sms {
	String value() default "";
	SmsChannelEnum channel() default SmsChannelEnum.ALI_YUN;
	SmsTypeEnum type() default SmsTypeEnum.NOTICE;
}
