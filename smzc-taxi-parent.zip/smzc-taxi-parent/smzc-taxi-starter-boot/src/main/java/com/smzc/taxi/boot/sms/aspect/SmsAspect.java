package com.smzc.taxi.boot.sms.aspect;

import com.smzc.taxi.boot.sms.ISmsTemplate;
import com.smzc.taxi.boot.sms.annotation.Sms;
import com.smzc.taxi.boot.sms.context.SmsContext;
import com.smzc.taxi.boot.sms.properties.SmsParams;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import java.lang.reflect.Method;
import java.util.List;

@Aspect
@Slf4j
@Component
public class SmsAspect implements InitializingBean {

	@Pointcut("@annotation(com.smzc.taxi.boot.sms.annotation.Sms)")
	public void pointCut() {
	}

	/**
	 * step 2
	 **/
	@Before("pointCut()")
	public void before(JoinPoint joinPoint) {

	}

	/**
	 * step 1
	 **/
	@Around("pointCut()")
	public Object advice(ProceedingJoinPoint joinPoint) {
		Object result = null;
		try {
			result = joinPoint.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * step 3,execute target method step 4
	 **/
	@After("pointCut()")
	public void after(JoinPoint joinPoint) {
		MethodSignature sign = (MethodSignature) joinPoint.getSignature();
		Method method = sign.getMethod();
		Sms annotation = method.getAnnotation(Sms.class);
		List<SmsParams> msgLists = SmsContext.getSmsContext().getSmsParams();
		WebApplicationContext context = ContextLoader.getCurrentWebApplicationContext();
		msgLists.stream().forEach(data -> {
			ISmsTemplate template = context.getBean(annotation.channel().getTemplate());
			template.send(annotation.type(), data);
		});
		SmsContext.setSmsContext(null);
	}

	@AfterThrowing(value="pointCut()",throwing="error")
	public void AfterThrowing(JoinPoint joinPoint, Throwable error) {
		MethodSignature sign = (MethodSignature) joinPoint.getSignature();
		Method method = sign.getMethod();
		log.error("target method [{}]throw exception ", method.getName(), error);
		SmsContext.setSmsContext(null);
	}

	@Override
	public void afterPropertiesSet() {
		log.info("sms aspect init successful!!!!!!!!");
	}
}
