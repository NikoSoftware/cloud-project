package com.smzc.taxi.boot.sms;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.smzc.taxi.boot.sms.enums.SmsTypeEnum;
import com.smzc.taxi.boot.sms.properties.HuaWeiSmsProperties;
import com.smzc.taxi.boot.sms.properties.SmsParams;
import com.smzc.taxi.boot.sms.properties.SmsResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.util.Asserts;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class HuaWeiSmsTemplate implements InitializingBean, DisposableBean, ISmsTemplate {
    private final HuaWeiSmsProperties huaWeiSmsProperties;
    private final RestTemplate restTemplate;

    public HuaWeiSmsTemplate(HuaWeiSmsProperties huaWeiSmsProperties) {
        restTemplate = new RestTemplate();
//        restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
        this.huaWeiSmsProperties = huaWeiSmsProperties;
    }

    private String getPhonesToString(String phones){
        Asserts.notBlank(phones, "手机号不能为空");
        return Arrays.asList(phones.trim().split(",")).stream().map(phone -> "+86" + phone).collect(Collectors.joining(","));

    }

    private String getTemplateParasToString(List<String> templateParas){
        String result = "";
        if (templateParas != null && templateParas.size() > 0){
            result = JSON.toJSONString(templateParas);
        }
        return result;
    }

    @Override
    public SmsResult send(SmsTypeEnum smsType, SmsParams smsParams) {

        MultiValueMap paramMap = new LinkedMultiValueMap<>();
        String paras = getTemplateParasToString((List<String>) Optional.ofNullable(smsParams.getParams())
                .orElse(Collections.emptyMap()).get("param"));
        paramMap.add("from", smsType.getSignatureChannel());
        paramMap.add("to", getPhonesToString(smsParams.getMobileNo()));
        paramMap.add("templateId", smsParams.getTemplateCode());
        paramMap.add("templateParas", paras);
        paramMap.add("statusCallback", huaWeiSmsProperties.getStatusCallback());

        HttpEntity request = new HttpEntity(paramMap, getHeader());
        ResponseEntity<String> response = restTemplate.postForEntity(huaWeiSmsProperties.getUrl(), request, String.class);
        log.info("钉钉消息:url--{}消息内容-->{},返回-->{}", huaWeiSmsProperties.getUrl(), JSON.toJSONString(smsParams), response.toString());
        if (response.getStatusCode() == HttpStatus.OK) {
            return getResult(response.getBody());
        } else {
            return new SmsResult(false, "-2", "-2", "调用短信接口异常:[]");
        }
    }

    private HttpHeaders getHeader(){
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.add("Content-Type", "application/x-www-form-urlencoded");
        requestHeaders.add("Authorization", huaWeiSmsProperties.getAuthHeaderValue());
        requestHeaders.add("X-WSSE", buildWsseHeader(huaWeiSmsProperties.getAppKey(), huaWeiSmsProperties.getAppSecret()));
        return requestHeaders;
    }

    private SmsResult getResult (String results) {
        SmsResult smsResult = new SmsResult();
        JSONObject jsStr = JSONObject.parseObject(results);
        smsResult.setCode(jsStr.getString("code"));
        smsResult.setMsg(jsStr.getString("description"));
        smsResult.setSuccess("000000".equals(smsResult.getCode()));
        return smsResult;
    }

    private String buildWsseHeader(String appKey, String appSecret) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        String time = sdf.format(new Date());
        String nonce = UUID.randomUUID().toString().replace("-", "");
        MessageDigest md;
        byte[] passwordDigest = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
            md.update((nonce + time + appSecret).getBytes());
            passwordDigest = md.digest();
        } catch (NoSuchAlgorithmException e) {
            log.error(e.getMessage(), e);
        }
        String passwordDigestBase64Str = Base64.getEncoder().encodeToString(passwordDigest);
        return String.format(huaWeiSmsProperties.getWsseHeaderFormat(), appKey, passwordDigestBase64Str, nonce, time);
    }

    @Override
    public void destroy() {
        log.info("huaWei sms template init success!!!");
    }

    @Override
    public void afterPropertiesSet() {
        log.info("huaWei sms template init success!!!");
    }
}
