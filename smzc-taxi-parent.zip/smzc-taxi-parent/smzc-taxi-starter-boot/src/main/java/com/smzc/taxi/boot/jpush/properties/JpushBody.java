package com.smzc.taxi.boot.jpush.properties;

import lombok.Data;
import java.util.Map;
import java.util.Set;

import com.smzc.taxi.boot.jpush.enums.MessageType;
import com.smzc.taxi.boot.jpush.enums.Platform;
import com.smzc.taxi.boot.jpush.enums.PushMode;

@Data
public class JpushBody {
		
	private final static PushMode DEFAULT_PUSHMODE = PushMode.SINGLE;
	
	private final static MessageType DEFAULT_MESSAGETYPE = MessageType.MESSAGE;
	
	private final static Platform DEFAULT_PLATFORM = Platform.ALL;
	
    /**
     * 消息标题
     */
    private String title;

    /**
     * 消息内容
     */
    private String content;

    /**
     * 通知平台类型 android 或 ios
     */
    private Platform platform = DEFAULT_PLATFORM;

    /**
     * APP设备编码组
     */
    private Set<String> deviceNos;
    
    /**
     * 标签组
     * **/
    private Set<String> deviceTags;

    /**
     * 分群码,极光限制一次只能给一个分群发
     */
    private String deviceSegment;

    /**
     * 附件参数 json格式
     */
    private Map<String,String> extrasParam;
    
    /**
     * 默认推送单条
     * **/
    private PushMode pushMode = DEFAULT_PUSHMODE;
    
    /**
     * 发送类型,通知或者消费
     * 默认推送消费
     * **/
    private MessageType messageType = DEFAULT_MESSAGETYPE;

    public String getTitle() {
        return title == null ? "" : title;
    }

    public String getContent() {
        return content == null ? "" : content;
    }
}
