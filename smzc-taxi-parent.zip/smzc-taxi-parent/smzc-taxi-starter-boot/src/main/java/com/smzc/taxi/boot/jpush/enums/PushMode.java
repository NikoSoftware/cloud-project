package com.smzc.taxi.boot.jpush.enums;

public enum PushMode {
	
	GROUP,
	
	SINGLE;

}
