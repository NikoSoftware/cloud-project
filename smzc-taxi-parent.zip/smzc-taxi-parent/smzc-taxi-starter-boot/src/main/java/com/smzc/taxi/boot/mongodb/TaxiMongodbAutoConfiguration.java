package com.smzc.taxi.boot.mongodb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

@Configuration
@ConditionalOnProperty(value = "spring.data.mongodb")
@EnableConfigurationProperties(MongoProperties.class)
public class TaxiMongodbAutoConfiguration {
	
	@Autowired
	private MongoProperties mongoProperties;
	
	@Bean
	@ConditionalOnMissingBean(MongoTemplate.class)
    public MongoTemplate mongoTemplate(@Autowired MongoDbFactory mongoDbFactory) {
		return new MongoTemplate(mongoDbFactory);
    }
	
	@Bean
	@ConditionalOnMissingBean(MongoDbFactory.class)
	public MongoDbFactory mogoDbFactory() {
		 return new SimpleMongoDbFactory(mongoClientURI());
	}
	
	@Bean
	@ConditionalOnMissingBean(MongoClient.class)
	public MongoClientURI mongoClientURI() {
		return new MongoClientURI(mongoProperties.getUri());
	}
}
