package com.smzc.taxi.boot.jpush.enums;

public enum MessageType {
	/**
	 * 消息
	 * **/
	MESSAGE,
	
	/***
	 * 通知
	 * **/
	NOTIFICATION,
	
	/**
	 * 消息与通知都发
	 * **/
	BOTH;

}
