package com.smzc.taxi.boot.mq;

import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@AutoConfigureAfter(RocketMQTemplate.class)
public class SmRocketMqAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(SmRocketMqTemplate.class)
    public SmRocketMqTemplate smMqTemplate() {
        return new SmRocketMqTemplate();
    }
}
