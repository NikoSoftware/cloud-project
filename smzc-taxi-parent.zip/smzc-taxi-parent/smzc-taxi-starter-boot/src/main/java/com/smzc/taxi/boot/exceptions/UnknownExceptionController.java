package com.smzc.taxi.boot.exceptions;

import com.smzc.taxi.boot.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;


/**
 * @author Administrator
 * @date 2018年5月5日
 * 未知错误异常处理
 */
@RestController
public class UnknownExceptionController implements ErrorController {
    private final static Logger logger = LoggerFactory.getLogger(UnknownExceptionController.class);

    private final static String ERROR_PATH = "/error";

    private final static String ERROR_MESSAGE = "系统内部处理异常";

    @RequestMapping("/error")
    public Response<Void> handleError(HttpServletRequest request) {
        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        Exception exception = (Exception) request.getAttribute("javax.servlet.error.exception");
        String requestUri = (String) request.getAttribute("javax.servlet.error.request_uri");
        if (requestUri == null) {
            requestUri = "Unknown";
        }
        if (statusCode == 401) {
            logger.error(requestUri, exception);
            return Response.instance().message(requestUri + "401").code(-1).build();
        } else if (statusCode == 404) {
            logger.error(requestUri, exception);
            return Response.instance().message(requestUri + "404,请求路径不存在").code(-1).build();
        } else if (statusCode == 403) {
            logger.error("status {},path {},exception", statusCode, requestUri, exception);
            return Response.instance().message(requestUri + "403").code(-1).build();
        } else {
            String msg = null;
            if (exception != null && exception.getMessage() != null) {
                String[] str = exception.getMessage().split(":");
                if (str.length == 2)
                    msg = str[1];
                else
                    msg = ERROR_MESSAGE;
                logger.error(requestUri, exception);
            }

            return Response.instance().message(requestUri + " " + msg).code(-1).build();
        }

    }

    @Override
    public String getErrorPath() {
        return ERROR_PATH;
    }

}
