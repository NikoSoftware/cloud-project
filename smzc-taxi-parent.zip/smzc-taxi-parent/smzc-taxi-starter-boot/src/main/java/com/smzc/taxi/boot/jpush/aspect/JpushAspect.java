package com.smzc.taxi.boot.jpush.aspect;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import org.apache.commons.text.StringSubstitutor;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import com.smzc.taxi.boot.jpush.JpushTemplate;
import com.smzc.taxi.boot.jpush.annotation.Jpush;
import com.smzc.taxi.boot.jpush.context.JpushContext;
import com.smzc.taxi.boot.jpush.properties.JpushBody;
import com.smzc.taxi.boot.jpush.properties.JpushMsgTemplate;
import com.smzc.taxi.boot.jpush.properties.JpushParams;
import com.smzc.taxi.boot.jpush.properties.JpushProperties;

import lombok.extern.slf4j.Slf4j;



@Aspect
@Slf4j
@Component
@ConditionalOnProperty(prefix="jpush",name = "enable", havingValue = "true")
public class JpushAspect {
	
	@Autowired
	private JpushTemplate JpushTemplate; 
	
	@Autowired 
	private JpushProperties jpushProperties;
	
	
	
	@Pointcut("@annotation(com.smzc.taxi.boot.jpush.annotation.Jpush)")
	public void pointCut() {
	}

	/**
	 * step 2
	 **/
	@Before("pointCut()")
	public void before(JoinPoint joinPoint) {
		
	}

	
	
	/**
	 * step 1
	 **/
	@Around("pointCut()")
	public Object advice(ProceedingJoinPoint joinPoint) {
		Object result = null;
		try {
			result = joinPoint.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * step 3,execute target method step 4
	 **/
	@After("pointCut()")
	public void after(JoinPoint joinPoint) {
		MethodSignature sign = (MethodSignature) joinPoint.getSignature();
		Method method = sign.getMethod();
		Jpush annotation = method.getAnnotation(Jpush.class);
		String templateName = annotation.value();
		log.info("msgType [{}]",templateName);
		JpushMsgTemplate msgTemplate = jpushProperties.getMsgTemplate().get(templateName);
		Assert.notNull(msgTemplate," msgTemplate对应的value为空" );
		List<JpushParams> msgLists= JpushContext.getJpushContext().getJpushParams();
		msgLists.stream().forEach(data->{
			JpushBody jpushBody = new JpushBody();
			jpushBody.setTitle(replacePlaceholder(data.getParmas(),msgTemplate.getMessageTitle()));
			jpushBody.setContent(replacePlaceholder(data.getParmas(),msgTemplate.getMessageContent()));
			jpushBody.setExtrasParam(data.getExtrasParam());
			jpushBody.setMessageType(annotation.messageType());
			jpushBody.setPushMode(annotation.pushMode());
			jpushBody.setPlatform(annotation.platform());
			jpushBody.setDeviceNos(data.getDeviceNos());
			jpushBody.setDeviceTags(data.getDeviceTags());
			JpushTemplate.send(jpushBody);
		});
		JpushContext.setJpushContext(null);
	}
	
	
	private String replacePlaceholder(Map<String, Object> data,String template) {
		StringSubstitutor stringSubstitutor = new StringSubstitutor(data);
		return stringSubstitutor.replace(template);
	}
	
	@org.aspectj.lang.annotation.AfterThrowing(throwing="error",pointcut="pointCut()")
	public void AfterThrowing(JoinPoint joinPoint, Throwable error) {
		MethodSignature sign = (MethodSignature) joinPoint.getSignature();
		Method method = sign.getMethod();
		log.error("target method [{}]throw exception ", method.getName(),error);
		JpushContext.setJpushContext(null);
	}
	
}
