package com.smzc.taxi.boot.operationlog.annotation;

public @interface OperationLog {
	
	String value() default ""; 
	
}
