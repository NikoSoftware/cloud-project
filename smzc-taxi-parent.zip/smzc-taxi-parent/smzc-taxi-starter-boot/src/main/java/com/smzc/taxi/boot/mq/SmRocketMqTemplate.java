package com.smzc.taxi.boot.mq;

import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.apache.rocketmq.spring.support.RocketMQHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;

import java.util.HashMap;
import java.util.Map;

public class SmRocketMqTemplate {

    @Autowired(required = false)
    private RocketMQTemplate rocketMQTemplate;

    public void syncSend(String topic, String tag, Object payload) {
        rocketMQTemplate.syncSend(topic + (StringUtils.isEmpty(tag) ? "" : (":" + tag)), payload);
    }

    public void syncSend(String topic, String tag, Object payload,String key) {
        rocketMQTemplate.syncSend(topic + (StringUtils.isEmpty(tag) ? "" : (":" + tag)), getMqMessage(payload, key));
    }


    public void syncSendOrderly(String topic, String tags, Object payload, String orderId) {
        rocketMQTemplate.syncSendOrderly(topic + (StringUtils.isEmpty(tags) ? "" : (":" + tags)), getMqMessage(payload, orderId),orderId);
    }

    public void asyncSend(String topic, String tag, Object payload, SendCallback sendCallback) {
        rocketMQTemplate.asyncSend(topic + (StringUtils.isEmpty(tag) ? "" : (":" + tag)), payload, sendCallback);
    }

    public void syncSend(String topic, Object payload) {
        rocketMQTemplate.syncSend(topic, payload);
    }

    public void asyncSend(String topic, Object payload, SendCallback sendCallback) {
        rocketMQTemplate.asyncSend(topic, payload, sendCallback);
    }

    private Message<Object> getMqMessage(final Object payload, final String orderId) {
        return new Message<Object>() {
            @Override
            public Object getPayload() {
                return payload;
            }

            @Override
            public MessageHeaders getHeaders() {
                Map<String, Object> map = new HashMap<>();
                map.put(RocketMQHeaders.KEYS, orderId);
                return new MessageHeaders(map);
            }
        };
    }


}
