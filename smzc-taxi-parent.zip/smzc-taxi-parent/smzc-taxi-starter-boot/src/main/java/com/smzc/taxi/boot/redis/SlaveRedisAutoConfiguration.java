package com.smzc.taxi.boot.redis;

import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.time.Duration;
import java.util.Objects;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisNode;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.alibaba.fastjson.support.spring.GenericFastJsonRedisSerializer;
import com.smzc.taxi.boot.redis.properties.SlaveRedisProperties;

import lombok.extern.slf4j.Slf4j;

@Configuration
@ConditionalOnProperty(value = "spring.redis.slave.enabled")
@EnableConfigurationProperties(SlaveRedisProperties.class)
@ConditionalOnClass({ RedisTemplate.class })
@EnableCaching
@Slf4j
public class SlaveRedisAutoConfiguration {

	@Autowired
	private SlaveRedisProperties slaveRedisProperties;

	@Bean("slaveRedisTemplate")
	public RedisTemplate<String, Object> slaveRedisTemplate(@Autowired RedisSerializer<Object> redisSerializer)
			throws UnknownHostException {
		RedisTemplate<String, Object> template = new RedisTemplate<String, Object>();
		template.setConnectionFactory(salveRedisConnectionFactory());
		template.setHashValueSerializer(redisSerializer);
		template.setValueSerializer(redisSerializer);
		StringRedisSerializer stringRedisSerializer = new StringRedisSerializer(Charset.forName("UTF-8"));
		template.setHashKeySerializer(stringRedisSerializer);
		template.setKeySerializer(stringRedisSerializer);
		log.info("salveRedisTemplate init success");
		return template;
	}

	@Bean
	public RedisSerializer<Object> slaveRedisSerializer() {
		return new GenericFastJsonRedisSerializer();
	}

	@Bean
	@ConditionalOnMissingBean(CacheManager.class)
	public CacheManager slaveCacheManager() {
		RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig();
		config = config.entryTtl(Duration.ofHours(1)) // 设置缓存的默认过期时间
				.disableCachingNullValues(); // 不缓存空值

		RedisCacheManager cacheManager = RedisCacheManager.builder(salveRedisConnectionFactory()) // 使用自定义的缓存配置初始化一个cacheManager
				/*	.initialCacheNames(cacheNames) // 注意这两句的调用顺序，一定要先调用该方法设置初始化的缓存名，再初始化相关的配置
					.withInitialCacheConfigurations(configMap).build();*/
				.build();
		return cacheManager;

	}

	@Bean
	public RedisConnectionFactory salveRedisConnectionFactory() {

		RedisSentinelConfiguration sentinelConfiguration = new RedisSentinelConfiguration();
		slaveRedisProperties.getSentinel().getNodes().forEach(host -> {
			String[] item = host.split(":");
			String ip = item[0];
			String port = item[1];
			sentinelConfiguration.addSentinel(new RedisNode(ip, Integer.parseInt(port)));
		});
		sentinelConfiguration.setMaster(slaveRedisProperties.getSentinel().getMaster());
		sentinelConfiguration.setDatabase(slaveRedisProperties.getDatabase());
		GenericObjectPoolConfig genericObjectPoolConfig = new GenericObjectPoolConfig();
		genericObjectPoolConfig.setMaxTotal(slaveRedisProperties.getLettuce().getPool().getMaxActive());
		genericObjectPoolConfig.setMinIdle(slaveRedisProperties.getLettuce().getPool().getMinIdle());
		genericObjectPoolConfig.setMaxIdle(slaveRedisProperties.getLettuce().getPool().getMaxIdle());
		genericObjectPoolConfig.setMaxWaitMillis(slaveRedisProperties.getLettuce().getPool().getMaxWait().getSeconds());

		LettucePoolingClientConfiguration.LettucePoolingClientConfigurationBuilder builder = LettucePoolingClientConfiguration
				.builder();
		builder.poolConfig(genericObjectPoolConfig);
		builder.commandTimeout(Duration.ofSeconds(slaveRedisProperties.getTimeout().getSeconds()));
		LettuceConnectionFactory connectionFactory = new LettuceConnectionFactory(sentinelConfiguration,
				builder.build());
		//connectionFactory.afterPropertiesSet();
		return connectionFactory;
	}

	@Bean("salveKeyGenerator")
	public KeyGenerator keyGenerator() {
		return new KeyGenerator() {
			@Override
			public Object generate(Object target, java.lang.reflect.Method method, Object... params) {
				StringBuilder sb = new StringBuilder();
				sb.append(target.getClass().getName());
				sb.append(method.getName());
				for (Object obj : params) {
					if (!Objects.isNull(obj)) {
						sb.append(obj.toString());
					}
				}
				return sb.toString();
			}
		};
	}

}
