package com.smzc.taxi.boot.sms.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

@Data
@ConfigurationProperties("sms")
public class SmsProperties {

	private String host;
	
	private String appKey;
	
	private String appSecret;
	
	private String signName;
	
}
