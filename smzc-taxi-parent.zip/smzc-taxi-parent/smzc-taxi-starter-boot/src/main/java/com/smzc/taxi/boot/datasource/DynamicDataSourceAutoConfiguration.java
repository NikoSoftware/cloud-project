package com.smzc.taxi.boot.datasource;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.ibatis.io.VFS;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.boot.autoconfigure.MybatisProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ResourceLoader;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.alibaba.druid.pool.DruidDataSource;
import com.smzc.taxi.boot.datasource.aspect.DataSourceAspect;
import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;

@Configuration
@ConditionalOnClass({ SqlSessionFactory.class, SqlSessionFactoryBean.class, DruidDataSource.class })
@ConditionalOnProperty(value = { "spring.datasource.druid.master",
		"spring.datasource.druid.slave" }, matchIfMissing = true)
@EnableAspectJAutoProxy(proxyTargetClass = true)
@EnableConfigurationProperties(MybatisProperties.class)
@AutoConfigureBefore(DataSourceAutoConfiguration.class)
public class DynamicDataSourceAutoConfiguration {

	@Bean(name = "masterDataSource", initMethod = "init", destroyMethod = "close")
	@Primary
	@ConfigurationProperties(prefix = "spring.datasource.druid.master")
	public DataSource masterDataSource() {
		DataSource dataSource = DataSourceBuilder.create(this.getClass().getClassLoader())
				.type(com.alibaba.druid.pool.DruidDataSource.class).build();
		return dataSource;
	}

	@Bean(name = "slaveDataSource", initMethod = "init", destroyMethod = "close")
	@ConfigurationProperties(prefix = "spring.datasource.druid.slave")
	public DataSource slaveDataSource() {
		DataSource dataSource = DataSourceBuilder.create(this.getClass().getClassLoader())
				.type(com.alibaba.druid.pool.DruidDataSource.class).build();
		return dataSource;
	}

	@Bean(name = "routingDataSource")
	public DynamicDataSource dataSource(@Autowired @Qualifier("masterDataSource") DataSource masterDataSource,
			@Autowired @Qualifier("slaveDataSource") DataSource slaveDataSource) {
		Map<Object, Object> targetDataSources = new HashMap<Object, Object>(2);
		targetDataSources.put(DataSourceAddr.MASTER, masterDataSource);
		targetDataSources.put(DataSourceAddr.SLAVE, slaveDataSource);
		return new DynamicDataSource(masterDataSource, targetDataSources);
	}

	/**
	 * 此处必须配置，否者determineCurrentLookupKey不能生效
	 * **/
	@Bean
	@ConditionalOnMissingBean
	public SqlSessionFactory sqlSessionFactory(@Autowired @Qualifier("routingDataSource") DataSource routingDataSource,
			@Autowired MybatisProperties mybatisProperties, @Autowired ResourceLoader resourceLoader) throws Exception {
		SqlSessionFactoryBean factory = new SqlSessionFactoryBean();
		//set config
		factory.setVfs(EcondingVFS.class);
		factory.setDataSource(routingDataSource);
		if (StringUtils.hasText(mybatisProperties.getConfigLocation())) {
			factory.setConfigLocation(resourceLoader.getResource(mybatisProperties.getConfigLocation()));
		}
		if (!ObjectUtils.isEmpty(mybatisProperties.resolveMapperLocations())) {
			factory.setMapperLocations(mybatisProperties.resolveMapperLocations());
		}

		if (!ObjectUtils.isEmpty(mybatisProperties.getTypeHandlersPackage())) {
			factory.setTypeHandlersPackage(mybatisProperties.getTypeHandlersPackage());
		}

		if (!ObjectUtils.isEmpty(mybatisProperties.getTypeAliasesPackage())) {
			factory.setTypeAliasesPackage(mybatisProperties.getTypeAliasesPackage());
		}

		org.apache.ibatis.session.Configuration configuration = new org.apache.ibatis.session.Configuration();
		configuration.setMapUnderscoreToCamelCase(true);
		factory.setConfiguration(configuration);

		return factory.getObject();
	}

	/***必须配置数据源对应事务**/
	@Bean
	@ConditionalOnMissingBean
	public DataSourceTransactionManager dataSourceTransactionManager(
			@Autowired @Qualifier("routingDataSource") DataSource routingDataSource) {
		return new DataSourceTransactionManager(routingDataSource);
	}

	@Bean
	@ConditionalOnMissingBean(DataSourceAspect.class)
	public DataSourceAspect dataSourceAspect() {
		return new DataSourceAspect();
	}

}
