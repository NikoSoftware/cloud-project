package com.smzc.taxi.boot.sms.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties("hw.sms")
public class HuaWeiSmsProperties {
    private String wsseHeaderFormat;
    private String authHeaderValue;
    private String url;
    private String appKey;
    private String appSecret;
    private String statusCallback;
    private Boolean enable;
}
