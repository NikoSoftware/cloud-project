package com.smzc.taxi.boot.filter;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

//@WebFilter
//@Component
@Slf4j
//@ConditionalOnWebApplication
/**
 * 对请求参数进行xss以及sql过滤
 **/
public class RequestParameterFilter implements Filter {

	private final static String excludeUrl[] = {"/v2/api-docs", "/swagger-ui", "/webjars/", "/swagger-resources/","/csrf" };
	
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		try {
			boolean flag = false;
			String path = ((HttpServletRequest) request).getRequestURI();
			for (String url : excludeUrl) {
				if (path.startsWith(url)) {
					flag = true;
					break;
				}
			}
			if (!flag) {
				Map<String, String[]> bodyMap = new HashMap<String, String[]>(request.getParameterMap());
				Map<String, String> headerMap = new HashMap<>(getHeaders((HttpServletRequest) request));
				HttpServletRequest req = new ParameterRequestWrapper((HttpServletRequest) request, bodyMap, headerMap);
				chain.doFilter(req, response);
			}else
				chain.doFilter(request, response);
			
		} finally {

		}
	}

	public void destroy() {

	}

	private Map<String, String> getHeaders(HttpServletRequest request) {
		Map<String, String> map = new HashMap<String, String>();
		Enumeration<?> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String key = (String) headerNames.nextElement();
			String value = request.getHeader(key);
			map.put(key, value);
		}
		return map;
	}

	/**
	 * 将请求参数重新包装到Map 重写部分方法
	 **/
	class ParameterRequestWrapper extends HttpServletRequestWrapper {

		private Map<String, String[]> bodyParams;

		private Map<String, String> headerParams;

		public ParameterRequestWrapper(HttpServletRequest request, Map<String, String[]> bodyParams,
				Map<String, String> headerParams) {
			super(request);
			this.bodyParams = bodyParams;
			this.headerParams = headerParams;
			updateParameterMap(request);

		}

		/***
		 * 重写getHeader将参数名和参数值都做xss过滤。
		 */
		public String getHeader(String name) {
			String value = headerParams.get(name);
			if (StringUtils.isNoneBlank(value))
				value = StringEscapeUtils.escapeHtml4(value);
			return value;
		}

		/***
		 * 
		 * 重写getParameter参数名和参数值都做xss过滤
		 **/
		@Override
		public String getParameter(String name) {
			Object value = bodyParams.get(name);
			String result = null;
			if (value instanceof String[]) {
				String[] strArr = (String[]) value;
				if (strArr.length > 0) {
					result = StringEscapeUtils.escapeHtml4(strArr[0]);
				} else {
					result = null;
				}
			} else if (value instanceof String) {
				result = StringEscapeUtils.escapeHtml4(String.valueOf(value));
			} else
				result = null;
			return result;
		}

		public Map<String, String[]> getParameterMap() {
			return bodyParams;
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public Enumeration<String> getParameterNames() {
			Vector vector = new Vector(bodyParams.keySet());
			return vector.elements();
		}

		@Override
		public String[] getParameterValues(String name) {
			String[] result = null;
			Object value = bodyParams.get(name);
			if (value instanceof String[]) {
				String[] temp = (String[]) value;
				result = new String[temp.length];
				for (int i = 0; i < temp.length; i++) {
					result[i] = StringEscapeUtils.escapeHtml4(temp[i]);
				}

			} else if (value instanceof String) {
				result = new String[] { StringEscapeUtils.escapeHtml4(String.valueOf(value)) };
			} else
				result = new String[] { StringEscapeUtils.escapeHtml4(String.valueOf(value)) };
			StringBuffer stringBuffer = new StringBuffer();
			for (int i = 0; i < result.length; i++) {
				stringBuffer.append(result[i]);
			}
			log.info("  paramter " + name + " value " + stringBuffer.toString());
			return result;
		}

		/**
		 * 对Post 请求内URL参数进行处理
		 * 
		 **/
		private void updateParameterMap(HttpServletRequest req) {
			String queryString = req.getQueryString();
			if (queryString != null && queryString.trim().length() > 0) {
				String[] params = queryString.split("&");
				for (int i = 0; i < params.length; i++) {
					int splitIndex = params[i].indexOf("=");
					if (splitIndex == -1) {
						continue;
					}
					String key = params[i].substring(0, splitIndex);
					if (this.bodyParams.containsKey(key)) {
						if (splitIndex < params[i].length()) {
							String value = params[i].substring(splitIndex + 1);
							String decodeValue = StringEscapeUtils.escapeHtml4(value);
							log.info("url paramter " + key + " value " + decodeValue);
							this.bodyParams.put(key, new String[] { decodeValue });
						}
					}
				}
			}
		}
	}

}
