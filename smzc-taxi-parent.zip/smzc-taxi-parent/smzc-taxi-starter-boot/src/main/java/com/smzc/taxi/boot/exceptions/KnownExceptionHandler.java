package com.smzc.taxi.boot.exceptions;

import org.hibernate.validator.internal.engine.path.NodeImpl;
import org.springframework.beans.ConversionNotSupportedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import com.smzc.taxi.boot.response.ExceptionEnums;
import com.smzc.taxi.boot.response.Response;
import lombok.extern.slf4j.Slf4j;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Path.Node;

/**
 * @author Administrator
 * @date 2018年5月10日 服务端500以内已知异常处理
 */
@RestController
@ControllerAdvice
@Slf4j
public class KnownExceptionHandler {

	@Autowired
	private MessageSource messageSource;

	@ExceptionHandler(value = ConstraintViolationException.class)
	public Response<Void> validateException(HttpServletRequest req, ConstraintViolationException e) throws Exception {
		List<String> msgList = new ArrayList<>();
		for (ConstraintViolation<?> constraintViolation : e.getConstraintViolations()) {
			Iterator<Node> iterator = constraintViolation.getPropertyPath().iterator();
			String filed = null;
			while (iterator.hasNext()) {
				NodeImpl node = (NodeImpl) iterator.next();
				filed = node.getName();
			}
			msgList.add(filed + constraintViolation.getMessage());
		}
		String messages = org.apache.commons.lang3.StringUtils.join(msgList.toArray(), "\r\n");
		log.error("path {},validate msg {}", req.getRequestURI(), messages);
		return Response.instance().message(messages).code(-1).build();
	}

	@ExceptionHandler(value = HttpMessageNotReadableException.class)
	public Response<Void> httpMessageNotReadableException(HttpServletRequest req, HttpMessageNotReadableException e)
			throws Exception {
		log.error(req.getRequestURI(), e);
		String msg = e.getMessage();
		return Response.instance().message(msg).code(ExceptionEnums.HttpMessageNotReadableException.errCode).build();
	}

	@ExceptionHandler(value = HttpMediaTypeNotSupportedException.class)
	public Response<Void> httpMediaTypeNotSupportedException(HttpServletRequest req,
			HttpMediaTypeNotSupportedException e) throws Exception {
		log.error(req.getRequestURI(), e);
		String msg = e.getMessage();
		return Response.instance().message(msg).code(ExceptionEnums.HttpMediaTypeNotSupportedException.errCode).build();
	}

	@ExceptionHandler(value = ConversionNotSupportedException.class)
	public Response<Void> conversionNotSupportedException(HttpServletRequest req, ConversionNotSupportedException e)
			throws Exception {
		log.error(req.getRequestURI(), e);
		String msg = e.getMessage();
		return Response.instance().message(msg).code(ExceptionEnums.ConversionNotSupportedException.errCode).build();
	}

	@ExceptionHandler(value = HttpMediaTypeNotAcceptableException.class)
	public Response<Void> httpMediaTypeNotAcceptableException(HttpServletRequest req,
			HttpMediaTypeNotAcceptableException e) throws Exception {
		log.error(req.getRequestURI(), e);
		String msg = e.getMessage();
		return Response.instance().message(msg).code(ExceptionEnums.HttpMediaTypeNotAcceptableException.errCode)
				.build();
	}

	@ExceptionHandler(value = MethodArgumentNotValidException.class)
	public Response<Void> methodArgumentNotValidException(HttpServletRequest req, MethodArgumentNotValidException e) {
		log.error(req.getRequestURI(), e);
		return Response.instance().message(e.getBindingResult().getAllErrors().get(0).getDefaultMessage()).code(-1)
				.build();
	}

	@ExceptionHandler(value = HttpRequestMethodNotSupportedException.class)
	public Response<Void> httpRequestMethodNotSupportedException(HttpServletRequest req,
			HttpRequestMethodNotSupportedException e) throws Exception {
		log.error(req.getRequestURI(), e);
		String msg = e.getMessage();
		return Response.instance().message(msg).code(ExceptionEnums.HttpRequestMethodNotSupportedException.errCode)
				.build();
	}

	@ExceptionHandler(value = MissingServletRequestParameterException.class)
	public Response<Void> servletRequestParameterException(HttpServletRequest req,
			MissingServletRequestParameterException e) throws Exception {
		log.error(req.getRequestURI(), e);
		String msg = e.getMessage();
		return Response.instance().message(msg).code(ExceptionEnums.MissingServletRequestParameterException.errCode)
				.build();
	}

	@ExceptionHandler(value = IllegalArgumentException.class)
	public Response<Void> IllegalArgumentException(HttpServletRequest req, IllegalArgumentException e)
			throws Exception {
		log.error(req.getRequestURI(), e);
		String msg = e.getMessage();
		return Response.instance().message(msg).code(ExceptionEnums.IllegalArgumentException.errCode).build();
	}

	@ExceptionHandler(value = IllegalStateException.class)
	public Response<Void> IllegalStateException(HttpServletRequest req, IllegalStateException e) throws Exception {
		log.error(req.getRequestURI(), e);
		String msg = e.getMessage();
		return Response.instance().message(msg).code(ExceptionEnums.IllegalStateException.errCode).build();
	}

	@ExceptionHandler(value = BindException.class)
	public Response<Void> bindException(HttpServletRequest req, BindException e) throws Exception {
		log.error(req.getRequestURI(), e);
		FieldError fieldError = e.getBindingResult().getFieldErrors().get(0);
		String fieldName;
		try {
			fieldName = messageSource.getMessage(fieldError.getField(), null, LocaleContextHolder.getLocale());
		} catch (NoSuchMessageException me) {
			try {
				fieldName = messageSource.getMessage(
						e.getTarget().getClass().getSimpleName().toLowerCase() + "." + fieldError.getField(), null,
						LocaleContextHolder.getLocale());
			} catch (NoSuchMessageException me1) {
				fieldName = fieldError.getField();
			}
		}
		return Response.instance().message(fieldName + fieldError.getDefaultMessage()).code(-1).build();
	}

	@ExceptionHandler(MaxUploadSizeExceededException.class)
	public Response<Void> MaxUploadSizeExceededException(HttpServletRequest req, MaxUploadSizeExceededException e)
			throws Exception {
		log.error(req.getRequestURI(), e);
		return Response.instance().message(ExceptionEnums.MaxUploadSizeExceededException.errMsg)
				.code(ExceptionEnums.MaxUploadSizeExceededException.errCode).build();
	}

	@ExceptionHandler(Exception.class)
	public Response<Void> finalException(HttpServletRequest req, Exception e) throws Exception {
		log.error(req.getRequestURI(), e);
		String errorMsg = null;
		if (e != null && e.getMessage() != null) {
			String[] str = e.getMessage().split(":");
			if (str.length == 2)
				errorMsg = str[1];
			else
				errorMsg = ExceptionEnums.SystemDealException.getErrMsg();
		}
		return Response.instance().message(ExceptionEnums.SystemDealException.errMsg).code(-1).build();
	}

}
