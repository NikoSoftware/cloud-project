package com.smzc.taxi.boot.operationlog;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.smzc.taxi.boot.operationlog.aspect.OperationLogAspect;
import com.smzc.taxi.boot.operationlog.properties.OperationLogProperties;


@Configuration
@EnableConfigurationProperties(OperationLogProperties.class)
@ConditionalOnProperty(prefix="log",name = "enable", havingValue = "true")
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class OperationLogAutoConfiguration {
	
	@Bean
	@ConditionalOnMissingBean(OperationLogAspect.class)
	public OperationLogAspect logAspect() {
		return new OperationLogAspect();
	}
	
	
	
	
	
}
