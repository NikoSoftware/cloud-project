package com.smzc.taxi.boot.sms.properties;

import lombok.Data;

import java.util.Map;
import java.util.Set;

@Data
public class SmsParams {
	
	private Map<String, Object> params;
	
	private String mobileNo;

	/**阿里云对应templateCode**/
	private String templateCode;

}
