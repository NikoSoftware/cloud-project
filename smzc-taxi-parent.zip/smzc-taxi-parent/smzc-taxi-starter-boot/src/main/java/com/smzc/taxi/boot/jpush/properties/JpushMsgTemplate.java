package com.smzc.taxi.boot.jpush.properties;

import lombok.Data;

@Data
public class JpushMsgTemplate {
	
	private String messageTitle;
	
	private String messageContent;
	
	private String notificationTitle;

}
