package com.smzc.taxi.boot.sms.enums;

public enum SmsTypeEnum {

    NOTICE("csms18090135", "通知"),
    VERIFICATION_CODE("csms18090136", "验证");

    private String signatureChannel;
    private String name;

    SmsTypeEnum(String signatureChannel, String name) {
        this.signatureChannel = signatureChannel;
        this.name = name;
    }

    public String getSignatureChannel() {
        return signatureChannel;
    }

    public String getName() {
        return name;
    }
}
