package com.smzc.taxi.boot.mail;

import java.util.Map;
import java.util.Properties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.mail.MailProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Configuration
@ConditionalOnClass(JavaMailSenderImpl.class)
@ConditionalOnProperty(value = "spring.mail.host")
@EnableConfigurationProperties(MailProperties.class)
public class TaxiMailSenderConfiguration {
	
	@Autowired
	private  MailProperties mailProperties;
	
	
	@Bean
	@ConditionalOnMissingBean(JavaMailSenderImpl.class)
	public JavaMailSenderImpl mailSender() {
		JavaMailSenderImpl sender = new JavaMailSenderImpl();
		applyProperties(sender);
		return sender;
	}

	private void applyProperties(JavaMailSenderImpl sender) {
		sender.setHost(this.mailProperties.getHost());
		if (this.mailProperties.getPort() != null) {
			sender.setPort(this.mailProperties.getPort());
		}
		sender.setUsername(this.mailProperties.getUsername());
		sender.setPassword(this.mailProperties.getPassword());
		sender.setProtocol(this.mailProperties.getProtocol());
		if (this.mailProperties.getDefaultEncoding() != null) {
			sender.setDefaultEncoding(this.mailProperties.getDefaultEncoding().name());
		}
		if (!this.mailProperties.getProperties().isEmpty()) {
			sender.setJavaMailProperties(asProperties(this.mailProperties.getProperties()));
		}
	}

	private Properties asProperties(Map<String, String> source) {
		Properties properties = new Properties();
		properties.putAll(source);
		return properties;
	}
	
	@Bean
	@ConditionalOnMissingBean(SendMailTemplate.class)
	public SendMailTemplate sendMailTemplate(@Autowired JavaMailSender javaMailSender ) {
		return new SendMailTemplate(javaMailSender);
	}
}
