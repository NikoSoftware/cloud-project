package com.smzc.taxi.boot.redis;

import com.alibaba.fastjson.support.spring.GenericFastJsonRedisSerializer;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.time.Duration;
import java.util.Objects;


@Configuration
@ConditionalOnProperty(value = "spring.redis.enabled",matchIfMissing = true)
@ConditionalOnClass({ RedisTemplate.class })
@EnableCaching
@Slf4j
public class RedisAutoConfiguration extends CachingConfigurerSupport {

	@Bean
	@ConditionalOnMissingBean(RedisTemplate.class)
	public RedisTemplate<String, Object> redisTemplate(@Autowired RedisConnectionFactory redisConnectionFactory,
			@Autowired RedisSerializer<Object> redisSerializer)
			throws UnknownHostException {
		RedisTemplate<String, Object> template = new RedisTemplate<String, Object>();
		template.setConnectionFactory(redisConnectionFactory);
		template.setHashValueSerializer(redisSerializer);
		template.setValueSerializer(redisSerializer);
		StringRedisSerializer stringRedisSerializer = new StringRedisSerializer(Charset.forName("UTF-8"));
		template.setHashKeySerializer(stringRedisSerializer);
		template.setKeySerializer(stringRedisSerializer);
		log.info("redisTemplate init success");
		return template;
	}

	 @Bean
	 @ConditionalOnMissingBean(value = RedisSerializer.class)
     public RedisSerializer<Object> redisSerializer() {
         return new GenericFastJsonRedisSerializer();
     }

	@Bean
	@ConditionalOnMissingBean(value = CacheManager.class)
	public CacheManager cacheManager(@Autowired RedisConnectionFactory redisConnectionFactory) {
		RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig(); 
		config = config.entryTtl(Duration.ofHours(1)) // 设置缓存的默认过期时间
				.disableCachingNullValues(); // 不缓存空值

		RedisCacheManager cacheManager = RedisCacheManager.builder(redisConnectionFactory) // 使用自定义的缓存配置初始化一个cacheManager
				/*	.initialCacheNames(cacheNames) // 注意这两句的调用顺序，一定要先调用该方法设置初始化的缓存名，再初始化相关的配置
					.withInitialCacheConfigurations(configMap).build();*/
				.build();
		return cacheManager;

	}
	

	@Bean
	public KeyGenerator keyGenerator() {
		return new KeyGenerator() {
			@Override
			public Object generate(Object target, java.lang.reflect.Method method, Object... params) {
				StringBuilder sb = new StringBuilder();
				sb.append(target.getClass().getName());
				sb.append(method.getName());
				for (Object obj : params) {
					if (!Objects.isNull(obj)){
						sb.append(obj.toString());
					}
				}
				return sb.toString();
			}
		};
	}
	
	@Bean
	@ConditionalOnMissingBean(RedisLock.class)
	public RedisLock redisLockService(){
		return new RedisLock();
	}
	

}
