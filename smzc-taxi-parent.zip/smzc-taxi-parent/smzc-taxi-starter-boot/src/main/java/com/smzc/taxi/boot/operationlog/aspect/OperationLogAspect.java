package com.smzc.taxi.boot.operationlog.aspect;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;
import javassist.ClassClassPath;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.Modifier;
import javassist.bytecode.CodeAttribute;
import javassist.bytecode.LocalVariableAttribute;
import javassist.bytecode.MethodInfo;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Aspect
@Order(-1)
public class OperationLogAspect {

	@Pointcut("@annotation(com.smzc.taxi.boot.operationlog.annotation.OperationLog)")
	public void pointCut() {

	}

	/**
	 * 在目标方法正常执行通过之后执行的通知
	 */
	@org.aspectj.lang.annotation.AfterReturning(value = "pointCut()")
	public void AfterReturning(JoinPoint joinPoint) {

		String classType = joinPoint.getTarget().getClass().getName();
		Class<?> clazz;
		try {
			clazz = Class.forName(classType);
			String clazzName = clazz.getName();
			Object[] args = joinPoint.getArgs(); //获取方法参数值
			String methodName = joinPoint.getSignature().getName(); //获取方法名称   
			Map<String, Object> nameAndValue = getFieldsName(clazz, clazzName, methodName, args);

			boolean flag = false;
			if (nameAndValue != null && nameAndValue.size() > 0) {
				for (Map.Entry<String, Object> entry : nameAndValue.entrySet()) {
					if (entry.getValue() instanceof String) {
						flag = true;
						break;
					}
				}
				StringBuffer sb = new StringBuffer();
				if (flag) {
					sb.append(JSONObject.toJSONString(nameAndValue)).append(",");
				} else {
					if (args != null) {
						for (Object object : args) {
							if (object != null) {
								if (object instanceof MultipartFile || object instanceof ServletRequest
										|| object instanceof ServletResponse) {
									continue;
								}
								sb.append(JSONObject.toJSONString(object)).append(",");
							}
						}
					}
				}
				
				log.info("[{}] 的输入参数[{}]",clazz,sb.toString());
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * 在目标方法抛出异常
	 */
	@AfterThrowing(value = "pointCut()", throwing = "error")
	public void readAfterThrowing(JoinPoint joinPoint, Exception error) {
		
		
	}

	private Map<String, Object> getFieldsName(Class<?> clazz, String clazzName, String methodName, Object[] args)
			throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		ClassPool pool = ClassPool.getDefault();
		ClassClassPath classPath = new ClassClassPath(clazz);
		pool.insertClassPath(classPath);
		CtClass cc = pool.get(clazzName);
		CtMethod cm = cc.getDeclaredMethod(methodName);
		MethodInfo methodInfo = cm.getMethodInfo();
		CodeAttribute codeAttribute = methodInfo.getCodeAttribute();
		LocalVariableAttribute attr = (LocalVariableAttribute) codeAttribute.getAttribute(LocalVariableAttribute.tag);
		if (attr == null) {

		}
		int pos = Modifier.isStatic(cm.getModifiers()) ? 0 : 1;
		for (int i = 0; i < cm.getParameterTypes().length; i++) {
			map.put(attr.variableName(i + pos), args[i]);
		}
		return map;
	}

}
