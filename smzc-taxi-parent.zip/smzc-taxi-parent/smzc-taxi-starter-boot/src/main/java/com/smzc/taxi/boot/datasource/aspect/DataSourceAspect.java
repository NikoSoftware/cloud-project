package com.smzc.taxi.boot.datasource.aspect;

import java.lang.reflect.Method;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;

import com.smzc.taxi.boot.datasource.annotation.RouterDataSource;
import com.smzc.taxi.boot.datasource.context.DataSourceContext;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Order(0)
@Aspect
public class DataSourceAspect {

	@Pointcut("@annotation(com.smzc.taxi.boot.datasource.annotation.RouterDataSource)")
	public void dataSourcePointCut() {

	}
	
	@Before("dataSourcePointCut()")
	public void before(JoinPoint joinPoint) {
		MethodSignature signature = (MethodSignature) joinPoint.getSignature();
		Method method = signature.getMethod();
		RouterDataSource routerDataSource = method.getAnnotation(RouterDataSource.class);
		DataSourceContext.setCurrentDataSource(routerDataSource.value());
		log.info("the current thread  datasource [{}]", routerDataSource.value());
	}

	@Around("dataSourcePointCut()")
	public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
		try {
			return joinPoint.proceed();
		} finally {
			DataSourceContext.removeDataSource();
			log.info("remove current thread  datasource ");
		}
	}

}
