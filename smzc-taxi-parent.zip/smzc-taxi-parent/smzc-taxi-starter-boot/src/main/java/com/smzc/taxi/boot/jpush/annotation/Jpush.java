package com.smzc.taxi.boot.jpush.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.smzc.taxi.boot.jpush.enums.MessageType;
import com.smzc.taxi.boot.jpush.enums.Platform;
import com.smzc.taxi.boot.jpush.enums.PushMode;

@Target({ ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Jpush {
	String value();   /**模板Id**/
	
	Platform platform() default Platform.ALL; /**推送平台**/
	
	PushMode pushMode() default PushMode.SINGLE; /**默认单条**/
	
	MessageType messageType() default MessageType.MESSAGE;   /***默认消息类型**/
}
