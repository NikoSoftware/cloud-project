package com.smzc.taxi.boot.sms;

import com.smzc.taxi.boot.sms.enums.SmsTypeEnum;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSONObject;
import com.smzc.taxi.boot.sms.context.SmsContext;
import com.smzc.taxi.boot.sms.properties.SmsParams;
import com.smzc.taxi.boot.sms.properties.SmsProperties;
import com.smzc.taxi.boot.sms.properties.SmsResult;
import com.taobao.api.ApiException;
import com.taobao.api.AutoRetryTaobaoClient;
import com.taobao.api.BatchTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.request.AlibabaAliqinFcSmsNumSendRequest;
import com.taobao.api.response.AlibabaAliqinFcSmsNumSendResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SmsTemplate implements InitializingBean,DisposableBean, ISmsTemplate {

	private SmsProperties smsProperties;

	private TaobaoClient taobaoClient;
	
	private TaobaoClient batchClient;

	public SmsTemplate(SmsProperties smsProperites) {
		this.smsProperties = smsProperites;
		this.taobaoClient = new AutoRetryTaobaoClient(smsProperites.getHost(), smsProperites.getAppKey(),smsProperites.getAppSecret()); //发送单条短信客户端
		this.batchClient =  new BatchTaobaoClient(smsProperites.getHost(), smsProperites.getAppKey(), smsProperites.getAppSecret());  //批量发送短信客户端

	}
	
	
	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(smsProperties.getAppKey(), "appkey is null ");
		Assert.notNull(smsProperties.getHost(), "sms host is null ");
		Assert.notNull(smsProperties.getAppSecret(), "sms secret is null ");
		Assert.notNull(smsProperties.getSignName(), "sms signName is null ");
		log.info("sms init success,host [{}],singname [{}]",smsProperties.getHost(),smsProperties.getSignName());		
	}

	private SmsResult doSmsSend(SmsParams smsParams) {
		AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest();
		req.setSmsType("normal");
		req.setSmsFreeSignName(smsProperties.getSignName());
		req.setSmsParamString(new JSONObject().fluentPutAll(smsParams.getParams()).toJSONString());
		req.setRecNum(smsParams.getMobileNo());
		req.setSmsTemplateCode(smsParams.getTemplateCode());
		AlibabaAliqinFcSmsNumSendResponse rsp = null;
		SmsResult result = null;
		try {
			rsp = taobaoClient.execute(req);
			if (rsp != null) {
				result = new SmsResult(rsp.isSuccess(), rsp.getErrorCode(), rsp.getSubCode(), rsp.getSubMsg());
				log.info("发送给【" + smsParams.getMobileNo() + "】的短信，发送结果：" + rsp.getBody());
			} else {
				result = new SmsResult(false, "-1", "-1", "没有接收到响应");
				log.info("发送给【" + smsParams.getMobileNo() + "】的短信，发送结果：没有接收到响应");
			}
		} catch (ApiException e) {
			log.error(e.getMessage(), e);
			result = new SmsResult(false, "-2", "-2", "调用短信接口异常:[" + e.getErrCode() + "]" + e.getErrMsg());
		}
		return result;
	}
	
	
	/**
	 * 批量发送
	 * @param mobiles 批量发送的手机号,用逗号分隔
	 * @param templateCode 短信模板编号
	 * @param params 短信参数
	 * @return
	 */
	private  SmsResult sendBatch(SmsParams smsParams) {
		AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest();
		req.setSmsType("normal");
		req.setSmsFreeSignName(smsProperties.getSignName());
		req.setSmsParamString(new JSONObject().fluentPutAll(smsParams.getParams()).toJSONString());
		req.setRecNum(smsParams.getMobileNo());
		req.setSmsTemplateCode(smsParams.getTemplateCode());
		AlibabaAliqinFcSmsNumSendResponse rsp = null;
		SmsResult result = null;
		try {
			rsp = batchClient.execute(req);
			if(rsp != null) {
				result = new SmsResult(rsp.isSuccess(), rsp.getErrorCode(), rsp.getSubCode(), rsp.getSubMsg());
			} else {
				result = new SmsResult(false, "-1", "-1", "没有接收到响应");
			}
		} catch (ApiException e) {
		    log.error(e.getMessage(),e);
			result = new SmsResult(false, "-2", "-2", "调用短信接口异常");
		}
		return result;
	}
	

	public SmsResult sendSms(SmsParams smsParams) {
		checkParam(smsParams);
		return doSmsSend(smsParams);
	}
	
	

	private void checkParam(SmsParams smsParams) {
		Assert.notNull(smsParams.getMobileNo(), "短信接收人不允许为空");
		Assert.notNull(smsParams.getTemplateCode(), "阿里云短信模板code不允许为空");
		Assert.notNull(smsParams.getParams(), "短信内容不允许为空");
	}

	@Override
	public void destroy() throws Exception {
		SmsContext.setSmsContext(null);
	}


	@Override
	public SmsResult send(SmsTypeEnum smsType, SmsParams smsParams) {
		return sendSms(smsParams);
	}
}
