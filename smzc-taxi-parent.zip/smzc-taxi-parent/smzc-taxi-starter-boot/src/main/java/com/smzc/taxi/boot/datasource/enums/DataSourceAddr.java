package com.smzc.taxi.boot.datasource.enums;

public enum DataSourceAddr {
	
	MASTER,
	
	SLAVE

}
