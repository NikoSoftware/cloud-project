package com.smzc.taxi.boot.datasource.context;


import com.smzc.taxi.boot.datasource.enums.DataSourceAddr;

public class DataSourceContext {
	
	private static final ThreadLocal<DataSourceAddr> contextHolder = ThreadLocal.withInitial(() ->DataSourceAddr.MASTER );
	
    public static void setCurrentDataSource(DataSourceAddr dataSourceAddr) {
        contextHolder.set(dataSourceAddr);
    }
    
    public static DataSourceAddr getCurrentDataSource() {
        return (DataSourceAddr) contextHolder.get();
    }
    
    public static void removeDataSource() {
    	contextHolder.remove();
    }
}
