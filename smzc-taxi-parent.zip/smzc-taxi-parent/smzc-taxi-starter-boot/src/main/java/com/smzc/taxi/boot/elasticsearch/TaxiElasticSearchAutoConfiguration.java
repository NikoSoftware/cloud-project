package com.smzc.taxi.boot.elasticsearch;

import java.util.Properties;

import org.elasticsearch.client.transport.TransportClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.data.elasticsearch.ElasticsearchProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.client.TransportClientFactoryBean;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;

import lombok.extern.slf4j.Slf4j;

@Configuration
@ConditionalOnClass(ElasticsearchTemplate.class)
@ConditionalOnProperty(value = "spring.data.elasticsearch.cluster-nodes")
@EnableConfigurationProperties(ElasticsearchProperties.class)
@Slf4j
public class TaxiElasticSearchAutoConfiguration {

	static{
		System.setProperty("es.set.netty.runtime.available.processors", "false");
	}

	@Autowired
	private ElasticsearchProperties elasticsearchProperties;

	@Bean
	@ConditionalOnMissingBean(ElasticsearchTemplate.class)
	public ElasticsearchTemplate elasticsearchTemplate() {
		try {
			return new ElasticsearchTemplate(elasticsearchClient());
		} catch (Exception e) {
			log.error("elasticsearch init fail");
			e.printStackTrace();
		}
		return null;
	}

	@Bean
	@ConditionalOnMissingBean(TransportClient.class)
	public org.elasticsearch.client.transport.TransportClient elasticsearchClient() throws Exception {
		TransportClientFactoryBean factory = new TransportClientFactoryBean();
		factory.setClusterNodes(this.elasticsearchProperties.getClusterNodes());
		factory.setProperties(createProperties());
		factory.afterPropertiesSet();
		return factory.getObject();
	}

	private Properties createProperties() {
		Properties properties = new Properties();
		properties.put("cluster.name", this.elasticsearchProperties.getClusterName());
		properties.putAll(this.elasticsearchProperties.getProperties());
		return properties;
	}

}
