package com.smzc.taxi.boot.sms.context;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import com.smzc.taxi.boot.sms.properties.SmsParams;

public class SmsContext {
	
	public static ThreadLocal<WeakReference<SmsContext>> actionContext = ThreadLocal
			.withInitial(() -> new WeakReference<>(new SmsContext(new ArrayList<>())));

	private List<SmsParams> smsContext;

	private SmsContext(List<SmsParams> smsContext) {
		this.smsContext = smsContext;
	}

	public static void setSmsContext(WeakReference<SmsContext> jpushContext) {
		actionContext.set(jpushContext);
	}

	public static SmsContext getSmsContext() {
		if (actionContext.get() == null) {
			SmsContext smsContext = new SmsContext(new ArrayList<>());
			WeakReference<SmsContext> weakReference = new WeakReference<SmsContext>(smsContext);
			actionContext.set(weakReference);
			return weakReference.get();
		} else
			return actionContext.get().get();
	}

	public void put(SmsParams smsParams) {
		smsContext.add(smsParams);
	}

	public List<SmsParams> getSmsParams() {
		return smsContext;
	}

}
