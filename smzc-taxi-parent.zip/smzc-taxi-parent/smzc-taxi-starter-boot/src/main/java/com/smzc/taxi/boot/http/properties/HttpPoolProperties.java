package com.smzc.taxi.boot.http.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "http.pool")
@Data
public class HttpPoolProperties {
	/**单位为毫秒**/
	private static final int DEFAULT_MAX_TOTAL =100;
	
	private static final int DEAULT_MAX_PER_ROUTE = 20;
	
	private static final int DEAULT_CONNECT_TIMEOUT = 3000;
	
	private static final int  DEFAULT_CONNECTION_REQUEST_TIMEOUT = 1000;
	
	private static final int  DEFAULT_SOCKET_READ_TIMEOUT= 5000;
	
	private static final int  DEFAULT_VALIDATE_AFTER_INACTIVITY = 2000;
	
    // 连接池的最大连接数
    private int maxTotal = DEFAULT_MAX_TOTAL;
    
    // 设置单域名的最大并发数
    private int defaultMaxPerRoute = DEAULT_MAX_PER_ROUTE;
    
    // 客户端向服务端连接请求超时时间
    private int connectTimeout = DEAULT_CONNECT_TIMEOUT;
    
    //从连接池获取连接的timeout超时时间
    private int connectionRequestTimeout = DEFAULT_CONNECTION_REQUEST_TIMEOUT;
    
    //客户端从服务端读取数据超时时间
    private int socketReadTimeout = DEFAULT_SOCKET_READ_TIMEOUT ;
    
    //空闲永久连接检查间隔
    //官方推荐使用这个来检查永久链接的可用性，而不推荐每次请求的时候才去检查
    private int validateAfterInactivity = DEFAULT_VALIDATE_AFTER_INACTIVITY;
}
