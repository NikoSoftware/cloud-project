package com.smzc.taxi.boot.mail.properties;

import java.io.File;
import java.io.Serializable;
import java.util.Set;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class MailInfo implements Serializable {
	private static final long serialVersionUID = 4809799930900299684L;

	/**
	 * 邮件发送地址
	 */
	private String fromMail;
	
	/**
	 * 邮件接收地址
	 */
	private Set<String> toMails;
	
	/**
	 * 邮件抄送地址
	 */
	private Set<String> ccMails;
	
	/**
	 * 邮件主题
	 */
	private String subject;
	
	/**
	 * 邮件主题
	 */
	private String content;
	
	/**
	 * 附件
	 */
	private Set<File> files;

}
